**I'm submitting a ...**  (check one with "x")

[ ] bug report
[ ] feature request
[ ] support request

<!-- Please be clear when explaining what behavior is expected -->
**Steps to reproduce the bug:**


**Related code:**
```
    insert any relevant code here
```

**Important information:**
<!-- State important information if needed, such as OS version, hardware info, ionic info, etc. -->
