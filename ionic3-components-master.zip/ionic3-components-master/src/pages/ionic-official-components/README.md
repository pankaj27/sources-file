These samples can be found at [ionic official documentation](ionicframework.com/docs/v2) and take little to no styling(which is what makes them amazing).

The only difference is that here they are not hardcoded, so you can just get them and adapt to your needs.