## Slides

In this file there are a few slider options you can choose from, but you can make your own customisation following the Swiper API:

http://idangero.us/swiper/api/

http://idangero.us/swiper/demos/