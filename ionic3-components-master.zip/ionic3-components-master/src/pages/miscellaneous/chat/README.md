Important note: The chat styles are all credit to [Ross Martin](http://codepen.io/rossmartin), who designed a *really nice* concept of chat for ionic 1. 

You can check his implementation on [codepen](http://codepen.io/rossmartin/pen/XJmpQr).
