## Using Chart.js in your application

The content used here was a mix of [this tutorial](https://www.joshmorony.com/adding-responsive-charts-graphs-to-ionic-2-applications/) and [chart.js documentation](http://www.chartjs.org/docs/).

### Installing the module
`npm install chart.js --save`

### Importing
`import Chart from 'chart.js'` 

Special thanks to [Joshua Morony](https://github.com/joshuamorony) for always providing amazing material! 
