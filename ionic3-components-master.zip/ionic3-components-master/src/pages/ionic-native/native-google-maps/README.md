

ionic cordova plugin add cordova-plugin-googlemaps --variable API_KEY_FOR_ANDROID="AIzaSyBaTVlHDndpSgbdDnRsCy2xFJt2tB41NB0" --variable API_KEY_FOR_IOS="AIzaSyBaTVlHDndpSgbdDnRsCy2xFJt2tB41NB0" && npm install --save @ionic-native/google-maps