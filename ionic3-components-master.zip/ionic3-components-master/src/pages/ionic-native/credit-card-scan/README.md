Docs: https://ionicframework.com/docs/v2/native/cardio/

You have to install the plugin with:
```sh
$ ionic plugin add https://github.com/card-io/card.io-Cordova-Plugin --save
``` 