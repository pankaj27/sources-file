This example gives the option to get a picture from either a camera or picture gallery.

Docs: http://ionicframework.com/docs/v2/native/camera/

You have to install the plugin with:
```sh
$ ionic plugin add cordova-plugin-camera --save