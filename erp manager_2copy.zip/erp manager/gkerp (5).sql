-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2016 at 07:20 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;


--
-- Database: `gkerp`
--

-- --------------------------------------------------------

--
-- Table structure for table `distributer_list`
--

CREATE TABLE `distributer_list` (
  `id` int(11) NOT NULL,
  `dist_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phno` varchar(255) NOT NULL,
  `add1` varchar(255) NOT NULL,
  `add2` varchar(255) NOT NULL,
  `add3` varchar(255) NOT NULL,
  `add4` varchar(255) NOT NULL,
  `pin` int(11) NOT NULL,
  `area` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `depositamount` decimal(20,2) NOT NULL,
  `interes` decimal(10,2) NOT NULL,
  `contactperson` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `doe` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributer_list`
--

INSERT INTO `distributer_list` (`id`, `dist_id`, `name`, `email`, `phno`, `add1`, `add2`, `add3`, `add4`, `pin`, `area`, `state`, `depositamount`, `interes`, `contactperson`, `remarks`, `doe`, `status`) VALUES
(1, 'GK/20160927/1', 'PANKAJ', 'patrapankaj36@gmail.com', '9800743629', 'abcdef', 'abcdef', 'abcdef', 'abcdef', 721648, 'abcdesg', 'EQUIPMENT', '2500.00', '5.00', 'abcdef', '  sdsdsdsds\nsdsdsdsdsdsd\nsdsdsdsdsd', '20160927 03:40:26 PM', 0),
(2, 'GK/20160927/2', 'Bibadi', 'patrapankaj36@gmail.com', '9800743629', 'abcdef', 'abcdef', 'abcdef', 'abcdef', 721648, 'abcdesg', 'EQUIPMENT', '2500.00', '5.00', 'abcdef', '  sdsdsdsds\r\nsdsdsdsdsdsd\r\nsdsdsdsdsd', '20160927 03:40:26 PM', 0),
(3, 'GK/20160927/3', 'ADFDF', 'dsfdsf', '365241', 'dsfds', 'sdfdsf', 'sdfdsf', 'sdfsd', 123456789, 'dsfdsf', 'ASSAM', '365400.00', '6.25', 'asdasdsd', '  asdasd', '20160927 10:01:33 PM', 0),
(4, 'GK/20160930/4', 'SDFDS', 'dfs@gmail.com', '7878', 'dfg', 'dfgf', 'dfgd', 'dfgd', 12312, 'sdfd', 'Prop.', '0.00', '2131.00', '231', '  123212312', '20160930 02:21:17 PM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_master_vhc_div`
--

CREATE TABLE `item_master_vhc_div` (
  `id` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL,
  `modelName` varchar(255) NOT NULL,
  `modelCode` varchar(255) NOT NULL,
  `modelSL` varchar(255) NOT NULL,
  `batteryPower` varchar(255) NOT NULL,
  `batteryModel` varchar(255) NOT NULL,
  `classofmodel` varchar(255) NOT NULL,
  `varient` varchar(255) NOT NULL,
  `openQty` int(50) NOT NULL,
  `manfCost` decimal(20,2) NOT NULL,
  `distributerPriceEx` decimal(25,2) DEFAULT NULL,
  `distributerPriceIn` decimal(25,2) DEFAULT NULL,
  `distributertosubEx` decimal(25,2) DEFAULT NULL,
  `distributertosubIn` decimal(25,2) DEFAULT NULL,
  `subdistributertoretailEx` decimal(25,2) DEFAULT NULL,
  `subdistributertoretailIn` decimal(25,2) DEFAULT NULL,
  `servicePaid` varchar(255) NOT NULL,
  `servicefromdays` varchar(30) NOT NULL,
  `motorPower` varchar(255) NOT NULL,
  `seatCapacity` int(20) NOT NULL,
  `grossvhclwt` varchar(255) NOT NULL,
  `typeBody` varchar(255) NOT NULL,
  `fuelused` varchar(255) NOT NULL,
  `mfgYear` varchar(20) NOT NULL,
  `unloadnWt` varchar(255) NOT NULL,
  `octraino` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_master_vhc_div`
--

INSERT INTO `item_master_vhc_div` (`id`, `brandName`, `modelName`, `modelCode`, `modelSL`, `batteryPower`, `batteryModel`, `classofmodel`, `varient`, `openQty`, `manfCost`, `distributerPriceEx`, `distributerPriceIn`, `distributertosubEx`, `distributertosubIn`, `subdistributertoretailEx`, `subdistributertoretailIn`, `servicePaid`, `servicefromdays`, `motorPower`, `seatCapacity`, `grossvhclwt`, `typeBody`, `fuelused`, `mfgYear`, `unloadnWt`, `octraino`, `status`) VALUES
(11, 'item1', 'ddasf', 'ddasf', 'as', '11', '134324', '45435', '432435', 435, '345.00', '1212.00', '12312.00', '12312.00', '12312.00', '213.00', '12312.00', '12312', '2132', '2132', 12213, '123', 'ewew', '12312', '12312', '123', '1232', 0),
(10, 'item1', 'ddasf', 'asdas', 'as', '11', '134324', '45435', '432435', 435, '345.00', '1212.00', '12312.00', '12312.00', '12312.00', '213.00', '12312.00', '12312', '2132', '2132', 12213, '123', 'ewew', '12312', '12312', '123', '1232', 0),
(9, 'item1', 'sddf', 'sdfdsfsd', 'fdf', '121323', '12132', '12132', '123', 12312, '1212.00', '1234.00', '23324.00', '23234.00', '3123124.00', '1323.00', '3123.00', '2334', '23432', '23432', 324, '23432', '324', 'fuelused', '3234', '234324', '234342', 0),
(8, 'item1', 'ffdgf', 'gdhgfh', 'z zcx', '1234', 'xxcdd', 'd', 'fd', 1211, '212.00', '1212.00', '121.00', '121.00', '12.00', '121.00', '1212.00', '23232', '2323', '2323', 323, '323', 'dfdf2', 'fuelused', '2232', '23', '232', 0);

-- --------------------------------------------------------

--
-- Table structure for table `spareparts`
--

CREATE TABLE `spareparts` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `group1` varchar(255) NOT NULL,
  `partsno` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `mrp` decimal(11,2) NOT NULL,
  `vat` decimal(11,2) NOT NULL,
  `latestpurchaseprice` decimal(11,2) NOT NULL,
  `rackno` varchar(255) NOT NULL,
  `openqty` int(11) NOT NULL,
  `valu2` decimal(11,2) NOT NULL,
  `balance` decimal(11,2) NOT NULL,
  `moq` varchar(255) NOT NULL,
  `reordlevel` varchar(255) NOT NULL,
  `minstock` int(11) NOT NULL,
  `maxstock` int(11) NOT NULL,
  `salestax` decimal(11,2) NOT NULL,
  `surcharge` decimal(11,2) NOT NULL,
  `addsurcharge` decimal(11,2) NOT NULL,
  `application` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `doe` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `statename` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `statename`, `status`) VALUES
(9, 'Andaman and Nicobar Islands', 0),
(10, 'Andhra Pradesh', 0),
(11, 'Arunachal Pradesh', 0),
(12, 'Assam', 0),
(13, 'Bihar', 0),
(14, 'Chandigarh', 0),
(15, 'Chhattisgarh', 0),
(16, 'Dadra and Nagar Haveli', 0),
(17, 'Daman and Diu', 0),
(18, 'National Capital Territory of Delhi', 0),
(19, 'Goa', 0),
(20, 'Gujarat', 0),
(21, 'Haryana', 0),
(22, 'Himachal Pradesh', 0),
(23, 'Jammu and Kashmir', 0),
(24, 'Jharkhand', 0),
(25, 'Karnataka', 0),
(26, 'Kerala', 0),
(27, 'Lakshadweep', 0),
(28, 'Madhya Pradesh', 0),
(29, 'Maharashtra', 0),
(30, 'Manipur', 0),
(31, 'Meghalaya', 0),
(32, 'Mizoram', 0),
(33, 'Nagaland', 0),
(34, 'Odisha', 0),
(35, 'Puducherry', 0),
(36, 'Punjab', 0),
(37, 'Rajasthan', 0),
(38, 'Sikkim', 0),
(39, 'Tamil Nadu', 0),
(40, 'Telangana', 0),
(41, 'Tripura', 0),
(42, 'Uttar Pradesh', 0),
(43, 'Uttarakhand', 0),
(44, 'West Bengal', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_name`, `password`, `status`) VALUES
(1, 'admin', 'admin', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `distributer_list`
--
ALTER TABLE `distributer_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item_master_vhc_div`
--
ALTER TABLE `item_master_vhc_div`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `spareparts`
--
ALTER TABLE `spareparts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `distributer_list`
--
ALTER TABLE `distributer_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `item_master_vhc_div`
--
ALTER TABLE `item_master_vhc_div`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `spareparts`
--
ALTER TABLE `spareparts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
