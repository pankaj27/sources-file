<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_Controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->library('fpdf_gen');
		//$this->load->library('fpdf_geninvoice');
		
		$this->load->library('numbertowords');
		$this->load->model('AccountManage_model');
		
		$this->load->model('Sales_Model');
	}
	public function sales_terget()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['sales_terget']=$this->Sales_Model->fetchTerget();
		$data['terget']=$this->Sales_Model->fetchTerget1();
		$this->load->view("Sales/view_sales_terget",$data);
	}
	public function saveinddata()
	{
		
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$month=$this->input->post("month");
		$month1=explode(" ",$month);
		$yrcode=$month1[1];
		$mnthcode=$month1[0];
		$terget=$this->input->post("terget");
		$salesmanid=$this->input->post("salesmanid");
		$mintarget=$this->input->post("mintarget");
		$data_array=array(
				"yearcode"=>$yrcode,
				"monthcode"=>$mnthcode,
				"terget"=>$terget,
				"mintarget"=>$mintarget,
				"salesmanid"=>$salesmanid
		);
		//print_r($data_array);
		$checkdataexist=$this->Sales_Model->getcheckexist($salesmanid,$mnthcode,$yrcode,$terget);
		if(empty($checkdataexist))
		{
				$res=$this->Sales_Model->saveinddata($data_array);
		}else
		{
				$res2=$this->Sales_Model->updateinddata($data_array,$salesmanid);
		}
		
		echo "Data Upadated Succesfully";
		

		
		/*
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$month=$this->input->post("month");
		$month1=explode("-",$month);
		$yrcode=$month1[1];
		$mnthcode=$month1[0];
		$terget=$this->input->post("terget");
		$salesmanid=$this->input->post("salesmanid");
		$data_array=array(
				//"salesmanid"=>$sid,
				"yearcode"=>$yrcode,
				"monthcode"=>$mnthcode,
				"terget"=>$terget,
				"salesmanid"=>$salesmanid
		);
		$this->Sales_Model->saveinddata($data_array);
		*/
	}
	public function savealldata()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$totrow=$this->input->post('totalrow');
		for($i=1;$i<intval($totrow);$i++)
		{
			$month=$this->input->post("month_$i");
			 $month1=explode(" ",$month);
			 
			 print_r($month1);
			$yrcode=$month1[1];
			$mnthcode=$month1[0];
			$terget=$this->input->post("terget_$i");
			$salesmanid=$this->input->post("salesmanid_$i");
			
			
			$data_array=array(
				"yearcode"=>$yrcode,
				"monthcode"=>$mnthcode,
				"terget"=>$terget,
				"salesmanid"=>$salesmanid
				);
				print_r($data_array);
		$checkdataexist=$this->Sales_Model->getcheckexist($salesmanid,$mnthcode,$yrcode);
		if(empty($checkdataexist))
			{
				$this->Sales_Model->saveinddata($data_array,$salesmanid);
			}else
			{
				$this->Sales_Model->updateinddata($data_array,$salesmanid);
			}
			
		}
		//redirect('Sales_Controller/sales_terget','refresh');
		
	}
	public function vieworder()
	  {
	  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$user=$this->session->userdata('uname');
		$data['title']="view Order List";
		$data['getbookinglist']=$this->AccountManage_model->getallbookinglist();
			$this->load->view('Sales/bookinglist',$data);
	  }
	public function print_invoice($id)
	 {
	 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$bkid=$id;
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo1.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		for($ty=0;$ty<4;$ty++){
		//$this->fpdf->addpage();
			
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image("$path",20,1,280,250,'png');
		$this->fpdf->SetFont('Times','I',12);
		if($ty==0){
			$this->fpdf->text(235,9,"( Original for Buyer's Copy )");
		}
		if($ty==1){
			$this->fpdf->text(230,9,"( Duplicate for Transporter Copy )");
		}
		if($ty==2){
			$this->fpdf->text(230,9,"( Triplicate for ASSESSCE Copy )");
		}
		if($ty==3){
			$this->fpdf->text(240,9,"( Extra Copy )");
		}
		$this->fpdf->SetFont('Arial','',9);
		
		$this->fpdf->SetMargins(5.5, 2.5 );
		$this->fpdf->line(6,5,290.5,5);
		$this->fpdf->line(6,5,6,40);
		$this->fpdf->line(290.5,5,290.5,40);
		$this->fpdf->line(6,40,290.5,40);
		if($ty==2 || $ty==1 || $ty==3){
			   $this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()+3,45,25,'png');
		}else
			{
				$this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()-4,45,25,'png');
			}
		
		$this->fpdf->SetFont('Times','B',20);
		$this->fpdf->text(125,39,"GK RICKSHOW");
		$this->fpdf->addSociete("Phone:(033)-64517771","Email: accounts@gkrickshow.com\n" ."CST/VAT No: 123456\n"."TIN No: 19731597605\n" ."Excise No:123456\n"."website:http://www.gkrickshaw.com" );
		$this->fpdf->addSocietecopy("Office Address","30(33/1) N.T Road ,\n"."Padmabati Colony, \n" ."Baidyabati, Hooghly, \n"."West Bengal-712222, \n"."India" );
		$this->fpdf->SetFont('Arial','B',11);
		//$this->fpdf->text(115,44,"TAX-INVOICE CUM-EXCISE INVOICE");
		$this->fpdf->text(120,44,"TAX-CUM-EXCISE-INVOICE");
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(95,48,"( $invoicetxt ) ");
		$this->fpdf->line(6,38,6,50);
		$this->fpdf->line(290.5,38,290.5,50);
		//$this->fpdf->line(203.5,5,203.5,30);
		$this->fpdf->line(6,50,290.5,50);
		$this->fpdf->line(6,50,6,98);
		$this->fpdf->line(100.5,50,100.5,98);
		$this->fpdf->line(198.5,50,198.5,98);
		$this->fpdf->line(6,98,290.5,98);
		$this->fpdf->line(290.5,50,290.5,98);
		//$this->fpdf->line(6,85,203.5,85);
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(7,54,"Consignee");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		$this->fpdf->consignee("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(7,82,"VAT TIN: 18440216892             CST: 18440216892");
		$this->fpdf->line(6,90,198.5,90);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(7,94,"TF/HSN Classification: 87039010");
		$this->fpdf->line(50,90,198.5,90);
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(105,54,"Buyer(if other than consignee)");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		$this->fpdf->buyeraddress("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(105,82,"VAT TIN: 18440216892             CST: 18440216892");
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(105,94,"Product: E-Rickshaw");
		$this->fpdf->compinfo("Invoice No                    : GKR/16-17/0001","Range                           : RANGE-1/480701\n"."Division                         : SINGUR/4807 \n" ."Commissionerate          : KOL-IV/48 \n"."PAN/Income Tax No     : AAMFG8605k \n"."Date of issue of Invoice : 20-Dec-2016 3:17:46 AM\n"."Date & Time of Removal : 21-Dec-2016 15:17:46 PM\n" );
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text(201,82,"Order ID: GKSLSBK00017  ");
		$this->fpdf->text(201,86,"Order Date: 17-12-2016   ");
		$this->fpdf->SetFont('Arial','B',9);
		//$this->fpdf->text(201,90,"Product: E-Rickshaw  ");
		//$this->fpdf->text(201,94," ");
		
		//$this->fpdf->row(array(""));
		$this->fpdf->ln(20);
		 $this->fpdf->SetFont('Arial','B',9);
		  $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R"));
	    $this->fpdf->SetWidths(array(11,30,40,25.5,83,30,20,10,35));
		 $this->fpdf->Rowheader(array("Sno","Particulars","Chasis No","Motor No","Battery No","Charger","Rate","Qty","Amount"));
		 $this->fpdf->SetFont('Times','',10);
	    $gtx=$this->fpdf->getX();
		$gty=$this->fpdf->getY()+8;
		$net=0;$net2=0;$netf=0;
		$chassisno="M6REP3085Q16B0001";
		$motorno="123456789";
		$battery="EXIDE1234,EXIDE3456,EXIDE2546,EXIDE4596";
		$charger="54789325698145";
		$lno=0;
		for($k=1;$k<11;$k++)
		{
			$amnt=42041.00;
			 $netf=$netf+$amnt;
		}
		$netf=number_format($netf,2);
		$pg=1;
		for($k=1;$k<11;$k++)
		{
			$pg++;
			$amnt=42041.00;
			$lno++;
			$this->fpdf->SetFont('Times','',10);
		    $this->fpdf->SetWidths(array(11,30,40,25.5,83,30,20,10,35));
		    $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R","R"));
		    $this->fpdf->Rowheader(array("$k","ER-India(G7)","$chassisno","$motorno","$battery","$charger","42,000.00","1","42,000.00"));
		    $sd=$this->fpdf->getY();
			 $net2=$net2+$amnt;
			$net3=number_format($net2,2);
			if($pg>4){
				$pg=0;
				$this->fpdf->SetWidths(array(239.5,10,35));
		        $this->fpdf->SetAligns(array("R","R","R"));
		        $this->fpdf->Rowheader(array("Page Total","$lno","$net3"));
				$this->fpdf->SetWidths(array(239.5,45));
		        $this->fpdf->SetAligns(array("R","R"));
		        $this->fpdf->Rowheader(array("Net Assesable Value","$netf"));
				$net2=0;
				$lno=0;
				 $gtx=$this->fpdf->getX();
		         $gety=$this->fpdf->getY();
//page footer=================================================
				//$this->fpdf->ln(2);
				/*$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
				$this->fpdf->line($gtx+.5,$gety,($gtx),($gety+31));
				$this->fpdf->line($gtx+285,$gety,($gtx+285),($gety+31));
				$this->fpdf->line($gtx+70,$gety,($gtx+70),($gety+31));
				$this->fpdf->SetFont('Times','',9);
				$this->fpdf->text($gtx+72,$gety+3,"1. Certified that the particulars given above are true and correct and that amount");
				$this->fpdf->text($gtx+72,$gety+6,"   indicated above represents the price actually changed from consignee and in ");
				$this->fpdf->text($gtx+72,$gety+9,"   according with sec 4 of the Central Excise Act 1944 and that there is no additi-");
				$this->fpdf->text($gtx+72,$gety+12,"   onal flow of consideration directly/or indirectly  from the buyer.");
				$this->fpdf->text($gtx+72,$gety+17,"2. Excise Duty payable under rule 8 of C Excise Rules 2002");
				$this->fpdf->line($gtx+180,$gety,($gtx+180),($gety+31));
				$this->fpdf->text($gtx+190,$gety+30,"Prepared by");
				$this->fpdf->text($gtx+230,$gety+30,"Checked by");
				$this->fpdf->text($gtx+260,$gety+30," Authorized Sign");
				
		//$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
		//$this->fpdf->line($gtx+.5,$gety,$gtx,($gety+30));
		//$this->fpdf->line(($gtx+284.5),$gety,($gtx+284.5),($gety+30));
		//$this->fpdf->line($gtx+.5,($gety+30),($gtx+149.5),($gety+30));
		//$this->fpdf->line(($gtx+149.5),$gety,284.5,$gety);
		//$this->fpdf->line(($gtx+149.5),($gety+30),291,($gety+30));
		//$this->fpdf->line(($gtx+149.5),($gety),($gtx+149.5),($gety+30));
		//$this->fpdf->line(285.5,($gety),285.5,($gety+30));
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->text(($gtx+244),($gety+4),"for G.K Rickshaw Pvt Ltd.");
		$this->fpdf->Image($img2, $this->fpdf->GetX()+260, $this->fpdf->GetY()+4,25,25,'png');
		//$gety=$gety+31;
		 $this->fpdf->SetFont('Times','',8);
		$this->fpdf->cell(30,5,"Serial No. in PLA/RG-23",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Manner Of Transport",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Despatched through",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"PR/GC Node No/L.R NO",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Vehicle No",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Date",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		
		//$this->fpdf->SetWidths(array(100));
		//$this->fpdf->axiontext("Phone:(033)-64517771","Email: accounts@gkrickshow.com\n" ."CST/VAT No: 123456\n"."TIN No: 19731597605\n" ."Excise No:123456\n" );
		//$this->fpdf->row3(array("$battery"));
		
		//$gtx=$this->fpdf->getX();
		//$gety=$this->fpdf->getY();
		/*$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',9);
		$this->fpdf->Multicell(285,5,"$declt",1);
		//$this->fpdf->ln(1);
		/*$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->Multicell(285,5,"NOTE: SUBJECT TO SERAMPORE JURISDICTION",1,'C');
		$this->fpdf->ln(2);
		$lnx=$this->fpdf->getX();
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',14);
		$this->fpdf->text($lnx+120,$lny+5,'"Your Green Partner"');*/
		//$this->fpdf->line($lnx,$lny,$lnx+285,$lny);
		//$this-
		//$this->fpdf->line($lnx,$lny,$lnx,$lny+10);
		//$this->fpdf->line($lnx,$lny+10,$lnx+285,$lny+10);
		//$lnx=$this->fpdf->getX();
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',9);
		$this->fpdf->text(270,$lny+15,"To be Contd...");
				 $this->fpdf->text(270,$lny+18,'Page No '.$this->fpdf->PageNo().' of {nb}');
	//end of page footer===========================================================================			
				$this->fpdf->addpage();
//##########################################################################################################################
//  start Page header
//##################################################################################################################
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Times','I',12);
		if($ty==0){
			$this->fpdf->text(235,9,"( Original for Buyer's Copy )");
		}
		if($ty==1){
			$this->fpdf->text(230,9,"( Duplicate for Transporter Copy )");
		}
		if($ty==2){
			$this->fpdf->text(230,9,"( Triplicate for ASSESSCE Copy )");
		}
		if($ty==3){
			$this->fpdf->text(240,9,"( Extra Copy )");
		}
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetMargins(5.5, 2.5 );
		$this->fpdf->line(6,5,290.5,5);
		$this->fpdf->line(6,5,6,40);
		$this->fpdf->line(290.5,5,290.5,40);
		$this->fpdf->line(6,40,290.5,40);
		//if($ty==2 || $ty==1){
			  // $this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY(),33,33,'png');
	//	}else
			//{
				$this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()+4,45,25,'png');
			//}
		
		$this->fpdf->SetFont('Times','B',20);
		$this->fpdf->text(125,39,"GK RICKSHOW");
		$this->fpdf->addSociete("Phone:(033)-64517771","Email: accounts@gkrickshow.com\n" ."CST/VAT No: 123456\n"."TIN No: 19731597605\n" ."Excise No:123456\n"."website:http://www.gkrickshaw.com" );
		$this->fpdf->addSocietecopy("Office Address","30(33/1) N.T Road ,\n"."Padmabati Colony, \n" ."Baidyabati, Hooghly, \n"."West Bengal-712222, \n"."India" );
		$this->fpdf->SetFont('Arial','B',11);
		//$this->fpdf->text(115,44,"TAX-INVOICE CUM-EXCISE INVOICE");
		$this->fpdf->text(120,44,"TAX-CUM-EXCISE-INVOICE");
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(95,48,"( $invoicetxt ) ");
		$this->fpdf->line(6,38,6,50);
		$this->fpdf->line(290.5,38,290.5,50);
		//$this->fpdf->line(203.5,5,203.5,30);
		$this->fpdf->line(6,50,290.5,50);
		$this->fpdf->line(6,50,6,98);
		$this->fpdf->line(100.5,50,100.5,98);
		$this->fpdf->line(198.5,50,198.5,98);
		$this->fpdf->line(6,98,290.5,98);
		$this->fpdf->line(290.5,50,290.5,98);
		//$this->fpdf->line(6,85,203.5,85);
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(7,54,"Consignee");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		$this->fpdf->consignee("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(7,82,"VAT TIN: 18440216892             CST: 18440216892");
		$this->fpdf->line(6,90,198.5,90);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(7,94,"TF/HSN Classification: 87039010 ");
		
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(105,54,"Buyer(if other than consignee)");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		$this->fpdf->buyeraddress("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(105,82,"VAT TIN: 18440216892             CST: 18440216892");
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(105,94,"Product: E-Rickshaw");
		
		$this->fpdf->compinfo("Invoice No                    : GKR/16-17/0001","Range                           : RANGE-1/480701\n"."Division                         : SINGUR/4807 \n" ."Commissionerate          : KOL-IV/48 \n"."PAN/Income Tax No     : AAMFG8605k \n"."Date of issue of Invoice : 20-Dec-2016 3:17:46 AM\n"."Date & Time of Removal : 21-Dec-2016 15:17:46 PM\n" );
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text(201,82,"Order ID: GKSLSBK00017  ");
		$this->fpdf->text(201,86,"Order Date: 17-12-2016   ");
		$this->fpdf->SetFont('Arial','B',9);
		
		//$this->fpdf->row(array(""));
		$this->fpdf->ln(20);		
		  $this->fpdf->SetFont('Arial','B',9);
		   $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R"));
	    $this->fpdf->SetWidths(array(11,30,40,25.5,83,30,20,10,35));
		 $this->fpdf->Rowheader(array("Sno","Particulars","Chasisno","Motor No","Battery No","Charger","Rate","Qty","Amount"));
		/*
		  $this->fpdf->SetWidths(array(11,40,40,25.5,73,30,20,10,35));
		    $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R","R"));
		    $this->fpdf->Rowheader(array("$k","ER-India(G7)","$chassisno","$motorno","$battery","$charger","42,000.00","1","42,000.00"));
		    */
			}
			//$this->fpdf->cell(10,10,"$sd",0,0,'L');
		    $net=$net+$amnt;
	    
		}
		/*for($n=1;$n<4;$n++)
		{
			$this->fpdf->text(($gtx+1.5),($gty),"$n");
			$gty=$gty+5;
		}*/
	    /*$line = array( "Sl No"    => "1",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$y   += $size + 1;
				
				$line = array( "Sl No"    => "2",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$line = array( "Sl No"    => "2",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$y   += $size + 1;
		
		$size = $this->fpdf->addLine( $y, $line );*/
	  // $this->fpdf->ln(1);
	    //$x=$this->fpdf->getX();
	   // $y=$this->fpdf->getY();
	   // $y=210-$y;
	   // $this->fpdf->cell(6,5,"$x,$y",1,0,'C');
	   //$number=1250.00;
	   
	   $netnum=number_format($net,2);
	  // $red=$this->numbertowords->convert_number($net);
	   //$getst=$this->AccountManage_model->convert_number_to_words(intval($net));
	   $tot=$k-1;
	  //  $this->fpdf->ln($y);
	    $this->fpdf->SetFont('Arial','',10);
	    $this->fpdf->SetWidths(array(239.5,10,35));
		$this->fpdf->SetAligns(array("R","R","R"));
	    $this->fpdf->Rowheader(array("Net Assesable Value","$tot","$netnum"));
	    $this->fpdf->SetFont('Arial','',10);
		$discount2=floatval($net)*(20/100);
		$discount=number_format($discount2,2);
		$net=floatval($net)-floatval($discount2);
		$netdis=number_format($net,2);
	    $this->fpdf->SetWidths(array(219.5,30,35));
		$this->fpdf->SetAligns(array("R","R","R"));
	    $this->fpdf->Rowheader(array("Special Discount @ 20%","-$discount","$netdis"));
	   
	   // echo $net;
		//echo "<br>";
	    $excise=floatval($net)*.06; 
	   	$excise1=number_format($excise,2);
		$net4=floatval($net)+floatval($excise);
	     $cst=floatval($net4)*.05;
		//echo "<br>";
		$cst1=number_format($cst,2);
		
		
	    $this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader2(array("Excise @ 6.00%","$excise1"));
		 $this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
		/*$cst=floatval($net)*.05;
		$cst1=number_format($cst,2);
		$excise=floatval($net)*.06;
		$excise1=number_format($excise,2);*/
	    $this->fpdf->Rowheader2(array("VAT @ 5.00%","$cst1"));
		/*$this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader2(array("Excise @ 6.00%","$excise1"));*/
	   $net2=floatval($net)+floatval($cst)+floatval($excise);
		//echo "<br>";
		//exit;
		$net3=number_format($net2,2);
		$this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader2(array("Grand Total","$net3"));
	   
		
		
		
	    /*$this->fpdf->SetAligns(array("C","C","C","C","C","C","R","C","R","R"));
	    $this->fpdf->SetWidths(array(11,40,18.5,35,30,55,30,20,10,35));
		$this->fpdf->Row(array("","Grand Total","","","","","","","$tot","$netnum"));*/
		/*$this->fpdf->SetWidths(array(239.5,10,35));
		$this->fpdf->SetAligns(array("R","R","R"));
		$this->fpdf->Rowheader(array("Page Total","$lno","$net3"));
        $this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader(array("Grand Total","$netf"));*/
		$red=$this->numbertowords->convert_number($net2);	
	    $this->fpdf->SetFont('Arial','',10);
	    $this->fpdf->SetWidths(array(70,214.5));
	    $this->fpdf->SetAligns(array("L","L"));
	    $this->fpdf->Row(array("Amount Chargable (In words)","Rs.$red Only"));
		//$this->fpdf->ln(1);
		$gtx=$this->fpdf->getX();
		$gety=$this->fpdf->getY();
		//$this->fpdf->ln(2);
		$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
		$this->fpdf->line($gtx+.5,$gety,($gtx),($gety+31));
		$this->fpdf->line($gtx+285,$gety,($gtx+285),($gety+31));
		$this->fpdf->line($gtx+70,$gety,($gtx+70),($gety+31));
		$this->fpdf->SetFont('Times','',9);
		$this->fpdf->text($gtx+72,$gety+3,"1. Certified that the particulars given above are true and correct and that amount");
		$this->fpdf->text($gtx+72,$gety+6,"   indicated above represents the price actually changed from consignee and in ");
		$this->fpdf->text($gtx+72,$gety+9,"   according with sec 4 of the Central Excise Act 1944 and that there is no additi-");
		$this->fpdf->text($gtx+72,$gety+12,"   onal flow of consideration directly/or indirectly  from the buyer.");
		$this->fpdf->text($gtx+72,$gety+17,"2. Excise Duty payable under rule 8 of C Excise Rules 2002");
		$this->fpdf->line($gtx+180,$gety,($gtx+180),($gety+31));
		$this->fpdf->text($gtx+190,$gety+30,"Prepared by");
		$this->fpdf->text($gtx+230,$gety+30,"Checked by");
		$this->fpdf->text($gtx+260,$gety+30," Authorized Sign");
		//$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
		//$this->fpdf->line($gtx+.5,$gety,$gtx,($gety+30));
		//$this->fpdf->line(($gtx+284.5),$gety,($gtx+284.5),($gety+30));
		//$this->fpdf->line($gtx+.5,($gety+30),($gtx+149.5),($gety+30));
		//$this->fpdf->line(($gtx+149.5),$gety,284.5,$gety);
		//$this->fpdf->line(($gtx+149.5),($gety+30),291,($gety+30));
		//$this->fpdf->line(($gtx+149.5),($gety),($gtx+149.5),($gety+30));
		//$this->fpdf->line(285.5,($gety),285.5,($gety+30));
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->text(($gtx+244),($gety+4),"for G.K Rickshaw Pvt Ltd.");
		$this->fpdf->Image($img2, $this->fpdf->GetX()+260, $this->fpdf->GetY()+4,25,25,'png');
		//$gety=$gety+31;
		 $this->fpdf->SetFont('Times','',8);
		$this->fpdf->cell(30,5,"Serial No. in PLA/RG-23",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Manner Of Transport",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Despatched through",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"PR/GC Node No/L.R NO",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Vehicle No",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Date",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		
		//$gtx=$this->fpdf->getX();
		//$gety=$this->fpdf->getY();
		$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->Multicell(285,5,"$declt",1);
		//$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',11);
		$this->fpdf->Multicell(285,5,"NOTE: SUBJECT TO SERAMPORE JURISDICTION",1,'C');
		$this->fpdf->ln(2);
		$lnx=$this->fpdf->getX();
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',14);
		$this->fpdf->text($lnx+120,$lny+5,'"Your Green Partner"');
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',9);
		$this->fpdf->text(270,$lny+15,"To be Contd...");
		$this->fpdf->text(270,$lny+18,'Page No '.$this->fpdf->PageNo().' of {nb}');
		if($ty<3){
			$this->fpdf->addpage();
		}
		
		
		
		}
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',20);
		  $this->fpdf->text($x+78,$y+10,"FORM 20 ");
		  $this->fpdf->SetFont('Arial','B',15);
		  $this->fpdf->text($x+160,$y+10,"Price Rs. 5/- ");
		  $y=$y+10;
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+82,$y+5,"(See Rule 47) ",'C');
		$y=$y+5;
			 $this->fpdf->SetFont('Arial','',13);
		$this->fpdf->text($x+45,$y+5,"Form of application for Registration of a Motor Vehicle ");
		$y=$y+5;
		$this->fpdf->SetFont('Arial','',11);
		$this->fpdf->text($x+0,$y+5,"Registering Authority,");
		$y=$y+5;
		$this->fpdf->text($x+0,$y+5,"Hooghly,");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"1. Full Name of person to be registered as registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"owner/son/wife/daughter of");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"2. Age of the person to be registered owner (proof of");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"age to be attached");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"3. Permanent address of the person to be registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"owner (evidence to be produced)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"4. Temporary address of the person to be registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"as register owner");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"5. Name and Address of the dealer or manufacturer");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"from whom the vehicle was purchased)");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"(sale certificate of road worthiness issued by the");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"manufacturer to be enclosed)");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"6. If ex-army vehicle or imported vehicle, enclosed");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"proof. If locally manufactured Trailer/Semi Trailer");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"enclosed the approval of design by the State");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"Transport Authority and note the proceedings");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"number and date of approval.");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"7. Class of Vehicle ( if Motor cycle, whether with or");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"without gear).");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"8. The Motor Vehicle is");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"a)A New Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"b)Ex-army Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"c)Imported Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"9. Type of Body");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"10. Type of Vehicle");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"11. Maker's Name");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"12. Month of year of Manufacturing");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"13. No. of Cylinder");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"14. Hours Power");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"15. Cubic Capacity");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"16. Maker's classification or if not know, wheel base");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"17. Chasis Number (Affix pencil permit)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"18. Engine Number");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"19. Seating Capacity (including driver)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"20. Fuel use in the engine");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"21. Unlanded Weight");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"22. Particulers of previous registration and registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"number (if any)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"23. Colour of dolours of body, wings ans front end.");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+8;
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		 
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+6,$y+5,"I hereby declared thet vehicle has not been registered if any state of India");
		$y=$y+4;
		$this->fpdf->text($x+6,$y+5,"Addition particulers to be completed only the case of transport vehicles other than motor car");
		$this->fpdf->SetFont('Arial','',11);
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"24. Number, description and size of type");
		$this->fpdf->text($x+70,$y+5,"..................................................................................................................");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"a) Front axle");
		$this->fpdf->text($x+26,$y+5,".................................................................");
		$this->fpdf->text($x+99,$y+5,"b) Rear axle");
		$this->fpdf->text($x+122,$y+5,"..................................................................");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"c) Any other axle");
		$this->fpdf->text($x+34,$y+5,"..........................................................");
		$this->fpdf->text($x+99,$y+5,"d) Tendem axle");
		$this->fpdf->text($x+127,$y+5,".............................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"25. Gross Vehicle Weight");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"a) As Cirtificated by the manufacturer");
		$this->fpdf->text($x+70,$y+5,"..........................................................................................................Kgms");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"b) to be regisered");
		$this->fpdf->text($x+37,$y+5,".........................................................................................................................................Kgms");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"26. Maximum axle weight");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"a) Front axle");
		$this->fpdf->text($x+26,$y+5,"........................................................Kgms.");
		$this->fpdf->text($x+99,$y+5,"b) Rear axle");
		$this->fpdf->text($x+122,$y+5,"..........................................................Kgms.");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"c) Any other axle");
		$this->fpdf->text($x+34,$y+5,".................................................Kgms.");
		$this->fpdf->text($x+99,$y+5,"d) Tendem axle");
		$this->fpdf->text($x+127,$y+5,".....................................................Kgms.");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"27. a) Front axle");
		$this->fpdf->text($x+26,$y+5,".................................................................");
		$this->fpdf->text($x+99,$y+5,"b) Rear axle");
		$this->fpdf->text($x+122,$y+5,"..................................................................");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"c) Any other axle");
		$this->fpdf->text($x+34,$y+5,"..........................................................");
		$this->fpdf->text($x+99,$y+5,"d) Tendem axle");
		$this->fpdf->text($x+127,$y+5,".............................................................");
		$y=$y+10;
		 $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+6,$y+5,"The above particulers are to be filled in for a right frame motor vehicle of two or more axle for an artiticulated vehicles of");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"three or more axles, or the..extent applicable of trailer, where as a second semi trailer or additional semi-trailer to be registered");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"with an articuleted motor vehicle the following particulers are to be fumished for each semi-teailer.");
		
		 $this->fpdf->SetFont('Arial','',11);
		$y=$y+10;
		$this->fpdf->text($x+0,$y+5,"28. Type of Body");
		$this->fpdf->text($x+32,$y+5,".......................................................................................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"29. Unlanden Weight");
		$this->fpdf->text($x+39,$y+5,"................................................................................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"30. Number, description and size of type on each axle");
		$this->fpdf->text($x+95,$y+5,"............................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"31. Maximum axle weight in respect of each axle");
		$this->fpdf->text($x+85,$y+5,".....................................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"32. The vehicle is covered by a valid");
		$this->fpdf->text($x+105,$y+5,"Insurance Certificate Cover note");
		$y=$y+6;
		$this->fpdf->text($x+7,$y+5,"certificated of insurance under");
		$this->fpdf->text($x+105,$y+5,"Note........................................dt...............................");
		$y=$y+6;
		$this->fpdf->text($x+7,$y+5,"chapter XI of the act");
		$this->fpdf->text($x+105,$y+5,"of.....................................................(Name of Comy)");
		$y=$y+7;
		$this->fpdf->text($x+0,$y+5,"33. The vehicle to exampted From");
		$this->fpdf->text($x+105,$y+5,"Valid from..................................to............................");
		$y=$y+6;
		$this->fpdf->text($x+7,$y+5,"Insurence. The relevent order is enclosed");
		$y=$y+10;
		$this->fpdf->text($x+0,$y+5,"34. I have prescribed fee of Rupees");
		$this->fpdf->text($x+64,$y+5,"........................................................................................................................");
		$y=$y+16;
		$this->fpdf->text($x+152,$y+5,"Signature of the person");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"Note :  The motor vehicle above described is :");
		$y=$y+6;
		$this->fpdf->text($x+13,$y+5,"i) Subject to hire purchase agreement / lease agreement / lease agreement with .......................................");
		$y=$y+4;
		$this->fpdf->text($x+16,$y+5,"....................................................................................................................................................................");
		$y=$y+4;
		$this->fpdf->text($x+13,$y+5,"ii) Subject to hypothecation in favour of ........................................................................................................");
		$y=$y+4;
		$this->fpdf->text($x+13,$y+5,"iii) Not, held under hire purchase agreement to lease / agreement or subject to hypothecation .");
		$y=$y+10;
		$this->fpdf->text($x+17,$y+5,"Strike out whatever is in applicable. If the vehicle is subject to any such agreement has been entered");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"into is to be obtain.");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"Signature of the person with whome leaser or");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"hypothecation has been entered into.");
		$y=$y+10;
		$this->fpdf->text($x+0,$y+5,"..............................................................................");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"Specimen Signature or the person to.");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"1.");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"2.");
		$this->fpdf->text($x+152,$y+5,"Signature of the owners");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"3.");
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',25);
		  $this->fpdf->text($x+78,$y+20,"IMPRESSION ");
		   $this->fpdf->SetFont('Arial','B',11);
		  $y=$y+20;
		$this->fpdf->text($x+40,$y+5,"30th, Vidyasagar Sarani, Manicknagar, Bhadreswar, Hoogly, 712124,W.B ",'C');
		$y=$y+5;
		$this->fpdf->text($x+75,$y+5,"FORM- 21 [ See rule 47(a)(d) ] ");
		$y=$y+7;
		$this->fpdf->SetFont('Arial','B',13);
		$this->fpdf->text($x+75,$y+5,"SALE CERTIFICATE");
		$this->fpdf->SetFont('Arial','B',11);
		$y=$y+10;
		//
		$this->fpdf->text($x+10,$y+5,"Certify that");
		$this->fpdf->text($x+90,$y+5,": G.K RICKSHOW");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Has been delivered by us to");
		$this->fpdf->text($x+90,$y+5,": Saugata Dalapati");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"So / Wife / Daughter Of");
		$this->fpdf->text($x+90,$y+5,": s/o Suraya Dalapati ");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Address (Present)");
		$this->fpdf->text($x+90,$y+5,": Ulberia , Howrah");
		$y=$y+20;
		$this->fpdf->text($x+10,$y+5,"Address (Permanent)");
		$this->fpdf->text($x+90,$y+5,": -Do-");
		$y=$y+15;
		$this->fpdf->SetFont('Arial','B',13);
		$this->fpdf->text($x+10,$y+5,"The vehicle is help under Agreement of hire purchase / Hypothecation with N / A");
		$y=$y+10;
		$this->fpdf->SetFont('Arial','B',13);
		$this->fpdf->text($x+65,$y+5,"PARTICULERS OF THE VEHICLE");
		$this->fpdf->SetFont('Arial','B',11);
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Class of Vehicle");
		$this->fpdf->text($x+90,$y+5,": E- Rickshaw ");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Maker's Name");
		$this->fpdf->text($x+90,$y+5,": G.K. Rickshow");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Chassis No.");
		$this->fpdf->text($x+90,$y+5,":");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Motor ID No.");
		$this->fpdf->text($x+90,$y+5,":");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Horse Power");
		$this->fpdf->text($x+90,$y+5,":");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Fuel Used");
		$this->fpdf->text($x+90,$y+5,":");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Seating Capacity");
		$this->fpdf->text($x+90,$y+5,": 4+1(Including Driver)");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Year of Manufacture");
		$this->fpdf->text($x+90,$y+5,": 2016");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Tyre");
		$this->fpdf->text($x+90,$y+5,": 350/12");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Unload Weight");
		$this->fpdf->text($x+90,$y+5,": 250kg");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Wheel Base");
		$this->fpdf->text($x+90,$y+5,": 2100 mm");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Colour");
		$this->fpdf->text($x+90,$y+5,": Cherri");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Type of Body");
		$this->fpdf->text($x+90,$y+5,": Metal");
//#############################################################################################################
//                        form 22
//########################################################################################################
$chasisn="M6REP3085T16B";
$motor="JMYM";$motor1=1245;
  for($k=1;$k<15;$k++){
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		 $chg=str_pad($k, 4 , '0', STR_PAD_LEFT);
		 $mtr2=str_pad($motor1, 5 , '0', STR_PAD_LEFT);
		 $chasisno=$chasisn.$chg;
		 $mtrno=$motor.$mtr2;
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		 $this->fpdf->Image($img, $this->fpdf->GetX()+160, $this->fpdf->GetY()+22,35,25,'png');
		  $this->fpdf->SetFont('Arial','B',15);
		  $this->fpdf->text($x+88,$y+50,"FORM 22 ");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','',10);
		  $this->fpdf->text($x+50,$y+50,"[See rules 47(g), 115(2) 115(6) 115(7) 115(a) 124, 126(A) and 127] ");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','B',12);
		  $this->fpdf->text($x+18,$y+50,"INITIAL CERTIFICATE OF COMPLIENCE WITH POLLUTION, STANDERDS, SAFETY ");
		  $y=$y+6;
		  $this->fpdf->text($x+38,$y+50,"STANDERD OF COMPONENTS AND ROAD WORTHINESS ");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','',10);
		  $this->fpdf->text($x+70,$y+50,"(To be issued by the manufacturer)");
		  $y=$y+15;
		  $this->fpdf->SetFont('Arial','',11);
		  $this->fpdf->text($x+10,$y+50,"Cerfified that");
		  $this->fpdf->SetFont('Arial','B',13);
		  $this->fpdf->text($x+35,$y+50,"GK RICKSHOW");
		  $this->fpdf->SetFont('Arial','',11);
		  $this->fpdf->text($x+70,$y+50,"(Brand name of vehicle) bearing chassis number ");
		  $this->fpdf->SetFont('Arial','B',13);
		  $this->fpdf->text($x+155,$y+50,"$chasisno");
		  $this->fpdf->text($x+155,$y+51.5,"...................................");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','',12);
		  $this->fpdf->text($x+10,$y+50,"MOTOR NO");
		  $this->fpdf->SetFont('Arial','B',13);
		   $this->fpdf->text($x+35,$y+50,"$mtrno");
		  $this->fpdf->text($x+35,$y+51.5,"......................");
		  $this->fpdf->SetFont('Arial','',11);
		  $this->fpdf->text($x+65,$y+50,"complies with provisions of the motor vehicles acts, 1988 and rules");
		  $y=$y+6;
		  $this->fpdf->text($x+10,$y+50,"made there under.");
		  $this->fpdf->SetFont('Arial','B',11);
		  $this->fpdf->text($x+150,$y+65,".............................................");
		  $this->fpdf->SetFont('Arial','B',11);
		  $this->fpdf->text($x+150,$y+69,"Signature of manufacturer");
		   $this->fpdf->Image($img, $x+10, $y+75,25,20,'png');
		   $this->fpdf->SetFont('Arial','B',16);
		   $this->fpdf->text($x+36,$y+80,"G.K RICKSHOW");
		   $this->fpdf->SetFont('Arial','',12);
		   $this->fpdf->text($x+36,$y+84,"30(33/1) N.T Road ,Padmabati Colony, ");
		   $this->fpdf->text($x+36,$y+89,"Baidyabati, Hooghly,West Bengal-712222,India ");
		    $this->fpdf->SetFont('Arial','I',10);
		   $this->fpdf->text($x+36,$y+94,"Phone:(033)-64517771 Email: accounts@gkrickshow.com ");
		    $this->fpdf->text($x+36,$y+99,"website:http://www.gkrickshaw.com");
		   
		  $motor1++;
		
		}
//#############################################################################################################
//                       end form 22
//########################################################################################################
		
		
		$invoice="Invoice_GKR/16-17/0001.pdf";
		$this->fpdf->output("I","$invoice");
		
		
	 }
	 public function form20()
	{
		
		
	$this->authentication->is_loggedin($this->session->userdata('user_name'));

		//$this->fpdf->Image("$path",9,10,195,280,'png');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',20);
		  $this->fpdf->text($x+78,$y+10,"FORM 20 ");
		  $this->fpdf->SetFont('Arial','B',15);
		  $this->fpdf->text($x+160,$y+10,"Price Rs. 5/- ");
		  $y=$y+10;
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+82,$y+5,"(See Rule 47) ",'C');
		$y=$y+5;
			 $this->fpdf->SetFont('Arial','',13);
		$this->fpdf->text($x+45,$y+5,"Form of application for Registration of a Motor Vehicle ");
		$y=$y+5;
		$this->fpdf->SetFont('Arial','',11);
		$this->fpdf->text($x+0,$y+5,"Registering Authority,");
		$y=$y+5;
		$this->fpdf->text($x+0,$y+5,"Hooghly,");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"1. Full Name of person to be registered as registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"owner/son/wife/daughter of");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"2. Age of the person to be registered owner (proof of");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"age to be attached");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"3. Permanent address of the person to be registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"owner (evidence to be produced)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"4. Temporary address of the person to be registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"as register owner");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"5. Name and Address of the dealer or manufacturer");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"from whom the vehicle was purchased)");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"(sale certificate of road worthiness issued by the");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"manufacturer to be enclosed)");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"6. If ex-army vehicle or imported vehicle, enclosed");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"proof. If locally manufactured Trailer/Semi Trailer");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"enclosed the approval of design by the State");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"Transport Authority and note the proceedings");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"number and date of approval.");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"7. Class of Vehicle ( if Motor cycle, whether with or");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"without gear).");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"8. The Motor Vehicle is");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"a)A New Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"b)Ex-army Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"c)Imported Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"9. Type of Body");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"10. Type of Vehicle");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"11. Maker's Name");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"12. Month of year of Manufacturing");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"13. No. of Cylinder");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"14. Hours Power");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"15. Cubic Capacity");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"16. Maker's classification or if not know, wheel base");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"17. Chasis Number (Affix pencil permit)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"18. Engine Number");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"19. Seating Capacity (including driver)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"20. Fuel use in the engine");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"21. Unlanded Weight");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"22. Particulers of previous registration and registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"number (if any)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"23. Colour of dolours of body, wings ans front end.");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+8;
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text($x+6,$y+5,"I hereby declared thet vehicle has not been registered if any state of India");
		$y=$y+4;
		$this->fpdf->text($x+6,$y+5,"Addition particulers to be completed only the case of transport vehicles other than motor car");
	
	
        $this->fpdf->Output();
		
	
}
//###############################  update on 10012017  
public function sparepartsprice()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['model']=$this->Sales_Model->getallmodellist();
	$this->load->view("Sales/viewsparepartsprice",$data);
}
public function printspareparts()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	 $modelname=strtoupper($this->input->post('modelname'));
	$getallparts=$this->Sales_Model->getallparts($modelname);
	//$data['model']=$this->Sales_Model->getallmodellist();
	$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo1.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/sparepartsprice.jpg";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image($img,10,10,35,25,'png');	
		$this->fpdf->Image($path,12,45,180,180,'jpg');	
		$x=$this->fpdf->getX();
		$y=$this->fpdf->gety();
		$this->fpdf->cell(150);
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->ln(30);30(33/1) N.T Road , Padmabati Colony, Baidyabati, Hooghly, West Bengal-712222, India
		//header information     ==============================
		$this->fpdf->cell(15,5,"Office Address",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"30(33/1) N.T Road ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Padmabati Colony, Baidyabati ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Hooghly, West Bengal ,",0,0,'L');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Pin-712222, India ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Email:sales@gkrickshow.com",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Contacts:033-64517771",0,0,'L');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->text(65,25,"GK RICKSHAW PVT LTD.");
		$this->fpdf->SetFont('Times','B',12);
		$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST FOR $modelname ");
		$this->fpdf->ln(17);
		$this->fpdf->line($x,$y+27,$x+190,$y+27);
		$this->fpdf->line($x,$y+27.5,$x+190,$y+27.5);
		$this->fpdf->line($x,$y+29,$x+190,$y+29);
		
		//$this->fpdf->cell(20,10,"asa",0,0,'C');
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->SetWidths(array(20,130,20,30));
		$this->fpdf->SetAligns(array("C","C","C","C"));
		$this->fpdf->Row(array("SL NO","PARTS NAME","UNIT","MRP/UNIT"));
		if(!empty($getallparts) && isset($getallparts))
		{
			$sl=1;
			foreach($getallparts as $row)
			{
				$partsname=$row->materialname;
				$mrp=$row->buyprcrnt;
				$unit=$row->unit;
				$this->fpdf->SetFont('Times','',9);
				$this->fpdf->SetWidths(array(20,130,20,30));
		       $this->fpdf->SetAligns(array("C","C","C","C"));
		      $this->fpdf->Row(array("$sl","$partsname","$unit","$mrp"));
			  $y=$this->fpdf->gety();
			  if($y>285)
			  {
			  	$this->fpdf->addpage();
			  	$this->fpdf->Image($img,10,10,35,25,'png');	
		$this->fpdf->Image($path,12,45,180,180,'jpg');	
		$x=$this->fpdf->getX();
		$y=$this->fpdf->gety();
		$this->fpdf->cell(150);
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->ln(30);30(33/1) N.T Road , Padmabati Colony, Baidyabati, Hooghly, West Bengal-712222, India
		//header information     ==============================
		$this->fpdf->cell(15,5,"Office Address",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"30(33/1) N.T Road ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Padmabati Colony, Baidyabati ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Hooghly, West Bengal ,",0,0,'L');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Pin-712222, India ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Email:sales@gkrickshow.com",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Contacts:033-64517771",0,0,'L');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->text(65,25,"GK RICKSHAW PVT LTD.");
		$this->fpdf->SetFont('Times','B',12);
		$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST");
		$this->fpdf->ln(17);
		$this->fpdf->line($x,$y+27,$x+190,$y+27);
		$this->fpdf->line($x,$y+27.5,$x+190,$y+27.5);
		$this->fpdf->line($x,$y+29,$x+190,$y+29);
		
		//$this->fpdf->cell(20,10,"asa",0,0,'C');
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->SetWidths(array(20,130,20,30));
		$this->fpdf->SetAligns(array("C","C","C","C"));
		$this->fpdf->Row(array("SL NO","PARTS NAME","UNIT","MRP/UNIT"));
			  	
			  }
		
				$sl++;
			}
			
		}
		
		
		
		
		$filename="Fpdfoutput/sparepartsprice.pdf";
		//}
		$this->fpdf->output('D','Sparepartspricelist.pdf');
}
public function printallspareparts()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	 //$modelname=strtoupper($this->input->post('modelname'));
	 $getmodel=$this->Sales_Model->getallmodedl();
	
	
	//$data['model']=$this->Sales_Model->getallmodellist();
	$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo1.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/sparepartsprice.jpg";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image($img,10,10,35,25,'png');	
		$this->fpdf->Image($path,12,45,180,180,'jpg');	
		$x=$this->fpdf->getX();
		$y=$this->fpdf->gety();
		$this->fpdf->cell(150);
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->ln(30);30(33/1) N.T Road , Padmabati Colony, Baidyabati, Hooghly, West Bengal-712222, India
		//header information     ==============================
		$this->fpdf->cell(15,5,"Office Address",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"30(33/1) N.T Road ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Padmabati Colony, Baidyabati ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Hooghly, West Bengal ,",0,0,'L');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Pin-712222, India ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Email:sales@gkrickshow.com",0,0,'L');
		$this->fpdf->ln(3);
		
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Contacts:033-64517771",0,0,'L');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->text(65,25,"GK RICKSHAW PVT LTD.");
		$this->fpdf->SetFont('Times','B',12);
		
		$this->fpdf->ln(17);
		$this->fpdf->line($x,$y+27,$x+190,$y+27);
		$this->fpdf->line($x,$y+27.5,$x+190,$y+27.5);
		$this->fpdf->line($x,$y+29,$x+190,$y+29);
		
		//$this->fpdf->cell(20,10,"asa",0,0,'C');
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->SetWidths(array(20,130,20,30));
		$this->fpdf->SetAligns(array("C","C","C","C"));
		$this->fpdf->Row(array("SL NO","PARTS NAME","UNIT","MRP/UNIT"));
		if(!empty($getmodel) && isset($getmodel))
		{
			
			foreach($getmodel as $row1)
			{
				$sl=1;
				$mname=$row1->model;
				$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST FOR $mname ");
				$getallparts=$this->Sales_Model->getallparts($mname);
				if(isset($getallparts) && !empty($getallparts))
				{
					foreach($getallparts as $row)
					{
				$partsname=$row->materialname;
				$mrp=$row->buyprcrnt;
				$unit=$row->unit;
				$this->fpdf->SetFont('Times','',9);
				$this->fpdf->SetWidths(array(20,130,20,30));
		       $this->fpdf->SetAligns(array("C","C","C","C"));
		      $this->fpdf->Row(array("$sl","$partsname","$unit","$mrp"));
			  $y=$this->fpdf->gety();
			  if($y>270)
				{
				   $this->fpdf->addpage();
				   $this->fpdf->Image($img,10,10,35,25,'png');	
					$this->fpdf->Image($path,12,45,180,180,'jpg');	
					$x=$this->fpdf->getX();
					$y=$this->fpdf->gety();
					$this->fpdf->cell(150);
					$this->fpdf->SetFont('Arial','B',10);
					//$this->fpdf->ln(30);30(33/1) N.T Road , Padmabati Colony, Baidyabati, Hooghly, West Bengal-712222, India
					//header information     ==============================
					$this->fpdf->cell(15,5,"Office Address",0,0,'L');
					$this->fpdf->ln(5);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"30(33/1) N.T Road ,",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					//$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST FOR $mname ");
					$this->fpdf->cell(25,4,"Padmabati Colony, Baidyabati ,",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Hooghly, West Bengal ,",0,0,'L');
					$this->fpdf->ln(4);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Pin-712222, India ,",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Email:sales@gkrickshow.com",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Contacts:033-64517771",0,0,'L');
					$this->fpdf->SetFont('Arial','B',16);
					$this->fpdf->text(65,25,"GK RICKSHAW PVT LTD.");
					$this->fpdf->SetFont('Times','B',12);
					$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST FOR $mname ");
					$this->fpdf->ln(17);
					$this->fpdf->line($x,$y+27,$x+190,$y+27);
					$this->fpdf->line($x,$y+27.5,$x+190,$y+27.5);
					$this->fpdf->line($x,$y+29,$x+190,$y+29);
					
					//$this->fpdf->cell(20,10,"asa",0,0,'C');
					$this->fpdf->SetFont('Arial','B',11);
					$this->fpdf->SetWidths(array(20,130,20,30));
					$this->fpdf->SetAligns(array("C","C","C","C"));
					$this->fpdf->Row(array("SL NO","PARTS NAME","UNIT","MRP/UNIT"));
			  	
			  }
		
				$sl++;
				
				
				}
             //#######################################  add new page  
				  $this->fpdf->addpage();
				   $this->fpdf->Image($img,10,10,35,25,'png');	
					$this->fpdf->Image($path,12,45,180,180,'jpg');	
					$x=$this->fpdf->getX();
					$y=$this->fpdf->gety();
					$this->fpdf->cell(150);
					$this->fpdf->SetFont('Arial','B',10);
					//$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST FOR $mname ");
					//$this->fpdf->ln(30);30(33/1) N.T Road , Padmabati Colony, Baidyabati, Hooghly, West Bengal-712222, India
					//header information     ==============================
					$this->fpdf->cell(15,5,"Office Address",0,0,'L');
					$this->fpdf->ln(5);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"30(33/1) N.T Road ,",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Padmabati Colony, Baidyabati ,",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Hooghly, West Bengal ,",0,0,'L');
					$this->fpdf->ln(4);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Pin-712222, India ,",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Email:sales@gkrickshow.com",0,0,'L');
					$this->fpdf->ln(3);
					$this->fpdf->SetFont('Arial','',9);
					$this->fpdf->cell(150);
					$this->fpdf->cell(25,4,"Contacts:033-64517771",0,0,'L');
					$this->fpdf->SetFont('Arial','B',16);
					$this->fpdf->text(65,25,"GK RICKSHAW PVT LTD.");
					$this->fpdf->SetFont('Times','B',12);
					//$this->fpdf->text(75,45,"SPAREPARTS PRICE LIST FOR $mname ");
					$this->fpdf->ln(17);
					$this->fpdf->line($x,$y+27,$x+190,$y+27);
					$this->fpdf->line($x,$y+27.5,$x+190,$y+27.5);
					$this->fpdf->line($x,$y+29,$x+190,$y+29);
					
					//$this->fpdf->cell(20,10,"asa",0,0,'C');
					$this->fpdf->SetFont('Arial','B',11);
					$this->fpdf->SetWidths(array(20,130,20,30));
					$this->fpdf->SetAligns(array("C","C","C","C"));
					$this->fpdf->Row(array("SL NO","PARTS NAME","UNIT","MRP/UNIT"));
				}
			}
			
		}
		
		
		
		
		
		//}
		$filename="Fpdfoutput/allspareparts.pdf";
		$this->fpdf->output('D',"$filename");
}
///////////////////16012017  //////////////////////////
  public function incentive_slab()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['slab']=$this->Sales_Model->fetchslab();
		$this->load->view("Sales/view_incentive_slab",$data);	
	}
	public function saveincentive()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$min_lngth=$this->input->post("min_lngth");
		$max_lngth=$this->input->post("max_lngth");
		$price=$this->input->post("price");
		$id=$this->input->post("id");
		$k=0;
		$data_array=array(
			"min_length"=>$min_lngth,
			"max_length"=>$max_lngth,
			"price"=>$price
		);
		$check=$this->Sales_Model->checkincentive();
		//print_r($data);
		foreach($check as $row1)
		{
			$min=$row1->min_length;
			$max=$row1->max_length;
			if((($min==$max_lngth) || ($max==$min_lngth)) && $k==0)
			{
				$k=1;
			}	
		}
		if($k==1)
		{
			echo "Data Can not Insert";
		}else{
			$this->Sales_Model->updateincentive($data_array,$id);
			echo "Data Insert Successfully";
		}
		//$this->Sales_Model->updateincentive($data_array,$id);
		
	}
	//update on 17012017
	public function acticedeactive()
	{
		$sid=$this->input->post('sid');
		$getstatus=$this->Sales_Model->getsatus($sid);
		foreach($getstatus as $row)
		{
			$st=$row->status;
			
		}
		if(intval($st)==1)
		{
			$stnew=0;
			$msg="Accounts Deativate Succesfully";
		}
		if(intval($st)==0)
		{
			$stnew=1;
			$msg="Accounts Activate Succesfully";
		}
		$this->Sales_Model->update_status($sid,$stnew);
		echo $msg;
	}
	//19012017
	public function printallmodelprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	 //$modelname=strtoupper($this->input->post('modelname'));
	 $getmodel=$this->Sales_Model->getallmodedlprice();
	
	
	//$data['model']=$this->Sales_Model->getallmodellist();
	$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo1.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/BOB_9012.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image($img,10,10,35,25,'png');	
		$this->fpdf->Image($path,8,100,200,120,'png');	
		$x=$this->fpdf->getX();
		$y=$this->fpdf->gety();
		$this->fpdf->cell(150);
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->ln(30);30(33/1) N.T Road , Padmabati Colony, Baidyabati, Hooghly, West Bengal-712222, India
		//header information     ==============================
		$this->fpdf->cell(15,5,"Office Address",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"30(33/1) N.T Road ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Padmabati Colony, Baidyabati ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Hooghly, West Bengal ,",0,0,'L');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Pin-712222, India ,",0,0,'L');
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Email:sales@gkrickshow.com",0,0,'L');
		$this->fpdf->ln(3);
		
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(150);
		$this->fpdf->cell(25,4,"Contacts:033-64517771",0,0,'L');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->text(65,25,"MODEL PRICE DETAILS");
		$this->fpdf->SetFont('Times','B',12);
		
		$this->fpdf->ln(17);
		$this->fpdf->line($x,$y+27,$x+190,$y+27);
		$this->fpdf->line($x,$y+27.5,$x+190,$y+27.5);
		$this->fpdf->line($x,$y+29,$x+190,$y+29);
		
		//$this->fpdf->cell(20,10,"asa",0,0,'C');
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->SetWidths(array(190));
		$this->fpdf->SetAligns(array("C","C","C","C"));
		$this->fpdf->Row(array("WITHOUT BATTERY & CHARGER"));
		
		$this->fpdf->SetWidths(array(20,30,30,30,30,30,20));
		$this->fpdf->SetAligns(array("C","C","C","C","C","C","C"));
		$this->fpdf->Row(array("SL NO","MODEL NAME","TYPE","MRP/RETAIL","SUB-DISTRIBUTER PRICE","DISTRIBUTER PRICE","CNF PRICE"));
		if(isset($getmodel) && !empty($getmodel))
		{
			$i=1;
			foreach($getmodel as $rowmodelpr)
			{
				$modelname=$rowmodelpr->productname;
				$mrp=$rowmodelpr->mainpr;
				$typ=$rowmodelpr->modeltyp;
				$retailpri=$rowmodelpr->retailerpercentage;
				$subdistpr=$rowmodelpr->subdistprice;
				$subdistper=$rowmodelpr->subdistpercentage;
				$distpr=$rowmodelpr->distprice;
				$distper=$rowmodelpr->distpercentage;
				$cnfpr=$rowmodelpr->cnfprice;
				$cnfpri=$rowmodelpr->cnfpercentage;
				$this->fpdf->SetFont('Times','',9);
				$this->fpdf->SetWidths(array(20,30,30,30,30,30,20));
				$this->fpdf->SetAligns(array("C","C","C","C","C","C","C"));
				$this->fpdf->Row(array("$i","$modelname","$typ","$mrp","$subdistpr($subdistper)","$distpr($distper%)","$cnfpr($cnfpri%)"));
				$i++;
			}
			
		}
		
		
		
		
		
		//}
		$filename="Fpdfoutput/allmodelprice.pdf";
		$this->fpdf->output("D",$filename);
	}
	

	
}