<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_report extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library('fpdf_gen');
		//$this->load->library('fpdf_geninvoice');
		
		//$this->load->library('numbertowords');
		$this->load->model('Manage_report_model');
		
		$this->load->model('Sales_Model');
		$this->load->model('stockManage_model');
	}
	public function salesexecutivereport()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Manage Report";
		$data['tergetachieve']=$this->Manage_report_model->getallsalesamn();
		//echo $year=date('Y');
		//$month=date('F');
		//$mnth=$this->Manage_report_model->fetchmonth($month);
		//print_r($mnth);
		//foreach($mnth as $row)
		//{
		//	echo $monthcd=$row->month_code;
		//}
		//$data['terget']=$this->Manage_report_model->terget($monthcd,$year);
		//print_r($data);
		$this->load->view("report/salesvisiting",$data);
	}
	
   
}