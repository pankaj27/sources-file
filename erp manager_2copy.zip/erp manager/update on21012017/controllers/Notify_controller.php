<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notify_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		//$this->load->library(array('session','authentication'));
		$this->load->model('Notify_model');
	}
	
	
	public function get_quatationstatus()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id=$this->input->post('id');
		$getall=$this->Notify_model->getall_quatation_status();
		//print_r($getall);
		$i=0;
		foreach($getall as $row)
		{
			$i++;
			/*$venname=$row->venid;
			$qtid=$row->pono;
			$getvenname=$this->Notify_model->getvenname($venname);
			$data_array=array(
				"title"=>"$getvenname send a quotation",
				"uniid"=>$qtid,
				"link"=>"Purchase_controller/viewquotation",
				"doe"=>date('Y-m-d')
							
			);
			$checknotexist=$this->Notify_model->getqtexist($venname,$qtid);
			if(empty($checknotexist))
			{
				$this->Notify_model->savenotify($data_array);
			}*/
			
		}
		if($i>0){
	      //echo "<sup class='badge style-danger'>$i</sup>";
		  $result=array("stat"=>"$i");
		  
		  echo json_encode($result);
		//print_r($data_array);
		}else
			{
				$i=0;
				$result=array("stat"=>"$i");
				echo json_encode($result);
			}
	}
	public function get_notification()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['getallnotice']=$this->Notify_model->getallnotice();
		
	} 
	public function setstatus()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id=$this->input->post("id");
		$get=$this->Notify_model->setstatusnotice();
		echo 1;
	}
}