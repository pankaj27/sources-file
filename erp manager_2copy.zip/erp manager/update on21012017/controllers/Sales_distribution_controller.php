<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_distribution_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Sales_distribution_model');
	}
	
	public function sales_dist_dash()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
    	$this->load->view('sales_distribution/sales_dist_dash',$data);
	}
/*------------------------------------------------  create new Distributer------------------------------------------------------*/
	public function create_new_dist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
		$data['state']=$this->Sales_distribution_model->getall_state();
		$data['registered_distributer']=$this->Sales_distribution_model->getall_distributer();
		$distid=$this->Sales_distribution_model->getlast_distid();
		if(!empty($distid)){
		    foreach($distid as $row){
			     $stid=$row->id;
		    }
			$stid1=$stid+1;
			$data["distid"]="GK/".date('Ymd')."/".$stid1;
		}else{
		   $data["distid"]="GK/".date('Ymd')."/". 1 ;
	    }
		//print_r($data);
    	$this->load->view('sales_distribution/create_nw_dist_view',$data);
    	//$this->load->view('sales_distribution/location',$data);
	}
/*-------------------------------------  save Distribution Details-----------------------------------------------------*/
   public function save_distributer_details()
   {
   	    $this->authentication->is_loggedin($this->session->userdata('user_name'));
		date_default_timezone_set("Asia/Kolkata");
		$data['title']='User Dash Board ';
		$name=$this->input->post('name');
		$distid=$this->input->post('distid');
		$phno=$this->input->post('phno');
		$email=$this->input->post('email');
		$area=$this->input->post('area');
		$add1=$this->input->post('add1');
		$add2=$this->input->post('add2');
		$add3=$this->input->post('add3');
		$add4=$this->input->post('add4');
		$pin=$this->input->post('pin');
		$state=$this->input->post('state');
		$depoamount=$this->input->post('depoamount');
		$interest=$this->input->post('interest');
		$contactper=$this->input->post('contactper');
		$remarks=$this->input->post('remarks');
		$data_array=array(
			"dist_id"=>$distid,
			"name"=>strtoupper($name),
			"email"=>$email,
			"phno"=>$phno,
			"add1"=>$add1,
			"add2"=>$add2,
			"add3"=>$add3,
			"add4"=>$add4,
			"pin"=>$pin,
			"area"=>$area,
			"state"=>$state,
			"depositamount"=>$depoamount,
			"interes"=>$interest,
			"contactperson"=>$contactper,
			"remarks"=>$remarks,
			"doe"=>date('Ymd h:i:s A')
		
		);
		$check_data_exist=$this->Sales_distribution_model->check_alreadyexist($name,$phno,$email);
		if(empty($check_data_exist))
		{
			$resul=$this->Sales_distribution_model->save_new_distributer($data_array);
			if($resul==1)
			{
				echo "Succesfully Registered";
			}else{
				echo "There are something went Wrong!.Please try again";
			}
		}else{
			echo "Already Registered.Please Check List for Details";
		}
		
   }
}