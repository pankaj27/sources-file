<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_price extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Pricing_model');
	}
	public function modelprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['model']=$this->Pricing_model->getmodel();
    	$this->load->view('Price/modelprice',$data);
	}
	public function saveprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$mName=$this->input->post('mName');
		
		$d_inc_battery=$this->input->post('d_inc_battery');
		$d_ex_battery=$this->input->post('d_ex_battery');
		$d_inc_charger=$this->input->post('d_inc_charger');
		$d_ex_charger=$this->input->post('d_ex_charger');
		$d_bat_chr=$this->input->post('d_bat_chr');
		$d_wth_bat_chr=$this->input->post('d_wth_bat_chr');
		
		$s_inc_battary=$this->input->post('s_inc_battary');
		$s_ex_battary=$this->input->post('s_ex_battary');
		$s_inc_charger=$this->input->post('s_inc_charger');
		$s_ex_charger=$this->input->post('s_ex_charger');
		$s_bat_chr=$this->input->post('s_bat_chr');
		$s_wth_bat_chr=$this->input->post('s_wth_bat_chr');
		
		$r_inc_battary=$this->input->post('r_inc_battary');
		$r_ex_battary=$this->input->post('r_ex_battary');
		$r_inc_charger=$this->input->post('r_inc_charger');
		$r_ex_charger=$this->input->post('r_ex_charger');
		$r_bat_chr=$this->input->post('r_bat_chr');
		$r_wth_bat_chr=$this->input->post('r_wth_bat_chr');
		
		$data_array=array(
			'd_inc_battery'=>$d_inc_battery,
			'd_ex_battery'=>$d_ex_battery,
			'd_inc_charger'=>$d_inc_charger,
			'd_ex_charger'=>$d_ex_charger,
			'd_bat_chr'=>$d_bat_chr,
			'd_wth_bat_chr'=>$d_wth_bat_chr,
			
			's_inc_battary'=>$s_inc_battary,
			's_ex_battary'=>$s_ex_battary,
			's_inc_charger'=>$s_inc_charger,
			's_ex_charger'=>$s_ex_charger,
			's_bat_chr'=>$s_bat_chr,
			's_wth_bat_chr'=>$s_wth_bat_chr,
			
			'r_inc_battary'=>$r_inc_battary,
			'r_ex_battary'=>$r_ex_battary,
			'r_inc_charger'=>$r_inc_charger,
			'r_ex_charger'=>$r_ex_charger,
			'r_bat_chr'=>$r_bat_chr,
			'r_wth_bat_chr'=>$r_wth_bat_chr
			
		);
		$this->Pricing_model->saveprice($data_array,$mName);		
		redirect('Manage_price/viewprice','refresh');
	}
	
	public function editprice($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$data['price']=$this->Pricing_model->fetchprice1($id1);
		//print_r($data);exit;
    	$this->load->view('Price/editprice',$data);
	}
	public function deleteprice($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$data_array=array(
			'd_inc_battery'=>'',
			'd_ex_battery'=>'',
			'd_inc_charger'=>'',
			'd_ex_charger'=>'',
			'd_bat_chr'=>'',
			'd_wth_bat_chr'=>'',
			
			's_inc_battary'=>'',
			's_ex_battary'=>'',
			's_inc_charger'=>'',
			's_ex_charger'=>'',
			's_bat_chr'=>'',
			's_wth_bat_chr'=>'',
			
			'r_inc_battary'=>'',
			'r_ex_battary'=>'',
			'r_inc_charger'=>'',
			'r_ex_charger'=>'',
			'r_bat_chr'=>'',
			'r_wth_bat_chr'=>''
			
		);
		$this->Pricing_model->deleteprice($data_array,$id1);
		redirect('Manage_price/viewprice','refresh');
	}
	
	
	
	////////////................SpareParts Price............///////////////
	
	
	
	public function sparepartsprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['model']=$this->Pricing_model->getmodel();
		
    	$this->load->view('Price/sparepartsprice',$data);
	}
	public function get_spareparts()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		 $mName=$this->input->post("mName");
		
		/*$parts=$this->Pricing_model->fetchparts($mName);
		
              echo ' <select class="form-control select2-list" data-placeholder="Select an item" name="spareparts" id="spareparts">';			
					echo '	<option value=""></option>';
					 if(isset($parts)){ 
						 foreach($parts as $row){ 
					 echo '  <option value="'.$row->materiel_id.'">'.$row->materialname.'</option>';
											
					 }}
				echo'</select>';
				echo '<label for="mName">SpareParts Name</label>';*/
				
		$parts=$this->Pricing_model->fetchparts($mName);
		//$parts=$this->Pricing_model->fetchfixprce();
		echo '<table id="mat_table" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
                <th>Sl No.</th>
				<th>SpareParts Name</th>
				<th>Oreder Price</th>
				<th>Sales Price</th>
                <th>Distributer Price(%)</th>
                <th>Subdistributer Price(%)</th>
				<th>Retailer Price(%)</th>
				
            </tr>
        </thead>
        
        <tbody>';
		
			 if(isset($parts) && !empty($parts)){ $i=1;
			 foreach($parts as $row1){
           
				
			    $matid=$row1->materiel_id;
				$matprice=$this->Pricing_model->fetchfixprce();
				
					if(isset($matprice) && !empty($matprice)){ $j=1;
					foreach($matprice as $row2){
						$parts=$row2->parts;
						$partsexplode=explode(",",$parts);
						
					 if(!empty($partsexplode) && isset($partsexplode)){ $k=1;
                      foreach($partsexplode as $row3){ 
                                 $partex=explode(";",$row3) ; 
                                              			
                                              			   $partsid=$partex[0];
                                              			  // $modelid=$partex[1];
														  // $partsqty=$partex[2];
														   $prtsrte=$partex[4];
														 //  $prtprice=$partex[5];
                                              			
                                             		
				 echo '<tr>
				<th>'.$i.'</th>
                <th>'.$row1->materialname.'</th>
				<input type="hidden" name="matid" id="matid_'.$i.'" value="'.$i.'">
				<input type="hidden" name="mat_'.$i.'" id="mat_'.$i.'" value="'.$matid.'">';
				 if($partsid==$matid){
				echo '<th>'.$prtsrte.'</th>
				<th><input type="text" min="0.00" name="sales_'.$i.'" id="sales_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00" name="dis_'.$i.'" id="dis_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00" name="subdis_'.$i.'" id="subdis_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00" name="ret_'.$i.'" id="ret_'.$i.'" style="width:90px; value=""></th>	
																							
				</td>';
				 }else{
				echo '<th><input type="text" min="0.00" name="ord_'.$i.'" id="ord_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00"  name="sales_'.$i.'" id="sales_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00" name="dis_'.$i.'" id="dis_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00" name="subdis_'.$i.'" id="subdis_'.$i.'" style="width:90px; value=""></th>
				<th><input type="text" min="0.00" name="ret_'.$i.'" id="ret_'.$i.'" style="width:90px; value=""></th>	
																							
				</td>
            </tr>';
				 }
			
			$k++; }}
			 $j++; }}
			 $i++; }}
			 echo ' 
			  
        </tbody>
    </table>';
				
	}
	public function savesparepartsprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$spareparts=$this->input->post('spareparts');
		$dprice=$this->input->post('matid');
		//$mat=$this->input->post('mat');
		//echo $mat;
		for($i=1;$i<=$dprice;$i++)
		{
			$mat=$this->input->post("mat_$i");
			
			$ord=$this->input->post("ord_$i");
			$sales=$this->input->post("sales_$i");
			$dis=$this->input->post("dis_$i");
			$subdis=$this->input->post("subdis_$i");
			$ret=$this->input->post("ret_$i");
			$data_array=array(
				'ordr_price'=>$ord,
				'sals_price'=>$sales,
				'dis_price'=>$dis,
				'sub_price'=>$subdis,
				'retail_price'=>$ret
			);
			$this->Pricing_model->savesparepartsprice($data_array,$mat);	
		}
		////$sprice=$this->input->post('sprice');
		//$rprice=$this->input->post('rprice');
		
		//$data_array=array(
			//'dis_price'=>$dprice,
			//'sub_price'=>$sprice,
			//'retail_price'=>$rprice	
		//);
		//$this->Pricing_model->savesparepartsprice($data_array,$spareparts);		
		redirect('Manage_price/viewspareparts','refresh');
	}
	public function viewspareparts()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));		
		$data['spare']=$this->Pricing_model->fetchspareparts();
    	$this->load->view('Price/viewspareparts',$data);
	}
	public function editspareparts($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$data['spare']=$this->Pricing_model->fetchspareparts1($id1);
    	$this->load->view('Price/editspareparts',$data);
		
	}
	public function savesparepartsprice2()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$materiel_id=$this->input->post('matid');
		$spareparts=$this->input->post('spareparts');

			
		$sprice=$this->input->post('sprice');
		$rprice=$this->input->post('rprice');
		$dprice=$this->input->post('dprice');
		$slsprice=$this->input->post('slsprice');
		
		$data_array=array(
			'sals_price'=>$slsprice,
			'dis_price'=>$dprice,
			'sub_price'=>$sprice,
			'retail_price'=>$rprice	
		);
		$this->Pricing_model->savesparepartsprice($data_array,$spareparts);	

		redirect('Manage_price/viewspareparts','refresh');
	}
	public function deletespareparts($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$data_array=array(
			'ordr_price'=>'',
			'sals_price'=>'',
			'dis_price'=>'',
			'sub_price'=>'',
			'retail_price'=>''	
		);
		$this->Pricing_model->deletespareparts($data_array,$id1);
		redirect('Manage_price/viewspareparts','refresh');
	}

	public function savemodelprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$model=$this->input->post("mName");
		$mainpr=$this->input->post("mainprice");
		$cnfpr=$this->input->post("cnfprice");
		$cnfper=$this->input->post("cnfpercentage");
		$distpr=$this->input->post("distprice");
		$disper=$this->input->post("distpercent");
		$subdispr=$this->input->post("subdistprice");
		$subdisper=$this->input->post("subdistpercentage");
		$retailpr=$this->input->post("retailerprice");
		$retailper=$this->input->post("retailerpercentage");
		$dataarray=array(
			"cnfprice"=>$cnfpr,
			"cnfpercentage"=>$cnfper,
			"distprice"=>$distpr,
			"distpercentage"=>$disper,
			"subdistprice"=>$subdispr,
			"subdistpercentage"=>$subdisper,
			"retailerprice"=>$retailpr,
			"retailerpercentage"=>$retailper,
			"mainpr"=>$mainpr
		
		);
		$this->Pricing_model->updatepriceingdetails($model,$dataarray);
		redirect('Manage_price/viewprice','refresh');
		
		
	}
	public function viewprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));		
		$data['model']=$this->Pricing_model->fetchprice();
    	$this->load->view('Price/viewprice',$data);
	}
	public function editmodelprice($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));	
		$data['getmodelpr']=$this->Pricing_model->getmodelpr($id);
		$data['model']=$this->Pricing_model->getmodel();
    	$this->load->view('Price/modelprice',$data);
	}
	public function updatemodelprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$rowid=$this->input->post("rowid");
		$model=$this->input->post("mName");
		$mainpr=$this->input->post("mainprice");
		$cnfpr=$this->input->post("cnfprice");
		$cnfper=$this->input->post("cnfpercentage");
		$distpr=$this->input->post("distprice");
		$disper=$this->input->post("distpercent");
		$subdispr=$this->input->post("subdistprice");
		$subdisper=$this->input->post("subdistpercentage");
		$retailpr=$this->input->post("retailerprice");
		$retailper=$this->input->post("retailerpercentage");
		$dataarray=array(
			"cnfprice"=>$cnfpr,
			"cnfpercentage"=>$cnfper,
			"distprice"=>$distpr,
			"distpercentage"=>$disper,
			"subdistprice"=>$subdispr,
			"subdistpercentage"=>$subdisper,
			"retailerprice"=>$retailpr,
			"retailerpercentage"=>$retailper,
			"mainpr"=>$mainpr
		
		);
		$this->Pricing_model->updatemodelpr($rowid,$dataarray);
		redirect('Manage_price/viewprice','refresh');
	}
	
	public function getsparepartsall()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$model=$this->input->post("mName");
		$data['getallparts']=$this->Pricing_model->getpartsdetails($model);
		$data['model']=$this->Pricing_model->getmodel();
		$data['mdl']=$model;
		$this->load->view('Price/sparepartsprice',$data);
	}
	
   //#############################################    Update on 28-12-2016  ################################
   //public function 
   public function savespareprtsprice()
   {
   	  $this->authentication->is_loggedin($this->session->userdata('user_name'));
	  date_default_timezone_set("Asia/Kolkata");
	  $totrow=intval($this->input->post("totrow"));
	  for($i=1;$i<intval($totrow);$i++)
	  {
	  	$partsid=$this->input->post("partsid_".$i);
	  	$mainpr=floatval($this->input->post("mainpr_".$i));
		if($mainpr>0)
		{
	  	$cnfpr=floatval($this->input->post("cnf_".$i));
		$cnfper=((floatval($mainpr)-floatval($cnfpr))/floatval($mainpr))*100;
		$cnfper=number_format($cnfper,2);
	  	$dist=floatval($this->input->post("dist_".$i));
		$distper=((floatval($mainpr)-floatval($dist))/floatval($mainpr))*100;
		$distper=number_format($distper,2);
	  	$subdist=floatval($this->input->post("subdist_".$i));
		$subdistper=((floatval($mainpr)-floatval($subdist))/floatval($mainpr))*100;
		$subdistper=number_format($subdistper,2);
	  	
		//$retail=floatval($this->input->post("retail_".$i));
		//$retailper=((floatval($retail)-floatval($mainpr))/floatval($mainpr))*100;
		//$retailper=number_format($retailper,2);
		  $data_array=array(
		  	"buyprcrnt"=>$mainpr,
		  	"cnfpr"=>$cnfpr,
		  	"cnfprper"=>$cnfper,
		  	"distpr"=>$dist,
		  	"distprper"=>$distper,
		  	"subdistpr"=>$subdist,
		  	"subdistprper"=>$subdistper,
		  	"retailpr"=>$mainpr,
		  	//"retailprper"=>$retailper,
		  	"purchsecrtd"=>$this->session->userdata('user_name')."#".date('Y-m-d h:i:s A')
		  );
		  
		  	$this->Pricing_model->updatesparepartsprice($data_array,$partsid);
		  }
	  	
	  }
    redirect('Manage_price/viewspareprtspr','refresh');
	  
   }
	public function viewspareprtspr()
	{
		 $this->authentication->is_loggedin($this->session->userdata('user_name'));
		 $data['getsparepartsprice']=$this->Pricing_model->getallspareprtprice();
		 $this->load->view("Price/viewspareparts", $data);
	     
	}
	public function editsparepartsprice($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$matid=$id;
		$data['getpartsprice']=$this->Pricing_model->getpartpr($id);
		$this->load->view('Price/editindiprtpr',$data);
	}
	public function updatepartspric()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$rowid=$this->input->post("rowid");
		//$model=$this->input->post("mName");
		$mainpr=$this->input->post("mainprice");
		$cnfpr=$this->input->post("cnfprice");
		$cnfper=$this->input->post("cnfpercentage");
		$distpr=$this->input->post("distprice");
		$disper=$this->input->post("distpercent");
		$subdispr=$this->input->post("subdistprice");
		$subdisper=$this->input->post("subdistpercentage");
		//$retailpr=$this->input->post("retailerprice");
		//$retailper=$this->input->post("retailerpercentage");
		$dataarray=array(
			"cnfpr"=>$cnfpr,
			"cnfprper"=>$cnfper,
			"distpr"=>$distpr,
			"distprper"=>$disper,
			"subdistpr"=>$subdispr,
			"subdistprper"=>$subdisper,
			"retailpr"=>$retailpr,
			"retailprper"=>$mainpr,
			"buyprcrnt"=>$mainpr
		
		);
		$this->Pricing_model->updateprtindi($rowid,$dataarray);
		redirect('Manage_price/viewspareprtspr','refresh');
	}
//update on 02-01-2017====================================
public function getmodelpricebymodel()
{
	$model=$this->input->post("model");
	$getallparts=$this->Pricing_model->getpartspricebymodl($model);
	$totval=0;
	foreach($getallparts as $row)
	{
		$qty=intval($row->unit);
		$buypr=floatval($row->buypr);
		$total=$buypr*$qty;
		$totval=$totval+$total;
		
	}
	echo floatval($totval)+2000;
}
public function getmodalprice()
{
	
	
	$model=$this->input->post("model");
	$getallparts=$this->Pricing_model->getpartspricebymodl($model);
	$totval=0;
	echo ' <button type="button" class="btn btn-flat btn-primary ink-reaction"  data-toggle="modal" data-target="#myModal" >Details Info</button>';
	
						echo '<div class="modal fade" id="myModal" role="dialog">
								    <div class="modal-dialog modal-lg">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">Model Price For '.strtoupper($model).'(Without battery & Charger )</h4>
								        </div>
								        <div class="modal-body">
								        	<div class="row">
								          		<div class="col-md-12" style="overflow-y:scroll;">
								          		 <table class="table table-bordered">
								          		  	<thead>
								          		  		<tr>
								          		  			<td>Sl NO.</td>
								          		  			<td>PARTS CODE</td>
								          		  			<td>PARTS NAME</td>
								          		  			<td>SELLER PRICE</td>
								          		  			<td>TAX</td>
								          		  			<td>OTHER EXPENSE.</td>
								          		  			<td>PURCHASE PRICE</td>
								          		  			<td>UNIT</td>
								          		  			<td>TOTAL</td>
								          		  			
								          		  			
															
								          		  		</tr>
								          		  	</thead>
								          		  	<tbody>
								          		  	';
													$i=1;
													foreach($getallparts as $row)
	                                                 {
	                                                 	$partscode=$row->materiel_id;
														$partsname=$row->materialname;
	                                                 	$sellerpr=$row->sellerpr;
														$tax=$row->tax;
														$others=$row->others;
														$qty=intval($row->unit);
														$buypr=floatval($row->buypr);
														$total=$buypr*$qty;
														$totval=$totval+$total;
														
														
								          		  		echo '<tr>
										          		  			<td>'.$i.'</td>
										          		  			<td>'.$partscode.'</td>
										          		  			<td>'.$partsname.'</td>
										          		  			<td>'.$sellerpr.'</td>
										          		  			<td>'.$tax.'</td>
										          		  			<td>'.$others.'</td>
										          		  			<td>'.$buypr.'</td>
										          		  			<td>'.$qty.'</td>
										          		  			<td style="text-align:right;">'.$total.'</td>
								          		  			
								          		  		
								          		  		</tr>';
								          		  		}
														 echo '<tr>
													  		<td colspan="8" style="text-align:right;">Total</td>
													  		<td style="text-align:right;">'.$totval.'</td>
													  
													  </tr>';
														$totval=floatval($totval)+2000;
														 echo '<tr>
													  		<td colspan="8" style="text-align:right;">Manufacturing Cost</td>
													  		<td style="text-align:right;">1000.00</td>
													  
													  </tr>';
													   echo '<tr>
													  		<td colspan="8" style="text-align:right;">Packaging Cost</td>
													  		<td style="text-align:right;">1000.00</td>
													  
													  </tr>';
                                                     
													  echo '<tr>
													  		<td colspan="8" style="text-align:right;">Total Price</td>
													  		<td style="text-align:right;">'.$totval.'</td>
													  
													  </tr>';
								          		  	echo '</tbody>
												 
												 <table>
								        	 
										  		</div>
											</div>
								        </div>
								        <div class="modal-footer">
								          
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" >Close</button>
								        </div>
								      </div>
								    </div>
					</div>';
							
}
//update on 02012017
 public function fixedprice()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['model']=$this->Pricing_model->getmodel();
    	$this->load->view('Price/fixedprice',$data);
 }
  public function savemodelfixedprice()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$model=$this->input->post("mName");
		$retailpr=$this->input->post("mainprice");
		$cnfpr=$this->input->post("cnfprice");
		$cnfper=$this->input->post("cnfpercentage");
		$distpr=$this->input->post("distprice");
		$disper=$this->input->post("distpercent");
		$subdispr=$this->input->post("subdistprice");
		$subdisper=$this->input->post("subdistpercentage");
		//$retailpr=$this->input->post("retailerprice");
		//$retailper=$this->input->post("retailerpercentage");
		$dataarray=array(
			"cnfprice"=>$cnfpr,
			"cnfpercentage"=>$cnfper,
			"distprice"=>$distpr,
			"distpercentage"=>$disper,
			"subdistprice"=>$subdispr,
			"subdistpercentage"=>$subdisper,
			"retailerprice"=>$retailpr,
			
			"mainpr"=>$retailpr
		
		);
		$this->Pricing_model->updatepriceingdetails($model,$dataarray);
		redirect('Manage_price/viewfixedprice','refresh');
  }
  public function viewfixedprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));		
		$data['model']=$this->Pricing_model->fetchprice();
    	$this->load->view('Price/viewfixedprice',$data);
	}
	public function editmodelfixedprice($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));	
		$data['getmodelpr']=$this->Pricing_model->getmodelpr($id);
		$data['model']=$this->Pricing_model->getmodel();
    	$this->load->view('Price/fixedprice',$data);
	}
	public function updatemodelfixedprice()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$rowid=$this->input->post("rowid");
		$model=$this->input->post("mName");
		$retailpr=$this->input->post("mainprice");
		$cnfpr=$this->input->post("cnfprice");
		$cnfper=$this->input->post("cnfpercentage");
		$distpr=$this->input->post("distprice");
		$disper=$this->input->post("distpercent");
		$subdispr=$this->input->post("subdistprice");
		$subdisper=$this->input->post("subdistpercentage");
		//$retailpr=$this->input->post("retailerprice");
		//$retailper=$this->input->post("retailerpercentage");
		$dataarray=array(
			"cnfprice"=>$cnfpr,
			"cnfpercentage"=>$cnfper,
			"distprice"=>$distpr,
			"distpercentage"=>$disper,
			"subdistprice"=>$subdispr,
			"subdistpercentage"=>$subdisper,
			"retailerprice"=>$retailpr,
			
			"mainpr"=>$retailpr
		
		);
		$this->Pricing_model->updatemodelpr($rowid,$dataarray);
		redirect('Manage_price/viewfixedprice','refresh');
	}


   	
	
}