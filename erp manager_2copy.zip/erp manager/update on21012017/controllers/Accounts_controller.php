<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Accounts_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		$this->load->library('fpdf_geninvoice');
		
		$this->load->library('numbertowords');
		$this->load->model('Account_model');
		
		$this->load->model('Sales_Model');
		$this->load->model('stockManage_model');
	}
	public function viewinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$data['gettaxliabilities']=$this->Account_model->gettaxinfo();
		$data['bankname']=$this->Account_model->getallbavkdetails();
		$data['paidtax']=$this->Account_model->getpaidtax();
		$this->load->view("taxliabilites/create",$data);
	}
	public function getallaccno()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$bank=$this->input->post("banknmae");
		$getaccno=$this->Account_model->getallaccno($bank);
		if(isset($getaccno) && !empty($getaccno))
		{
			echo "<option value=''>--select--</option>";
			foreach($getaccno as $row)
			{
				echo "<option value='".$row->accno."'>".$row->accno."</option>";
			}
		}
	}
	public function getaccountsdetailse()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$accno=$this->input->post("accno");
		$getaccdetails=$this->Account_model->getaccdetails($accno);
		$result=array();
		foreach($getaccdetails as $row)
		{
			$branch=$row->branchname;
			$balance=$row->balance;
		}
		$result=array("branch"=>"$branch","balance"=>"$balance");
		echo json_encode($result);
		
	}
	public function saveallcurrentliabilkities()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		date_default_timezone_set("Asia/kolkata");
		$paytyp=$this->input->post("paytyp");
		$bankname=$this->input->post("bankname");
		$accno=$this->input->post("accno");
		$branch=$this->input->post("branchname");
		 $total=$this->input->post("total");
		$date=$this->input->post("date");
				
		$tablerow=intval($this->input->post("tablerow"));
		for($i=1;$i<=$tablerow;$i++)
		{
			$excise=$this->input->post("excise_".$i);
			$exciseper=$this->input->post("excisepercent_".$i);
			$cstvat=$this->input->post("cstvat_".$i);
			
			$cstsvatinfo=$this->input->post("taxinfo_".$i);
			$cstvatper=$this->input->post("taxpercet_".$i);
			$invoiceno=$this->input->post("invoiceinfo_".$i);
			
			if(isset($excise))
			{
				//echo $excise;
				//echo "<br>";
				///invoice table update 
				$getexstatus=$this->Account_model->getexstatus($invoiceno);
				foreach($getexstatus as $roest){ $cstvatstatus=intval($roest->cstvatstatus);}
				if($cstvatstatus==1)
				{
					$datainvoice=array(
					"excisestatus"=>"1",
					"taxstatus"=>"1"
				   );
				   $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}else{
					$datainvoice=array(
					"excisestatus"=>"1"
				   );
				   $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}
				///taxduty table insert
				$getinsertstatus=$this->Account_model->getinsertstatus($invoiceno);
				if(empty($getinsertstatus))
				{
					$datatacduyinsert=array(
						"doe"=>$date,
						"invoiceno"=>$invoiceno,
						"excisepercent"=>$exciseper,
						"excise"=>$excise,
						"totalliab"=>$total,
						"crtdby"=>$this->session->userdata('user_name'),
						"dos"=>date('Y-m-d h:i:s A')
					
					);
					$this->Account_model->savetaxandduty($datatacduyinsert);
				}else{
					foreach($getinsertstatus as $rowtaxduty)
					{
						$excise=floatval($rowtaxduty->excise);
						$cst=floatval($rowtaxduty->cstamnt);
						$vat=floatval($rowtaxduty->vatamnt);
						
					}
				 	$tottaxduty=$excise+$cst+$vat;
					$dataupdatetaxduty=array(
						"doe"=>$date,
						"invoiceno"=>$invoiceno,
						"excisepercent"=>$exciseper,
						"excise"=>$excise,
						"totalliab"=>$tottaxduty,
						"crtdby"=>$this->session->userdata('user_name'),
						"dos"=>date('Y-m-d h:i:s A')
					
					);
					$this->Account_model->updatetaxandduty($dataupdatetaxduty,$invoiceno);
					
				}
				
			}
			if(isset($cstvat))
			{
				///invoice table update
				$getexstatus=$this->Account_model->getexstatus($invoiceno);
				foreach($getexstatus as $roest){ $excisestatus=intval($roest->excisestatus);}
				if($excisestatus==1)
				{
					$datainvoice=array(
					"cstvatstatus"=>"1",
					"taxstatus"=>"1"
				   );
				  $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}else{
					$datainvoice=array(
					"cstvatstatus"=>"1"
				   );
				   $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}
				
			///taxduty table insert
			   if(strtoupper($cstsvatinfo)=="CST")
			   {
			   		$getinsertstatus=$this->Account_model->getinsertstatus($invoiceno);
					if(empty($getinsertstatus))
					{
						$datatacduyinsert=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"cstpercent"=>$cstvatper,
							"cstamnt"=>$cstvat,
							"totalliab"=>$total,
							"crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->savetaxandduty($datatacduyinsert);
					}else{
						foreach($getinsertstatus as $rowtaxduty)
						{
							$excise=floatval($rowtaxduty->excise);
							$cst=floatval($rowtaxduty->cstamnt);
							$vat=floatval($rowtaxduty->vatamnt);
							
						}
						 $tottaxduty=$excise+$cst+$vat+floatval($cstvat);
						$dataupdatetaxduty=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"cstpercent"=>$cstvatper,
							"cstamnt"=>$cstvat,
							"totalliab"=>$tottaxduty,
							"crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->updatetaxandduty($dataupdatetaxduty,$invoiceno);
						
					}
			   	
			   }
               if(strtoupper($cstsvatinfo)=="VAT")
			   {
			   		$getinsertstatus=$this->Account_model->getinsertstatus($invoiceno);
					if(empty($getinsertstatus))
					{
						$datatacduyinsert=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"vatpercent"=>$cstvatper,
							"vatamnt"=>$total,
							"totalliab"=>$total,
							"crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->savetaxandduty($datatacduyinsert);
					}else{
						foreach($getinsertstatus as $rowtaxduty)
						{
							$excise=floatval($rowtaxduty->excise);
							$cst=floatval($rowtaxduty->cstamnt);
							$vat=floatval($rowtaxduty->vatamnt);
							
						}
						 $tottaxduty=$excise+$cst+$vat+floatval($cstvat);
						$dataupdatetaxduty=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"vatpercent"=>$cstvatper,
							"vatamnt"=>$cstvat,
							"totalliab"=>$tottaxduty,
							"crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->updatetaxandduty($dataupdatetaxduty,$invoiceno);
						
					}
			   	
			   }
               //cash in hand transaction
               
				
			}
		}
		if(strtoupper($paytyp)=="CASH")
			   {
			   	         $getlastbalance=$this->Account_model->getallcashinhandlastbalance();
						 foreach($getlastbalance as $rowcash){ $balance=floatval($rowcash->closebal);}
			   				$totalcash=floatval($balance)-floatval($total);
							$data_array_cashinhand=array(
								"closebal"=>$totalcash
							
							);
							$this->Account_model->updatecashinhand($data_array_cashinhand);
							$getlasbalanceincashtrans=$this->Account_model->getlasttransbalance();
							if(!empty($getlasbalanceincashtrans)){
							foreach($getlasbalanceincashtrans as $rowtrans)
							{
								$balancetrns=floatval($rowtrans->balance);
								$txno=$rowtrans->txnno;
							}
							$txnost=intval(substr($txno, -6));
							$nexttx=$txnost+1;
							
							$nexttx2=str_pad($nexttx,6,"0", STR_PAD_LEFT);
							$newtxno="TXNGK".$nexttx2;
							}else
								{
									$newtxno="TXNGK000001";
								}
							$tranbal=floatval($balancetrns)-floatval($total);
							$data_array_trans=array(
								"credit"=>$total,
								"balance"=>$tranbal,
								"doe"=>date('Y-m-d'),
								"crtd"=>$this->session->userdata('user_name'),
								"txnno"=>$newtxno,
								"cdoe"=>date('Y-m-d h:i:s A')
							);
							$this->Account_model->getbalancetransupdate($data_array_trans);
			   			
			   		
			   	
			   }
			   //cash in bank transaction  
			   if(strtoupper($paytyp)=="BANK")
			   {
			           $getlastbalancebank=$this->Account_model->getallbank($accno);
						 foreach($getlastbalancebank as $rowbalance){ $balancebank=floatval($rowbalance->balance);}
						 //echo $balancebank;
						 // "<br>";
			   				 $totalcashbank=floatval($balancebank)-floatval($total);
							$data_array_cashinbank=array(
								"balance"=>$totalcashbank
							
							);
							$this->Account_model->updatecashinbank($data_array_cashinbank,$accno);
							$getlasbalanceinbanktrans=$this->Account_model->getlastbanktransbalance($accno);
							if(!empty($getlasbalanceinbanktrans)){
							foreach($getlasbalanceinbanktrans as $rowtrans)
							{
								$balancetrns=floatval($rowtrans->balance);
								$txno=$rowtrans->txnno;
							}
							$txnost=intval(substr($txno, -6));
							$nexttx=$txnost+1;
							
							$nexttx2=str_pad($nexttx,6,"0", STR_PAD_LEFT);
							$newtxno="TXNGK".$nexttx2;
							}else
								{
									$newtxno="TXNGK000001";
								} //echo "<br>";
						     $tranbal=floatval($balancetrns)-floatval($total);
						
							$data_array_trans_bank=array(
								"credit"=>$total,
								"balance"=>$tranbal,
								"doe"=>date('Y-m-d'),
								"crtd"=>$this->session->userdata('user_name'),
								"cdoe"=>date('Y-m-d h:i:s A'),
								"txnno"=>$newtxno,
							);
							$this->Account_model->getbankbalancetransupdate($data_array_trans_bank);
			   			
			   		
			   }
             redirect("Accounts_controller/viewinfo",'refresh');
	}
	
   
}