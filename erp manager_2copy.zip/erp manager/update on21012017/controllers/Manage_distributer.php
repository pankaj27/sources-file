<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_distributer extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Distributer_model');
	}
	public function index()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));	
		$data['title']="Dashboard";
		$data['alldistributer']=$this->Distributer_model->getalldistributer();
		$this->load->view("Distributer/viewdistributer",$data);
	}
	public function createnew()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));	
		$data['title']="Dashboard";
		$data['country']=$this->Distributer_model->getcountry();
		$data['customertype']=$this->Distributer_model->getcustomertyp();
		$lastid=$this->Distributer_model->getlastid();
		if(empty($lastid))
		{
			$lastid=1;
		}else{
			$lastid=intval($lastid)+1;
		}
		$data['lastid']="GKCLNT".date('y').str_pad($lastid, 5 , '0', STR_PAD_LEFT);
		
		$this->load->view("Distributer/create",$data);
	}
	public function savenewdistributer()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));	
		$path="uploads/clientpics/";
		date_default_timezone_set("asia/Kolkata");
		$custname=$this->input->post('custname');
		$custid=$this->input->post('custid');
		$custtype=strtoupper($this->input->post("custtype"));
		if($custtype=="DEALER" || $custtype=="SUB-DEALER" )
		{
			$cnf=$this->input->post("cnf");
		}else{
			$cnf="";
		}
		if($custtype=="SUB-DEALER" )
		{
			$dealer=$this->input->post("dealer");
		}else{
			$dealer="";
		}
		if($custtype=="DEALER")
		{
			$custid="D$custid";
		}
		if($custtype=="CNF")
		{
			$custid="C$custid";
		}
		if($custtype=="SUB-DEALER")
		{
			$custid="SD$custid";
		}
		if($custtype=="RETAILER")
		{
			$custid="R$custid";
		}
		//$cnf=$this->input->post("");
		$interest=$this->input->post("percentage");
		$agreement=$this->input->post("agreement");
		$compname=$this->input->post('compname');
		$password=$this->input->post("password");
		$openbal=$this->input->post("openbal");
		$ph=$this->input->post('ph');
		$ph1=$this->input->post('ph2');
		$email=$this->input->post('email');
		$email1=$this->input->post('email2');
		$password=$this->input->post("password");
		$openbal=$this->input->post("openbal");
		$add1=$this->input->post('add1');
		$add2=$this->input->post('add2');
		$country=$this->input->post('country');
		$state=$this->input->post('state');
		if(isset($state))
		{
		 $state=$state;
		}else{
			$state="";
		}
		$district=$this->input->post('district');
		$area=$this->input->post('area');
		$pin=$this->input->post('pin');
		$pan=$this->input->post('pan');
		$tin_vat=$this->input->post('tin');
		//$vat=$this->input->post('vat');
		$excise=$this->input->post('excise');
		$cst=$this->input->post('cst');
		//bank details=======
		$bankname1=$this->input->post("bankname1");
		$acname=$this->input->post("acname1");
		$acno1=$this->input->post("acno1");
		$branch1=$this->input->post("branch1");
		$ifsc1=$this->input->post("ifsc1");
		$swift1=$this->input->post("swift1");
		///////////////////////// 2nd bank details  /////////////////////////////////
		$bankname2=$this->input->post("bank2");
		$acname2=$this->input->post("acname2");
		$acno2=$this->input->post("acno2");
		$branch2=$this->input->post("branch2");
		$ifsc2=$this->input->post("ifsc2");
		$swift2=$this->input->post("swift2");
		/*$acno2=$this->input->post("acno2");
		$bank2=$this->input->post("bank2");
		$branch2=$this->input->post("branch2");
		$ifsc2=$this->input->post("ifsc2");	*/
		//end of bank details==
		$fact1=$this->input->post('fact1');
		$fact2=$this->input->post('fact2');
		$fact3=$this->input->post('fact3');
		$shr1=$this->input->post('shr1');
		$shr2=$this->input->post('shr2');
		$shr3=$this->input->post('shr3');
		$file1=$_FILES['image1']['name'];
		$image1=$this->imageupload($file1,"image1",$path);
		//$image1=$this->input->post('image1');
		$data_array=array(
			"clientid"=>$custid,
			"custtype"=>$custtype,
			"cnf"=>$cnf,
			"dealer"=>$dealer,
			"interest"=>$interest,
			"agreemnt_validity"=>$agreement,
			"name"=>$custname,
			"image"=>$image1,
			"compname"=>$compname,
			"phone"=>$ph,
			"phno2"=>$ph1,
			"email"=>$email,
			"pass"=>$password,
			"openbal"=>$openbal,
			"acname1"=>$acname,
			"acname2"=>$acname2,
			"swift1"=>$swift1,
			"swift2"=>$swift2,
			"email2"=>$email1,
			"add1"=>$add1,
			"add2"=>$add2,
			"country"=>$country,
			"state"=>$state,
			"district"=>$district,
			"area"=>$area,
			"pin"=>$pin,
			"pan"=>$pan,
			"tin_vat"=>$tin_vat,
			//"vat"=>$vat,
			"cst"=>$cst,
			"excise"=>$excise,
			"acno1"=>$acno1,
			"bank1"=>$bankname1,
			"branch1"=>$branch1,
			"ifsc1"=>$ifsc1,
			"acno2"=>$acno2,
			"bank2"=>$bankname2,
			"branch2"=>$branch2,
			"ifsc2"=>$ifsc2,
			
			"factory1"=>$fact1,
			"factory2"=>$fact2,
			"factory3"=>$fact3,
			"showroom1"=>$shr1,
			"showroom2"=>$shr2,
			"showroom3"=>$shr3,
			
			"doe"=>date('Y-m-d h:i:s A')
			//"sid"=>$this->session->userdata('uid'),
			//"sname"=>$this->session->userdata('uname')
		);
		//if($image1!="")
		//{
			$data['email']=$email;
			$data['pasword']=$password;
			$getres=$this->Distributer_model->saveclentdetails($data_array);
			if($getres==1)
			{
				$this->load->view("send_mail/senddistributermail",$data);
				redirect('Manage_distributer','refresh');
			}else{
				redirect('Manage_distributer/createnew','refresh');
			}
			//redirect('Manage_customer/viewclientlist','refresh');
		//}else
		//{
				//redirect('Manage_customer/createcustomer','refresh');
		//}
	}
public function imageupload($file,$name,$path)
	{
		$image=$file;
		if($image != '')
		{
			$allowedtype = "jpg|gif|png|jpeg|JPEG";
			$max_size = '';
			$max_width = '0';
			$max_height = '0';
			$upload_path = $path;
			$config['upload_path'] = $upload_path;
			$config['allowed_types'] = $allowedtype;
			$config['max_size']	= $max_size;
			$config['max_width'] = $max_width;
			$config['max_height'] = $max_height;
			$config['overwrite'] = FALSE;
			//$file_name = $file['prod_image']['name'];
			$file_name = $file;
			$file_name = preg_replace('/[\s,$#&\+\-()\[\];\'~`]/','_',$file_name);
			$f_name=time()."_".$file_name;
			$config['file_name'] = $f_name;
			//$config['orig_name'] = $file['prod_image']['name'];
			$config['orig_name'] = $file;
			$this->upload->initialize($config);
			if($this->upload->do_upload($name))
			{
				$data = array('upload_data' => $this->upload->data());
				$latest_filename_rtr = $data['upload_data']['file_name'];
				//generate the thumb image from the main image 
				$config['image_library'] = 'gd2'; 
				$config['source_image'] = "uploads/clientpics/".$latest_filename_rtr; 
				//$config['new_image'] = "uploads/thumb_images/"; 
				$config['thumb_marker'] = ''; 
				$config['create_thumb'] = TRUE; 
				$config['maintain_ratio'] = TRUE; 
				$config['width'] = 185; 
				$config['height'] = 185; 
				$this->image_lib->initialize($config); 
				if (!$this->image_lib->resize())
				{ 

				} 
				return $latest_filename_rtr;
			}
			else
			{
				print($this->upload->display_errors());
				return '';  
				
			}
			
		}
		else
			return '';   
				  
		
	}
  public function getstate()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $country=$this->input->post("country");
	  $getstate=$this->Distributer_model->getstatename($country);
	  if(!empty($getstate) && isset($getstate))
	  {
	  	echo "<select id='state2' name='state' class='form-control'>";
		echo "<option value=''></option>";
	  	foreach($getstate as $row )
		{
			echo "<option value='".$row->statename."'>".$row->statename."</option>";
		}
		echo "</select>";
	  }
	}
	public function editdistributer($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$data['country']=$this->Distributer_model->getcountry();
		$data['customertype']=$this->Distributer_model->getcustomertyp();
		$country="In";
		$data['getstate2']=$this->Distributer_model->getstatename($country);
		$data['getalldistributer']=$this->Distributer_model->getditr($id);
		
		$this->load->view("Distributer/create",$data);
	}
	public function updatedistributer()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$path="uploads/clientpics/";
		date_default_timezone_set("asia/Kolkata");
		$id=$this->input->post("dist_id");
		$custname=$this->input->post('custname');
		$custid=$this->input->post('custid');
		$custtype=strtoupper($this->input->post("custtype"));
		if($custtype=="DEALER" || $custtype=="SUB-DEALER" )
		{
			$cnf=$this->input->post("cnf");
		}else{
			$cnf="";
		}
		if($custtype=="SUB-DEALER" )
		{
			$dealer=$this->input->post("dealer");
		}else{
			$dealer="";
		}
		$interest=$this->input->post("percentage");
		$agreement=$this->input->post("agreement");
		
		$compname=$this->input->post('compname');
		$password=$this->input->post("password");
		$openbal=$this->input->post("openbal");
		$ph=$this->input->post('ph');
		$ph1=$this->input->post('ph2');
		$email=$this->input->post('email');
		$email1=$this->input->post('email2');
		$password=$this->input->post("password");
		$openbal=$this->input->post("openbal");
		$add1=$this->input->post('add1');
		$add2=$this->input->post('add2');
		$country=$this->input->post('country');
		$state=$this->input->post('state');
		if(isset($state))
		{
		 $state=$state;
		}else{
			$state="";
		}$district=$this->input->post('district');
		$area=$this->input->post('area');
		$pin=$this->input->post('pin');
		$pan=$this->input->post('pan');
		$tin_vat=$this->input->post('tin');
		//$vat=$this->input->post('vat');
		$excise=$this->input->post('excise');
		$cst=$this->input->post('cst');
		//bank details=======
		$bankname1=$this->input->post("bankname1");
		$acname=$this->input->post("acname1");
		$acno1=$this->input->post("acno1");
		$branch1=$this->input->post("branch1");
		$ifsc1=$this->input->post("ifsc1");
		$swift1=$this->input->post("swift1");
		///////////////////////// 2nd bank details  /////////////////////////////////
		$bankname2=$this->input->post("bank2");
		$acname2=$this->input->post("acname2");
		$acno2=$this->input->post("acno2");
		$branch2=$this->input->post("branch2");
		$ifsc2=$this->input->post("ifsc2");
		$swift2=$this->input->post("swift2");
		/*$acno2=$this->input->post("acno2");
		$bank2=$this->input->post("bank2");
		$branch2=$this->input->post("branch2");
		$ifsc2=$this->input->post("ifsc2");	*/
		//end of bank details==
		$fact1=$this->input->post('fact1');
		$fact2=$this->input->post('fact2');
		$fact3=$this->input->post('fact3');
		$shr1=$this->input->post('shr1');
		$shr2=$this->input->post('shr2');
		$shr3=$this->input->post('shr3');
		$file1=$_FILES['image1']['name'];
		if(!empty($file1)){
			$image1=$this->imageupload($file1,"image1",$path);
		//$image1=$this->input->post('image1');
		$data_array=array(
			"name"=>$custname,
			"custtype"=>$custtype,
			"cnf"=>$cnf,
			"dealer"=>$dealer,
			"interest"=>$interest,
			"agreemnt_validity"=>$agreement,
			"image"=>$image1,
			"compname"=>$compname,
			"phone"=>$ph,
			"phno2"=>$ph1,
			"email"=>$email,
			"pass"=>$password,
			"openbal"=>$openbal,
			"acname1"=>$acname,
			"acname2"=>$acname2,
			"swift1"=>$swift1,
			"swift2"=>$swift2,
			"email2"=>$email1,
			"add1"=>$add1,
			"add2"=>$add2,
			"country"=>$country,
			"state"=>$state,
			"district"=>$district,
			"area"=>$area,
			"pin"=>$pin,
			"pan"=>$pan,
			"tin_vat"=>$tin_vat,
			//"vat"=>$vat,
			"cst"=>$cst,
			"excise"=>$excise,
			"acno1"=>$acno1,
			"bank1"=>$bankname1,
			"branch1"=>$branch1,
			"ifsc1"=>$ifsc1,
			"acno2"=>$acno2,
			"bank2"=>$bankname2,
			"branch2"=>$branch2,
			"ifsc2"=>$ifsc2,
			
			"factory1"=>$fact1,
			"factory2"=>$fact2,
			"factory3"=>$fact3,
			"showroom1"=>$shr1,
			"showroom2"=>$shr2,
			"showroom3"=>$shr3,
			
			"doe"=>date('Y-m-d h:i:s A')
			//"sid"=>$this->session->userdata('uid'),
			//"sname"=>$this->session->userdata('uname')
		);
			
		}else{
			//$image1=$this->imageupload($file1,"image1",$path);
		//$image1=$this->input->post('image1');
		$data_array=array(
			
			"name"=>$custname,
			"compname"=>$compname,
			"phone"=>$ph,
			"phno2"=>$ph1,
			"email"=>$email,
			"pass"=>$password,
			"openbal"=>$openbal,
			"acname1"=>$acname,
			"acname2"=>$acname2,
			"swift1"=>$swift1,
			"swift2"=>$swift2,
			"email2"=>$email1,
			"add1"=>$add1,
			"add2"=>$add2,
			"country"=>$country,
			"state"=>$state,
			"district"=>$district,
			"area"=>$area,
			"pin"=>$pin,
			"pan"=>$pan,
			"tin_vat"=>$tin_vat,
			//"vat"=>$vat,
			"cst"=>$cst,
			"excise"=>$excise,
			"acno1"=>$acno1,
			"bank1"=>$bankname1,
			"branch1"=>$branch1,
			"ifsc1"=>$ifsc1,
			"acno2"=>$acno2,
			"bank2"=>$bankname2,
			"branch2"=>$branch2,
			"ifsc2"=>$ifsc2,
			
			"factory1"=>$fact1,
			"factory2"=>$fact2,
			"factory3"=>$fact3,
			"showroom1"=>$shr1,
			"showroom2"=>$shr2,
			"showroom3"=>$shr3,
			
			"doe"=>date('Y-m-d h:i:s A')
			//"sid"=>$this->session->userdata('uid'),
			//"sname"=>$this->session->userdata('uname')
		);	
			
		}
		$this->Distributer_model->updatedistributer($data_array,$id);
		redirect('Manage_distributer','refresh');
		
		
	}
  public function deletedistributer($id)
  {
  	    $this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$this->Distributer_model->delete_distr($id);
		redirect('Manage_distributer','refresh');
		
  	
  }
  public function get_cnflist()
  {
  	//  $this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $ctyp=$this->input->post("custype");
	  $getcnflist=$this->Distributer_model->get_cnflistmodel($ctyp);
	  if(!empty($getcnflist) && isset($getcnflist))
	  {
	  	
		echo '<div class="form-group">
										
					<select name="cnf" id="cnf" class="form-control" onchange="getdealer();" >
							 <option value=""></option>';
							foreach($getcnflist as $row3)
		          {
										
											echo '<option value="'. $row3->compname.'">'. $row3->compname.'</option>';
																
																
											
															
			       } 
										echo '</select>
											<label for="mName">CNF LIST</label>
										</div>';
	  	
			
		
	  }else{
	  	
	  }
  }
  
  public function getdelaerlist()
  {
  	$cnf=$this->input->post("cnf");
	  $getdealer=$this->Distributer_model->get_dealer($cnf);
	  if(!empty($getdealer) && isset($getdealer))
	  {
	  	
		echo '<div class="form-group">
										
					<select name="dealer" id="dealer" class="form-control"  >
							<option value=""></option>';
							foreach($getdealer as $row3)
		          {
										
											echo '<option value="'. $row3->compname.'">'. $row3->compname.'</option>';
																
																
											
															
			       } 
										echo '</select>
											<label for="mName">DEALER LIST</label>
										</div>';
	  	
			
		
	  }else{
	  	
	  }
  }
	
}