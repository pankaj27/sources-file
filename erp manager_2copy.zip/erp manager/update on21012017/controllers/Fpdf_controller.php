<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fpdf_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		//$this->load->model('Purchase_model');
	}
	 public function index() {	
		$this->load->library('fpdf_gen');
		
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Cell(40,10,'Hello World!');
		
		$filename="Fpdfoutput/test.pdf";
        //$this->fpdf->Output($filename,'F');
		 $this->fpdf->Output("$filename",'F');
	}
	
}