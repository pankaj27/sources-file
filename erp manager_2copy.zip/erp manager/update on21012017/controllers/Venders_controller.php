<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Venders_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Venders_model');
	}
	public function createVenders()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
		$data['countries']=$this->Venders_model->get_country();
		$data['spareparts']=$this->Venders_model->getalspareparts();
		$data['products']=$this->Venders_model->getallproducts();
		$data['allvendors']=$this->Venders_model->getall_vendors_list();
    	$this->load->view('venders/create',$data);
	}
	public function save_venders()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
		//$vname=$this->input->post('vname');
		$vemail=$this->input->post('vemail');
		$vphno=$this->input->post('vphno');
		$vaddress1=$this->input->post('add1');
		$vaddress2=$this->input->post('add2');
		$vpin=$this->input->post('pin');
		$country=$this->input->post('country');
		
		$state=$this->input->post('state');
		
		$vcompany=$this->input->post('vcompany');
		$bank1=$this->input->post('bank1');
		$bankac1=$this->input->post('bankac1');
		$bankifsc1=$this->input->post('bankifsc1');
		$bankswift1=$this->input->post('bankswift1');
		$bankbr1=$this->input->post('bankbr1');
		/*------------------------*/
		$bank2=$this->input->post('bank2');
		$bankac2=$this->input->post('bankac2');
		$bankifsc2=$this->input->post('bankifsc2');
		$bankswift2=$this->input->post('bankswift2');
		$bankbr2=$this->input->post('bankbr2');
		/*------------company info -----*/
		$cstno=$this->input->post('cstno');	
		$vatno=$this->input->post('vatno');
		$iecno=$this->input->post('iecno');
		$tinno=$this->input->post('tinno');
		
		
		$contactname1=$this->input->post('contactname1');
		$contactemail1=$this->input->post('contactemail1');
		$contactphone1=$this->input->post('contactphno1');
		$contactname2=$this->input->post('contactname2');
		$contactemail2=$this->input->post('contactemail2');
		$contactphone2=$this->input->post('contactphno2');
		$material1=$this->input->post('material');
		if(empty($material1))
		{
			$material="";
		}else{
			$material=implode(",",$material1);
		}
		
		$product1=$this->input->post('product');
		if(empty($product1))
		{
			$product="";
		}
		else{
			$product=implode(",",$product1);
		}
		
		$checkdataex=$this->Venders_model->getdat_ex();
		if(empty($checkdataex))
		{
			$vid="GK/".date('Ymd'). 1;
		}else{
			$getlastid=$this->Venders_model->getlastid();
			foreach($getlastid as $row){
				 $vid=$row->vender_id;
			}
			 $vid1=substr($vid,10);
			$vid2=intval($vid1);
			 $vid3=$vid2+1;
			 $vid="GK/".date('Ymd'). $vid3;
			
		}
		$data_array=array(
		    "vender_id"=>$vid,
			//"vname"=>$contactname1,
			"vcompany"=>$vcompany,
			"vemail"=>$vemail,
			"vphno"=>$vphno,
			"add1"=>$vaddress1,
			"add2"=>$vaddress2,
			"cst"=>$cstno,
			"vat"=>$vatno,
			"IEC_No"=>$iecno,
			"TIN_No"=>$tinno,
			"pin"=>$vpin,
			"country"=>$country,
			"state"=>$state,
			"contactname1"=>$contactname1,
			"contactemail1"=>$contactemail1,
			"contactphno1"=>$contactphone1,
			"contactname2"=>$contactname2,
			"contactemail2"=>$contactemail2,
			"contactphno2"=>$contactphone2,
			"material"=>$material,
			"products"=>$product,
			"bankname1"=>$bank1,
			"bankacc1"=>$bankac1,
			"bankifsc1"=>$bankifsc1,
			"bankswift1"=>$bankswift1,
			"branch1"=>$bankbr1,
			"bankname2"=>$bank2,
			"bankacc2"=>$bankac2,
			"bankifsc2"=>$bankifsc2,
			"bankswift2"=>$bankswift2,
			"branch2"=>$bankbr2
			
		);
		
		
		//print_r($data_array);exit();
		$getdata=$this->Venders_model->check_data_exist($vemail,$vphno);
		if(empty($getdata))
		{
			
			
		     $message='Venders Account Succesfully Created.....';
		     $this->session->set_flashdata('message',$message);
			 $res=$this->Venders_model->insert_venderlist($data_array);
			
		}else{
			$message='Account Alraedy Exist.....';
		    $this->session->set_flashdata('message',$message);
		}
		redirect('Venders_controller/viewvendors','refresh');
    	//$this->load->view('venders/create',$data);
	}
	public function editvendorsdetails($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$vid=$id;
		$data['getvendorsdetails']=$this->Venders_model->getvendorsdetails($vid);
		$data['title']='User Dash Board ';
		$data['countries']=$this->Venders_model->get_country();
		$data['spareparts']=$this->Venders_model->getalspareparts();
		$data['products']=$this->Venders_model->getallproducts();
		$data['allvendors']=$this->Venders_model->getall_vendors_list();
		$this->load->view('venders/create',$data);
		
	}
	public function updatevendors()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$vid=$this->input->post('vid');
		//$vname=$this->input->post('vname');
		$vemail=$this->input->post('vemail');
		$vphno=$this->input->post('vphno');
		$vaddress1=$this->input->post('add1');
		$vaddress2=$this->input->post('add2');
		$vpin=$this->input->post('pin');
		$country=$this->input->post('country');
		$state=$this->input->post('state');
		
		$vcompany=$this->input->post('vcompany');
		$bank1=$this->input->post('bank1');
		$bankac1=$this->input->post('bankac1');
		$bankifsc1=$this->input->post('bankifsc1');
		$bankswift1=$this->input->post('bankswift1');
		$bankbr1=$this->input->post('bankbr1');
		/*------------------------*/
		$bank2=$this->input->post('bank2');
		$bankac2=$this->input->post('bankac2');
		$bankifsc2=$this->input->post('bankifsc2');
		$bankswift2=$this->input->post('bankswift2');
		$bankbr2=$this->input->post('bankbr2');
		/*------------company info -----*/
		$cstno=$this->input->post('cstno');	
		$vatno=$this->input->post('vatno');
		$iecno=$this->input->post('iecno');
		$tinno=$this->input->post('tinno');
		
		
		$contactname1=$this->input->post('contactname1');
		$contactemail1=$this->input->post('contactemail1');
		$contactphone1=$this->input->post('contactphno1');
		$contactname2=$this->input->post('contactname2');
		$contactemail2=$this->input->post('contactemail2');
		$contactphone2=$this->input->post('contactphno2');
		$material1=$this->input->post('material');
		if(empty($material1)){
			$material="";
		}else{
			$material=implode(",",$material1);
		}
		$product1=$this->input->post('product');
		if(empty($product1)){
			$product="";
		}else{
			$product=implode(",",$product1);
		}
		$checkdataex=$this->Venders_model->getdat_ex();
		$data_array=array(
		   //"vname"=>$contactname1,
			"vcompany"=>$vcompany,
			"vemail"=>$vemail,
			"vphno"=>$vphno,
			"add1"=>$vaddress1,
			"add2"=>$vaddress2,
			"cst"=>$cstno,
			"vat"=>$vatno,
			"IEC_No"=>$iecno,
			"TIN_No"=>$tinno,
			"pin"=>$vpin,
			"country"=>$country,
			"state"=>$state,
			"contactname1"=>$contactname1,
			"contactemail1"=>$contactemail1,
			"contactphno1"=>$contactphone1,
			"contactname2"=>$contactname2,
			"contactemail2"=>$contactemail2,
			"contactphno2"=>$contactphone2,
			"material"=>$material,
			"products"=>$product,
			"bankname1"=>$bank1,
			"bankacc1"=>$bankac1,
			"bankifsc1"=>$bankifsc1,
			"bankswift1"=>$bankswift1,
			"branch1"=>$bankbr1,
			"bankname2"=>$bank2,
			"bankacc2"=>$bankac2,
			"bankifsc2"=>$bankifsc2,
			"bankswift2"=>$bankswift2,
			"branch2"=>$bankbr2
			
		);
		$update=$this->Venders_model->update_vendors($data_array,$vid);
		if($update==1)
		{
			 $message1='Venders Account Updated Succesfully .....';
		     $this->session->set_flashdata('message',$message1);
			 //$res=$this->Venders_model->insert_venderlist($data_array);
		}else{
			 $message2='Sorry !There Is an error.....';
		     $this->session->set_flashdata('message2',$message2);
			 //$res=$this->Venders_model->insert_venderlist($data_array);
		}
		redirect('Venders_controller/viewvendors','refresh');
	}
	public function deleteVemdors($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$vid=$id;
		$delete=$this->Venders_model->delete_vendors($vid);
		if($delete==1)
		{
		 $message1='Account Deleted Succesfully .....';
		     $this->session->set_flashdata('message',$message1);
			 //$res=$this->Venders_model->insert_venderlist($data_array);
		}else{
			 $message2='Sorry !There Is an error.....';
		     $this->session->set_flashdata('message2',$message2);
		}
		redirect('Venders_controller/viewvendors','refresh');
		
	}
	public function viewvendors()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
		$data['countries']=$this->Venders_model->get_country();
		$data['spareparts']=$this->Venders_model->getalspareparts();
		$data['products']=$this->Venders_model->getallproducts();
		$data['allvendors']=$this->Venders_model->getall_vendors_list();
    	$this->load->view('venders/view',$data);
	}
	public function get_stateName()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$country=$this->input->post("country");
		if($country==77){
			$state=$this->Venders_model->fetchState();
              echo ' <select class="form-control select2-list" data-placeholder="Select an item" name="state" id="state">';			
					echo '	<option value="">Select State Name</option>';
					 if(isset($state)){ 
						 foreach($state as $row){ 
					 echo '  <option value="'.$row->statename.'">'.$row->statename.'</option>';
											
					 }}
				echo'</select>';
			
		}else{
			echo' <input type="text" class="form-control" id="state" name="state" value=" ">';
			echo '<label for="state">Enter State Name</label>';
		}
	}
}