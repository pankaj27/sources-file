<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manufactarer_Controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		//$this->load->library(array('session','authentication'));
		$this->load->model('Manufactarer_model');
	}
	public function  craeteModel()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Manufacturer';
		$data['modellist']=$this->Manufactarer_model->getallmodel();
		//$data['getcolor']=$this->Manufactarer_model->getallcolor();
		$this->load->view('Manufacturer/create',$data);
	}
	public function getchasis()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Get Chasis Details';
		date_default_timezone_set('Asia/kolkata');
		$dte=$this->input->post("datename");
		$model=$this->input->post("model");
		$color=$this->input->post("color");
		$qty=$this->input->post("qty");
		
		$mnth=date('m');
		$getmonthcode=$this->Manufactarer_model->getmnthcode($mnth);
		$yr=date('Y');
		$yrt=date('y');
		//$data['modellist']=$this->Manufactarer_model->getallmodel();
		$getchasisno=$this->Manufactarer_model->getallchasisdt($yr,$getmonthcode);
		if(!empty($getchasisno)){
			
			foreach($getchasisno as $row3)
			{
				$chasisno=$row3->chasisno;
			}
			
			$data['chasisdetails']=$chasisno;
			$data['mnthcode']=$getmonthcode;
			$data['yrcode']=$yrt;
			//$chasisid=intval(substr($chasisno, -4));
			//echo $chasisid
			
		}else{
			$data['chasisdetails']="M6REP3085".$getmonthcode.$yrt."B0000";
			$data['mnthcode']=$getmonthcode;
			$data['yrcode']=$yrt;
		}
		$data['dte']=$dte;
		$data['model']=$model;
		$data['color']=$color;
		$data['qty']=$qty;
		$data['modellist']=$this->Manufactarer_model->getallmodel();
		//$data['getlast']
		$this->load->view('Manufacturer/create',$data);
		
	}
	public function printWriteForm()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Print Write Form';
		date_default_timezone_set('Asia/kolkata');
		$dte=$this->input->post("date");
		$mnthcode=$this->input->post("mnthcode");
		$yrcode=$this->input->post("yrcode");
		$chasisno=$this->input->post("chasisno");
		$qty=$this->input->post("qty");
		$model=$this->input->post("model");
		$date=date('d-m-Y h:i:s A');
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		//$this->fpdf->Addpage('legal');
		$this->fpdf->Image("$path",10,10,-300);
		
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->Text(130,45,"Date:$date");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,54,200,54);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,55,200,55);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		//$this->fpdf->Ln($y);
		//$this->fpdf->Ln(30);
		$this->fpdf->ln($y+40);
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Cell(190,10,"FORM M",0,0,'C');	
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',8);
		$this->fpdf->cell(10,5,"SL",1,0,'C');
		$this->fpdf->cell(12,5,"MODEL",1,0,'C');
		$this->fpdf->cell(30,5,"CHS NO",1,0,'C');
		$this->fpdf->cell(30,5,"CTRL NO",1,0,'C');
		$this->fpdf->cell(28,5,"MTR NO",1,0,'C');
		$this->fpdf->cell(19,5,"BTR1",1,0,'C');
		$this->fpdf->cell(19,5,"BTR2",1,0,'C');
		$this->fpdf->cell(19,5,"BTR3",1,0,'C');
		$this->fpdf->cell(19,5,"BTR4",1,1,'C');
		$chasisd=$chasisno;
		$lastfid=intval(substr($chasisd,-4));
		$lastid1=intval($lastfid)+1;
							   
		for($i=0;$i<intval($qty);$i++)
		{
			$sl=$i+1;
			$chasisnonew="M6REP3085".$mnthcode.$yrcode."B".str_pad($lastid1,4 ,'0',STR_PAD_LEFT);
			$this->fpdf->SetFont('Arial','',7);
			$this->fpdf->cell(10,10,"$sl",1,0,'C');
			$this->fpdf->cell(12,10,"$model",1,0,'C');
			$this->fpdf->cell(30,10,"$chasisnonew",1,0,'C');
			$this->fpdf->cell(30,10,"",1,0,'C');
			$this->fpdf->cell(28,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,1,'C');
			$lastid1++;
			
			
		}
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		
		 $this->fpdf->Output();
	} 
	
}