<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_salesman extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Manage_salesman_model');
	}
		public function create()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$data['title']="Add Employee";
			$getlastid=$this->Manage_salesman_model->getlastid();
			$data['departments']=$this->Manage_salesman_model->getdepartments();
			if(empty($getlastid))
			{
				$invID=1;
				$sid="GKSLS".str_pad($invID, 4 , '0', STR_PAD_LEFT);
			}else
			{
					$invID=intval($getlastid)+1;
				    $sid="GKSLS".str_pad($invID, 4 , '0', STR_PAD_LEFT);
			}
			$data['empid']=$sid;
			$this->load->view('managesalesman/create',$data);
		}
		public function savesalesman()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			//$data['title']="View Salesman";
			$getlastid=$this->Manage_salesman_model->getlastid();
			if(empty($getlastid))
			{
				$invID=1;
				$sid="GKSLS".str_pad($invID, 4 , '0', STR_PAD_LEFT);
			}else
			{
					$invID=intval($getlastid)+1;
				    $sid="GKSLS".str_pad($invID, 4 , '0', STR_PAD_LEFT);
			}
			$path="uploads/Salesman/";
			$name=$this->input->post('salesman');
			
			$email=$this->input->post('salemail');
			$dept=$this->input->post('departments');
			$desg=$this->input->post('desig');
			$add=$this->input->post('address');
			$phno=$this->input->post('phone');
			$whatapp=$this->input->post('whatapp');
			$pwd=$this->input->post('pwd');
			$salary=$this->input->post('salary');
			//profile image
			
			$file1=$_FILES['image1']['name'];
			
			
			//voter image
			$voter=$this->input->post('voterid');
			 $file2=$_FILES['image2']['name'];
			
			//pan image
			$pan=$this->input->post('panno');
			 $file3=$_FILES['image3']['name'];
		
			//adhar image
			$adhar=$this->input->post('adharno');
			$file4=$_FILES['image4']['name'];
			
			//$imagevotercard=
			$image1=$this->imageupload($file1,"image1",$path);
			$image2=$this->imageupload2($file2,"image2",$path);
			$image3=$this->imageupload3($file3,"image3",$path);
			$image4=$this->imageupload4($file4,"image4",$path);
			//if($image1 != '')
			//{
			$data_insert=array(
			   "salesmanid"=>$sid,
				"name"=>$name,
				"email"=>$email,
				"address"=>$add,
				"phno"=>$phno,
				"whatsapp"=>$whatapp,
				"deprts"=>$dept,
				"desig"=>$desg,
				"passwod"=>$pwd,
				"salary"=>$salary,
				"image"=>$image1,
				"voterid"=>$voter,
				"voterimg"=>$image2,
				"panno"=>$pan,
				"panimg"=>$image3,
				"adharno"=>$adhar,
				"adharimg"=>$image4,
				"doe"=>date('Y-m-d h:i:s A'),
				"crtd"=>$this->session->userdata('user_name')
				
			);
			$this->Manage_salesman_model->insert($data_insert);	
			  $msg="Data Saved Succesfully";
			   $this->session->set_flashdata('message',$msg);
			   redirect('Manage_salesman/view','refresh'); 
			/*}
			else
			{
				$msg ="Sorry!. There Is an error";
				 $this->session->set_flashdata('message',$msg);
			   redirect('Manage_salesman/create','refresh'); 
			}
			*/
			
			//$phno=$this->input->post();
			
			//$this->load->view('managesalesman/view',$data);
		}
	public function imageupload($file,$name,$path)
	{
		$image=$file;
		if($image != '')
		{
			$allowedtype = "jpg|gif|png|jpeg|JPEG";
			$max_size = '';
			$max_width = '0';
			$max_height = '0';
			$upload_path = $path;
			$config['upload_path'] = $upload_path;
			$config['allowed_types'] = $allowedtype;
			$config['max_size']	= $max_size;
			$config['max_width'] = $max_width;
			$config['max_height'] = $max_height;
			$config['overwrite'] = FALSE;
			//$file_name = $file['prod_image']['name'];
			$file_name = $file;
			$file_name = preg_replace('/[\s,$#&\+\-()\[\];\'~`]/','_',$file_name);
			$f_name=time()."_".$file_name;
			$config['file_name'] = $f_name;
			//$config['orig_name'] = $file['prod_image']['name'];
			$config['orig_name'] = $file;
			$this->upload->initialize($config);
			if($this->upload->do_upload($name))
			{
				$data = array('upload_data' => $this->upload->data());
				$latest_filename_rtr = $data['upload_data']['file_name'];
				//generate the thumb image from the main image 
				$config['image_library'] = 'gd2'; 
				$config['source_image'] = "uploads/Salesman/".$latest_filename_rtr; 
				//$config['new_image'] = "uploads/thumb_images/"; 
				$config['thumb_marker'] = ''; 
				$config['create_thumb'] = TRUE; 
				$config['maintain_ratio'] = TRUE; 
				$config['width'] = 185; 
				$config['height'] = 185; 
				$this->image_lib->initialize($config); 
				if (!$this->image_lib->resize())
				{ 

				} 
				return $latest_filename_rtr;
			}
			else
			{
				print($this->upload->display_errors());
				return '';  
				
			}
			
		}
		else
			return '';   
				  
		
	}
public function imageupload2($file,$name,$path)
	{
		$image=$file;
		if($image != '')
		{
			$allowedtype = "jpg|gif|png|jpeg|JPEG";
			$max_size = '';
			$max_width = '0';
			$max_height = '0';
			$upload_path = $path;
			$config['upload_path'] = $upload_path;
			$config['allowed_types'] = $allowedtype;
			$config['max_size']	= $max_size;
			$config['max_width'] = $max_width;
			$config['max_height'] = $max_height;
			$config['overwrite'] = FALSE;
			//$file_name = $file['prod_image']['name'];
			$file_name = $file;
			$file_name = preg_replace('/[\s,$#&\+\-()\[\];\'~`]/','_',$file_name);
			$f_name=time()."_".$file_name;
			$config['file_name'] = $f_name;
			//$config['orig_name'] = $file['prod_image']['name'];
			$config['orig_name'] = $file;
			$this->upload->initialize($config);
			if($this->upload->do_upload($name))
			{
				$data = array('upload_data' => $this->upload->data());
				$latest_filename_rtr = $data['upload_data']['file_name'];
				//generate the thumb image from the main image 
				$config['image_library'] = 'gd2'; 
				$config['source_image'] = "uploads/Salesman/".$latest_filename_rtr; 
				//$config['new_image'] = "uploads/thumb_images/"; 
				$config['thumb_marker'] = ''; 
				$config['create_thumb'] = TRUE; 
				$config['maintain_ratio'] = TRUE; 
				$config['width'] = 185; 
				$config['height'] = 185; 
				$this->image_lib->initialize($config); 
				if (!$this->image_lib->resize())
				{ 

				} 
				return $latest_filename_rtr;
			}
			else
			{
				print($this->upload->display_errors());
				return '';  
				
			}
			
		}
		else
			return '';   
				  
		
	}
public function imageupload3($file,$name,$path)
	{
		$image=$file;
		if($image != '')
		{
			$allowedtype = "jpg|gif|png|jpeg|JPEG";
			$max_size = '';
			$max_width = '0';
			$max_height = '0';
			$upload_path = $path;
			$config['upload_path'] = $upload_path;
			$config['allowed_types'] = $allowedtype;
			$config['max_size']	= $max_size;
			$config['max_width'] = $max_width;
			$config['max_height'] = $max_height;
			$config['overwrite'] = FALSE;
			//$file_name = $file['prod_image']['name'];
			$file_name = $file;
			$file_name = preg_replace('/[\s,$#&\+\-()\[\];\'~`]/','_',$file_name);
			$f_name=time()."_".$file_name;
			$config['file_name'] = $f_name;
			//$config['orig_name'] = $file['prod_image']['name'];
			$config['orig_name'] = $file;
			$this->upload->initialize($config);
			if($this->upload->do_upload($name))
			{
				$data = array('upload_data' => $this->upload->data());
				$latest_filename_rtr = $data['upload_data']['file_name'];
				//generate the thumb image from the main image 
				$config['image_library'] = 'gd2'; 
				$config['source_image'] = "uploads/Salesman/".$latest_filename_rtr; 
				//$config['new_image'] = "uploads/thumb_images/"; 
				$config['thumb_marker'] = ''; 
				$config['create_thumb'] = TRUE; 
				$config['maintain_ratio'] = TRUE; 
				$config['width'] = 185; 
				$config['height'] = 185; 
				$this->image_lib->initialize($config); 
				if (!$this->image_lib->resize())
				{ 

				} 
				return $latest_filename_rtr;
			}
			else
			{
				print($this->upload->display_errors());
				return '';  
				
			}
			
		}
		else
			return '';   
				  
		
	}
public function imageupload4($file,$name,$path)
	{
		$image=$file;
		if($image != '')
		{
			$allowedtype = "jpg|gif|png|jpeg|JPEG";
			$max_size = '';
			$max_width = '0';
			$max_height = '0';
			$upload_path = $path;
			$config['upload_path'] = $upload_path;
			$config['allowed_types'] = $allowedtype;
			$config['max_size']	= $max_size;
			$config['max_width'] = $max_width;
			$config['max_height'] = $max_height;
			$config['overwrite'] = FALSE;
			//$file_name = $file['prod_image']['name'];
			$file_name = $file;
			$file_name = preg_replace('/[\s,$#&\+\-()\[\];\'~`]/','_',$file_name);
			$f_name=time()."_".$file_name;
			$config['file_name'] = $f_name;
			//$config['orig_name'] = $file['prod_image']['name'];
			$config['orig_name'] = $file;
			$this->upload->initialize($config);
			if($this->upload->do_upload($name))
			{
				$data = array('upload_data' => $this->upload->data());
				$latest_filename_rtr = $data['upload_data']['file_name'];
				//generate the thumb image from the main image 
				$config['image_library'] = 'gd2'; 
				$config['source_image'] = "uploads/Salesman/".$latest_filename_rtr; 
				//$config['new_image'] = "uploads/thumb_images/"; 
				$config['thumb_marker'] = ''; 
				$config['create_thumb'] = TRUE; 
				$config['maintain_ratio'] = TRUE; 
				$config['width'] = 185; 
				$config['height'] = 185; 
				$this->image_lib->initialize($config); 
				if (!$this->image_lib->resize())
				{ 

				} 
				return $latest_filename_rtr;
			}
			else
			{
				print($this->upload->display_errors());
				return '';  
				
			}
			
		}
		else
			return '';   
				  
		
	}
	public function view()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="View Employee";
		$data['salesman']=$this->Manage_salesman_model->getallsalesman();
		$this->load->view('managesalesman/view',$data);
	}
	public function deletesalesman($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$sid=$id;
		//$data['title']="View Employee";
		//$data['salesman']=$this->Manage_salesman_model->getallsalesman();
		$deletesman=$this->Manage_salesman_model->deletesalesman($sid);
		$msg ="Deletion made successfully";
				 
		//$this->load->view('managesalesman/view',$data);
		$this->session->set_flashdata('message',$msg);
         redirect('Manage_salesman/view','refresh'); 
	}
	// update on 31122016===========================
	public function editemployee($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$sid=$id;
		$data['salesman']=$this->Manage_salesman_model->getallsalesmanindividual($sid);
		$data['departments']=$this->Manage_salesman_model->getdepartments();
		$this->load->view('managesalesman/create',$data);
	}
	public function updatesalesman()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
			//$data['title']="View Salesman";
			
			$path="uploads/Salesman/";
			$name=$this->input->post('salesman');
			$id=$this->input->post("sidd");
			$email=$this->input->post('salemail');
			$dept=$this->input->post('departments');
			$desg=$this->input->post('desig');
			$add=$this->input->post('address');
			$phno=$this->input->post('phone');
			$whatapp=$this->input->post('whatapp');
			$pwd=$this->input->post('pwd');
			$salary=$this->input->post('salary');
			//profile image
			
			$file1=$_FILES['image1']['name'];
			
			
			//voter image
			$voter=$this->input->post('voterid');
			 $file2=$_FILES['image2']['name'];
			
			//pan image
			$pan=$this->input->post('panno');
			 $file3=$_FILES['image3']['name'];
		
			//adhar image
			$adhar=$this->input->post('adharno');
			$file4=$_FILES['image4']['name'];
			
			//$imagevotercard=
			$image1=$this->imageupload($file1,"image1",$path);
			$image2=$this->imageupload2($file2,"image2",$path);
			$image3=$this->imageupload3($file3,"image3",$path);
			$image4=$this->imageupload4($file4,"image4",$path);
			if($image1!=""){
				$image1=$image1;
			}else{
				$image1=$this->input->post("image1ed");
			}
			if($image2!=""){
				
				$image2=$image2;
			}else{
				$image2=$this->input->post("image2ed");
			}
			if($image3!=""){
				$image=$image3;
			}else{
				$image3=$this->input->post("image3ed");
			}
			if($image4!=""){
				$image4=$image4;
			}else{
				$image4=$this->input->post("image4ed");
			}
			//if($image1 != '')
			//{
			$data_insert=array(
			   
				"name"=>$name,
				"email"=>$email,
				"address"=>$add,
				"phno"=>$phno,
				"whatsapp"=>$whatapp,
				"deprts"=>$dept,
				"desig"=>$desg,
				"passwod"=>$pwd,
				"salary"=>$salary,
				"image"=>$image1,
				"voterid"=>$voter,
				"voterimg"=>$image2,
				"panno"=>$pan,
				"panimg"=>$image3,
				"adharno"=>$adhar,
				"adharimg"=>$image4,
				"doe"=>date('Y-m-d h:i:s A'),
				"crtd"=>$this->session->userdata('user_name')
				
			);
			$this->Manage_salesman_model->updatesalesman($data_insert,$id);	
			  $msg="Data Updated Succesfully";
			   $this->session->set_flashdata('message',$msg);
			   redirect('Manage_salesman/view','refresh'); 
			/*}
			else
			{
				$msg ="Sorry!. There Is an error";
				 $this->session->set_flashdata('message',$msg);
			   redirect('Manage_salesman/create','refresh'); 
			}
			*/
			
			//$phno=$this->input->post();
			
			//$this->load->view('managesalesman/view',$data);
	}
		
}
