<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AcountsManage_Controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		$this->load->library('fpdf_geninvoice');
		
		$this->load->library('numbertowords');
		$this->load->model('AccountManage_model');
		
		$this->load->model('Sales_Model');
		$this->load->model('stockManage_model');
	}
	public function accounts()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Accounts";
		$this->load->view("Accounts/accounts",$data);
	}
	public function save_accountsinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$data['title']="Accounts";
		$pono=$this->input->post("");
		$type=$this->input->post("");
		$amount=$this->input->post("");
		$ptype=$this->input->post("");
		$bnakname=$this->input->post("");
		$acno=$this->input->post("");
		$chqno=$this->input->post("");
		
	}
  public function vieworder()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$user=$this->session->userdata('uname');
	$data['title']="view Order List";
	$data['getbookinglist']=$this->AccountManage_model->getallbookinglist();
		$this->load->view('Accounts/bookinglist',$data);
  }
  public function viewsalesorder()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	//$user=$this->session->userdata('uname');
	$ordercode=$this->AccountManage_model->getOrderCode();
		if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}
	$data['title']="Dash Board";
	$data['godown']=$this->stockManage_model->fetchgodown();
	$data['title']="Order";
	$data['model']=$this->stockManage_model->getmodel();
	$data['spareparts']=$this->stockManage_model->getspareparts();
	$data['box']=$this->stockManage_model->getboxwisestock();
	$this->load->view('Accounts/viewsalesorder',$data);
  }
  public function vieworder_details()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dash Board";
		$ordercode=$this->AccountManage_model->getOrderCode();
		if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}
		$bkid=$this->input->post("orderno");
		$data['bkid']=$bkid;
		//$data['bkid']=$bkid;
		$data['orderdetals']=$this->AccountManage_model->getallsalesorder($bkid);
		if(isset($data['orderdetals'])&& !empty($data['orderdetals'])){
			foreach($data['orderdetals'] as $row)
			{
				$clientid=$row->custid;
				$salesman=$row->sname;
				$bkdt=$row->doe;
			}
			$data['bkdt']=$bkdt;
			$data['clientid']=$clientid;
			$data['salesman']=$salesman;;
			$data['custdetails']=$this->AccountManage_model->fgetcustdetails($clientid);
		}
		$data['godown']=$this->stockManage_model->fetchgodown();
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		$this->load->view('Accounts/viewsalesorder',$data);
		
		
		
  }
  public function getstockdata()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//echo "hello";
		//orderdetails================================================
		$ordercode=$this->AccountManage_model->getOrderCode();
		if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD".date('y').$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD".date('y').$invID;
		}
		  $bkid=$this->input->post("bkid1");
		$data['bkid']=$bkid;
		//$data['bkid']=$bkid;
		$data['orderdetals']=$this->AccountManage_model->getallsalesorder($bkid);
		//print_r($data['orderdetals']);
		if(isset($data['orderdetals'])&& !empty($data['orderdetals'])){
			foreach($data['orderdetals'] as $row)
			{
				$clientid=$row->custid;
				$salesman=$row->sname;
				$bkdt=$row->doe;
			}
			$data['bkdt']=$bkdt;
			$data['clientid']=$clientid;
			$data['salesman']=$salesman;;
			$data['custdetails']=$this->AccountManage_model->fgetcustdetails($clientid);
		}
		$data['godown']=$this->stockManage_model->fetchgodown();
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		$orderno=$this->input->post("orderno2");
		$model=$this->input->post("model");
		$transfer=$this->input->post("transfer");
		$godown=$this->input->post("godown");
		$trackno=$this->input->post("trackno");
		$partiname=$this->input->post("partyname");
		$custcode=$this->input->post("partycode");
		$balance=$this->input->post("balance");
		//$drivername=$this->input->post("drivername");
		
		$drivercontact=$this->input->post("drivercontact");
		$data['modelnme']=$model;
		$data['ordernme']=$orderno;
		$data['transfr']=$transfer;
		$data['godwn']=$godown;
		$data['trackno']=$trackno;
		$data['partyname']=$partiname;
		$data['partycode']=$custcode;
		$data['balance']=$balance;
		
		//$data['drivername']=$drivername;
		$data['drivercontact']=$drivercontact;
		$data_array=array(
			'Order_Code'=>$orderno,
			'modelName'=>$model,
			'transfer_Type'=>$transfer,
			'godown'=>$godown
		);
		//print_r($data_array);
		//$checkdataex=$this->stockManage_model->save_data($data_array);
		$data['getpareparts']=$this->stockManage_model->getsparepartsbymodel($model);
		$data['godown']=$this->stockManage_model->fetchgodown();
		//$data['ordercodes']=$orderno;
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		$data['stockmodel']=$this->stockManage_model->getstockmodeldis($godown);
		if(isset($godown) && !empty($godown) && empty($model))
		{
			
			$data['temp_data']=$this->stockManage_model->getallpono_godown($godown);
		}
		if(isset($godown)&& !empty($godown) && isset($model) && !empty($model))
		{
			
			$data['temp_data']=$this->stockManage_model->getallpono_godownmodel($godown,$model);
		}
		
		$this->load->view('Accounts/viewsalesorder',$data);
  }
	public function cash_entry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Accounts";
		$this->load->view("Accounts/cash_check_entry",$data);
	}
	public function fetch_cashinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$clientid=$this->input->post("clientID");
		$data['cashinfo']=$this->AccountManage_model->fgetcustdetails($clientid);
		$this->load->view("Accounts/cash_check_entry",$data);
	}
	public function get_chqu()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$pdamount=$this->input->post("pdamount");
		if($pdamount=="Cash"){
							
		}else{
			echo '<div class="row" id="chq">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="no" name="no" >
												<label for="no">No</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="bnkname" name="bnkname" >
												<label for="bnkname">Bank Name</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="Branch" name="Branch" >
												<label for="Branch">Branch</label>
											</div>
										</div>
									</div>';
		};
	}
	public function getsecurityDetails()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$Purpose=$this->input->post("Purpose");
		$securityamountpaid=$this->input->post("securityamountpaid");
		if($Purpose=="Security"){
			echo '<div class="row" id="">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="paidamnt" name="paidamnt" value="'.$securityamountpaid.'" readonly >
												<label for="paidamnt">Paid Amount(security)</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="payamnt" name="payamnt" onblur="getduebalence()" value="" required  >
												<label for="payamnt">Pay Amount</label>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="Dueblnce" name="Dueblnce" value=" " readonly >
												<label for="Dueblnce">Due Balence</label>
											</div>
										</div>	
									</div>';			
		}else{
			echo '<div class="row">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="payamnt1" name="payamnt1" onblur="getpbalence()" required="">
												<label for="payamnt">Pay Amount</label>
											</div>
										</div>
											
									</div>';
		};
	}
	public function save_cashinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$clientID=$this->input->post("clientID");
		if(isset($clientID) && !empty($clientID))
		{
			$clientID=$clientID;
		}else{
			$clientID="";
		}
		//$paidamt=$this->input->post("payamnt");
		$date1=$this->input->post("date1");
		$pdatype=$this->input->post("pdatype");
		$remark=$this->input->post("remark");
		if(isset($remark) && !empty($remark))
		{
			$remark=$remark;
		}else{
			$remark="";
		}
		$no=$this->input->post("no");
		if(isset($no) && !empty($no))
		{
			$no=$no;
		}else{
			$no="";
		}
		$bnkname=$this->input->post("bnkname");
		if(isset($bnkname) && !empty($bnkname))
		{
			$bnkname=$bnkname;
		}else{
			$bnkname="";
		}
		$Branch=$this->input->post("Branch");
		if(isset($Branch) && !empty($Branch))
		{
			$Branch=$Branch;
		}else{
			$Branch="";
		}
		$balance=$this->input->post("balence");
		$paidamt=floatval($this->input->post("pamnt"));
		$securityamountpaid=floatval($this->input->post("securityamountpaid"));
		date_default_timezone_set("Asia/kolkata");
		$data['clientid']=$clientID;
		$Purpose=$this->input->post("Purpose");
		$data_array=array(
			"dat"=>$date1,
			"type"=>$pdatype,
			"paid_amt"=>$paidamt,
			"purpose"=>$Purpose,
			"remark"=>$remark,
			"clientID"=>$clientID,
			"cheque_no"=>$no,
			"bankName"=>$bnkname,
			"branchName"=>$Branch
		);
		$checkdata=$this->AccountManage_model->save_chqDetails($data_array);
		if($Purpose=="Security"){
			$update_amt=floatval($securityamountpaid)+floatval($paidamt);
			$checkmalst=$this->AccountManage_model->getmailsentstatus($clientID);
			if(intval($checkmalst)==0)
			{
				$this->load->view("send_mail/sendagreement",$data);
			}
			 
			$data_array=array(
			"securityamountpaid"=>$update_amt,
			"trns_crtd"=>$this->session->userdata('user_name'),
			"trns_doe_updt"=>date('Y-m-d h:i:s A'),
			"mailsentstatus"=>1
		);
		$checkdata1=$this->AccountManage_model->update_chqDetails($data_array,$clientID);
		
		}else{
			$update_amt=floatval($balance)+floatval($paidamt);
			$data_array=array(
			"balance"=>$update_amt,
			"trns_crtd"=>$this->session->userdata('user_name'),
			"trns_doe_updt"=>date('Y-m-d h:i:s A')
		);
		
		$checkdata1=$this->AccountManage_model->update_chqDetails($data_array,$clientID);
		}
		
		
		//$checkdata1=$this->AccountManage_model->save_chqDetails1($data_array);
		redirect("AcountsManage_Controller/view_cashinfo",'refresh');
	}
	 public function view_cashinfo()
	 {
	 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['cashinfo']=$this->AccountManage_model->fetchTransctn();
		$this->load->view("Accounts/cash_check_view",$data);
	 }
	 public function print_invoice($id)
	 {
	 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$bkid=$id;
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetMargins(5.5, 2.5 );
		$this->fpdf->line(6,5,290.5,5);
		$this->fpdf->line(6,5,6,35);
		$this->fpdf->line(290.5,5,290.5,35);
		$this->fpdf->line(6,35,290.5,35);
		$this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()-8,33,33,'png');
		$this->fpdf->addSociete("Phone:(033)-64517771","Email: sales@gkrickshow.com\n" ."CST No: 123456\n"."VAT/TIN No: 19731597605\n" ."" );
		$this->fpdf->addSocietecopy("Office Address","30(33/1) N.T Road ,\n"."Padmabati Colony, \n" ."Baidyabati, Hooghly, \n"."West Bengal-712222, \n"."India" );
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->text(115,39,"TAX-INVOICE CUM-EXCISE INVOICE");
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(95,43,"( $invoicetxt ) ");
		$this->fpdf->line(6,35,6,45);
		$this->fpdf->line(290.5,35,290.5,45);
		//$this->fpdf->line(203.5,5,203.5,30);
		$this->fpdf->line(6,45,290.5,45);
		$this->fpdf->line(6,45,6,85);
		
		$this->fpdf->line(150.5,45,150.5,85);
		$this->fpdf->line(6,75,290.5,75);
		$this->fpdf->line(290.5,45,290.5,85);
		//$this->fpdf->line(6,85,203.5,85);
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(7,49,"Buyer (if other than consignee)");
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(7,52,"To,");
		$this->fpdf->buyeraddress("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(7,82,"VAT TIN: 18440216892             CST: 18440216892");
		$this->fpdf->compinfo("Invoice No                    : GKR/16-17/0001","Range                           : RANGE-1/480701\n"."Division                         : SINGUR/4807 \n" ."Commissionerate          : KOL-IV/48 \n"."PAN/Income Tax No     : AAMFG8605k \n"."Date of issue of Invoice : 20-Dec-2016 3:17:46 AM\n"."Date & Time of Removal : 21-Dec-2016 15:17:46 PM\n" );
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text(155,82,"Order ID: GKSLSBK00017                Order Date: 17-12-2016   ");
		$cols=array( "Sno"    => 11,
             "Particulars"  => 50,
             "Qty"=>10,
             "Chasisno"     => 50,
             "Motor No"      => 50,
             "Battery No" => 35,
             "Charger"=>35,
             "Rate" => 19,"Amount"=>25
              );
		$this->fpdf->addCols( $cols);
		 $this->fpdf->SetFont('Times','',10);
		$cols=array( "Sno"    =>"L",
		             "Particulars"  => "L",
		             "Qty"=>"L",
		            "Chasisno"      => "L",
		             "Motor No"      => "C",
		             "Battery No" => "C",
		             "Charger"=>"C",
		             "Rate" =>"C",
		             "Amount"=>"R"
		              );
		 $this->fpdf->addLineFormat( $cols);
	    $this->fpdf->addLineFormat($cols);
	    $y  =95;
	    $this->fpdf->ln(5);
	    $this->fpdf->SetFont('Times','',10);
	    $gtx=$this->fpdf->getX();
		$gty=$this->fpdf->getY()+8;
		$net=0;
		$chassisno="M6REP3085Q16B0001";
		$motorno="123456789";
		$battery="EXIDE1234,EXIDE3456,EXIDE2546,EXIDE4596";
		$charger="54789325698145";
		for($k=1;$k<3;$k++)
		{
			$amnt=42041.00;
			$this->fpdf->SetFont('Times','',10);
		    $this->fpdf->SetWidths(array(11,50,10,50,50,35,35,25,19));
		    $this->fpdf->SetAligns(array("C","C","C","C","C","C","C","L","R"));
		    $this->fpdf->Row3(array("$k","ER-India(G7)","1","$chassisno","$motorno","$battery","$charger","42,000.00","42,000.00"));
		    $net=$net+$amnt;
	    
		}
		/*for($n=1;$n<4;$n++)
		{
			$this->fpdf->text(($gtx+1.5),($gty),"$n");
			$gty=$gty+5;
		}*/
	    /*$line = array( "Sl No"    => "1",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$y   += $size + 1;
				
				$line = array( "Sl No"    => "2",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$line = array( "Sl No"    => "2",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$y   += $size + 1;
		
		$size = $this->fpdf->addLine( $y, $line );*/
	  // $this->fpdf->ln(1);
	    $x=$this->fpdf->getX();
	    $y=$this->fpdf->getY();
	    $y=210-$y;
	   // $this->fpdf->cell(6,5,"$x,$y",1,0,'C');
	   //$number=1250.00;
	   
	   $netnum=number_format($net,2);
	   $red=$this->numbertowords->convert_number($net);
	   //$getst=$this->AccountManage_model->convert_number_to_words(intval($net));
	   $tot=$k-1;
	    $this->fpdf->ln($y);
	    $this->fpdf->SetFont('Arial','',10);
	    $this->fpdf->SetWidths(array(11,50,10,50,50,70,25,19));
	    $this->fpdf->SetAligns(array("C","C","C","C","C","C","C","C"));
	    $this->fpdf->Row(array("","Total","$tot","","","","","$netnum"));
	    $this->fpdf->SetFont('Arial','',10);
	    $this->fpdf->SetWidths(array(70,215));
	    $this->fpdf->SetAligns(array("L","L"));
	    $this->fpdf->Row(array("Amount Chargable (In words)","Rs.$red Only"));
		$this->fpdf->ln(1);
		$gtx=$this->fpdf->getX();
		$gety=$this->fpdf->getY();
		
		$this->fpdf->line($gtx+.5,$gety,($gtx+285.5),$gety);
		$this->fpdf->line($gtx+.5,$gety,$gtx,($gety+30));
		$this->fpdf->line(($gtx+285.5),$gety,($gtx+285.5),($gety+30));
		$this->fpdf->line($gtx+.5,($gety+30),($gtx+150.5),($gety+30));
		$this->fpdf->line(($gtx+150),$gety,285.5,$gety);
		$this->fpdf->line(($gtx+150),($gety+30),291,($gety+30));
		$this->fpdf->line(($gtx+150),($gety),($gtx+150),($gety+30));
		//$this->fpdf->line(285.5,($gety),285.5,($gety+30));
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->text(($gtx+200),($gety+4),"for G.K Rickshaw Pvt Ltd.");
		$this->fpdf->Image($img2, $this->fpdf->GetX()+200, $this->fpdf->GetY()+4,27,27,'png');
		//$gety=$gety+31;
		 $this->fpdf->SetFont('Times','',8);
		$this->fpdf->cell(30,5,"Serial No. in PLA/RG-23",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Manner Of Transport",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Despatched through",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"PR/GC Node No/L.R NO",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Truck No",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Date",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		
		//$gtx=$this->fpdf->getX();
		//$gety=$this->fpdf->getY();
		$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->Multicell(285,5,"$declt",1);
		$this->fpdf->ln(2);
		$this->fpdf->SetFont('Times','B',11);
		$this->fpdf->Multicell(285,5,"NOTE: SUBJECT TO SERAMPORE JURISDICTION",1,'C');
	    //$this->fpdf->text($x,$y,"helloworld");
	    //$this->fpdf->
		//$this->fpdf->addLineFormat( $cols);
		//$this->fpdf->addLineFormat($cols);
		
		
				//$this->fpdf->addCadreTVAs();
		/*$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->cell(195,10,"TAX INVOICE-CUM-EXCISE INVOICE",1,1,'C');
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->text(55,54,"( $invoicetxt )");
		$this->fpdf->SetFont('Arial','B',7);
		//$cell2=$this->fpdf->cell(10,3,"ssfsfgfdg",0,1,'L');
		$this->fpdf->cell(97.5,30,"",1,0,'C');
		
		$this->fpdf->cell(97.5,30,"",1,1,'C');
		//$this->fpdf->Text(130,20,"Office Address");*/
		
		$this->fpdf->output();
		
		
	 }
	public function generateinvoice($bkid)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$bkid=$id;
	}
	//=====================================  Taxation   Details=======================================
	public function createtax()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$this->load->view('Accounts/createtaxation',$data);
	}
	public function savetaxation()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$vat=strtoupper($this->input->post("vat"));
		$vatamount=$this->input->post("vatamount");
		$cst=strtoupper($this->input->post("cst"));
		$cstamount=$this->input->post("cstamount");
		$excise=strtoupper($this->input->post("excise"));
		$exciseamount=$this->input->post("exciseamount");
		$tds=strtoupper($this->input->post("tds"));
		$tdsamount=$this->input->post("tdsamount");
		$custom=strtoupper($this->input->post("custom"));
		$customamnt=$this->input->post("customamount");
		$ptax=strtoupper($this->input->post("ptax"));
		$ptaxamount=$this->input->post("ptaxamount");
		$servicetax=strtoupper($this->input->post("stax"));
		$serviceamnt=$this->input->post("staxamount");
		$incometax=strtoupper($this->input->post("incometax"));
		$incometaxamnt=$this->input->post("incometaxamount");
		$dataarray=array(
			"vatno"=>$vat,
			"vatamnt"=>$vatamount,
			"cstno"=>$cst,
			"cstamnt"=>$cstamount,
			"exciseno"=>$excise,
			"exciswamnt"=>$exciseamount,
			"tdsno"=>$tds,
			"tdsamnt"=>$tdsamount,
			"custom"=>$custom,
			"customamnt"=>$customamnt,
			"ptax"=>$ptax,
			"ptaxamnt"=>$ptaxamount,
			"stax"=>$servicetax,
			"staxamnt"=>$serviceamnt,
			"intax"=>$incometax,
			"intaxamnt"=>$incometaxamnt
		
		);
		$this->AccountManage_model->savetaxation($dataarray);
		redirect('AcountsManage_Controller/vioewtaxtaion');
		
	}
  public function vioewtaxtaion()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	$data['title']="Dashboard";
	$data['getalltax']=$this->AccountManage_model->getalltaxation();
	$this->load->view('Accounts/viewtaxation',$data);
  }
  public function edittaxtaion($id)
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	$data['title']="Dashboard";
  	$data['taxinfo']=$this->AccountManage_model->gettaxinfo($id);
	$this->load->view('Accounts/createtaxation',$data);
	
  }
  public function updatetaxtaion()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$vat=strtoupper($this->input->post("vat"));
		$vatamount=$this->input->post("vatamount");
		$cst=strtoupper($this->input->post("cst"));
		$cstamount=$this->input->post("cstamount");
		$excise=strtoupper($this->input->post("excise"));
		$exciseamount=$this->input->post("exciseamount");
		$tds=strtoupper($this->input->post("tds"));
		$tdsamount=$this->input->post("tdsamount");
		$custom=strtoupper($this->input->post("custom"));
		$customamnt=$this->input->post("customamount");
		$ptax=strtoupper($this->input->post("ptax"));
		$ptaxamount=$this->input->post("ptaxamount");
		$servicetax=strtoupper($this->input->post("stax"));
		$serviceamnt=$this->input->post("staxamount");
		$incometax=strtoupper($this->input->post("incometax"));
		$incometaxamnt=$this->input->post("incometaxamount");
		$roeid=$this->input->post("rowid");
		$dataarray=array(
			"vatno"=>$vat,
			"vatamnt"=>$vatamount,
			"cstno"=>$cst,
			"cstamnt"=>$cstamount,
			"exciseno"=>$excise,
			"exciswamnt"=>$exciseamount,
			"tdsno"=>$tds,
			"tdsamnt"=>$tdsamount,
			"custom"=>$custom,
			"customamnt"=>$customamnt,
			"ptax"=>$ptax,
			"ptaxamnt"=>$ptaxamount,
			"stax"=>$servicetax,
			"staxamnt"=>$serviceamnt,
			"intax"=>$incometax,
			"intaxamnt"=>$incometaxamnt
		
		);
		$this->AccountManage_model->updatetaxtaion($dataarray,$roeid);
		redirect('AcountsManage_Controller/vioewtaxtaion');
  }
//update on 30122013=============================================
  public function setmodelprice()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$data['model']=$this->stockManage_model->getmodel();
	    $data['spareparts']=$this->stockManage_model->getspareparts();
		$this->load->view('Accounts/setmodelprice',$data);
	
	    
  }
  public function getallparts()
  {
  	//$this->authentication->is_loggedin($this->session->userdata('user_name'));
	//$data['title']="Dashboard";
	$model=$this->input->post("model");
	$getallparts=$this->AccountManage_model->getallparts($model);
	/*$getalltaxdetail=$this->AccountManage_model->getalltaxlast();
	foreach($getalltaxdetail as $row)
	{
		$tax=$row->tax;
	}
    $taxexpl=explode(",",$tax);
    
    $taxcount=count($taxexpl);*/
  //  print_r($taxcount);
	if(!empty($getallparts))
	{
		  echo'<div class="card-head style-primary">
							<header>ALL SPAREPARTS LIST</header>
					</div>
				 <form action="'.base_url().'AcountsManage_Controller/savepartspurchasepricemanual" method="post">
					<div class="card-body floating-label">
					        <div class="col-md-12">
					        <div class="form-group">
					           <div class="col-md-6">
					           	<input type="date" name="dte" class="form-control" placeholder="Enter Invoice  Date" required/>
					           </div>
					           <div class="col-md-6">
					           <input type="text" name="poid" class="form-control" placeholder="Enter PO NO/INVOICE NO" required/>
					           </div>
					        
					        </div>
							</div>
							<div class="col-md-12">
					<div class="form-group" id="parts" style="overflow-y:scroll;">
			';
			
			echo '<table class="table table-bordered table-hover">';
				echo '<thead>
						<tr>
							<th>Sl No.</th>
							<th>Model</th>
							<th>Parts Code</th>
							<th>Parts name</th>
							<th>Enter Qty</th>
							<th>Enter Seller Unit  Price</th>
							<th>Total</th>
							<th>Action</th>
						</tr>
				    </thead>
				    <tbody>';
					$i=1;
				    foreach($getallparts as $row)
		             {
		             	$mname=$row->mName;
						$prtscd=$row->materiel_id;
						$prtsnme=$row->materialname;
						$prtsv=$row->buypr;
						$unit=$row->unit;
						
		
				    	echo '<tr>';
					    	 echo  '<td>'.$i.'</td>';
							 echo  '<td>'.$mname.'<input type="hidden" name="model_'.$i.'" value="'.$mname.'"/></td>';
							 echo  '<td>'.$prtscd.'<input type="hidden" name="partsid_'.$i.'" value="'.$prtscd.'"/></td>';
							 echo  '<td>'.$prtsnme.' <input type="hidden" name="partsname_'.$i.'" value="'.$prtsnme.'"/></td>';
							 
							 echo  '<td><input type="text" name="qty_'.$i.'" id="qty_'.$i.'" style="width:75px;" onblur="gettotalpartspr(this.id);" /></td>';
							 echo  '<td><input  name="unitprice_'.$i.'"  type="text" style="width:75px;" id="sellerpr_'.$i.'" value="" placeholder="Unit Price" onblur="gettotalpartspr(this.id);"/></td>';
							  echo  '<td><input  name="tot_'.$i.'"  type="text" style="width:100px;border:none;" id="tot_'.$i.'" value="" placeholder="Total" readonly/></td>';
							 echo  '<td> <button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-floppy-o" aria-hidden="true"></i></button></td>';
							 
					    		
					  echo 	'</tr>';
						
		            $i++;  }
                     echo '<tr><td colspan="4" style="text-align:right;">Total<input type="hidden" name="totprtsrow" id="totrow" value="'.$i.'"/></td>
                     			<td><input type="text" id="totqty" name="totqty" style="width:75px;"  readonly /></td>
                     			<td></td>
                     			<td><input type="text" id="totprice" name="totprice" style="width:100px;"  readonly /></td>
                     			<td></td>
                     		</tr>';
		             echo	   ' </tbody>';
			
			echo '</table>';
			echo '</div>
			       		</div>
			       		<hr>';
			       		for($tax=1;$tax<4;$tax++){
			       		  echo ' <div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									 
									</div>
									<div class="col-md-6">
									  <input  type="text" style="width:400px;"  name="taxname_'.$tax.'" value="" placeholder="Tax Title'.$tax.'" />
									</div>
									<div class="col-md-2">
									   <input type="text" style="width:200px;" value="" name="taxval_'.$tax.'"   placeholder="Tax Rate'.$tax.'" />
									</div>
								</div>
												
							</div>';
							
						}
							echo '<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									   
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" name="transportname" value="" placeholder="Transport Name" />
									</div>
									<div class="col-md-2">
									  <input type="text" style="width:200px;" name="transportfare" value="" placeholder="Transport Fare" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" name="clgh" placeholder="Custom duty" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="csdval" />
									</div>
								</div>
												
							</div>
							
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" name="clgh" placeholder="Clearing Charge" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="clval" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" name="labourch" placeholder="Labour Charge" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" name="lcval" value="" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Other Expense 1" name="othex1" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="otex1" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Other Expense 2" name="othex2" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="otex2" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12">
								<div class="form-group" id="submit" >
									<div class="card-actionbar">
										<div class="card-actionbar-row">
											 <button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
										 </div>
									</div>
								</form>				
							</div>
					</div>
			</div>';
		
	  }
	
  }
//======================update on 31122016===================================================================
 public function getpartspurchaseprice()
 {
 	    $this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$data['model']=$this->stockManage_model->getmodel();
	    $data['spareparts']=$this->stockManage_model->getspareparts();
		$this->load->view('Accounts/setpartspurchase',$data);
 }
  public function getallpodetails()
  {
  	$dte=$this->input->post("dte");
	$getallpurcse=$this->AccountManage_model->getpurchasepodetails($dte);
	$po=array();
	if(!empty($getallpurcse))
	{
		foreach($getallpurcse as $row)
		{
			$poid=$row->poid;
			array_push($po,$poid);
		}
	}
	echo json_encode($po);
  }
  public function getallprtsprice()
  {
  	$po=$this->input->post('po');
	$getpurchaselst=$this->AccountManage_model->getallpurchaselst($po);
	if(!empty($getpurchaselst))
	{
		foreach($getpurchaselst as $row)
		{
			$model=$row->model;
			$parts=$row->parts;
			$tax=$row->tax;
			$pono=$row->poid;
			$venid=$row->venid;
		}
		echo '<form action="'.base_url().'AcountsManage_Controller/savepartspurchaseprice" method="post">';
		echo'<div class="card-head style-primary">
							<header>ALL SPAREPARTS LIST</header>
					</div>
					<div class="card-body floating-label">
							<div class="col-md-12">
					<div class="form-group" id="parts" style="overflow-y:scroll;">
			';
			echo '<table class="table table-bordered table-hover">';
				echo '<thead>
						<tr>
							<th>Sl No.</th>
							<th>Model</th>
							<th>Parts Code</th>
							<th>Parts name</th>
							<th>Qty</th>
							<th>Total Price</th>
							<th>Unit Price</th>
							<th>Action</th>
						</tr>
				    </thead>
				    <tbody>';
					$i=1;
					$totqty=0;
					if(isset($model) && !empty($model)){
						$modelexplode=explode(",",$model);
				    foreach($modelexplode as $rowmodel)
		             {
		             	$rowmodelexplode2=explode(",",$rowmodel);
						foreach($rowmodelexplode2 as $rowmodel2){
							$rowmodelexplode=explode(";",$rowmodel2);
						//print_r($rowmodelexplode);
		             	$mname=$rowmodelexplode[0];
						$prtscd=$rowmodelexplode[2];
						$prtsnme=$this->AccountManage_model->getpartsname($prtscd);
						$qty=$rowmodelexplode[4];
						$tot=$rowmodelexplode[7];
						$unitprice=$rowmodelexplode[6];
						//$prtsv=$row->buypr;
						//$unit=$row->unit;
						
						$totqty=intval($totqty)+intval($qty);
				    	echo '<tr>';
					    	 echo  '<td>'.$i.'</td>';
							 echo  '<td>'.$mname.'<input type="hidden" name="model_'.$i.'" value="'.$mname.'" /></td>';
							 echo  '<td>'.$prtscd.'<input type="hidden" name="partsid_'.$i.'" value="'.$prtscd.'"/></td>';
							 echo  '<td>'.$prtsnme.'<input type="hidden" name="partsname_'.$i.'" value="'.$prtsnme.'"/></td>';
							 echo  '<td>'.$qty.'<input type="hidden" name="qty_'.$i.'" value="'.$qty.'"/></td>';
							 echo '<td>'.$tot.'<input type="hidden" name="tot_'.$i.'" value="'.$tot.'"/></td>';
							
							 echo  '<td><input class="form-control"  type="text" style="width:75px;" name="unitprice_'.$i.'" id="price_'.$i.'" value="'.$unitprice.'"/></td>';
							 echo  '<td> <button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-floppy-o" aria-hidden="true"></i></button></td>';
							 
					    		
					  echo 	'</tr>';
						
		            $i++;  } }

                    }
//###################################################  alll parts  details--------------------------
                    if(isset($parts) && !empty($parts)){
						$partsexplode=explode(",",$parts);
				    foreach($partsexplode as $rowparts)
		             {
		             	$rowpartsexplode2=explode(",",$rowparts);
						foreach($rowpartsexplode2 as $rowmodel2){
							$rowmodelexplode=explode(";",$rowmodel2);
						//print_r($rowmodelexplode);
		             	$mname=$rowmodelexplode[1];
						$prtscd=$rowmodelexplode[0];
						$prtsnme=$this->AccountManage_model->getpartsname($prtscd);
						$qty=$rowmodelexplode[2];
						$tot=$rowmodelexplode[5];
						$unitprice=$rowmodelexplode[4];
						//$prtsv=$row->buypr;
						//$unit=$row->unit;
						
		              $totqty=intval($totqty)+intval($qty);
				    	echo '<tr>';
					    	 echo  '<td>'.$i.'</td>';
							 echo  '<td>'.$mname.'<input type="hidden" name="model_'.$i.'" value="'.$mname.'" /></td>';
							 echo  '<td>'.$prtscd.'<input type="hidden" name="partsid_'.$i.'" value="'.$prtscd.'"/></td>';
							 echo  '<td>'.$prtsnme.'<input type="hidden" name="partsname_'.$i.'" value="'.$prtsnme.'"/></td>';
							 echo  '<td>'.$qty.'<input type="hidden" name="qty_'.$i.'" value="'.$qty.'"/></td>';
							 echo '<td>'.$tot.' <input type="hidden" name="tot_'.$i.'" value="'.$tot.'"/></td>';
							
							 echo  '<td><input class="form-control"  type="text" style="width:75px;" name="unitprice_'.$i.'" id="price_'.$i.'" value="'.$unitprice.'"/></td>';
							 echo  '<td> <button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-floppy-o" aria-hidden="true"></i></button></td>';
							 
					    		
					  echo 	'</tr>';
						
		            $i++;  } }

                    }
					echo '<tr>';
						echo '<td colspan="4" style="text-align:right;">Total  Item Qty</td>';
						echo '<td>'.$totqty.'<input type="hidden" id="totprtsqty" name="totprtsqty" value="'.$totqty.'"/>
						<input type="hidden" name="totprtsrow" value="'.$i.'"/>
						<input type="hidden" name="poid" value="'.$pono.'"/>
						<input type="hidden" name="venid" value="'.$venid.'"/>
						
						</td>';
						echo '<td colspan="3"></td>';
					
					echo '</tr>';
		             echo	   ' </tbody>';
			
			echo '</table>';
			echo '</div>
			       		</div>
			       		<hr>';
						$t=0;
						if(isset($tax) && !empty($tax)){
							$taxexplode=explode(",",$tax);
							
							foreach($taxexplode as $rowtax){
								$rowtaxexplode=explode(";",$rowtax);
								$taxtitle=$rowtaxexplode[0];
								$taxrt=$rowtaxexplode[1];
								$taxamnt=$rowtaxexplode[2];
								
								$t++;
			       		   echo '<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									 
									</div>
									<div class="col-md-6" >
									  <input  type="text" style="width:400px;text-align:right; border:none;" name="taxname_'.$t.'" value="'.$taxtitle.'('.$taxrt.'%)'.'" placeholder="Tax 1" readonly />
									</div>
									<div class="col-md-2" style="float:left;">
									   <input type="text" style="width:200px;" name="taxval_'.$t.'" value="'.$taxamnt.'" readonly/>
									</div>
								</div>
												
							</div>';
							
						}
						}else{
							for($taxr=0;$taxr<3;$taxr++){
							   echo '<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									   
									</div>
									<div class="col-md-6" >
									   <input type="text" style="width:400px;" name="taxname_'.$taxr.'" value="" placeholder="Tax 2" />
									</div>
									<div class="col-md-2" style="float:left;">
									  <input type="text" style="width:200px;" name="taxval_'.$taxr.'" value="" />
									</div>
								</div>
												
							</div>';
							}   
							   
						}
                      if($t>0){
                      	echo '<input type="hidden" name="taxrow" value="'.$t.'"/>';
                      }else{
                      	echo '<input type="hidden" name="taxrow" value="'.$taxr.'"/>';
                      }
							
							echo '
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									   
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" name="transportname" value="" placeholder="Transport Name" />
									</div>
									<div class="col-md-2">
									  <input type="text" style="width:200px;" name="transportfare" value="" placeholder="Transport Fare" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Custom Duty"  name="csd"/>
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="csdval" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Clearing Charge"  name="clchg" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="clval" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Labour Charge" name="lc" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="lcval" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Other Expense 1" name="othex1" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="otex1" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12" style="border-bottom:2px solid #c2c2c2;padding-bottom:4px;">
								<div class="form-group">
									<div class="col-md-4">
									    
									</div>
									<div class="col-md-6">
									   <input type="text" style="width:400px;" value="" placeholder="Other Expense 2" name="othex2" />
									</div>
									<div class="col-md-2">
									    <input type="text" style="width:200px;" value="" name="otex2" />
									</div>
								</div>
												
							</div>
							<div class="col-md-12">
								<div class="form-group" id="submit" >
									<div class="card-actionbar">
										<div class="card-actionbar-row">
											 <button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
										 </div>
									</div>
												
							</div>
					</div>
			</div>';
			echo '</form>';
	}
	
	//print_r($getpurchaselst);
  }
  public function savepartspurchaseprice()
  {
  	 $this->authentication->is_loggedin($this->session->userdata('user_name'));
  	 date_default_timezone_set("Asia/kolkata");
  	$tottablerow=intval($this->input->post("totprtsrow"));
	// echo "<br>"; 
	 $poid=$this->input->post("poid");
	 $venid=$this->input->post("venid");
	 $totqty=intval($this->input->post("totprtsqty"));
	 $custom=floatval($this->input->post("csdval"));
	 $clearing=floatval($this->input->post("clval"));
	 $lc=floatval($this->input->post("lcval"));
	 $otex1=floatval($this->input->post("otex1"));
	 $otex2=floatval($this->input->post("otex2"));
	  $transportfare=floatval($this->input->post("transportfare"));
	 $transportname=$this->input->post("transportname");
	
	 
	 //gettax info details
	 
	 $taxrow=intval($this->input->post("taxrow"));
	 $tottaxval=0;
	 $taxinfo=array();
	 for($tx=1;$tx<=$taxrow;$tx++)
	 {
	 	$taxname=$this->input->post("taxname_".$tx);
		$taxval=floatval($this->input->post("taxval_".$tx));
		$taxi="$taxname;$taxval";
		array_push($taxinfo,$taxi);
		/*$datatax=array(
			"taxnam"=>$taxname,
			"taxval"=>$taxval
			
		);
		$this->AccountManage_model->savetaxinfo();*/
		
	 	$tottaxval=floatval($tottaxval)+floatval($taxval);
	 }
	  $taxinfoimp=implode(",",$taxinfo);
	 
	 $individualtax=floatval($tottaxval)/$totqty;
	//..........................................................................................................
	
//################################################################################################	
	//customduty---------------------------------
	  if(isset($custom) && !empty($custom))
	  {
	  	  $cusd=floatval($custom)/$totqty;
	  }
	  //transport fare=====================================
	 if(isset($transportfare) && !empty($transportfare))
	 {
	 	$transportfare2=floatval($transportfare)/$totqty;
		
	 }else
	 {
	 	$transportfare2=0;
	 }
	  
//####################################################################################################	  
	  //clearing  charge------------------------------------------------
	  
	  if(isset($clearing) && !empty($clearing))
	  {
	  	$clg=floatval($clearing)/$totqty;
	  }
	  
//####################################################################################	 
 
	  //clearing  charge------------------------------------------------
	  
	  if(isset($lc) && !empty($lc))
	  {
	  	$lchg=floatval($clearing)/$totqty;
	  }
	  
//####################################################################################	
     //otherexpen1 
     if(isset($otex1) && !empty($otex1))
	 {
	 	$otindividualval1=floatval($otex1)/$totqty;
	 }
	  //otherexpen2
     if(isset($otex2) && !empty($otex2))
	 {
	 	$otindividualval2=floatval($otex2)/$totqty;
	 }
	//#######################################  checking all value   ################################
	if(isset($individualtax) & !empty($individualtax))
	{
		$individualtax=floatval($individualtax);
	}else{
		
		$individualtax=0;
		
	}
	
	if(isset($cusd) & !empty($cusd))
	{
		$cusd=floatval($cusd);
		
	}else{
		
		$cusd=0;
		
	}
//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
	if(isset($clg) & !empty($cusd))
	{
		$clg=floatval($clg);
	}else{
		
		$clg=0;
		
	}
	
//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
	if(isset($lchg) & !empty($lchg))
	{
		$lchg=floatval($lchg);
	}else{
		
		$lchg=0;
		
	}

//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
$oherex=array();
	if(isset($otindividualval1) & !empty($otindividualval1))
	{
		$otindividualval1=floatval($otindividualval1);
		$ottit=$this->input->post("othex1");
		$otindividualval12=number_format($otindividualval1,2);
		$othreexp="$ottit;$otindividualval12";
		array_push($oherex,$othreexp);
	}else{
		
		$otindividualval1=0;
		
	}


//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
	if(isset($otindividualval2) & !empty($otindividualval2))
	{
		$otindividualval2=floatval($otindividualval2);
		$ottit2=$this->input->post("othex2");
		$otindividualval21=number_format($otindividualval2,2);
		$othreexp="$ottit2;$otindividualval21";
		array_push($oherex,$othreexp);
	}else{
		
		$otindividualval2=0;
		
	}

   $oherexim=implode(",",$oherex);
	 //table info  details
	 $allpr=array();
  	 if($tottablerow>1){
  	 	
		for($i=1;$i<$tottablerow;$i++)
		{
			$model=$this->input->post("model_".$i);
			$qty=$this->input->post("tot_".$i);
			$tot=$this->input->post("tot_".$i);
			 $partsid=$this->input->post("partsid_".$i);
			//echo "&nbsp;";
			 $partsname=$this->input->post("partsname_".$i);
			//echo "&nbsp;";
		     $unitprice=$this->input->post("unitprice_".$i);
			// "&nbsp;";
		    $perpr=floatval($unitprice)+floatval($individualtax)+floatval($cusd)+floatval($clg)+floatval($lchg)+floatval($otindividualval1)+floatval($otindividualval2)+floatval($transportfare2);
			$others=floatval($cusd)+floatval($clg)+floatval($lchg)+floatval($otindividualval1)+floatval($otindividualval2)+floatval($transportfare2);
		//echo "<br>";
			$prtspr="$model;$partsid;$partsname;$qty;$unitprice;$tot;$perpr";
			array_push($allpr,$prtspr);
			$datapr=array(
				"buypr"=>$perpr,
				"sellerpr"=>floatval($unitprice),
				"taxinfo"=>$taxinfoimp,
				"tax"=>floatval($individualtax),
				"others"=>floatval($others),
				"pono"=>$poid,
				"purchseupdte"=>date('Y-m-d h:i:s A'),
				"purchsecrtd"=>$this->session->userdata('user_name')
			);
			//print_r($datapr);
			$this->AccountManage_model->updatebuypr($datapr,$partsid,$model);
		}
		$allprimpl=implode(",",$allpr);
		$data_array=array(
			"pono"=>$poid,
			"venid"=>$venid,
			"dop"=>date('Y-m-d'),
			"allpr"=>$allprimpl,
			"tax"=>$taxinfoimp,
			"custom"=>$cusd,
			"clrg"=>$clg,
			"transport"=>$transportfare2,
			"qty"=>$totqty,
			"transportnae"=>$transportname,
			"tottransport"=>$transportfare2,
			"lbchr"=>$lchg,
			"othex1"=>$oherexim,
			"doe"=>date('Y-m-d h:i:s A'),
			"crtd"=>$this->session->userdata('user_name')
		);
		$checkpoexist=$this->AccountManage_model->checkpoeist($poid,$venid);
		if(isset($checkpoexist) && !empty($checkpoexist))
		{
			$this->AccountManage_model->updatepurchasepr($data_array,$poid,$venid);
		}else{
			
				$this->AccountManage_model->savepurchasepr($data_array);
		}
	
		
		
  	 }
  	// exit;
  	redirect('AcountsManage_Controller/getpurchaseprbypo','refresh');
	 
	 
  }
  public function getpurchaseprbypo()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['getallpurchase']=$this->AccountManage_model->getallpurchaseprc();
	$this->load->view('Accounts/viewpurprc',$data);
  }
  public function viewpurchaseprice()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['model']=$this->stockManage_model->getmodel();
	$this->load->view("Accounts/viewallpurchsaeprice",$data);
  }
  public function getallsparepartspurchsaeprice()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['model']=$this->stockManage_model->getmodel();
	$model=$this->input->post("mName");
	$data['modelname']=$model;
	$data['partsprice']=$this->AccountManage_model->getallparts($model);
	$this->load->view("Accounts/viewallpurchsaeprice",$data);
  }

public function savepartspurchasepricemanual()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	 date_default_timezone_set("Asia/kolkata");
  	$tottablerow=intval($this->input->post("totprtsrow"));
	// echo "<br>"; 
	 $poid=$this->input->post("poid");
	// $venid=$this->input->post("venid");
	 $totqty=intval($this->input->post("totqty"));
	 $custom=floatval($this->input->post("csdval"));
	 $clearing=floatval($this->input->post("clval"));
	 $lc=floatval($this->input->post("lcval"));
	 $otex1=floatval($this->input->post("otex1"));
	 $otex2=floatval($this->input->post("otex2"));
	 $transportfare=floatval($this->input->post("transportfare"));
	 $transportname=$this->input->post("transportname");
	 
	 
	 //gettax info details
	 
	// $taxrow=intval($this->input->post("taxrow"));
	 $tottaxval=0;
	 $taxinfo=array();
	 for($tx=1;$tx<4;$tx++)
	 {
	 	$taxname=$this->input->post("taxname_".$tx);
		$taxval=floatval($this->input->post("taxval_".$tx));
		
		if(isset($taxval) && !empty($taxval)){
			$taxi="$taxname;$taxval";
		array_push($taxinfo,$taxi);
		/*$datatax=array(
			"taxnam"=>$taxname,
			"taxval"=>$taxval
			
		);
		$this->AccountManage_model->savetaxinfo();*/
		
	 	 $tottaxval=floatval($tottaxval)+floatval($taxval);
		}
	 }
	  $taxinfoimp=implode(",",$taxinfo);
	 
	 $individualtax=floatval($tottaxval)/$totqty;
	//..........................................................................................................
	
//################################################################################################	
	//customduty---------------------------------
	  if(isset($custom) && !empty($custom))
	  {
	  	  $cusd=floatval($custom)/$totqty;
	  }
	  
//####################################################################################################	  
	  //clearing  charge------------------------------------------------
	  
	  if(isset($clearing) && !empty($clearing))
	  {
	  	$clg=floatval($clearing)/$totqty;
	  }
	 //transport fare=====================================
	 if(isset($transportfare) && !empty($transportfare))
	 {
	 	$transportfare2=floatval($transportfare)/$totqty;
		
	 }else
	 {
	 	$transportfare2=0;
	 }
	 
	  
//####################################################################################	 
 
	  //clearing  charge------------------------------------------------
	  
	  if(isset($lc) && !empty($lc))
	  {
	  	$lchg=floatval($clearing)/$totqty;
	  }
	  
//####################################################################################	
     //otherexpen1 
     if(isset($otex1) && !empty($otex1))
	 {
	 	$otindividualval1=floatval($otex1)/$totqty;
	 }
	  //otherexpen2
     if(isset($otex2) && !empty($otex2))
	 {
	 	$otindividualval2=floatval($otex2)/$totqty;
	 }
	//#######################################  checking all value   ################################
	if(isset($individualtax) & !empty($individualtax))
	{
		$individualtax=floatval($individualtax);
	}else{
		
		$individualtax=0;
		
	}
	
	if(isset($cusd) & !empty($cusd))
	{
		$cusd=floatval($cusd);
		
	}else{
		
		$cusd=0;
		
	}
//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
	if(isset($clg) & !empty($cusd))
	{
		$clg=floatval($clg);
	}else{
		
		$clg=0;
		
	}
	
//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
	if(isset($lchg) & !empty($lchg))
	{
		$lchg=floatval($lchg);
	}else{
		
		$lchg=0;
		
	}

//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
$oherex=array();
	if(isset($otindividualval1) & !empty($otindividualval1))
	{
		$otindividualval1=floatval($otindividualval1);
		$ottit=$this->input->post("othex1");
		$otindividualval12=number_format($otindividualval1,2);
		$othreexp="$ottit;$otindividualval12";
		array_push($oherex,$othreexp);
	}else{
		
		$otindividualval1=0;
		
	}


//=-=-=-=-==-==-=-=-=-=-=-=-=-=-=-=-=-======================-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
	if(isset($otindividualval2) & !empty($otindividualval2))
	{
		$otindividualval2=floatval($otindividualval2);
		$ottit2=$this->input->post("othex2");
		$otindividualval21=number_format($otindividualval2,2);
		$othreexp="$ottit2;$otindividualval21";
		array_push($oherex,$othreexp);
	}else{
		
		$otindividualval2=0;
		
	}

   $oherexim=implode(",",$oherex);
	 //table info  details
	 $allpr=array();
  	 if($tottablerow>1){
  	 	
		for($i=1;$i<$tottablerow;$i++)
		{
			$model=$this->input->post("model_".$i);
			echo $qty=$this->input->post("qty_".$i);
			echo "&nbsp;";
			$tot=$this->input->post("tot_".$i);
			//echo "&nbsp;";
			 $partsid=$this->input->post("partsid_".$i);
			//echo "&nbsp;";
			 $partsname=$this->input->post("partsname_".$i);
			//echo "&nbsp;";
		     $unitprice=$this->input->post("unitprice_".$i);
			 echo "&nbsp;";
			 echo "<br>";
			// "&nbsp;";
			if(isset($qty)>0 && !empty($qty) && isset($unitprice)>0 && !empty($unitprice) && isset($tot)>0 && !empty($tot))
			{
				
		
		    $perpr=floatval($unitprice)+floatval($individualtax)+floatval($cusd)+floatval($clg)+floatval($lchg)+floatval($otindividualval1)+floatval($otindividualval2)+floatval($transportfare2);
			$others=floatval($cusd)+floatval($clg)+floatval($lchg)+floatval($otindividualval1)+floatval($otindividualval2)+floatval($transportfare2);
		//echo "<br>";
			$prtspr="$model;$partsid;$partsname;$qty;$unitprice;$tot;$perpr";
			array_push($allpr,$prtspr);
			$datapr=array(
				"buypr"=>$perpr,
				"sellerpr"=>floatval($unitprice),
				"taxinfo"=>$taxinfoimp,
				"tax"=>floatval($individualtax),
				"others"=>floatval($others),
				"pono"=>$poid,
				"purchseupdte"=>date('Y-m-d h:i:s A'),
				"purchsecrtd"=>$this->session->userdata('user_name')
			);
			//print_r($datapr);
			$this->AccountManage_model->updatebuypr($datapr,$partsid,$model);
			
			
			}
		}
		$allprimpl=implode(",",$allpr);
		$data_array=array(
			"pono"=>$poid,
			
			"dop"=>date('Y-m-d'),
			"allpr"=>$allprimpl,
			"tax"=>$taxinfoimp,
			"custom"=>$cusd,
			"clrg"=>$clg,
			"transport"=>$transportfare2,
			"qty"=>$totqty,
			"transportnae"=>$transportname,
			"tottransport"=>$transportfare2,
			"lbchr"=>$lchg,
			"othex1"=>$oherexim,
			"doe"=>date('Y-m-d h:i:s A'),
			"crtd"=>$this->session->userdata('user_name')
		);
		$checkpoexist=$this->AccountManage_model->checkpoeist2($poid);
		if(isset($checkpoexist) && !empty($checkpoexist))
		{
			$this->AccountManage_model->updatepurchasepr2($data_array,$poid);
		}else{
			
				$this->AccountManage_model->savepurchasepr($data_array);
		}
	
		
		
  	 }
  	// exit;
  	redirect('AcountsManage_Controller/getpurchaseprbypo','refresh');
	 
}
//#############################################################################################################
//
//                             UPDATE ON 03012017  INVOIVE GENERATION
//#############################################################################################################	
 public function createinvoice()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Accounts";
	$data['models']=$this->AccountManage_model->getallmodel();
	$invoice=$this->AccountManage_model->getlastinvoice();
	if(!empty($invoice))
	{
		//$invoiceid=explode("/",$invoice);
		$invoiceid=substr($invoice,-5);
		$invoid=intval($invoiceid);
		$invoid=intval($invoid)+1;
		$invoid2=str_pad($invoid,5,"0",STR_PAD_LEFT);
		$dt=date('y');
		$data['invoice']="GKINV".$dt."$invoid2";
	}else
		{
			$dt=date('y');
			$data['invoice']="GKINV".$dt."0001";
		}
	$getlastorder=$this->AccountManage_model->getlastorder();
	if(!empty($getlastorder))
	{
		$bkid=intval(substr($getlastorder,-5));
		$bkid=$bkid+1;
		$bkid2=str_pad($bkid,5,"0",STR_PAD_LEFT);
		$data['booking']="GKSLSBK$bkid2";
	}else
	{
		$data['booking']="GKSLSBK00000";	
			
	}
	$data['allinvoice']=$this->AccountManage_model->getallinvoice();
	$this->load->view("Accounts/createinvoice",$data);
 }
 public function getmodellistbyparts()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
 	$cat=$this->input->post("cattyp");
	$getallmodellist=$this->AccountManage_model->getallmodel();
	if($cat=="product"){
	if(isset($getallmodellist) && !empty($getallmodellist)){
		echo '<select id="mname" class="form-control select2-list"  name="mName"  required onchange="getmodeltypebyparts()" >';
		echo '<option value="0"></option>';
		$i=1;
		foreach($getallmodellist as $row)
		{
			
				echo '<option value="'.$row->productname.'">'.$row->productname.'</option>';
												
		$i++;	
		}
	echo '</select>';
	echo '<label for="mName">Select Model</label>';
	}
	}
	if($cat=="parts"){
	if(isset($getallmodellist) && !empty($getallmodellist)){
		echo '<select id="mname" class="form-control select2-list"  name="mName"  required onchange="getmodelpartsdetails();" >';
		echo '<option value="0"></option>';
		$i=1;
		foreach($getallmodellist as $row)
		{
			
				echo '<option value="'.$row->productname.'">'.$row->productname.'</option>';
												
			$i++;
		}
	echo '</select>';
	echo '<label for="mName">Select Model</label>';
	}
	}
 }
public function getmodelprice()
{
	//echo "hello";
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$modelname=$this->input->post("type");
	$custype=$this->input->post("custype");
	$getmodel=$this->AccountManage_model->getmodelsbyjs($modelname);
	$getpartspr=$this->AccountManage_model->getbatterprice($modelname);
	$getcharger=$this->AccountManage_model->getchargerprice($modelname);
	 $batterypr=0;
	//echo $chargerypr=0;
	$getcolorcode=$this->AccountManage_model->getallcolorcode();
	//print_r($getpartspr);
	//echo "<br>";
	//print_r($getcharger);
	if(!empty($getmodel) && isset($getmodel))
	{
		foreach($getmodel as $row)
		{
			$modelmrp=$row->mainpr;
			$cnfper=$row->cnfpercentage;
			$distper=$row->distpercentage;
			$subdistper=$row->subdistpercentage;
			
		}
		if($custype=="CNF")
		{
			$dis=$cnfper;
		}
		else if($custype=="DEALER")
		{
			$dis=$distper;
		}
        else if($custype=="SUB-DEALER")
		{
			$dis=$subdistper;
		}else{
			$dis=0;
		}
		if(isset($getpartspr) && !empty($getpartspr))
		{
			foreach($getpartspr as $row2)
			{
				$batterypr=floatval($row2->buyprcrnt);
				$cnfpr=floatval($row2->cnfprper);
				$dispr=floatval($row2->distprper);
				$subdistper=floatval($row2->subdistprper);
			}
			if(isset($batterypr) && !empty($batterypr))
			{
				$batterypr=$batterypr;
			}else
			{
					$batterypr=999999;
			}
			if($custype=="CNF")
			{
					$batterydis=$cnfpr;
			}
			else if($custype=="DEALER")
			{
					$batterydis=$dispr;
			}
		    else if($custype=="SUB-DEALER")
		     {
				$batterydis=$subdistper;
			  }else{
					$batterydis=$batterypr;
				}
	      }else{
	      	$batterydis=0;
	      }
		if(isset($getcharger) && !empty($getcharger))
		{
			foreach($getcharger as $row2)
			{
				 $chargerypr=floatval($row2->buyprcrnt);
				$cnfchgpr=floatval($row2->cnfprper);
				$dischgpr=floatval($row2->distprper);
				$subdistchgper=floatval($row2->subdistprper);
			}
			if(isset($chargerypr) && !empty($chargerypr))
			{
				$chargerypr=$chargerypr;
			}else
			{
					$chargerypr=999999;
			}
			if($custype=="CNF")
			{
					$cnfcghpr=$cnfchgpr;
			}
			else if($custype=="DEALER")
			{
					$cnfcghpr=$dischgpr;
			}
		    else if($custype=="SUB-DEALER")
		     {
				    $cnfcghpr=$subdistchgper;
			  }else{
					$cnfcghpr=$chargerypr;
				}
	      }else{
	      	$cnfcghpr=0;
	      }
		
	}
  //echo $cnfcghpr;
	echo '
	<hr class="dotted">
	<div class="col-md-12">
				<div class="col-md-6">
					<div class="form-group">
						 <div class="checkbox checkbox-inline checkbox-styled">
								<label class="checkbox-inline checkbox-styled checkbox-primary">
									<input type="checkbox" name="erick" value="'.$modelmrp.'" checked><span><b>E- Rickshaw</b></span>
								</label>
						  </div>
						  <div class="checkbox checkbox-inline checkbox-styled">
								<label>
									<input type="checkbox" id="battery" name="battery" value="'.$batterydis.'"><span><b>Battery</b></span>
								</label>
						  </div>
						  <div class="checkbox checkbox-inline checkbox-styled">
								<label>
									<input type="checkbox" id="charger" name="charger" value="'.$cnfcghpr.'"><span><b>Charger</b></span>
								</label>
						  </div>
					</div>
				</div>
	        </div>
	        ';
			echo ' <hr class="dotted">
			<div class="col-md-12">
				<div class="col-md-6">
					<div class="form-group">
						 <input type="text" name="reqty" class="form-control"  id="reqty" placeholder=""  onblur="getallchassisinfo();" required/>
						 <label for="mName">Enter Required Qty</label>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						 
					</div>
				</div>
				<div class="col-md-12" style="overflow-x:scroll;" >
					<div class="form-group">
						 <table class="table table-bordered table-hover">
						 	<thead>
						 	   
						 		<tr>';
								if(isset($getcolorcode) && !empty($getcolorcode))
								{
									foreach($getcolorcode as $rowcolor)
									{
										echo '<td>'.$rowcolor->color_name.'</td>';
									}
								}
								
						 			
						 		echo '</tr>
						 	</thead>
						 	<tbody>
						 		<tr>';
						 			if(isset($getcolorcode) && !empty($getcolorcode))
								{
									$color=1;
									foreach($getcolorcode as $rowcolor)
									{
										echo '<td><input type="text" name="color_'.$color.'" style="background-color:'.$rowcolor->code_hex.';color:white;font-weight:bolder;text-align:center;" id="color_'.$color.'" onblur="getmodelrate(this.id);"/></td>';
										$color++;
									}
								}
						 			
								echo '</tr>
								
						 	</tbody>
						 </table>
						 <input type="hidden" name="colorrow" id="colorrow" value="'.$color.'"/>
					</div>
				</div>
	        </div>
	       ';
			
	
	
	
}
 public function getchassisdetails()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$reqty=intval($this->input->post("reqty"));
	  $battery=floatval($this->input->post("battery"));
	 $charger=floatval($this->input->post("charger"));
	if(isset($reqty) && !empty($reqty) && $battery!=999999 && $charger!=999999 )
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									<th>Charger No</th>
									<th>Battery 1</th>
									<th>Battery 2</th>
									<th>Battery 3</th>
									<th>Battery 4</th>
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'"  style="text-transform: uppercase;" /></td>
					<td><input type="text" name="charger_'.$t.'" id="charger_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery1_'.$t.'" id="battery1_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery2_'.$t.'" id="battery2_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery3_'.$t.'" id="battery3_'.$t.'"  style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery4_'.$t.'" id="battery4_'.$t.'" style="text-transform: uppercase;" /></td>
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div><div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    ';
	
	}
    if(isset($reqty) && !empty($reqty) && $battery==999999 && $charger==999999 )
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'" style="text-transform: uppercase;" /></td>
					
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div>
		    <div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    ';
	
	}
	if(isset($reqty) && !empty($reqty) && $battery!=999999 && $charger==999999 )
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									
									<th>Battery 1</th>
									<th>Battery 2</th>
									<th>Battery 3</th>
									<th>Battery 4</th>
									
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;"  /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'" style="text-transform: uppercase;" /></td>
					
					<td><input type="text" name="battery1_'.$t.'" id="battery1_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery2_'.$t.'" id="battery2_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery3_'.$t.'" id="battery3_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery4_'.$t.'" id="battery4_'.$t.'" style="text-transform: uppercase;" /></td>
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div>
		    <div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    ';
	
	}
  if(isset($reqty) && !empty($reqty) && $battery==999999 && $charger!=999999 )
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									<th>Charger No</th>
									
									
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="charger_'.$t.'" id="charger_'.$t.'" style="text-transform: uppercase;" /></td>
					
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div>
		    <div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    
		    ';
	
	}
   
	
 }
 public function saveinvoicetemp()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	date_default_timezone_set("Asia/Kolkata");
	$custname=$this->input->post("custdet");
	$custaddress=$this->input->post("custaddress");
	$custtype=strtoupper($this->input->post("custtyp"));
	$custid=strtoupper($this->input->post("custid"));
	$getsalemainid=$this->AccountManage_model->getsalemanid($custid);
	if(!empty($getsalemainid) & !empty($getsalemainid))
	{
		foreach($getsalemainid as $row)
		{
			$sid=$row->sid;
		}
	}
	if(isset($sid) && !empty($sid))
	{
		$sid=$sid;
	}else{
		$sid="";
	}
	/*$custcomp=$this->input->post("");
	$cadd1=$this->input->post("");
	$add2=$this->input->post("");
	$add3=$this->input->post("");
	$add4=$this->input->post("");
	$pin=$this->input->post("");*/
	$model=$this->input->post("mName");
	$color=$this->input->post("clolorrow");
	$battery=floatval($this->input->post("battery"));
	 $charger=floatval($this->input->post("charger"));
	$custvat=$this->input->post("custvat");
	$custtin=$this->input->post("custtin");
	$consigneename=$this->input->post("consigneename");
	$consigneeadd=$this->input->post("consigneeadd");
	$consigneevat=$this->input->post("consigneevat");
	$consigneetin=$this->input->post("consigneetin");
	$cattype=$this->input->post("cattyp");
	if($cattype=="product")
	{
		$particulars="E-Rickshaw";
	}
	if($cattype=="parts")
	{
		$particulars="Spare Parts";
	}
	if($custtype=="RETAILER")
	{
		$datacustar=array(
			"clientid"=>$custid,
			"name"=>$custname,
			"custtype"=>$custtype,
			"add1"=>$custaddress,
			"tin_vat"=>$custvat,
			"cst"=>$custtin,
			"doe"=>date('Y-m-d h:i:s A'),
			
		);
		$checkdataexistcust=$this->AccountManage_model->checkdatacustexist($custname,$custaddress,$custvat,$custtin,$custtype);
		if(empty($checkdataexistcust))
		{
			$this->AccountManage_model->savecustdata($datacustar);
		}else
		{
			$this->AccountManage_model->updatecustdata($datacustar,$custid);
		}
	}
	/*$dateofissue=$this->input->post("");
	$dateandtimeremv=$this->input->post("");*/
	$orderno=$this->input->post("orderno");
	$invoiceno=$this->input->post("invoicno");
	$orderdate=$this->input->post("orderdate");
	 $reqty=intval($this->input->post("reqty"));
	for($i=1;$i<=$reqty;$i++){
		
		$chassis=$this->input->post("chassis_".$i);
		$motor=$this->input->post("motor_".$i);
		if(isset($battery)){
			$battery1=$this->input->post("battery1_".$i);
			$battery2=$this->input->post("battery2_".$i);
			$battery3=$this->input->post("battery3_".$i);
			$battery4=$this->input->post("battery4_".$i);
			$battery_sve="$battery1,$battery2,$battery3,$battery4";
			
		}else
			{
				$battery_sve="";
			}
		if(isset($charger)&& !empty($charger))
		{
			$charger_save=$this->input->post("charger_".$i);
		}else{
			$charger_save="";
		}
		//$charger=$this->input->post("");
		
		$mnthcode=date('m');
		$yrcode=date('Y');
	$dataarray=array(
		"invoiceno"=>$invoiceno,
		"orderno"=>$orderno,
		"orderdate"=>$orderdate,
		"particulars"=>$particulars,
		"custid"=>$custid,
		"custtyp"=>$custtype,
		"custname"=>$custname,
		"custadd"=>$custaddress,
		"custvat"=>$custvat,
		"custtin"=>$custtin,
		"consigname"=>$consigneename,
		"consigneeadd"=>$consigneeadd,
		"consigneevat"=>$consigneevat,
		"consigneetin"=>$consigneetin,
		"doissue"=>date('Y-m-d h:i:s A'),
		"chasisno"=>$chassis,
		"motorno"=>$motor,
		"chargerno"=>$charger_save,
		"batteryno"=>$battery_sve,
		"mnthcd"=>$mnthcode,
		"yrcode"=>$yrcode,
		"sid"=>$sid
		
	);
	    //print_r($dataarray);
	    //echo "<br>";
	   //if($invoiceno)
	  //$checkinvoice=$this->AccountManage_model->checkinvoice($invoiceno);
	  //if(empty($checkinvoice))
	  //{
	  	$saveinvoice=$this->AccountManage_model->saveinvoice_info($dataarray);
	 // }
	   
	
	}
	$getprice=$this->AccountManage_model->getpriceinfo($model);
	if(!empty($getprice))
	{
		foreach($getprice as $row)
		{
			$data['mainpr']=$row->mainpr;
			$data['cnfper']=$row->cnfpercentage;
			$data['distper']=$row->distpercentage;
			$data['subdistpercentage']=$row->subdistpercentage;
		}
		$data['mainpr']=floatval($data['mainpr'])+floatval($battery) +floatval($charger);
	}
	$data['model']=$model;
	$data['custtyp']=$custtype;
	$data['taxinfo']=$this->AccountManage_model->gettaxinfodetails();
	//$serial n
	$data['allinfo']=$this->AccountManage_model->getalldata($invoiceno);
	$this->load->view("Accounts/createinvoicep2",$data);
	
 }
 public function updateinvoicedata()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$noofprod=intval($this->input->post("noofprod"));
	$productmrp=$this->input->post("Custtype");
	$custid=$this->input->post("custid");
	$getcustsalesmaninfo=$this->AccountManage_model->getcustinfodetails($custid);
	if(!empty($getcustsalesmaninfo) && isset($getcustsalesmaninfo))
	{
		foreach($getcustsalesmaninfo as $rosal)
		{
			$sid=$rosal->sid;
		}
	}
	if(isset($sid) && !empty($sid))
	{
		$sid=$sid;
	}else
	{
		$sid=0;	
	}
	
	$custtyp=$this->input->post("discount");
	$discount=$this->input->post("dis");
	$distext=$this->input->post("distext");
	$disval=$this->input->post("disval");
	$excisetaxpercent=$this->input->post("excisetaxpercent");
	$excisetaxval=$this->input->post("excisetaxval");
	$afterexiceamnt=$this->input->post("afterexiceamnt");
	$vatcst=$this->input->post("vatcst");
	$vatpercent=$this->input->post("vatpercent");
	$vatamnt=$this->input->post("vatamnt");
	$aftervat=$this->input->post("aftervat");
	$gtot=$this->input->post("gtotal2");
	$invoice=$this->input->post("invoice");
	//###################################
	$serialno=$this->input->post("serialno");
	$mot=$this->input->post("mot");
	$trnspname=$this->input->post("trnspname");
	$prglrno=$this->input->post("prglrno");
	$vehicleno=$this->input->post("vehicleno");
	$drivercontact=$this->input->post("drivercontact");
	$despatched=$this->input->post("despatched");
	$dte=$this->input->post("dte");
	$dateofremoval=$this->input->post("dotm");
	if($noofprod>1)
	{
		for($i=1;$i<intval($noofprod); $i++)
		{
			$id=$this->input->post("rowid_".$i);
			$particulars=$this->input->post("particulars_".$i);
			$chassisno=$this->input->post("chassisno_".$i);
			$motorno=$this->input->post("motorno_".$i);
			$chargerno=$this->input->post("chargerno_".$i);
			$batteryno=$this->input->post("batteryno_".$i);
			$unitpr=$this->input->post("unitpr_".$i);
			$qty=$this->input->post("qty_".$i);
			$total=$this->input->post("total_".$i);
			$data_array=array(
			    "particulars"=>$particulars,
				"chasisno"=>$chassisno,
				"motorno"=>$motorno,
				"chargerno"=>$chargerno,
				"batteryno"=>$batteryno,
				"qty"=>$qty,
				"unitprice"=>$unitpr,
				"distext"=>$distext,
				"discountper"=>$discount,
				"discountamnt"=>$disval,
				"total"=>$total,
				"excisetx"=>$excisetaxpercent,
				"exciseamnt"=>$excisetaxval,
				"afterexcise"=>$afterexiceamnt,
				"csttax"=>$vatpercent,
				"csttext"=>$vatcst,
				"cstamnt"=>$vatamnt,
				"afercstamnt"=>$aftervat,
				"gtotal"=>$gtot,
				"dateofremo"=>$dateofremoval,
				"transportname"=>$trnspname,
				"vehicleno"=>$vehicleno,
				"mannertransport"=>$mot,
				"serialno"=>$serialno,
				"prglrno"=>$prglrno,
				"despt"=>$despatched,
				"dte"=>$dte,
				"mnthcd"=>date('m'),
				"yrcode"=>date('Y'),
				"sid"=>$sid,
				"drivercontact"=>$drivercontact,
				"crtdby"=>$this->session->userdata('user_name')
				
			
			
			
			);
			
			$this->AccountManage_model->updateinvoicedata($data_array,$id);
		}
     $data['invoice']=$invoice;
	}
	redirect("AcountsManage_Controller/print_invoice2/$invoice",$data);
 }

//#################################################################################################################
//
//                         Print Invoice
//
//################################################################################################################

public function print_invoice2($id)
	 {
	 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$bkid=$id;
		$gettotalbokking=$this->AccountManage_model->getallinvoiceno($bkid);
		//print_r($gettotalbokking);
		if(!empty($gettotalbokking))
		{
			foreach($gettotalbokking as $rowbk)
			{
				$bkno=$rowbk->norow;
			}
		}else{
			$bkno=0;
		}
		//===================header information  ==================================== 
		$getallinvoice=$this->AccountManage_model->getallinvoicedet($bkid);  
		if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowinfo)
				{
					$orderid=$rowinfo->orderno;
					$orderdte=$rowinfo->orderdate;
					$invoiceissue=$rowinfo->doissue;
					$invoiceno=$rowinfo->invoiceno;
					$custname=strtoupper($rowinfo->custname);
					 $custadd=strtoupper($rowinfo->custadd);
					$custvat=strtoupper($rowinfo->custvat);
					$custtin=strtoupper($rowinfo->custtin);
					$consigname=strtoupper($rowinfo->consigname);
					 $consigneeadd=strtoupper($rowinfo->consigneeadd);
					$consigneevat=strtoupper($rowinfo->consigneevat);
					$consigneetin=strtoupper($rowinfo->consigneetin);
					$classifi=$rowinfo->classficno;
					$particular=$rowinfo->particulars;
					$serial=$rowinfo->serialno;
					$prglrno=$rowinfo->prglrno;
					$despt=$rowinfo->despt;
					$drivercontact=$rowinfo->drivercontact;
					$mannertransport=$rowinfo->mannertransport;
					$vehicleno=$rowinfo->vehicleno;
					$dte=$rowinfo->dte;
					$dateofremo=$rowinfo->dateofremo;
					$custtype=$rowinfo->custtyp;
					$custid=$rowinfo->custid;
					
				}
			}

   if(strtoupper($custtype)=="RETAILER")
   {
   	   $custname=$custname;
   }else{
   	 $getcuscom=$this->AccountManage_model->getcustcom($custid);
	 foreach($getcuscom as $rowcom)
	 {
	 	$compname=$rowcom->compname;
	 }
	 
	$custname=$compname;
   }
   	
		$particular=explode("(",$particular);
		$prttxt=$particular[0];
		//========================  end of header information==============================
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo1.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		for($ty=0;$ty<4;$ty++){
		//$this->fpdf->addpage();
			
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image("$path",20,1,280,250,'png');
		$this->fpdf->SetFont('Times','I',12);
		if($ty==0){
			$this->fpdf->text(235,9,"( Original for Buyer's Copy )");
		}
		if($ty==1){
			$this->fpdf->text(230,9,"( Duplicate for Transporter Copy )");
		}
		if($ty==2){
			$this->fpdf->text(230,9,"( Triplicate for ASSESSCE Copy )");
		}
		if($ty==3){
			$this->fpdf->text(240,9,"( Extra Copy )");
		}
		$this->fpdf->SetFont('Arial','',9);
		
		$this->fpdf->SetMargins(5.5, 2.5 );
		$this->fpdf->line(6,5,290.5,5);
		$this->fpdf->line(6,5,6,40);
		$this->fpdf->line(290.5,5,290.5,40);
		$this->fpdf->line(6,40,290.5,40);
		if($ty==2 || $ty==1 || $ty==3){
			   $this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()+3,45,25,'png');
		}else
			{
				$this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()-4,45,25,'png');
			}
		
		$this->fpdf->SetFont('Times','B',20);
		$this->fpdf->text(125,39,"GK RICKSHOW");
		$this->fpdf->addSociete("Phone:(033)-64517771","Email: accounts@gkrickshow.com\n" ."CST/VAT No: 123456\n"."TIN No: 19731597605\n" ."Excise No:123456\n"."website:http://www.gkrickshaw.com" );
		$this->fpdf->addSocietecopy("Office Address","30(33/1) N.T Road ,\n"."Padmabati Colony, \n" ."Baidyabati, Hooghly, \n"."West Bengal-712222, \n"."India" );
		//$this->fpdf->addSocietecopy("Office Address","$custadd" );
		$this->fpdf->SetFont('Arial','B',11);
		//$this->fpdf->text(115,44,"TAX-INVOICE CUM-EXCISE INVOICE");
		$this->fpdf->text(120,44,"TAX-CUM-EXCISE-INVOICE");
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(95,48,"( $invoicetxt ) ");
		$this->fpdf->line(6,38,6,50);
		$this->fpdf->line(290.5,38,290.5,50);
		//$this->fpdf->line(203.5,5,203.5,30);
		$this->fpdf->line(6,50,290.5,50);
		$this->fpdf->line(6,50,6,98);
		$this->fpdf->line(100.5,50,100.5,98);
		$this->fpdf->line(198.5,50,198.5,98);
		$this->fpdf->line(6,98,290.5,98);
		$this->fpdf->line(290.5,50,290.5,98);
		//$this->fpdf->line(6,85,203.5,85);
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(7,54,"Consignee");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		//$this->fpdf->consignee("$custname","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->consignee("$custname","Address-$consigneeadd" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(7,82," VAT/TIN: $custvat             CST: $custtin");
		$this->fpdf->line(6,90,198.5,90);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(7,94,"TF/HSN Classification: $classifi");
		$this->fpdf->line(50,90,198.5,90);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(105,54,"Buyer(if other than consignee)");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		//$this->fpdf->buyeraddress("$consigname","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->buyeraddress("$consigname","Address-$custadd" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(105,82,"VAT/TIN: $consigneevat             CST: $consigneetin");
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(105,94,"Product: $prttxt");
		$this->fpdf->compinfo("Invoice No                    : $invoiceno","Range                           : RANGE-1/480701\n"."Division                         : SINGUR/4807 \n" ."Commissionerate          : KOL-IV/48 \n"."PAN/Income Tax No     : AAMFG8605k \n"."Date of issue of Invoice : $invoiceissue\n"."Date & Time of Removal : $dateofremo\n" );
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text(201,82,"Order ID: $orderid  ");
		$this->fpdf->text(201,86,"Order Date: $orderdte   ");
		$this->fpdf->SetFont('Arial','B',9);
		//$this->fpdf->text(201,90,"Product: E-Rickshaw  ");
		//$this->fpdf->text(201,94," ");
		
		//$this->fpdf->row(array(""));
		$this->fpdf->ln(20);
		 $this->fpdf->SetFont('Arial','B',9);
		  $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R"));
	    $this->fpdf->SetWidths(array(11,30,40,25.5,83,30,20,10,35));
		 $this->fpdf->Rowheader(array("Sno","Particulars","Chasis No","Motor No","Battery No","Charger","Rate","Qty","Amount"));
		 $this->fpdf->SetFont('Times','',10);
	    $gtx=$this->fpdf->getX();
		$gty=$this->fpdf->getY()+8;
		$net=0;$net2=0;$netf=0;
		$chassisno="M6REP3085Q16B0001";
		$motorno="123456789";
		$battery="EXIDE1234,EXIDE3456,EXIDE2546,EXIDE4596";
		$charger="54789325698145";
		$lno=0;
		$getallinvoice=$this->AccountManage_model->getallinvoicedet($bkid);
			if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowtot)
				{
					/*for($k=1;$k<=intval($bkno);$k++)
					{*/
						$amnt=floatval($rowtot->unitprice);
						 $netf=$netf+$amnt;
				}
			}
		$netf=number_format($netf,2);
		$pg=1;
		//for($k=1;$k<=intval($bkno);$k++)
		//{
			$getallinvoice=$this->AccountManage_model->getallinvoicedet($bkid);
			if(!empty($getallinvoice) && isset($getallinvoice)){
				$k=1;
			foreach($getallinvoice as $rowinv)
			{
			
			$pg++;
			$amnt=floatval($rowinv->unitprice);
			$qty=$rowinv->qty;
			$total=$rowinv->total;
			$particulars=$rowinv->particulars;
			$chass=$rowinv->chasisno;
			$motor=$rowinv->motorno;
			$charger=$rowinv->chargerno;
			$battr=$rowinv->batteryno;
			$lno++;
			$this->fpdf->SetFont('Times','',10);
		    $this->fpdf->SetWidths(array(11,30,40,25.5,83,30,20,10,35));
		    $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R","R"));
		    $this->fpdf->Rowheader(array("$k","E-Rickshaw","$chass","$motor","$battr","$charger","$amnt","$qty","$total"));
		    $sd=$this->fpdf->getY();
			 $net2=$net2+$amnt;
			$net3=number_format($net2,2);
			if($pg>4){
				$pg=0;
				$this->fpdf->SetWidths(array(239.5,10,35));
		        $this->fpdf->SetAligns(array("R","R","R"));
		        $this->fpdf->Rowheader(array("Page Total","$lno","$net3"));
				$this->fpdf->SetWidths(array(239.5,45));
		        $this->fpdf->SetAligns(array("R","R"));
		        $this->fpdf->Rowheader(array("Net Assesable Value","$netf"));
				$net2=0;
				$lno=0;
				 $gtx=$this->fpdf->getX();
		         $gety=$this->fpdf->getY();
//page footer=================================================
				//$this->fpdf->ln(2);
				/*$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
				$this->fpdf->line($gtx+.5,$gety,($gtx),($gety+31));
				$this->fpdf->line($gtx+285,$gety,($gtx+285),($gety+31));
				$this->fpdf->line($gtx+70,$gety,($gtx+70),($gety+31));
				$this->fpdf->SetFont('Times','',9);
				$this->fpdf->text($gtx+72,$gety+3,"1. Certified that the particulars given above are true and correct and that amount");
				$this->fpdf->text($gtx+72,$gety+6,"   indicated above represents the price actually changed from consignee and in ");
				$this->fpdf->text($gtx+72,$gety+9,"   according with sec 4 of the Central Excise Act 1944 and that there is no additi-");
				$this->fpdf->text($gtx+72,$gety+12,"   onal flow of consideration directly/or indirectly  from the buyer.");
				$this->fpdf->text($gtx+72,$gety+17,"2. Excise Duty payable under rule 8 of C Excise Rules 2002");
				$this->fpdf->line($gtx+180,$gety,($gtx+180),($gety+31));
				$this->fpdf->text($gtx+190,$gety+30,"Prepared by");
				$this->fpdf->text($gtx+230,$gety+30,"Checked by");
				$this->fpdf->text($gtx+260,$gety+30," Authorized Sign");
				
		//$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
		//$this->fpdf->line($gtx+.5,$gety,$gtx,($gety+30));
		//$this->fpdf->line(($gtx+284.5),$gety,($gtx+284.5),($gety+30));
		//$this->fpdf->line($gtx+.5,($gety+30),($gtx+149.5),($gety+30));
		//$this->fpdf->line(($gtx+149.5),$gety,284.5,$gety);
		//$this->fpdf->line(($gtx+149.5),($gety+30),291,($gety+30));
		//$this->fpdf->line(($gtx+149.5),($gety),($gtx+149.5),($gety+30));
		//$this->fpdf->line(285.5,($gety),285.5,($gety+30));
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->text(($gtx+244),($gety+4),"for G.K Rickshaw Pvt Ltd.");
		$this->fpdf->Image($img2, $this->fpdf->GetX()+260, $this->fpdf->GetY()+4,25,25,'png');
		//$gety=$gety+31;
		 $this->fpdf->SetFont('Times','',8);
		$this->fpdf->cell(30,5,"Serial No. in PLA/RG-23",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Manner Of Transport",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Despatched through",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"PR/GC Node No/L.R NO",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Vehicle No",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		$this->fpdf->cell(30,5,"Date",0,0,'L');
		$this->fpdf->cell(30,5,": ",0,1,'L');
		
		//$this->fpdf->SetWidths(array(100));
		//$this->fpdf->axiontext("Phone:(033)-64517771","Email: accounts@gkrickshow.com\n" ."CST/VAT No: 123456\n"."TIN No: 19731597605\n" ."Excise No:123456\n" );
		//$this->fpdf->row3(array("$battery"));
		
		//$gtx=$this->fpdf->getX();
		//$gety=$this->fpdf->getY();
		/*$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',9);
		$this->fpdf->Multicell(285,5,"$declt",1);
		//$this->fpdf->ln(1);
		/*$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->Multicell(285,5,"NOTE: SUBJECT TO SERAMPORE JURISDICTION",1,'C');
		$this->fpdf->ln(2);
		$lnx=$this->fpdf->getX();
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',14);
		$this->fpdf->text($lnx+120,$lny+5,'"Your Green Partner"');*/
		//$this->fpdf->line($lnx,$lny,$lnx+285,$lny);
		//$this-
		//$this->fpdf->line($lnx,$lny,$lnx,$lny+10);
		//$this->fpdf->line($lnx,$lny+10,$lnx+285,$lny+10);
		//$lnx=$this->fpdf->getX();
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',9);
		$this->fpdf->text(270,$lny+15,"To be Contd...");
				 $this->fpdf->text(270,$lny+18,'Page No '.$this->fpdf->PageNo().' of {nb}');
	//end of page footer===========================================================================			
				$this->fpdf->addpage();
//##########################################################################################################################
//  start Page header
//##################################################################################################################
		$this->fpdf->AliasNbPages();
		$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Times','I',12);
		if($ty==0){
			$this->fpdf->text(235,9,"( Original for Buyer's Copy )");
		}
		if($ty==1){
			$this->fpdf->text(230,9,"( Duplicate for Transporter Copy )");
		}
		if($ty==2){
			$this->fpdf->text(230,9,"( Triplicate for ASSESSCE Copy )");
		}
		if($ty==3){
			$this->fpdf->text(240,9,"( Extra Copy )");
		}
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetMargins(5.5, 2.5 );
		$this->fpdf->line(6,5,290.5,5);
		$this->fpdf->line(6,5,6,40);
		$this->fpdf->line(290.5,5,290.5,40);
		$this->fpdf->line(6,40,290.5,40);
		//===================header information  ==================================== 
		$getallinvoice=$this->AccountManage_model->getallinvoicedet($bkid);  
		if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowinfo)
				{
					$orderid=$rowinfo->orderno;
					$orderdte=$rowinfo->orderdate;
					$invoiceissue=$rowinfo->doissue;
					$invoiceno=$rowinfo->invoiceno;
					$custname=strtoupper($rowinfo->custname);
					$custadd=strtoupper($rowinfo->custadd);
					$custvat=strtoupper($rowinfo->custvat);
					$custtin=strtoupper($rowinfo->custtin);
					$consigname=strtoupper($rowinfo->consigname);
					$consigneeadd=strtoupper($rowinfo->consigneeadd);
					$consigneevat=strtoupper($rowinfo->consigneevat);
					$consigneetin=strtoupper($rowinfo->consigneetin);
					$classifi=$rowinfo->classficno;
					$particular=$rowinfo->particulars;
					$serial=$rowinfo->serialno;
					$prglrno=$rowinfo->prglrno;
					$despt=$rowinfo->despt;
					$drivercontact=$rowinfo->drivercontact;
					$mannertransport=$rowinfo->mannertransport;
					$vehicleno=$rowinfo->vehicleno;
					$dte=$rowinfo->dte;
					$dateofremo=$rowinfo->dateofremo;
					$custtyp=$rowinfo->custtyp;
					$custid=$rowinfo->custid;
				}
			}
if(strtoupper($custtype)=="RETAILER")
   {
   	   $custname=$custname;
   }else{
   	 $getcuscom=$this->AccountManage_model->getcustcom($custid);
	 foreach($getcuscom as $rowcom)
	 {
	 	$compname=$rowcom->compname;
	 }
	 
	$custname=$compname;
   }
		$particular=explode("(",$particular);
		$prttxt=$particular[0];
		//========================  end of header information==============================
		
		//if($ty==2 || $ty==1){
			  // $this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY(),33,33,'png');
	//	}else
			//{
				$this->fpdf->Image($img, $this->fpdf->GetX()+120, $this->fpdf->GetY()+4,45,25,'png');
			//}
		
		$this->fpdf->SetFont('Times','B',20);
		$this->fpdf->text(125,39,"GK RICKSHOW");
		$this->fpdf->addSociete("Phone:(033)-64517771","Email: accounts@gkrickshow.com\n" ."CST/VAT No: 123456\n"."TIN No: 19731597605\n" ."Excise No:123456\n"."website:http://www.gkrickshaw.com" );
		$this->fpdf->addSocietecopy("Office Address","30(33/1) N.T Road ,\n"."Padmabati Colony, \n" ."Baidyabati, Hooghly, \n"."West Bengal-712222, \n"."India" );
		$this->fpdf->SetFont('Arial','B',11);
		//$this->fpdf->text(115,44,"TAX-INVOICE CUM-EXCISE INVOICE");
		$this->fpdf->text(120,44,"TAX-CUM-EXCISE-INVOICE");
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(95,48,"( $invoicetxt ) ");
		$this->fpdf->line(6,38,6,50);
		$this->fpdf->line(290.5,38,290.5,50);
		//$this->fpdf->line(203.5,5,203.5,30);
		$this->fpdf->line(6,50,290.5,50);
		$this->fpdf->line(6,50,6,98);
		$this->fpdf->line(100.5,50,100.5,98);
		$this->fpdf->line(198.5,50,198.5,98);
		$this->fpdf->line(6,98,290.5,98);
		$this->fpdf->line(290.5,50,290.5,98);
		//$this->fpdf->line(6,85,203.5,85);
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(7,54,"Consignee");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		//$this->fpdf->consignee("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->consignee("$consigname","$consigneeadd" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(7,82,"VAT/TIN: $consigneevat             CST: $consigneetin");
		$this->fpdf->line(6,90,198.5,90);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(7,94,"TF/HSN Classification: $classifi ");
		
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text(105,54,"Buyer(if other than consignee)");
		$this->fpdf->SetFont('Arial','',9);
		//$this->fpdf->text(7,57,"To,");
		//$this->fpdf->buyeraddress("ACE DISTRIBUTORS","Champa Place, Ground Floor ,\n"."BRP Road, Gate No.7 \n" ."Guwahati \n"."India" );
		$this->fpdf->buyeraddress("$custname","$custadd" );
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text(105,82,"VAT/TIN: $custvat             CST: $custtin");
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->text(105,94,"Product: $prttxt");
		
		$this->fpdf->compinfo("Invoice No                    : $invoiceno","Range                           : RANGE-1/480701\n"."Division                         : SINGUR/4807 \n" ."Commissionerate          : KOL-IV/48 \n"."PAN/Income Tax No     : AAMFG8605k \n"."Date of issue of Invoice : $invoiceissue\n"."Date & Time of Removal : $dateofremo\n" );
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text(201,82,"Order ID: $orderid  ");
		$this->fpdf->text(201,86,"Order Date: $orderdte   ");
		$this->fpdf->SetFont('Arial','B',9);
		
		//$this->fpdf->row(array(""));
		$this->fpdf->ln(20);		
		  $this->fpdf->SetFont('Arial','B',9);
		   $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R"));
	    $this->fpdf->SetWidths(array(11,30,40,25.5,83,30,20,10,35));
		 $this->fpdf->Rowheader(array("Sno","Particulars","Chasisno","Motor No","Battery No","Charger","Rate","Qty","Amount"));
		/*
		  $this->fpdf->SetWidths(array(11,40,40,25.5,73,30,20,10,35));
		    $this->fpdf->SetAligns(array("C","C","C","C","C","R","C","R","R"));
		    $this->fpdf->Rowheader(array("$k","ER-India(G7)","$chassisno","$motorno","$battery","$charger","42,000.00","1","42,000.00"));
		    */
			}
			//$this->fpdf->cell(10,10,"$sd",0,0,'L');
		    $net=$net+$amnt;
		    $k++;
		    $distext=$rowinv->distext;
		    $dispercent=floatval($rowinv->discountper);
			$excisetax=$rowinv->excisetx;
			$vatcst=$rowinv->csttext;
	    
		}
		}
        $cstvat=explode("_",$vatcst);
        $cstct=floatval($cstvat[0]);
		$csttx=$cstvat[1];
		/*for($n=1;$n<4;$n++)
		{
			$this->fpdf->text(($gtx+1.5),($gty),"$n");
			$gty=$gty+5;
		}*/
	    /*$line = array( "Sl No"    => "1",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$y   += $size + 1;
				
				$line = array( "Sl No"    => "2",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$line = array( "Sl No"    => "2",
               "Description Of Goods"  => "E-Rickshaw( ER India G-7 )" 
               ,
               "Classification"     => "87039010",
               "Qty"      => "20 pcs",
               "Rate" => "42,000.00",
			   "Per"          => "pcs",
			   "Amount"=>"8,40,000.00" );
				$size = $this->fpdf->addLine( $y, $line );
				$y   += $size + 1;
		
		$size = $this->fpdf->addLine( $y, $line );*/
	  // $this->fpdf->ln(1);
	    //$x=$this->fpdf->getX();
	   // $y=$this->fpdf->getY();
	   // $y=210-$y;
	   // $this->fpdf->cell(6,5,"$x,$y",1,0,'C');
	   //$number=1250.00;
	   
	   $netnum=number_format($net,2);
	  // $red=$this->numbertowords->convert_number($net);
	   //$getst=$this->AccountManage_model->convert_number_to_words(intval($net));
	   $tot=$k-1;
	  //  $this->fpdf->ln($y);
	    $this->fpdf->SetFont('Arial','',10);
	    $this->fpdf->SetWidths(array(239.5,10,35));
		$this->fpdf->SetAligns(array("R","R","R"));
	    $this->fpdf->Rowheader(array("Net Assesable Value","$tot","$netnum"));
	    $this->fpdf->SetFont('Arial','',10);
		$discount2=floatval($net)*($dispercent/100);
		$discount=number_format($discount2,2);
		$net=floatval($net)-floatval($discount2);
		$netdis=number_format($net,2);
	    $this->fpdf->SetWidths(array(219.5,30,35));
		$this->fpdf->SetAligns(array("R","R","R"));
	    $this->fpdf->Rowheader(array("$distext","-$discount","$netdis"));
	   
	   // echo $net;
		//echo "<br>";
	    $excise=(floatval($net)*floatval($excisetax))/100; 
	   	$excise1=number_format($excise,2);
		$net4=floatval($net)+floatval($excise);
	     $cst=(floatval($net4)*floatval($cstct))/100;
		//echo "<br>";
		$cst1=number_format($cst,2);
		
		
	    $this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader2(array("Excise @ $excisetax%","$excise1"));
		 $this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
		/*$cst=floatval($net)*.05;
		$cst1=number_format($cst,2);
		$excise=floatval($net)*.06;
		$excise1=number_format($excise,2);*/
	    $this->fpdf->Rowheader2(array("$csttx @ $cstct%","$cst1"));
		/*$this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader2(array("Excise @ 6.00%","$excise1"));*/
	   $net2=round(floatval($net)+floatval($cst)+floatval($excise));
		//echo "<br>";
		//exit;
		$net3=number_format($net2,2);
		$this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader2(array("Grand Total","$net3"));
	   
		
		
		
	    /*$this->fpdf->SetAligns(array("C","C","C","C","C","C","R","C","R","R"));
	    $this->fpdf->SetWidths(array(11,40,18.5,35,30,55,30,20,10,35));
		$this->fpdf->Row(array("","Grand Total","","","","","","","$tot","$netnum"));*/
		/*$this->fpdf->SetWidths(array(239.5,10,35));
		$this->fpdf->SetAligns(array("R","R","R"));
		$this->fpdf->Rowheader(array("Page Total","$lno","$net3"));
        $this->fpdf->SetWidths(array(239.5,45));
		$this->fpdf->SetAligns(array("R","R"));
	    $this->fpdf->Rowheader(array("Grand Total","$netf"));*/
		$red=$this->numbertowords->convert_number($net2);	
	    $this->fpdf->SetFont('Arial','',10);
	    $this->fpdf->SetWidths(array(70,214.5));
	    $this->fpdf->SetAligns(array("L","L"));
	    $this->fpdf->Row(array("Amount Chargable (In words)","Rs.$red Only"));
		//$this->fpdf->ln(1);
		$gtx=$this->fpdf->getX();
		$gety=$this->fpdf->getY();
		//$this->fpdf->ln(2);
		$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
		$this->fpdf->line($gtx+.5,$gety,($gtx),($gety+31));
		$this->fpdf->line($gtx+285,$gety,($gtx+285),($gety+31));
		$this->fpdf->line($gtx+70,$gety,($gtx+70),($gety+31));
		$this->fpdf->SetFont('Times','',9);
		$this->fpdf->text($gtx+72,$gety+3,"1. Certified that the particulars given above are true and correct and that amount");
		$this->fpdf->text($gtx+72,$gety+6,"   indicated above represents the price actually changed from consignee and in ");
		$this->fpdf->text($gtx+72,$gety+9,"   according with sec 4 of the Central Excise Act 1944 and that there is no additi-");
		$this->fpdf->text($gtx+72,$gety+12,"   onal flow of consideration directly/or indirectly  from the buyer.");
		$this->fpdf->text($gtx+72,$gety+17,"2. Excise Duty payable under rule 8 of C Excise Rules 2002");
		$this->fpdf->line($gtx+180,$gety,($gtx+180),($gety+31));
		$this->fpdf->text($gtx+190,$gety+30,"Prepared by");
		$this->fpdf->text($gtx+230,$gety+30,"Checked by");
		$this->fpdf->text($gtx+260,$gety+30," Authorized Sign");
		//$this->fpdf->line($gtx+.5,$gety,($gtx+284.5),$gety);
		//$this->fpdf->line($gtx+.5,$gety,$gtx,($gety+30));
		//$this->fpdf->line(($gtx+284.5),$gety,($gtx+284.5),($gety+30));
		//$this->fpdf->line($gtx+.5,($gety+30),($gtx+149.5),($gety+30));
		//$this->fpdf->line(($gtx+149.5),$gety,284.5,$gety);
		//$this->fpdf->line(($gtx+149.5),($gety+30),291,($gety+30));
		//$this->fpdf->line(($gtx+149.5),($gety),($gtx+149.5),($gety+30));
		//$this->fpdf->line(285.5,($gety),285.5,($gety+30));
		
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->text(($gtx+244),($gety+4),"for G.K Rickshaw Pvt Ltd.");
		$this->fpdf->Image($img2, $this->fpdf->GetX()+260, $this->fpdf->GetY()+4,25,25,'png');
		//$gety=$gety+31;
		 $this->fpdf->SetFont('Times','',8);
		$this->fpdf->cell(30,5,"Serial No. in PLA/RG-23",0,0,'L');
		$this->fpdf->cell(30,5,": $serial ",0,1,'L');
		$this->fpdf->cell(30,5,"Manner Of Transport",0,0,'L');
		$this->fpdf->cell(30,5,": $mannertransport ",0,1,'L');
		$this->fpdf->cell(30,5,"Despatched through",0,0,'L');
		$this->fpdf->cell(30,5,": $despt ",0,1,'L');
		$this->fpdf->cell(30,5,"PR/GC Node No/L.R NO",0,0,'L');
		$this->fpdf->cell(30,5,": $prglrno ",0,1,'L');
		$this->fpdf->cell(30,5,"Vehicle No",0,0,'L');
		$this->fpdf->cell(30,5,": $vehicleno ",0,1,'L');
		$this->fpdf->cell(30,5,"Date",0,0,'L');
		$this->fpdf->cell(30,5,": $dte ",0,1,'L');
		
		//$gtx=$this->fpdf->getX();
		//$gety=$this->fpdf->getY();
		$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',10);
		$this->fpdf->Multicell(285,5,"$declt",1);
		//$this->fpdf->ln(1);
		$this->fpdf->SetFont('Times','B',11);
		$this->fpdf->Multicell(285,5,"NOTE: SUBJECT TO SERAMPORE JURISDICTION",1,'C');
		$this->fpdf->ln(2);
		$lnx=$this->fpdf->getX();
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',14);
		$this->fpdf->text($lnx+120,$lny+5,'"Your Green Partner"');
		$lny=$this->fpdf->getY();
		$this->fpdf->SetFont('Times','I',9);
		$this->fpdf->text(270,$lny+15,"To be Contd...");
		$this->fpdf->text(270,$lny+18,'Page No '.$this->fpdf->PageNo().' of {nb}');
		if($ty<3){
			$this->fpdf->addpage();
		}
		
		
		
		}
        if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowinfo)
				{
					$custtyp=$rowinfo->custtyp;
				}
		}
					
        if(strtoupper($custtyp)=="RETAILER"){
        	if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowinv)
				{
					$custnme=strtoupper($rowinv->custname);
					$custadd=strtoupper($rowinv->custadd);
					$chasisno=strtoupper($rowinv->chasisno);
			        $mtrno=strtoupper($rowinv->motorno);
					$particulars=strtoupper($rowinv->particulars);
					$modelexplode=explode("(",$particulars);
					$model=substr($modelexplode[1],-1);
					$makers="G K RICKSHOW";
					$getmodelinfo=$this->AccountManage_model->getallmodelinformation($model);
					if(!empty($getmodelinfo) && isset($getmodelinfo))
					{
						foreach($getmodelinfo as $romodelinfo)
						{
							$clsmodel=strtoupper($romodelinfo->clsModel);
							$batterypower=strtoupper($romodelinfo->batteryPower);
							$motorpower=strtoupper($romodelinfo->motorPower);
							$seatcap=strtoupper($romodelinfo->seatcap);
							$iron=strtoupper($romodelinfo->bodyType);
							$mfgyr=strtoupper($romodelinfo->mfgYear);
							$wt=strtoupper($romodelinfo->grossvhc);
						}
						
					}
					
					$clsvhc="E-Rickshaw";
			
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
	  
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',20);
		  $this->fpdf->text($x+78,$y+10,"FORM 20 ");
		  $this->fpdf->SetFont('Arial','B',15);
		  $this->fpdf->text($x+160,$y+10,"Price Rs. 5/- ");
		  $y=$y+10;
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+82,$y+5,"(See Rule 47) ",'C');
		$y=$y+5;
			 $this->fpdf->SetFont('Arial','',13);
		$this->fpdf->text($x+45,$y+5,"Form of application for Registration of a Motor Vehicle ");
		$y=$y+5;
		$this->fpdf->SetFont('Arial','',11);
		$this->fpdf->text($x+0,$y+5,"Registering Authority,");
		$y=$y+5;
		$this->fpdf->text($x+0,$y+5,"Hooghly,");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"1. Full Name of person to be registered as registered");
		//----------customer name-------------------------//
		if(isset($custnme) && !empty($custnme))
		{
			$this->fpdf->text($x+105,$y+5,"$custnme");
		    $this->fpdf->text($x+100,$y+6,"___________________________________________");
		}else{
			 $this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"owner/son/wife/daughter of");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"2. Age of the person to be registered owner (proof of");
		if(isset($custadd) & !empty($custadd)){
			$this->fpdf->text($x+105,$y+5,"$custadd");
			$this->fpdf->text($x+100,$y+6,"___________________________________________");
			
		}else{
			
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		//$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"age to be attached");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"3. Permanent address of the person to be registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"owner (evidence to be produced)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"4. Temporary address of the person to be registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"as register owner");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"5. Name and Address of the dealer or manufacturer");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"from whom the vehicle was purchased)");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"(sale certificate of road worthiness issued by the");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"manufacturer to be enclosed)");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"6. If ex-army vehicle or imported vehicle, enclosed");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"proof. If locally manufactured Trailer/Semi Trailer");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"enclosed the approval of design by the State");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"Transport Authority and note the proceedings");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"number and date of approval.");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"7. Class of Vehicle ( if Motor cycle, whether with or");
		if(isset($clsvhc) && !empty($clsvhc))
		{
			$this->fpdf->text($x+105,$y+5,"$clsvhc");
			$this->fpdf->text($x+100,$y+6,"___________________________________________");
		}else{
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"without gear).");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"8. The Motor Vehicle is");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"a)A New Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"b)Ex-army Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+4,$y+5,"c)Imported Vehicle :");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"9. Type of Body");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"10. Type of Vehicle");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"11. Maker's Name");
		if(isset($makers) && !empty($makers))
		{
			$this->fpdf->text($x+105,$y+5,"$makers");
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}else{
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"12. Month of year of Manufacturing");
		if(isset($mfgyr) && !empty($mfgyr))
		{
			$this->fpdf->text($x+105,$y+5,"$mfgyr");
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}else{
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"13. No. of Cylinder");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"14. Hours Power");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"15. Cubic Capacity");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"16. Maker's classification or if not know, wheel base");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"17. Chasis Number (Affix pencil permit)");$chasisno;
		if(isset($chasisno) && !empty($chasisno))
		{
			$this->fpdf->text($x+110,$y+5,"$chasisno");
		
		$this->fpdf->text($x+100,$y+6,"___________________________________________");
		}else
			{
				$this->fpdf->text($x+100,$y+5,"___________________________________________");
			}
		
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"18. Engine Number");
		if(isset($mtrno) && !empty($mtrno))
		{
			$this->fpdf->text($x+105,$y+5,"$mtrno");
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}else
		{
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"19. Seating Capacity (including driver)");
		if(isset($seatcap) && !empty($seatcap))
		{
			$this->fpdf->text($x+105,$y+5,"$seatcap");
			$this->fpdf->text($x+100,$y+6,"___________________________________________");
		}else{
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"20. Fuel use in the engine");
		$this->fpdf->text($x+105,$y+5,"Battery");
		$this->fpdf->text($x+100,$y+6,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"21. Unlanded Weight");
		if(isset($wt) && !empty($wt))
		{
			$this->fpdf->text($x+105,$y+5,"$wt");
			$this->fpdf->text($x+100,$y+6,"___________________________________________");
		}else{
			$this->fpdf->text($x+100,$y+5,"___________________________________________");
		}
		
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"22. Particulers of previous registration and registered");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"number (if any)");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"23. Colour of dolours of body, wings ans front end.");
		$this->fpdf->text($x+100,$y+5,"___________________________________________");
		$y=$y+8;
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		 
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+6,$y+5,"I hereby declared thet vehicle has not been registered if any state of India");
		$y=$y+4;
		$this->fpdf->text($x+6,$y+5,"Addition particulers to be completed only the case of transport vehicles other than motor car");
		$this->fpdf->SetFont('Arial','',11);
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"24. Number, description and size of type");
		$this->fpdf->text($x+70,$y+5,"..................................................................................................................");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"a) Front axle");
		$this->fpdf->text($x+26,$y+5,".................................................................");
		$this->fpdf->text($x+99,$y+5,"b) Rear axle");
		$this->fpdf->text($x+122,$y+5,"..................................................................");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"c) Any other axle");
		$this->fpdf->text($x+34,$y+5,"..........................................................");
		$this->fpdf->text($x+99,$y+5,"d) Tendem axle");
		$this->fpdf->text($x+127,$y+5,".............................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"25. Gross Vehicle Weight");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"a) As Cirtificated by the manufacturer");
		$this->fpdf->text($x+70,$y+5,"..........................................................................................................Kgms");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"b) to be regisered");
		$this->fpdf->text($x+37,$y+5,".........................................................................................................................................Kgms");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"26. Maximum axle weight");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"a) Front axle");
		$this->fpdf->text($x+26,$y+5,"........................................................Kgms.");
		$this->fpdf->text($x+99,$y+5,"b) Rear axle");
		$this->fpdf->text($x+122,$y+5,"..........................................................Kgms.");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"c) Any other axle");
		$this->fpdf->text($x+34,$y+5,".................................................Kgms.");
		$this->fpdf->text($x+99,$y+5,"d) Tendem axle");
		$this->fpdf->text($x+127,$y+5,".....................................................Kgms.");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"27. a) Front axle");
		$this->fpdf->text($x+26,$y+5,".................................................................");
		$this->fpdf->text($x+99,$y+5,"b) Rear axle");
		$this->fpdf->text($x+122,$y+5,"..................................................................");
		$y=$y+6;
		$this->fpdf->text($x+6,$y+5,"c) Any other axle");
		$this->fpdf->text($x+34,$y+5,"..........................................................");
		$this->fpdf->text($x+99,$y+5,"d) Tendem axle");
		$this->fpdf->text($x+127,$y+5,".............................................................");
		$y=$y+10;
		 $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+6,$y+5,"The above particulers are to be filled in for a right frame motor vehicle of two or more axle for an artiticulated vehicles of");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"three or more axles, or the..extent applicable of trailer, where as a second semi trailer or additional semi-trailer to be registered");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"with an articuleted motor vehicle the following particulers are to be fumished for each semi-teailer.");
		
		 $this->fpdf->SetFont('Arial','',11);
		$y=$y+10;
		$this->fpdf->text($x+0,$y+5,"28. Type of Body");
		if(isset($iron) && !empty($iron))
		{
			$this->fpdf->text($x+37,$y+5,"$iron");
			$this->fpdf->text($x+32,$y+6,"................................................................................................................................................");
		}else{
			$this->fpdf->text($x+32,$y+5,"................................................................................................................................................");
		}
		//$this->fpdf->text($x+32,$y+5,".......................................................................................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"29. Unlanden Weight");
		if(isset($wt) && !empty($wt))
		{
			$this->fpdf->text($x+44,$y+5,"$wt");
			$this->fpdf->text($x+39,$y+6,"................................................................................................................................................");
		}else{
			$this->fpdf->text($x+39,$y+5,"................................................................................................................................................");
		}
		
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"30. Number, description and size of type on each axle");
		$this->fpdf->text($x+95,$y+5,"............................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"31. Maximum axle weight in respect of each axle");
		$this->fpdf->text($x+85,$y+5,".....................................................................................................");
		$y=$y+9;
		$this->fpdf->text($x+0,$y+5,"32. The vehicle is covered by a valid");
		$this->fpdf->text($x+105,$y+5,"Insurance Certificate Cover note");
		$y=$y+6;
		$this->fpdf->text($x+7,$y+5,"certificated of insurance under");
		$this->fpdf->text($x+105,$y+5,"Note........................................dt...............................");
		$y=$y+6;
		$this->fpdf->text($x+7,$y+5,"chapter XI of the act");
		$this->fpdf->text($x+105,$y+5,"of.....................................................(Name of Comy)");
		$y=$y+7;
		$this->fpdf->text($x+0,$y+5,"33. The vehicle to exampted From");
		$this->fpdf->text($x+105,$y+5,"Valid from..................................to............................");
		$y=$y+6;
		$this->fpdf->text($x+7,$y+5,"Insurence. The relevent order is enclosed");
		$y=$y+10;
		$this->fpdf->text($x+0,$y+5,"34. I have prescribed fee of Rupees");
		$this->fpdf->text($x+64,$y+5,"........................................................................................................................");
		$y=$y+16;
		$this->fpdf->text($x+152,$y+5,"Signature of the person");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"Note :  The motor vehicle above described is :");
		$y=$y+6;
		$this->fpdf->text($x+13,$y+5,"i) Subject to hire purchase agreement / lease agreement / lease agreement with .......................................");
		$y=$y+4;
		$this->fpdf->text($x+16,$y+5,"....................................................................................................................................................................");
		$y=$y+4;
		$this->fpdf->text($x+13,$y+5,"ii) Subject to hypothecation in favour of ........................................................................................................");
		$y=$y+4;
		$this->fpdf->text($x+13,$y+5,"iii) Not, held under hire purchase agreement to lease / agreement or subject to hypothecation .");
		$y=$y+10;
		$this->fpdf->text($x+17,$y+5,"Strike out whatever is in applicable. If the vehicle is subject to any such agreement has been entered");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"into is to be obtain.");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"Signature of the person with whome leaser or");
		$y=$y+4;
		$this->fpdf->text($x+0,$y+5,"hypothecation has been entered into.");
		$y=$y+10;
		$this->fpdf->text($x+0,$y+5,"..............................................................................");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"Specimen Signature or the person to.");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"1.");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"2.");
		$this->fpdf->text($x+152,$y+5,"Signature of the owners");
		$y=$y+6;
		$this->fpdf->text($x+0,$y+5,"3.");
		}
		}
		}
		if(strtoupper($custtyp)=="RETAILER"){
			if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowinv)
				{
					$custnme=strtoupper($rowinv->custname);
					$custadd=strtoupper($rowinv->custadd);
					$chasisno=strtoupper($rowinv->chasisno);
			        $mtrno=strtoupper($rowinv->motorno);
					$particulars=strtoupper($rowinv->particulars);
					$modelexplode=explode("(",$particulars);
					 $model=rtrim($modelexplode[1],")");
					$makers="G K RICKSHOW";
					$getmodelinfo=$this->AccountManage_model->getallmodelinformation($model);
					if(!empty($getmodelinfo) && isset($getmodelinfo))
					{
						foreach($getmodelinfo as $romodelinfo)
						{
							$clsmodel=strtoupper($romodelinfo->clsModel);
							$batterypower=strtoupper($romodelinfo->batteryPower);
							$motorpower=strtoupper($romodelinfo->motorPower);
							$seatcap=strtoupper($romodelinfo->seatcap);
							$iron=strtoupper($romodelinfo->bodyType);
							$mfgyr=strtoupper($romodelinfo->mfgYear);
							$wt=strtoupper($romodelinfo->grossvhc);
						}
						
					}
					
					$clsvhc="E-Rickshaw";
			
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',25);
		  $this->fpdf->text($x+78,$y+20,"IMPRESSION ");
		   $this->fpdf->SetFont('Arial','B',11);
		  $y=$y+20;
		 
		$this->fpdf->text($x+30,$y+5," 30(33/1) N.T Road ,Padmabati Colony,Baidyabati, Hooghly,West Bengal-712222,India ",'C');
		$y=$y+5;
		$this->fpdf->text($x+75,$y+5,"FORM- 21 [ See rule 47(a)(d) ] ");
		$y=$y+7;
		$this->fpdf->SetFont('Arial','B',13);
		$this->fpdf->text($x+75,$y+5,"SALE CERTIFICATE");
		$this->fpdf->SetFont('Arial','B',11);
		$y=$y+10;
		//
		$this->fpdf->text($x+10,$y+5,"Certify that");
		$this->fpdf->text($x+90,$y+5,": G.K RICKSHOW");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Has been delivered by us to");
		$this->fpdf->text($x+90,$y+5,": $custnme");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"So / Wife / Daughter Of");
		$this->fpdf->text($x+90,$y+5,":  ");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Address (Present)");
		$this->fpdf->text($x+90,$y+5,": $custadd");
		$y=$y+20;
		$this->fpdf->text($x+10,$y+5,"Address (Permanent)");
		$this->fpdf->text($x+90,$y+5,": -Do-");
		$y=$y+15;
		$this->fpdf->SetFont('Arial','B',13);
		$this->fpdf->text($x+10,$y+5,"The vehicle is help under Agreement of hire purchase / Hypothecation with N / A");
		$y=$y+10;
		$this->fpdf->SetFont('Arial','B',13);
		$this->fpdf->text($x+65,$y+5,"PARTICULERS OF THE VEHICLE");
		$this->fpdf->SetFont('Arial','B',11);
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Class of Vehicle");
		$this->fpdf->text($x+90,$y+5,": E- Rickshaw ");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Maker's Name");
		$this->fpdf->text($x+90,$y+5,": G.K. Rickshow");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Chassis No.");
		$this->fpdf->text($x+90,$y+5,": $chasisno");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Motor ID No.");
		$this->fpdf->text($x+90,$y+5,": $mtrno");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Horse Power");
		$this->fpdf->text($x+90,$y+5,": $motorpower");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Fuel Used");
		$this->fpdf->text($x+90,$y+5,": Battery");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Seating Capacity");
		$this->fpdf->text($x+90,$y+5,": $seatcap");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Year of Manufacture");
		$this->fpdf->text($x+90,$y+5,": $mfgyr");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Tyre");
		$this->fpdf->text($x+90,$y+5,": ");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Unload Weight");
		$this->fpdf->text($x+90,$y+5,": $wt");
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Wheel Base");
		$this->fpdf->text($x+90,$y+5,": ");
		/*$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Colour");
		$this->fpdf->text($x+90,$y+5,": Cherri");*/
		$y=$y+10;
		$this->fpdf->text($x+10,$y+5,"Type of Body");
		$this->fpdf->text($x+90,$y+5,": $iron");
		}
		}
      }
//#############################################################################################################
//                        form 22
//########################################################################################################
$chasisn="M6REP3085T16B";
$motor="JMYM";$motor1=1245;
  if(!empty($getallinvoice) && isset($getallinvoice)){
				foreach($getallinvoice as $rowinv)
				{
				
		$this->fpdf->addpage('P');
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		// $chg=str_pad($k, 4 , '0', STR_PAD_LEFT);
		 //$mtr2=str_pad($motor1, 5 , '0', STR_PAD_LEFT);
		// $chasisno=$chasisn.$chg;
		// $mtrno=$motor.$mtr2;
		   $chasisno=$rowinv->chasisno;
			$mtrno=$rowinv->motorno;
			//$charger=$rowinv->chargerno;
			//$battr=$rowinv->batteryno;
			
		//company address--
		
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		 $this->fpdf->Image($img, $this->fpdf->GetX()+160, $this->fpdf->GetY()+22,35,25,'png');
		  $this->fpdf->SetFont('Arial','B',15);
		  $this->fpdf->text($x+88,$y+50,"FORM 22 ");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','',10);
		  $this->fpdf->text($x+50,$y+50,"[See rules 47(g), 115(2) 115(6) 115(7) 115(a) 124, 126(A) and 127] ");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','B',12);
		  $this->fpdf->text($x+18,$y+50,"INITIAL CERTIFICATE OF COMPLIENCE WITH POLLUTION, STANDERDS, SAFETY ");
		  $y=$y+6;
		  $this->fpdf->text($x+38,$y+50,"STANDERD OF COMPONENTS AND ROAD WORTHINESS ");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','',10);
		  $this->fpdf->text($x+70,$y+50,"(To be issued by the manufacturer)");
		  $y=$y+15;
		  $this->fpdf->SetFont('Arial','',11);
		  $this->fpdf->text($x+10,$y+50,"Cerfified that");
		  $this->fpdf->SetFont('Arial','B',13);
		  $this->fpdf->text($x+35,$y+50,"GK RICKSHOW");
		  $this->fpdf->SetFont('Arial','',11);
		  $this->fpdf->text($x+70,$y+50,"(Brand name of vehicle) bearing chassis number ");
		  $this->fpdf->SetFont('Arial','B',13);
		  $this->fpdf->text($x+155,$y+50,"$chasisno");
		  $this->fpdf->text($x+155,$y+51.5,"...................................");
		  $y=$y+6;
		  $this->fpdf->SetFont('Arial','',12);
		  $this->fpdf->text($x+10,$y+50,"MOTOR NO");
		  $this->fpdf->SetFont('Arial','B',13);
		   $this->fpdf->text($x+35,$y+50,"$mtrno");
		  $this->fpdf->text($x+35,$y+51.5,"......................");
		  $this->fpdf->SetFont('Arial','',11);
		  $this->fpdf->text($x+65,$y+50,"complies with provisions of the motor vehicles acts, 1988 and rules");
		  $y=$y+6;
		  $this->fpdf->text($x+10,$y+50,"made there under.");
		  $this->fpdf->SetFont('Arial','B',11);
		  $this->fpdf->text($x+150,$y+65,".............................................");
		  $this->fpdf->SetFont('Arial','B',11);
		  $this->fpdf->text($x+150,$y+69,"Signature of manufacturer");
		   $this->fpdf->Image($img, $x+10, $y+75,25,20,'png');
		   $this->fpdf->SetFont('Arial','B',16);
		   $this->fpdf->text($x+36,$y+80,"G.K RICKSHOW");
		   $this->fpdf->SetFont('Arial','',12);
		   $this->fpdf->text($x+36,$y+84,"30(33/1) N.T Road ,Padmabati Colony, ");
		   $this->fpdf->text($x+36,$y+89,"Baidyabati, Hooghly,West Bengal-712222,India ");
		    $this->fpdf->SetFont('Arial','I',10);
		   $this->fpdf->text($x+36,$y+94,"Phone:(033)-64517771 Email: accounts@gkrickshow.com ");
		    $this->fpdf->text($x+36,$y+99,"website:http://www.gkrickshaw.com");
		   
		  $motor1++;
		
		}
		}
//#############################################################################################################
//                       end form 22
//########################################################################################################
		
		
		$invoice="Invoice_GKR/16-17/0001.pdf";
		$this->fpdf->output("I","$invoice");
		
		
	 }
 public function getorderdate()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $orderno=$this->input->post("orderno");
	$getorderdte=$this->AccountManage_model->getorderdate($orderno);
	if(!empty($getorderdte) && isset($getorderdte))
	{
		foreach($getorderdte as $row)
		{
			$dt=$row->doe;
			//$custid=$row->custid;
		}
	}else
		{
			$dt="";
		}
		echo $dt;
		
 }
 public function getcustinformation()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$custid=$this->input->post("custinfo");
	$getcustinfo=$this->AccountManage_model->getcustinfo($custid);
	//print_r($getcustinfo);
	$result=array();
	if(!empty($getcustinfo))
	{
		foreach($getcustinfo as $row)
		{
			$clientid=$row->clientid;
			$name=$row->name;
			$comp=$row->compname;
			$type=strtoupper($row->custtype);
			$add=$row->add1.",".$row->add2.",".$row->district.",".",".$row->state.",".$row->country.",".$row->pin;
			$balance=$row->balance;
			$tin_vat=$row->tin_vat;
			$cst=$row->cst;
		}
		$result=array("clientid"=>"$clientid","compname"=>"$comp","name"=>"$name","type"=>"$type","address"=>"$add","balance"=>"$balance","tinvat"=>"$tin_vat","cst"=>"$cst");
	}else{
		$gettemcustid=$this->AccountManage_model->getlastretailcust();
		//print_r($gettemcustid);
		if(!empty($gettemcustid))
		{
			$clientid1=intval(substr($gettemcustid,-5));
			$clientid2=$clientid1+1;
			$clientid3=str_pad($clientid2, 5,"0",STR_PAD_LEFT);
			$clientid4="TGKCLNT".date('y')."$clientid3";
		}else
			{
				$clienti4="TGKCLNT1600001";
			}
		$result=array("clientid"=>"$clientid4","compname"=>"$custid","name"=>"","type"=>"RETAILER","address"=>"","balance"=>"","tinvat"=>"","cst"=>"");
	}
	echo json_encode($result);
 }
//##################################  update on 09012017   ###############################################
public function getsalesorderdetails($id)
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dash Board";
		$ordercode=$this->AccountManage_model->getOrderCode();
		$this->load->view("");
		//$ordercode=strtoupper($id);
		/*if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD".date('y').$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD".date('y').$invID;
		}*/
		//$bkid=$this->input->post("orderno");
		//$data['bkid']=$bkid;
		//$data['bkid']=$bkid;
		/*$data['orderdetals']=$this->AccountManage_model->getallsalesorder($bkid);
		if(isset($data['orderdetals'])&& !empty($data['orderdetals'])){
			foreach($data['orderdetals'] as $row)
			{
				$clientid=$row->custid;
				$salesman=$row->sname;
				$bkdt=$row->doe;
			}
			$data['bkdt']=$bkdt;
			$data['clientid']=$clientid;
			$data['salesman']=$salesman;;
			$data['custdetails']=$this->AccountManage_model->fgetcustdetails($clientid);
		}
		$data['godown']=$this->stockManage_model->fetchgodown();
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();*/
		//$this->load->view('Accounts/viewallsalesorder',$data);
}

//update on 10012017  
public function editinvoice($id)
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	//$data['title']="Dash Board";
	$invoiceid=$id;
	$data['getallinvoiceinfo']=$this->AccountManage_model->getallinvoiceedit($invoiceid);
	$data['title']="Accounts";
	$data['models']=$this->AccountManage_model->getallmodel();
	
	//$data['allinvoice']=$this->AccountManage_model->getallinvoice();
	$this->load->view("Accounts/editinvoice",$data);
	
}
//update on 12012017
 public function viewreceiptamnt()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['getreceipt']=$this->AccountManage_model->getreceiptamnt();
	$data['bankinfo']=$this->AccountManage_model->getbankinfo();
	$this->load->view("Accounts/viewreceipt",$data);
 }
  public function savebankinfo()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	date_default_timezone_set("Asia/kolkata");
	$accno=$this->input->post("accno");
	$doe=$this->input->post("dte");
	$depositby=$this->input->post("depositby");
	$purpose=strtoupper($this->input->post("purpose"));
	$custid=$this->input->post("custid");
	if(isset($depositby) && !empty($depositby))
	{
		$depositby=$depositby;
	}else
		{
			$depositby="";
		}
	$chqno=$this->input->post("chqno");
	if(isset($chqno)&& !empty($chqno))
	{
		$chqno=$chqno;
	}else{
		$chqno="";
	}
	$payamnt=floatval($this->input->post("payamnt"));
	$paymenttyp=$this->input->post("payamnttyp");
	$txnid=$this->input->post("txnid");
	//get  tansaction master update
	$dataarraytrnsmaster=array(
		"acstatus"=>1,
		"updateby"=>$this->session->userdata('user_name'),
		"receiptamnt"=>$payamnt,
		"lstupdte"=>date('Y-m-d h:i:s A')
	);
	$this->AccountManage_model->updatemastertcn($dataarraytrnsmaster,$txnid);
	//get current bank balance=
	$getbankbalance=$this->AccountManage_model->getbankbalanceinfo($accno);
	$balance=0;
	if(!empty($getbankbalance))
	{
		foreach($getbankbalance as $row)
		{
			$balance=floatval($row->balance);
		}
	}
	$balance=$balance+floatval($payamnt);
	//bank master balance update
	$data_array_bankmaster=array(
		"balance"=>$balance
	);
	$this->AccountManage_model->updatebankmainbalance($data_array_bankmaster,$accno);
	//set balance for bank transaction
	$getlasttransaction=$this->AccountManage_model->getlasttrnxno();
	print_r($getlasttransaction);
	if(!empty($getlasttransaction) && isset($getlasttransaction))
	{
		foreach($getlasttransaction as $rowtx)
		{
			$id=$rowtx->id;
		}
		$getlasttxn=$this->AccountManage_model->getlasttxn($id);
		print_r($getlasttxn);
		foreach($getlasttxn as $txrow)
		{
			$txnno=$txrow->txnno;
		}
		$lsttx=intval(substr($txnno,-6));
		$lasttr=$lsttx+1;
		$lsttxno=str_pad($lasttr,"6",0,STR_PAD_LEFT);
		$txnno="TXNGK".$lsttxno;
	}else{
		$txnno="TXNGK000001";
	}
	$data_array_banktransc=array(
		"accno"=>$accno,
		"debit"=>$payamnt,
		"balance"=>$balance,
		"chequeno"=>$chqno,
		"txnno"=>$txnno,
		"doe"=>date('Y-m-d'),
		"crtd"=>$this->session->userdata('user_name'),
		"cdoe"=>date('Y-m-d h:i:s A')
		
	
	);
	$this->AccountManage_model->savebanktransaction($data_array_banktransc);
	
	//set client master table
	  
	  if($purpose=="SECURITY")
	  {
	  	//$custid;
	  	$getsecuritybal=$this->AccountManage_model->getsecuritypaidbalance($custid);
		foreach($getsecuritybal as $mastx)
		{
			$security=floatval($mastx->securityamountpaid);
		}
		$security=floatval($security)+floatval($payamnt);
		$data_array_securitybal=array(
		
			"securityamountpaid"=>$security,
			"trns_crtd"=>$this->session->userdata('user_name'),
			"trns_doe_updt"=>date('Y-m-d h:i:s A')
		);
		$this->AccountManage_model->getupdatesecurity($data_array_securitybal,$custid);
		
	  }else{
	  	$getsecuritybal=$this->AccountManage_model->getsecuritypaidbalance($custid);
		foreach($getsecuritybal as $mastx)
		{
			$balance=floatval($mastx->balance);
		}
		$balnew=floatval($balance)+floatval($payamnt);
		$data_array_mainbal=array(
		
			"balance"=>$balnew,
			"trns_crtd"=>$this->session->userdata('user_name'),
			"trns_doe_updt"=>date('Y-m-d h:i:s A')
		);
		$this->AccountManage_model->getupdatemainbal($data_array_mainbal,$custid);
		
		
	  }
	  redirect('AcountsManage_Controller/viewreceiptamnt','refresh');
	
	
  }
  public function getbanifo()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$bankname=$this->input->post("bankname");
	$getallinfo=$this->AccountManage_model->getbankinfo2($bankname);
	$result=array();
	if(!empty($getallinfo) && !empty($getallinfo))
	{
		foreach($getallinfo as $row)
		{
			$bankacc=$row->accno;
			$brnch=$row->branchname;
			$accname=$row->accname;
		}
	}
	$result=array("accname"=>"$accname","accno"=>"$bankacc","branch"=>"$brnch");
	echo json_encode($result);
  }
  ////////////////////////////////////////////////////////  update on 13012017
  public function getpartsdetailsbymodel()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $type=$this->input->post("type");
	$custype=$this->input->post("custype");
	$getallparts=$this->AccountManage_model->getallspareparts($type);
	$gettaxinfo=$this->AccountManage_model->gettxin();
	foreach($gettaxinfo as $rowtx)
	{
		$cst=$rowtx->cstamnt;
		$vat=$rowtx->vatamnt;
	}
	if(!empty($getallparts) && isset($getallparts))
	{
		echo '<div class="col-md-12">
		 			<div class="col-md-6">
		 				<div class="form-group">
		 				    <input type="text" class="form-control" name="reqty" id="reqty" onblur="getalltotalparts()"/>
		 				     <label for="mName"> Enter Qty</label>
		 				</div>
		 			</div>
		 			<div class="col-md-6">
		 			</div>
		       </div>';
			   echo '<div class="col-md-12" style="overflow:scroll;height:300px;">
			   
			   	<table class="table table-bordered table-hover">
			   	<thead>
			   		<tr>
			   		    <th>
			   		    	<label class="checkbox-inline checkbox-styled checkbox-primary">
									<input type="checkbox" name="erick" id="checkAll" onclick="getallchecked('.$cst.','.$vat.');" class="second" /><span></span>
							</label>
						</th>
			   			<th><b>Sl No.</b></th>
			   			<th><b>Particulars(without discount)</b></th>
			   			<th><b>Unit</b></th>
			   			<th><b>Unit Price</b></th>
			   			<th><b>Total Qty</b></th>
			   			<th><b>Total</b></th>
			   			
					</tr>
				</thead>
				<tbody>
			   
			   ';
		 			
		      
		$sl=1;
		
		foreach($getallparts as $roparts)
		{
			echo '<tr>
			           <td>
				           	<label class="checkbox-inline checkbox-styled checkbox-primary">
										<input value="asd" class="second" id="chkbx_'.$sl.'" type="checkbox" name="rick_'.$sl.'" onclick="getalltotalassablevalue('.$cst.','.$vat.');"><span></span>
							</label>
			           </td>
			           <td>'.$sl.'</td>
			          
			           <td><input type="text" name="partsname_'.$sl.'" value="'.$roparts->materialname.'('.$roparts->mName.')" style="border:none;width:200px;" readonly/></td>
			           <td><input type="text" id="partsunit_'.$sl.'" name="partsunit_'.$sl.'" value="'.$roparts->unit.'" style="border:none;width:20px;" readonly/></td>
			           <td><input type="text" id="unitprice_'.$sl.'" name="unitprice_'.$sl.'" value="'.$roparts->buyprcrnt.'" style="border:none;width:50px;" readonly/></td>
			           <td><input type="text" name="totqty_'.$sl.'" value="" id="totqty_'.$sl.'" style="border:none;width:100px;" /></td>
			           <td><input type="text" name="totalmrp_'.$sl.'" value="" id="totalmrp_'.$sl.'" style="border:none;width:100px;text-align:right;" readonly/></td>
			           
			           
			
			     </tr>';
			
			
			$sl++;
			
			
		}
		 echo ' </tbody></table>
		 <input type="hidden" name="tottabrow" value="'.$sl.'" id="totrw"/>
		 
		 	</div>';
	}
	
	
  }

//update  14012017
   public function generate_invoice($id)
   {
   	$this->authentication->is_loggedin($this->session->userdata('user_name'));
   	$invoiceid=$id;
   	$data['bokingdetails']=$this->AccountManage_model->getallbookingdetails($invoiceid);
	$bokingdetails=$data['bokingdetails'];
	if(isset($bokingdetails) && !empty($bokingdetails))
	{
		foreach($bokingdetails as $rowinv)
		{
			$booking=$rowinv->bokingid;
			$custid=$rowinv->custid;
		   $particulars=$rowinv->particulars;
			$qnty=intval($rowinv->qnty);
			$color=$rowinv->color;
			$doe=$rowinv->doe;
		}
		$particularsex=explode("(",$particulars);
		 $parti=$particularsex[0];
		$pname=$particularsex[1];
		 $pnme2=explode(")",$pname);
		 $modelname=$pnme2[0];
	}
	$data['title']="Accounts";
	$data['models']=$this->AccountManage_model->getallmodel();
	$invoice=$this->AccountManage_model->getlastinvoice();
	if(!empty($invoice))
	{
		//$invoiceid=explode("/",$invoice);
		$invoiceid=substr($invoice,-5);
		$invoid=intval($invoiceid);
		$invoid=intval($invoid)+1;
		$invoid2=str_pad($invoid,5,"0",STR_PAD_LEFT);
		$dt=date('y');
		$data['invoice']="GKINV".$dt."$invoid2";
	}else
		{
			$dt=date('y');
			$data['invoice']="GKINV".$dt."0001";
		}
	/*$getlastorder=$this->AccountManage_model->getlastorder();
	if(!empty($getlastorder))
	{
		$bkid=intval(substr($getlastorder,-5));
		$bkid=$bkid+1;
		$bkid2=str_pad($bkid,5,"0",STR_PAD_LEFT);
		$data['booking']="GKSLSBK$bkid2";
	}else
	{
		$data['booking']="GKSLSBK00000";	
			
	}*/
	$data['getmodel']=$this->AccountManage_model->getmodelsbyjs($modelname);
	$data['getpartspr']=$this->AccountManage_model->getbatterprice($modelname);
	
	$data['getcharger']=$this->AccountManage_model->getchargerprice($modelname);
	
	$data['getcolorcode']=$this->AccountManage_model->getallcolorcode();
	
	$data['allinvoice']=$this->AccountManage_model->getallinvoice();
	$this->load->view("Accounts/createinvoice",$data);
	
   }
//update on 160102017
 public function generate_invoice_orderno()
   {
   	$this->authentication->is_loggedin($this->session->userdata('user_name'));
   	$invoiceid=$this->input->post("orderno");
   	$data['bokingdetails']=$this->AccountManage_model->getallbookingdetails($invoiceid);
	$bokingdetails=$data['bokingdetails'];
	if(isset($bokingdetails) && !empty($bokingdetails))
	{
		foreach($bokingdetails as $rowinv)
		{
			$booking=$rowinv->bokingid;
			$custid=$rowinv->custid;
		   $particulars=$rowinv->particulars;
			$qnty=intval($rowinv->qnty);
			$color=$rowinv->color;
			$doe=$rowinv->doe;
		}
		$particularsex=explode("(",$particulars);
		 $parti=$particularsex[0];
		$pname=$particularsex[1];
		 $pnme2=explode(")",$pname);
		 $modelname=$pnme2[0];
	}
	$data['title']="Accounts";
	$data['models']=$this->AccountManage_model->getallmodel();
	$invoice=$this->AccountManage_model->getlastinvoice();
	if(!empty($invoice))
	{
		//$invoiceid=explode("/",$invoice);
		$invoiceid=substr($invoice,-5);
		$invoid=intval($invoiceid);
		$invoid=intval($invoid)+1;
		$invoid2=str_pad($invoid,5,"0",STR_PAD_LEFT);
		$dt=date('y');
		$data['invoice']="GKINV".$dt."$invoid2";
	}else
		{
			$dt=date('y');
			$data['invoice']="GKINV".$dt."0001";
		}
	/*$getlastorder=$this->AccountManage_model->getlastorder();
	if(!empty($getlastorder))
	{
		$bkid=intval(substr($getlastorder,-5));
		$bkid=$bkid+1;
		$bkid2=str_pad($bkid,5,"0",STR_PAD_LEFT);
		$data['booking']="GKSLSBK$bkid2";
	}else
	{
		$data['booking']="GKSLSBK00000";	
			
	}*/
	$data['getmodel']=$this->AccountManage_model->getmodelsbyjs($modelname);
	$data['getpartspr']=$this->AccountManage_model->getbatterprice($modelname);
	
	$data['getcharger']=$this->AccountManage_model->getchargerprice($modelname);
	
	$data['getcolorcode']=$this->AccountManage_model->getallcolorcode();
	
	$data['allinvoice']=$this->AccountManage_model->getallinvoice();
	$this->load->view("Accounts/createinvoice",$data);
	
   }
   
}