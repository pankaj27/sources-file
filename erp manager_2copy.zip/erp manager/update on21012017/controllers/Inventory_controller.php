<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Inventory_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Inventory_model');
	}
	
	public function index()
	{		
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dashboard';
		//print_r($data);exit;
		$config = array();
        $config["base_url"] = base_url()."ManageTemplteCtrl/index";
        $config["total_rows"] =$this->ManageTemplteCtrl_Model->count_all_emailtemplate();
        $config["per_page"] = 10;
        $config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Previous';
		$config['uri_segment'] = 4;
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		///////// pagination ///////////////
		$data['all_picture']=$this->ManageTemplteCtrl_Model->fetch_all_emailtemplate($config["per_page"],$page);
		
		$str_links = $this->pagination->create_links();
		$data["links"] = explode('&nbsp;',$str_links );
		$this->load->view('Template/viewEmailTmplte',$data);
	}
  public function vehicle_master()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']='Add Email  Template ';
    $this->load->view('Inventory/item_master',$data);
	//echo "hello";
  }
  public function save_vehicle_item_master()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$bname=$this->input->post('bname');
  	$modelname=$this->input->post('modelname');
	$modelcode=$this->input->post('modelcode');
	$model_sal=$this->input->post('model_sal');
	$battery_power=$this->input->post('battery_power');
	$battery_model=$this->input->post('battery_model');
	$class_model=$this->input->post('class_model');
	$varient=$this->input->post('varient');
	$openqty=$this->input->post('openqty');
	$mancost=$this->input->post('mancost');
	$dealersaleprex=$this->input->post('dealersaleprex');
	$dealersaleprin=$this->input->post('dealersaleprin');
	$retailarprex=$this->input->post('retailarprex');
	$retailarprin=$this->input->post('retailarprin');
	//$retailarprin=$this->input->post('retailarprin');
	$retailarsaleprex=$this->input->post('retailarsaleprex');
	$retailarsaleprin=$this->input->post('retailarsaleprin');
	$servicepaid=$this->input->post('servicepaid');
	$servicedays=$this->input->post('servicedays');
	$motorpower=$this->input->post('motorpower');
	$seatcap=$this->input->post('seatcap');
	$grosswt=$this->input->post('grosswt');
	$typebody=$this->input->post('typebody');
	$fuelusd=$this->input->post('fuelusd');
	$mfgyr=$this->input->post('mfgyr');
	$unload=$this->input->post('unload');
	$octrai=$this->input->post('octrai');
	$data_array=array(
		"brandName"=>$bname,
		"modelName"=>$modelname,
		"modelCode"=>$modelname,
		"modelSL"=>$model_sal,
		"batteryPower"=>$battery_power,
		"batteryModel"=>$battery_model,
		"classofmodel"=>$class_model,
		"varient"=>$varient,
		"openQty"=>$openqty,
		"manfCost"=>$mancost,
		"distributerPriceEx"=>$dealersaleprex,
		"distributerPriceIn"=>$dealersaleprin,
		"distributertosubEx"=>$retailarprex,
		"distributertosubIn"=>$retailarprin,
		"subdistributertoretailEx"=>$retailarsaleprex,
		"subdistributertoretailIn"=>$retailarsaleprin,
		"servicePaid"=>$servicepaid,
		"servicefromdays"=>$motorpower,
		"motorPower"=>$motorpower,
		"seatCapacity"=>$seatcap,
		"grossvhclwt"=>$grosswt,
		"typeBody"=>$typebody,
		"fuelused"=>$fuelusd,
		"mfgYear"=>$mfgyr,
		"unloadnWt"=>$unload,
		"octraino"=>$octrai
	
	);
	$res1=$this->Inventory_model->checkdata($bname,$modelname,$modelname);
	if(empty($res1)){
	$res=$this->Inventory_model->savevehicle_itemmaster($data_array);
	if($res==1)
	{
		echo "Data Inserted Succesfully";
	}else{
		echo "Sorry!There is a problem";
	}
	}else{
		 
		echo "Data Already Inserted";
	}
	
	//echo $modelname;		
	}
  public function spareparts_master()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']='User Dash Board ';
	
    $this->load->view('Inventory/spare_parts_master',$data);
  }
  public function save_spare_parts()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	$data['title']='User Dash Board ';
	$brand_name=$this->input->post('brand_name');
	$group=$this->input->post('group');
	$partsno=$this->input->post('partsno');
	$description=$this->input->post('description');
	$mrp=$this->input->post('mrp');
	$vat=$this->input->post('vat');
	$latestpurchaseprice=$this->input->post('latestpurchaseprice');
	$rackno=$this->input->post('rackno');
	$openqty=$this->input->post('openqty');
	$valu2=$this->input->post('valu2');
	$balance=$this->input->post('balance');
	$moq=$this->input->post('moq');
	$reordlevel=$this->input->post('reordlevel');
	$minstock=$this->input->post('minstock');
	$maxstock=$this->input->post('maxstock');
	$salestax=$this->input->post('salestax');
	$surcharge=$this->input->post('surcharge');
	$addsurcharge=$this->input->post('addsurcharge');
	$application=$this->input->post('application');
	$type=$this->input->post('type');
	$data_save=array(
		"brand_name"=>$brand_name,
		"group1"=>$group,
		"partsno"=>$partsno,
		"description"=>$description,
		"mrp"=>$mrp,
		"vat"=>$vat,
		"latestpurchaseprice"=>$latestpurchaseprice,
		"rackno"=>$rackno,
		"openqty"=>$openqty,
		"valu2"=>$valu2,
		"balance"=>$balance,
		"moq"=>$moq,
		"reordlevel"=>$reordlevel,
		"minstock"=>$minstock,
		"maxstock"=>$maxstock,
		"salestax"=>$salestax,
		"surcharge"=>$surcharge,
		"addsurcharge"=>$addsurcharge,
		"application"=>$application,
		"type"=>$type
		
	);
	$res1=$this->Inventory_model->checkdata_spareparts($brand_name,$partsno);
	if(empty($res1)){
	$res=$this->Inventory_model->savespareparts_master($data_array);
	if($res==1)
	{
		echo "Data Inserted Succesfully";
	}else{
		echo "Sorry!There is a problem";
	}
	}else{
		 
		echo "Data Already Inserted";
	}
	
	
		
	
  	
  }
  public function inventary_dashboard()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']='User Dash Board ';
    $this->load->view('Inventory/inventory_dash',$data);
  }
	
}