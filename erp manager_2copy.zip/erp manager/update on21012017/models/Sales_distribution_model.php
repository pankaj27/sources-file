
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_distribution_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getlast_distid()
	{
		$query=$this->db->query("select max(id) as id from distributer_list");
		return $query->result();
	}
	
	public function check_alreadyexist($name,$phno,$email)
	{
		$query=$this->db->query("select * from distributer_list where name like'%".trim(strtoupper($name))."%' and email like'%".trim($email)."%' and phno like'%".trim($phno)."%'");
		return $query->result();
	}
	public function save_new_distributer($data_array)
	{
		$res=$this->db->insert('distributer_list',$data_array);
		if($res==TRUE)
		{
			return 1 ;
		}else{
			return 0 ;
		}
	}
	public function getall_state()
	{
		$query=$this->db->query("select * from state");
		return $query->result();
	}
	public function getall_distributer()
	{
		$query=$this->db->query("select * from distributer_list where status='0' order by id desc");
		return $query->result();
	}
}
