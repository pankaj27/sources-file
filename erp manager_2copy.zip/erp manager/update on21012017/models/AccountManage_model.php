<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AccountManage_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getallbookinglist()
	{
		$query=$this->db->query("select * from bookingorder where status='1' order by id desc ");
		return $query->result();
	}
	public function getallsalesorder($bkid)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($bkid)."' and status=1 ");
		return $query->result();
	}
	public function fgetcustdetails($clientid)
	{
		$query=$this->db->query("select * from 	clientmaster where 	clientid='".trim($clientid)."'");
		return $query->result();
	}
	public function getOrderCode()                                        //
	{                                                                     //
		$query=$this->db->query("select max(id) as id from StockTable");  //
		return $query->result();                                          //
	}
	public function save_chqDetails($data_array)
	{
		$this->db->insert('transection_master_acount', $data_array);
	}
	public function fetchTransctn()
	{
		$query=$this->db->query("select * from transection_master_acount order by id desc ");  
		return $query->result(); 
	}
	public function update_chqDetails($data_array,$clientID)
	{
		$this->db->where('clientid',$clientID);
		$this->db->update('clientmaster',$data_array);
	}
	public function getbookingdetls($bkid)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($bkid)."' and status='1'");
		return $query->result();
	}
	
	//================================  Taxation Details========================
	public function savetaxation($dataarray)
	{
		$this->db->insert("taxationdetails",$dataarray);
	}
  public function getalltaxation()
  {
  	$query=$this->db->query("select * from taxationdetails ");
	return $query->result();
  }
  public function gettaxinfo($id)
  {
  	$query=$this->db->query("select * from  taxationdetails where id='".trim($id)."'");
	return $query->result();
  }
  public function updatetaxtaion($dataarray,$roeid)
  {
  	$this->db->where('id',$roeid);
  	$this->db->update("taxationdetails",$dataarray);
  }
  public function getallparts($model)
  {
  	$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($model))."'");
	return $query->result();
  }
  public function getalltaxlast()
  {
  	$query=$this->db->query("select * from finalorder  order by id desc limit 1 ");
	return $query->result();
	
  }
  public function getpurchasepodetails($dte)
  {
  	$query=$this->db->query("select distinct(poid) as poid from finalorder where doe like'%".trim($dte)."%' ");
	return $query->result();
  }
  public function getallpurchaselst($po)
  {
  	$query=$this->db->query("select * from finalorder where poid='".trim(strtoupper($po))."' order by id desc limit 1");
	return $query->result();
  }
  public function getpartsname($prtscd)
  {
  	$query=$this->db->query("select * from materiel_master where materiel_id='".trim($prtscd)."'");
	$res=$query->result();
	foreach($res as $row)
	{
		$prtsname=$row->materialname;
	}
	return $prtsname;
  }
    
  public function updatebuypr($datapr,$partsid,$model)
  {
  	$dtar=array("materiel_id"=>$partsid);
  	$this->db->where($dtar);
	$this->db->update("materiel_master",$datapr);
  }
  public function savepurchasepr($data_array)
  {
  	$this->db->insert("purchaseprice",$data_array);
  }
  public function checkpoeist($poid,$venid)
  {
  	$query=$this->db->query("select * from purchaseprice where pono='".trim($poid)."' and venid='".trim($venid)."'");
  	return $query->result();
  	
	
  }
  public function checkpoeist2($poid)
  {
  	$query=$this->db->query("select * from purchaseprice where pono='".trim($poid)."'");
  	return $query->result();
  	
	
  }
  public function updatepurchasepr($data_array,$poid,$venid)
  {
  	$datar=array("pono"=>$poid,"venid"=>$venid);
  	$this->db->where($datar);
	$this->db->update("purchaseprice",$data_array);
  }
  public function updatepurchasepr2($data_array,$poid)
  {
  	$datar=array("pono"=>$poid);
  	$this->db->where($datar);
	$this->db->update("purchaseprice",$data_array);
  }
  public function getallpurchaseprc()
  {
  	$query=$this->db->query("select * from purchaseprice order by id desc ");
  	return $query->result();
  }
  
  //#################################################################################
  //  Update on 03012017
  //#################################################################################
  public function getallmodel()
  {
  	$query=$this->db->query("select * from productmaster order by id desc");
	return $query->result();
  }
  public function getmodelsbyjs($modelname)
  {
  	$query=$this->db->query("select  * from  productmaster where ucase(productname)='".trim(strtoupper($modelname))."'");
	return $query->result();
  }
  public function getbatterprice($modelname)
  {
  	$query=$this->db->query("select * from materiel_master where ucase(materialname)='BATTERY'  and mName='".trim(strtoupper($modelname))."'");
	return $query->result();
  }
   public function getchargerprice($modelname)
  {
  	$query=$this->db->query("select * from materiel_master where  ucase(materialname)='CHARGER' and mName='".trim(strtoupper($modelname))."'");
	return $query->result();
  }
  public function getallcolorcode()
  {
  	$query=$this->db->query("select * from color_code");
	return $query->result();
  }
  public function saveinvoice_info($dataarray)
  {
  	$this->db->insert("invoicegenerate",$dataarray);
  }
	
	public function getalldata($invoiceno)
	{
		$query=$this->db->query("select * from invoicegenerate where ucase(invoiceno)='".trim(strtoupper($invoiceno))."' ");
		return $query->result();
	}
	public function getpriceinfo($model)
	{
		$query=$this->db->query("select * from productmaster where ucase(productname)='".trim(strtoupper($model))."'");
		return $query->result();
	}
	public function gettaxinfodetails()
	{
		$query=$this->db->query("select * from taxationdetails");
		return $query->result();
	}
	public function updateinvoicedata($data_array,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("invoicegenerate",$data_array);
	}
	public function getlastinvoice()
	{
		$query=$this->db->query("select max(id) as id from  invoicegenerate");
		$res=$query->result();
		
			foreach($res as $row)
			{
				$id=$row->id;
			}
			$query2=$this->db->query("select * from invoicegenerate where id='".trim($id)."'");
			$result=$query2->result();
			foreach($result as $row2)
			{
				$invoiceno=$row2->invoiceno;
			}
			//return $invoiceno;
			if(isset($invoiceno) && !empty($invoiceno))
			{
				$invoiceno=$invoiceno;
			}else{
				$dt=date('y');
				$invoiceno="GKINV".$dt."0000";
			}
		
		return $invoiceno;
	}
	public function getlastorder()
	{
		$query=$this->db->query("select max(id) as id from  bookingorder");
		$res=$query->result();
		
			foreach($res as $row)
			{
				$id=$row->id;
			}
			$query2=$this->db->query("select * from bookingorder where id='".trim($id)."'");
			$result=$query2->result();
			foreach($result as $row2)
			{
				$bookingid=$row2->bokingid;
			}
			//return $invoiceno;
			if(isset($bookingid) && !empty($bookingid))
			{
				$bookingid=$bookingid;
			}else{
				//$dt=date('y');
				$bookingid="GKSLSBK00000";
			}
		return $bookingid;
	}
	public function getorderdate($orderno)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($orderno)."'");
		return $query->result();
	}
	public function getallinvoiceno($bkid)
	{
		$query=$this->db->query("select count(*) as norow from invoicegenerate where  invoiceno='".trim($bkid)."' ");
		return $query->result();
	}
	public function getallinvoicedet($bkid)
	{
		$query=$this->db->query("select * from invoicegenerate where  invoiceno='".trim($bkid)."' ");
		return $query->result();
	}
	public function getcustinfo($custid)
	{
		$query=$this->db->query("select * from clientmaster where ucase(clientid)='".trim(strtoupper($custid))."' or ucase(name)='".trim(strtoupper($custid))."' or ucase(compname)='".trim(strtoupper($custid))."' ");
		return $query->result();
	}
	public function getlastretailcust()
	{
		$query=$this->db->query("select max(id) as id from clientmaster");
		$res=$query->result();
		//print_r($res);
	    if(!empty($res) && isset($res))
		{
			foreach($res as $row)
			{
				$clid=$row->id;
			}
			$qur=$this->db->query("select * from clientmaster where id='".trim($clid)."'");
			$resu=$qur->result();
			foreach($resu as $row2)
			{
				$cld=$row2->clientid;
			}
			//echo $cld;
		}
		if(isset($cld) && !empty($cld))
		{
			$cld=$cld;
		}else
			{
				$cld="TGKCLNT1600000";
			}
		
		return $cld;
	}
	public function getallmodelinformation($model)
	{
		$query=$this->db->query("select * from productmaster where ucase(productname)='".trim(strtoupper($model))."'");
		return $query->result();
	}
	public function getcustcom($custid)
	{
		$query=$this->db->query("select * from clientmaster where ucase(clientid)='".trim(strtoupper($custid))."'");
		return $query->result();
	}
	//update on 10012017
	public function getallinvoice()
	{
		$query=$this->db->query("select * from invoicegenerate order by invoiceno desc");
		return $query->result();
	}
	public function getallinvoiceedit($invoiceid)
	{
		$query=$this->db->query("select * from invoicegenerate where invoiceno='".trim(strtoupper($invoiceid))."' ");
		return $query->result();
	}
	public function checkdatacustexist($custname,$custaddress,$custvat,$custtin,$custtype)
	{
		$query=$this->db->query("select * from clientmaster where ucase(name)='".trim(strtoupper($custname))."' and ucase(custtype)='".trim(strtoupper($custtype))."' and ucase(add1)='".trim(strtoupper($custaddress))."' and ucase(tin_vat)='".trim(strtoupper($custvat))."' and ucase(cst)='".trim(strtoupper($custtin))."' ");
		return $query->result();
	}
	public function savecustdata($datacustar)
	{
		$this->db->insert("clientmaster",$datacustar);
	}
	public function updatecustdata($datacustar,$custid)
	{
		$this->db->where("clientid",$custid);
		$this->db->update("clientmaster",$datacustar);
	}
	public function getmailsentstatus($clientID)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($clientID)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$mailsentst=$row->mailsentstatus;
		}
		return $mailsentst;
	}
	//update on 11012017
	public function getsalemanid($custid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($custid)."'");
		$res=$query->result();
		
		return $res;
	}
	public function getreceiptamnt()
	{
		$query=$this->db->query("select tma.id as id,tma.dat as doe,tma.branchname as branchName,tma.submitby as submitby ,tma.type as type,tma.bankName as bankName,tma.paid_amt as paid_amt,tma.purpose as purpose,tma.cheque_no as cheque_no,tma.acstatus as acstatus,cm.clientid as clientID,cm.custtype,cm.name as name  from transection_master_acount as tma,clientmaster as cm where tma.clientID=cm.clientid order by tma.id desc");
		//echo "select * from transection_master_acount as tma,clientmaster as cm where tma.clientID=cm.clientid order by tma.id desc";
		return $query->result();
	}
	//update on 12012017
	public function getbankinfo()
	{
		$query=$this->db->query("select * from bankinformation order by bankname asc ");
		return $query->result();
	}
	public function updatemastertcn($dataarraytrnsmaster,$txnid)
	{
		$this->db->where('id',$txnid);
		$this->db->update("transection_master_acount",$dataarraytrnsmaster);
	}
	public function getbankbalanceinfo($accno)
	{
		$query=$this->db->query("select * from bankinformation where accno='".trim(strtoupper($accno))."'");
		return $query->result();
	}
	public function updatebankmainbalance($data_array_bankmaster,$accno)
	{
		$this->db->where("accno",$accno);
		$this->db->update("bankinformation",$data_array_bankmaster);
	}
	public function getlasttrnxno()
	{
		$query=$this->db->query("select max(id) as id from bankinformation ");
		return $query->result();
		
	}
	public function getlasttxn($id)
	{
		$query=$this->db->query("select * from banktransaction where id='".trim($id)."'");
		return $query->result();
	}
	public function savebanktransaction($data_array_banktransc)
	{
		$this->db->insert("banktransaction",$data_array_banktransc);
	}
	public function getsecuritypaidbalance($custid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($custid)."'");
		return $query->result();
	}
	public function getupdatesecurity($data_array_securitybal,$custid)
	{
		$this->db->where("clientid",$custid);
		$this->db->update("clientmaster",$data_array_securitybal);
	}
	public function getupdatemainbal($data_array_mainbal,$custid)
	{
		$this->db->where("clientid",$custid);
		$this->db->update("clientmaster",$data_array_mainbal);
	}
	public function getbankinfo2($bankname)
	{
		$query=$this->db->query("select * from bankinformation where id='".trim($bankname)."'");
		return $query->result();
	}
////////////////////////////////////////         upsdate on 13012017   /////////////////////////////////////
   public function getallspareparts($type)
   {
   	$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($type))."' order by materialname asc");
	
	return $query->result();
   }
   public function gettxin()
   {
   	$query=$this->db->query("select * from taxationdetails");
	return $query->result();
   }
     //------------------------update on 14012017--------------
   public function getallbookingdetails($invoiceid)
   {
   	$query=$this->db->query("select * from bookingorder where bokingid='".trim(strtoupper($invoiceid))."'");
	return $query->result();
   }
   //update on 16012017
   public function getcustinfodetails($custid)
   {
   	$query=$this->db->query("select * from clientmaster where  clientid='".trim($custid)."'");
   	return $query->result();
   }
 }