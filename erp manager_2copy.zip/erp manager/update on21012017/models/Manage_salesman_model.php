<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_salesman_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getlastid()
	{
		$query=$this->db->query("select max(id) as id from salesman");
		$res= $query->result();
		foreach($res as $row)
		{
			$id=$row->id;
		}
		return $id;
	}
	public function insert($data_insert)
	{
		$this->db->insert('salesman',$data_insert);
	}
	public function getallsalesman()
	{
		$query=$this->db->query("select * from salesman order by id desc");
		return $query->result();
	}
	public function deletesalesman($sid)
	{
		$query=$this->db->query("delete from salesman where id='".trim($sid)."'");
	}
	public function getdepartments()
	{
		$query=$this->db->query("select * from departments where status='0' order by name asc");
		return $query->result();
	}
	//updae on 31122016========
	public function getallsalesmanindividual($sid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($sid)."' ");
		return $query->result();
	}
	public function updatesalesman($data_insert,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("salesman",$data_insert);
	}
}
	

