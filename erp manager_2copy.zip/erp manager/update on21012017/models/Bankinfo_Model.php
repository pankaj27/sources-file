<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bankinfo_Model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function saveinfo($data_array)
	{
		$this->db->insert('bankinformation',$data_array);
	}
	public function getalldata()
	{
		$query=$this->db->query("select * from bankinformation order by id desc");
		return $query->result();
	}
	public function deleteinfo($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('bankinformation');
	}
	public function fetchinfo1($id1)
	{
		$query=$this->db->query("select * from bankinformation where id='".trim($id1)."'");
		return $query->result();
	}
	public function updateinfo($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('bankinformation', $data_array);
	}
}
	

