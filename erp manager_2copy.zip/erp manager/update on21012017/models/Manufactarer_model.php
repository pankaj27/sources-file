<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manufactarer_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getallmodel()
	{
		$query=$this->db->query("select * from productmaster");
		return $query->result();
	}
	public function getmnthcode($mnth)
	{
		$query=$this->db->query("select * from chasismntcode where mnthno='".trim($mnth)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$code=$row->code;
		}
		return $code;
	}
	public function getallchasisdt($yr,$getmonthcode)
	{
		$query=$this->db->query("select * from manufact where manfYr='".trim($yr)."' and monthcode='".trim($getmonthcode)."' order by id desc limit 1");
		return $query->result();
	}
}
