<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>

<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		input[type="text"]{
			text-transform: uppercase;
		}
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"><?php  if(isset($title)){ echo $title; } ?></li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">
				

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Model Price</a></li>
								<!--<li><a href="<?php echo base_url(); ?>newBrand_controller/viewmodel">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" action="<?php  echo base_url();?>Sales_Controller/printmodelprice"  method="post" target="_blank"  >
						<div class="card">
							<div class="card-head style-primary">
								<header>Create</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-12">
											<div class="form-group">
												<!--<input type="text" class="form-control" id="departments" name="departments" value="" required="required">-->
												<select class="form-control" name="modelname" required="required">
													<option value=""></option>
													<?php if(isset($model1)  && !empty($model1)){ ?>
														<option value="<?php echo $model1; ?>" selected><?php echo $model1; ?></option>
														<?php if(isset($model) && !empty($model)){ ?>
													      <?php foreach($model1 as $row){ ?>
														
															<option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
													
												         <?php 
														  }
														} 
														 
												 	}else{ ?>
												<?php if(isset($model) && !empty($model)){ ?>
													<?php foreach($model as $row){ ?>
														
															<option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option>
													
												<?php } }
													}  ?>
												 </select>
												<label for="modelcode">SELECT MODEL</label>
											</div>
										</div>
									
								</div>
								<div class="row">	
									<div class="card-actionbar">
										<div class="card-actionbar-row">
											<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
										</div>
									</div>
							    </div>
							</form>	
							<div class="row">
								<form action="<?php  echo base_url();?>Sales_Controller/printallmodelprice" method="post" target="_blank">
									<div class="col-md-12">
										<div class="card-actionbar">
										<div class="card-actionbar-row">
											<button type="submit" class="btn btn-flat btn-primary ">Print All</button>
										</div>
									    </div>
									</div>
								</form>
							</div>	
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						    	</div>
							    	
							    	
							    	
							</div>
				</div>
				
         
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLvoter(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLpan(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah2').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLadhar(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah3').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#imgInp").change(function(){
        readURL(this);
    });
    $("#imgInp1").change(function(){
        readURLvoter(this);
    });
    $("#imgInp2").change(function(){
        readURLpan(this);
    });
    $("#imgInp3").change(function(){
        readURLadhar(this);
    });
</script>
