<?php 
//$con=mysqli_connect("localhost","senatedt_erp_man","pkp@9800743629","senatedt_erp_manager");
 //$con=mysqli_connect("localhost","gkricksh_erp","gkerp@2016","gkricksh_erpmanager");

$con=mysqli_connect("localhost","root","","erp_manager"); 


?>