 <?php include('conection.php'); ?>
 
 <?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			
		}
		#example tr{
			line-height:5px;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">View Salesman Terget</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View</a></li>
								<!--<li><a href="<?php// echo base_url(); ?>newBrand_controller/modelEntry">Create</a></li>>-->
								<!--<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
<center><button type="button" class="btn btn-flat btn-primary ink-reaction">CREATE TERGET</button></center>
						<form action="<?php echo base_url(); ?>Sales_Controller/savealldata" method="POST">	
							
							<div class="tab-pane active" id="first1"  style="overflow-x: scroll;">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
                <th>ID</th>
                <th>NAME</th>
                <th>IMAGE</th>
                <th>MONTH</th>
                <th>TARGET</th>
                <th>MIN TARGET</th>
				 <th>SAVE</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($sales_terget)){  $j=1; ?>
			<?php foreach($sales_terget as $row){ ?>
				
            <tr>
               <td><?php echo $j; ?> </td>
                <td><?php echo $row->salesmanid; ?> <input type="hidden" name="salesmanid_<?php echo $j; ?>" id="salesmanid_<?php echo $j; ?>" value="<?php echo $row->salesmanid; ?>"></td>
                <td><?php echo $row->name; ?></td>
                <td><img src="<?php echo base_url(); ?>uploads/Salesman/<?php echo $row->image; ?>" width="70" height="70" style="border-radius:50%" /> </td>
                <td>
					<select name="month_<?php echo $j; ?>" id="month_<?php echo $j; ?>">
						<!--<option value="<?php// echo date('M Y'); ?>"><?php// echo date('M Y'); ?></option>-->
						<?php $salesmanid=$row->salesmanid; ?>
						
						<?php $queryst=mysqli_query($con,"select * from sales_terget where salesmanid='".trim($salesmanid)."' and monthcode='".date('F')."' "); ?>
						<?php //while($alldata=mysqli_fetch_array($queryst)){
							$alldata=mysqli_fetch_array($queryst);
							$month=$alldata['monthcode'];
							$year=$alldata['yearcode'];
						if(!empty($alldata) && isset($alldata)){?>
							<option value="<?php echo $month; ?> <?php echo $year; ?>"><?php echo $month; ?> <?php echo $year; ?></option>
						
						<?php
							  for ($i = 0; $i <= 11; ++$i) {
								$time = strtotime(sprintf('+%d months', $i));
								$value = date('Y-m', $time);
								$label = date('F Y', $time);
								printf('<option value="%s">%s</option>', $label, $label);
							  }
							  ?>
						<?php }else{?>
							<?php 
								for ($i = 0; $i <= 11; ++$i) {
								$time = strtotime(sprintf('+%d months', $i));
								$value = date('Y-m', $time);
								$label = date('F Y', $time);
								printf('<option value="%s">%s</option>', $label, $label);
							  }
						} //}?>	
					</select>
				
				
				</td>
                <td>
				<?php $queryst=mysqli_query($con,"select * from sales_terget where salesmanid='".trim($salesmanid)."' and monthcode='".date('F')."' and yearcode='".date('Y')."' "); ?>
						<?php //while($alldata=mysqli_fetch_array($queryst)){
							$alldata=mysqli_fetch_array($queryst);
							$terget=$alldata['terget'];
							$minterget=intval($alldata['mintarget']);
							if(!empty($alldata) && isset($alldata)){ ?>
						<input type="number" name="terget_<?php echo $j; ?>" id="terget_<?php echo $j; ?>" value="<?php echo $terget; ?>" /> 
						<?php }else{ ?>
						<input type="number" name="terget_<?php echo $j; ?>" id="terget_<?php echo $j; ?>"  /> 
						<?php }?>
				</td>
				<td> 
					
					<?php echo "<select name='mintarget' id='mintarget_".$j."'>"; ?>
					<?php if($minterget>0){
						
						
						echo "<option value='".$minterget."' selected>".$minterget."</option>";
						 $getmintarget=mysqli_query($con,"select * from incentive order by id asc"); ?>
					
					<?php while($getrmintarget=mysqli_fetch_array($getmintarget))
						{
							
							
								echo "<option value='".$getrmintarget['min_length']."'>".$getrmintarget['min_length']."</option>";
							
							
							
							
							
							
						}
						
					}else{ ?>
					
					<?php $getmintarget=mysqli_query($con,"select * from incentive order by id asc"); ?>
					
					<?php while($getrmintarget=mysqli_fetch_array($getmintarget))
						{
							
							
								echo "<option value='".$getrmintarget['min_length']."'>".$getrmintarget['min_length']."</option>";
							
							
							
							
							
							
						}
						
					
					}
					echo "</select>"; 
					 ?>
					
					
				</td>

				<td>
							 <!--<button type="button" class="btn btn-sm btn-success"><i class="ace-icon fa fa-check">-->
							 <button type="button" id="savesing_<?php echo $j; ?>" onclick="saveindividualdata(this.id);" class="btn btn-flat btn-primary ink-reaction"></i> save</button>
									
				</td>
				
            </tr>
            <?php $j++; } } ?>
			
        </tbody>
		
    </table>
    <input type="hidden" value="<?php echo $j; ?>" name="totalrow">
				</div><br>
				<!--<center><button type="submit" class="btn btn-primary"></i> save</button></center>-->
				</form>	


						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->

		</div><!--end .section-body -->
	</section>
	<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

<script>
function saveindividualdata(id)
   {
	   var idsplit=id.split("_");
	   var month=$("#month_"+idsplit[1]).val();
	   //alert(month);
	   var terget=$("#terget_"+idsplit[1]).val();
	   var salesmanid=$("#salesmanid_"+idsplit[1]).val();
	  var mintarget=$("#mintarget_"+idsplit[1]).val();
	  // alert(terget);
	   $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url(); ?>Sales_Controller/saveinddata",
  			data :{'month':month,'terget':terget,'salesmanid':salesmanid,'mintarget':mintarget},
  			success : function(data){
  				//console.log(data); 
				alert(data);
								
  				//alert('Data Inserted Successful');
				
              }  
           }); 	
   }
</script>