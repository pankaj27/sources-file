<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php  include('conection.php'); ?>
<?php date_default_timezone_set("Asia/Kolkata"); ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>


	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"> CREATE RETAIL BOOKING </li>
				</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">RETAIL BOKKING</a></li>
								<li><a href="#second">EDIT/VIEW BOOKING</a></li>
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
							<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" action="<?php echo base_url(); ?>Bokking_controller/savebooking" method="post" >
					<div class="card">
							<div class="card-head style-primary">
								<header>CUSTOMER INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="invoicno" class="form-control"  id="invoiceno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($booking) && !empty($booking)){ echo $booking; } ?>" readonly />
												<label for="mName">BOOKING ID</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="orderdate" class="form-control"  id="orderid" placeholder="" style="text-transform: uppercase;" value="<?php echo date('Y-m-d h:i:s A') ?>"  />
												<label for="mName">BOOKING DATE</label>
											</div>
										</div>
										<!--<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderdate" class="form-control"  id="orderdate" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">Order Date</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<!--<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>-->
										</div>
										</div>
										
									</div>
								</div>
							
						<div class="card">
							<div class="card-head style-primary">
								<header>CUSTOMER  INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" name="custname" class="form-control"  id="custinfo" placeholder="" style="text-transform: uppercase;" onblur="custdetails()" required="required"/>
											<label for="mName">CUSTOMER NAME</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="custid" id="custid" value="" readonly/>
												
												<label for="mName">CUSTOMER ID</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="add1" class="form-control"  id="custaddress" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">ADDRESSLINE 1</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="add2" class="form-control"  id="custbalance" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">ADDRESSLINE 2</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="pin" class="form-control"  id="pin" placeholder="" style="text-transform: uppercase;" required="required"  />
												<label for="mName">PINCODE </label>
											</div>
										</div>
										
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custtyp" class="form-control"  id="custtyp" placeholder="" style="text-transform: uppercase;" readonly />
												<label for="mName">CUSTOMER TYPE</label>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="email" id="emailid" value="" />
												<input type="hidden" name="custcomp" id="custcomp" value=""/>
												<label for="mName">EMAIL ID</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="phnono" class="form-control"  id="phno" placeholder="" style="text-transform: uppercase;" required="required" />
												<label for="mName">PHONE NO</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="voterid" class="form-control"  id="voterid" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">VOTER ID(OPTIONAL)</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="panno" class="form-control"  id="panno" placeholder="" style="text-transform: uppercase;"  />
												<label for="mName">PAN CARD NO(OPTIONAL)</label>
											</div>
										</div>
										
									</div>
								</div>
								<div class="row"><hr></div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="vattin" class="form-control"  id="vattin" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">VAT/TIN NO</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="cst" class="form-control"  id="c" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">CST NO</label>
											</div>
										</div>
										
										
									</div>
								</div>
								
								
								
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>PAYMENT INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" name="deposit" class="form-control"  id="deposit" placeholder="" style="text-transform: uppercase;" required />
											<label for="mName">AMOUNT DEPOSIT</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<select id="purpose" class="form-control select2-list" name="purpose"  required  >
													<option value="0"></option>
													<option value="security">SECURITY DEPOSIT</option>
													<option value="advanced">ADVANCED</option>
													<option value="others">Others</option>
												</select>
											<label for="mName">PURPOSE</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<select id="paymentmode" class="form-control select2-list" name="paymentmode"  required  >
													<option value="0"></option>
													<option value="cash">CASH</option>
													<option value="cheque">CHEQUE</option>
													<option value="rtgs">RTGS/NEFT</option>
												</select>
												<label for="mName">PAYMENT MODE</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="chqno" class="form-control"  id="chqno" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">CHEQUE NO</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<!--<input type="text" name="bankname" class="form-control"  id="bankname" placeholder="" style="text-transform: uppercase;" readonly />-->
												<?php if(isset($bankdetails) && !empty($bankdetails)){ ?>
												<select name="bankname" class="form-control">
													<option value=""></option>
													<?php foreach($bankdetails as $robank){ ?>
													 <option value="<?php echo $robank->bank_name; ?>"><?php echo $robank->bank_name; ?></option>
													<?php } ?>
												</select>
												<?php  } ?>
												<label for="mName">BANK NAME</label>
											</div>
										</div>
										
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="branch" id="branch" value="" />
												
												<label for="mName">BRANCH NAME</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="delivary" id="delivary"  required />
												
												<label for="mName">EXPEXTED DELIVERY DATE</label>
											</div>
										</div>
										<!--<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="phnono" class="form-control"  id="phno" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">PHONE NO</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="voterid" class="form-control"  id="voterid" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">VOTER ID(OPTIONAL)</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="panno" class="form-control"  id="panno" placeholder="" style="text-transform: uppercase;"  />
												<label for="mName">PAN CARD NO(OPTIONAL)</label>
											</div>
										</div>-->
										
									</div>
								</div>
								<!--<div class="row"><hr></div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="vattin" class="form-control"  id="vattin" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">VAT/TIN NO</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="cst" class="form-control"  id="c" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">CST NO</label>
											</div>
										</div>
										
										
									</div>
								</div>-->
								
								
								
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>BOOKING DETAILS</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<select id="cattyp" class="form-control select2-list" name="cattyp"  required onchange="gettypedetails()" required >
													<option value="0"></option>
													<option value="product">Model</option>
													<option value="parts">Spare Parts</option>
												</select>
										       <label for="mName"> Select Product Type</label>
											</div>
										</div>
										<div class="col-md-16">
										
										<div class="col-md-6">
											<div class="form-group" id="modeldetails">
												
											</div>
										</div>
									</div>
									</div>
								</div>
<!--###########################################################################  Model details  Information   --->
								<div class="row" id="model_details">
									 
								</div>
								<hr>
								<!--<div class="row" id="getchassisin">
									 
								</div>-->
								<div class="row" id="parts_details">
									
									
								</div>
								<div class="row">
									
										<table class="table table-bordered table-hover" id="particulars">
											
											<tbody>
												<tr>
												   <th>Sl No.</th>
													<th>Particulars(without discount)</th>
													<th>Qnty</th>
													<th>Unit Price</th>
													<th>Total</th>
													<th>Action</th>
												</tr>
											</tbody>
										</table>
									</div>
									<div class="col-md-12">
										<hr>
									</div>
									<div class="col-md-12">
										<div class="col-md-3"></div>
										<div class="col-md-3"></div>
										<div class="col-md-3" style="text-align: right;"><b>Net Assasable Value:</b></div>
										<div class="col-md-3" style="text-align: center;"><input type="text" name="netassval" id="netassableval" style="border:none;font-weight: bolder;"/></div>
														
													
									 </div>
									 <div class="col-md-12">
										<hr>
									</div>
									<div class="col-md-12" id="excisetx">
														
													
									 </div>
									 <div class="col-md-12" id="cstvat">
														
													
									 </div>
									  <div class="col-md-12" id="nettoal">
														
													
									 </div>
									 <div class="col-md-12" id="nettoal">
									 	  <input type="hidden" name="excise" id="exc"/>
											<input type="hidden" name="tabtotrow" id="tabtotrow" value=""/>
											<button type="Submit" class="btn btn-primary" id="submit" >SUBMIT</button>		
									 </div>
								</div>
						</div>
						
						</div>
						
							
				 </form>	
    						
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					</div>
					</div>
<!--########################################################################################################################-->
<!--  -                                        Second Tab  -->
<!-- #############################################################################################################-->
					
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  
 
 
<script>
  $(document).ready(function(){
  	 $("#submit").hide();
  	 
  	 $("#delivary").datepicker({dateFormat:'yy-mm-dd'});
  	 
  });
	function gettypedetails()
	{
		var cattyp=$("#cattyp").val(); 
	//alert(cattyp);
	//console.log(cattyp);
	if(cattyp=="0")
	{
		//$("#model").show();
  	    //$("#model").html(data);
  	    $("#modeldetails").remove();
  	    
	}else
	{
		//$("#model").hide();
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodellistbyparts",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					//$("#model").show();
  				  $("#modeldetails").html(data);
              }  
       });
		
		//if(cattyp=="parts")
		//{
			
		//}else
		//{
			
		//}
	}
	}
	function getmodeltypebyparts()
    {
	var type1=$("#mname").val();
	var custype=$("#custtype").val();
	//var custype="CNF";
	//alert(type1);
	//var typesplit=type1.split("_");
	//var type=typesplit[0];
	//var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodelprice",
  			data :{'type':type1,'custype':custype},
  			success : function(data){
  					//alert(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#model_details").html(data);
              }  
       });
	
	
}
function getallchassisinfo()
{
	var reqty=parseInt($("#reqty").val());
	var model=$("#mname").val();
	//alert(reqty);
	var netassval=parseFloat($("#netassval").val());
	if(netassval==""|| isNaN(netassval))
	{
		netassval=0;
	}
	//alert(netassval);
	//var trln=$("#particulars")
	
	var rowCount = $('#particulars tr').length;
	if($('#battery').is(':checked'))
	{
		var battery=parseFloat($("#battery").val());
	}else
	{
		var battery=0;
	}
	if($('#charger').is(':checked'))
	{
		var charger=parseFloat($("#charger").val());
	}else
	{
		var charger=0;
	}
	//alert(battery);
	//alert(charger);
	//var battery=$().val()
	if(reqty=="" || isNaN(reqty))
	{
		//$("#getchassisin").remove();
	}else
	{
		rowCount=rowCount-1;
		var troe=rowCount+1;
		
		/*$.ajax({			
 			type :"POST",
  			url : "<?php //echo base_url();  ?>//AcountsManage_Controller/getchassisdetails",
  			//data :{'reqty':reqty,'battery':battery,'charger':charger},
  			/*success : function(data){
  					//alert(data);
  					console.log(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#getchassisin").html(data);
              }  
       });*/
      $("#tabtotrow").val(troe);
      $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/gettablelist",
  			data :{'reqty':reqty,'battery':battery,'charger':charger,'model':model},
  			success : function(data){
  					//alert(data);
  					console.log(data);
  					var json=JSON.parse(data);
  					var particulars=json.particulars;
  					var txt=json.txt;
  					var qty=json.qty;
  					var unitpr=parseFloat(json.unitpr);
  					unitpr=unitpr.toFixed(2);
  					var cst=json.cst;
  					var vat=json.vat;
  					var excise=parseFloat(json.excise);
  					$("#exc").val(excise);
  					excise=excise.toFixed(2);
  					var total=parseFloat(json.total);
  					total=total.toFixed(2);
  					var netassval=0;
  					
  					//netassval=parseFloat(netassval)+parseFloat(total);
  					//$("#modalparts_"+id).modal('show');
  				 // $("#getchassisin").html(data);
  				// $("#nettoal").show();
  				 $('#particulars tr:last').after('<tr><td>'+troe+'</td><td>'+particulars+'<br>'+txt+'<input type="hidden" name="particulars_'+troe+'" value="'+particulars+'" /><input type="hidden" name="txt_'+troe+'" value="'+txt+'" /></td><td>'+qty+'<input type="hidden" name="qnty_'+troe+'" value="'+qty+'"/></td><td>'+unitpr+'<input type="hidden" name="unit_'+troe+'" value="'+unitpr+'"/></td><td>'+total+'<input type="hidden" id="total_'+troe+'" name="total_'+troe+'" value="'+total+'"/></td><td></td></tr>');
  				 for(var nt=1;nt<=parseInt(troe);nt++)
  					{
  						netassval=parseFloat(netassval)+parseFloat($("#total_"+nt).val());
  						console.log();
  					}
  					netassval=netassval.toFixed(2);
  					$("#netassableval").val(netassval);
  					var excisetx=(parseFloat(netassval)*parseFloat(excise))/100;
  					var totnet=parseFloat(netassval)+parseFloat(excisetx);
  					
  					
  					console.log(excisetx);
  				  
  				 $("#excisetx").html('<div class="col-md-9" style="text-align: right;"><b>Excise Tax @ '+excise+'%:</b></div><div class="col-md-3" style="text-align: center;"><input type="text" name="exciseamnt" id="excise" value="'+excisetx+'" style="border:none;font-weight: bolder;"/></div>');
  				 $("#cstvat").html('<div class="col-md-9"style="text-align: right;"><select class="form-control" id="cst_vat" name="cstvat" onchange="getcstvatdetails()"><option value="0">--Select Tax --</option><option value="cst@'+cst+'">CST@'+cst+'%</option><option value="vat@'+vat+'">VAT @ '+vat+'%</option></select></div><div class="col-md-3" style="text-align: center;"><input type="text" name="cstv" id="cstv" style="border:none;font-weight: bolder;"/></div>');
  				 $("#nettoal").html('<div class="col-md-9" style="text-align: right;"><b>Net Total:</b></div><div class="col-md-3" style="text-align: center;"><input type="text" name="nettl" value="'+totnet+'" id="nettl" style="border:none;font-weight: bolder;"/></div>');
  				$("#submit").show();
              }  
       });
	}
}
function checksameasaddress()
{
	if($("#sameasc").is(':checked'))
	{
		//alert('checked');
		var custdet=$("#custinfo").val();
		var custadd=$("#custaddress").val();
		var custvat=$("#custvat").val();
		var custtin=$("#custtin").val();
		//consignee details
		$("#consigneename").val(custdet);
		$("#consigneeadd").val(custadd);
		$("#consigneevat").val(custvat);
		$("#consigneetin").val(custtin);
		
	}else
	{
		alert('notchecked');
		$("#consigneename").val("");
		$("#consigneeadd").val("");
		$("#consigneevat").val("");
		$("#consigneetin").val("");
	}
}
function getorderdate()
{
	var orderno=$("#orderno").val();
	//alert(orderno);
	if(isNaN(orderno) && orderno=="" )
	{
		 $("#orderdate").val("");
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getorderdate",
  			data :{'orderno':orderno},
  			success : function(data){
  					alert(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#orderdate").val(data);
              }  
       });
	}
	
}
function custdetails()
{
	//console.log("hello");
	var custinfo=$("#custinfo").val();
	if(custinfo=="")
	{
		
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getcustinformation",
  			data :{'custinfo':custinfo},
  			success : function(data){
  				
  					console.log(data);
  					//var custcomp=
  					var json=JSON.parse(data);
  					var comp=json.compname;
  					var name=json.name;
  					var clientid=json.clientid;
  					var type=json.type;
  					var address=json.address;
  					var balance=json.balance;
  					var tinvat=json.tinvat;
  					var cst=json.cst;
  				  //$("#modalparts_"+id).modal('show');
  				 // $("#orderdate").val(data);
  				 $("#custid").val(clientid);
  				 $("#custcomp").val(comp);
  				 $("#custaddress").val(address);
  				 $("#custbalance").val(balance);
  				 $("#custtyp").val(type);
  				 $("#custvat").val(tinvat);
  				 $("#custtin").val(cst);
  				 //$().val();
  				 
  				// $().val();
              }  
       });
	}
}
function getmodelrate(id)
{
	var idsplit=id.split("_");
	var reqty=parseInt($("#reqty").val());
	var colorrow=parseInt($("#colorrow").val());
	var colorqty=0;
	for(var c=1;c<colorrow;c++)
	{
		colorqty=parseInt(colorqty)+parseInt($("#color_"+idsplit[1]).val());
	}
	if(colorqty>reqty)
	{
		//alert('please right no of color quantity');
	}else
	{
		//alert('asd');
	}
}
function getcstvatdetails()
{
	//console.log('htg');
	var castvat1=$("#cst_vat").val();
	console.log(castvat1);
	castvat2=castvat1.split("@");
	console.log(castvat2);
	castvat=parseFloat(castvat2[1]);
	if(castvat1=="0")
	{
		castvat=0;
	}
	console.log(castvat);
	var rowCount = $('#particulars tr').length;
	var excise=parseFloat($("#excise").val());
	console.log(excise);
	/*rowCount=rowCount-1;
	netassval=0;
	 for(var nt=1;nt<=parseInt(rowCount);nt++)
  	{
  		netassval=parseFloat(netassval)+parseFloat($("#total_"+nt).val());
  		
  	}*/
  	var netassval=parseFloat($("#netassableval").val());
  	var netto=parseFloat(excise)+parseFloat(netassval);
  	console.log(netto);
  	var cstamnt=(parseFloat(netto)*parseFloat(castvat))/100;
  	cstamnt=cstamnt.toFixed(2);
  		console.log(netto);
  	$("#cstv").val(cstamnt);
  	var net_net=parseFloat(netto)+parseFloat(cstamnt);
  	net_net=net_net.toFixed(2);
  	$("#nettl").val(net_net);
  //	console.log(net_net);
  				
}
function getmodelpartsdetails()
{
	
	var type1=$("#mname").val();
	var custype=$("#custtype").val();
	//var custype="CNF";
	//alert(type1);
	//var typesplit=type1.split("_");
	//var type=typesplit[0];
	//var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$("#particulars").remove();
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getpartsdetailsbymodel",
  			data :{'type':type1,'custype':custype},
  			success : function(data){
  					//alert(data);
  					console.log(data);
  					$("#parts_details").html(data);
  					
  				  //$("#modalparts_"+id).modal('show');
  				 // $("#model_details").html(data);
              }  
       });
	
}
function getallchecked(cst,vat)
{
	
   $(".second").prop("checked", $("#checkAll").prop("checked"));
   var totreq=parseInt($("#reqty").val());
	var totrw=parseInt($("#totrw").val());
	var alltot=0;
	for(var qt=1;qt<totrw;qt++)
	{
		if($("#chkbx_"+qt).prop('checked') == true)
		{
			var unit= parseInt($("#partsunit_"+qt).val());
			var totqty=parseInt(unit)*parseInt(totreq);
			//$("#totqty_"+qt).val(totqty);
			var unitprice=parseFloat($("#unitprice_"+qt).val());
			var totalprice=parseFloat(unitprice)*parseFloat(totqty);
			alltot=parseFloat(alltot)+parseFloat(totalprice);
			//totalprice=totalprice.toFixed(2);
			
			//$("#totalmrp_"+qt).val(totalprice);
			//var unutpr=$().val()
		
		}
		
		
		
		
	}
	console.log(alltot);
	alltot=alltot.toFixed(2);
	$("#netassableval").val(alltot);
    //var excisetx=(parseFloat(netassval)*parseFloat(excise))/100;
  	var totnet=parseFloat(alltot);
  	 $("#cstvat").html('<div class="col-md-9"style="text-align: right;"><select class="form-control" id="castvat" name="cstvat" onchange="getcst_vatdetails()"><option value="">--Select Tax --</option><option value="cst@'+cst+'">CST@'+cst+'%</option><option value="vat@'+vat+'">VAT @ '+vat+'%</option></select></div><div class="col-md-3" style="text-align: center;"><input type="text" name="cstv" id="cstv" style="border:none;font-weight: bolder;"/></div>');
  	$("#nettoal").html('<div class="col-md-9" style="text-align: right;"><b>Net Total:</b></div><div class="col-md-3" style="text-align: center;"><input type="text" name="nettl" value="'+totnet+'" id="nettl" style="border:none;font-weight: bolder;"/></div>');
  	$("#submit").show();
	console.log(alltot);
   
}
function getalltotalparts()
{
	var totreq=parseInt($("#reqty").val());
	var totrw=parseInt($("#totrw").val());
	for(var qt=1;qt<=totrw;qt++)
	{
		var unit= parseInt($("#partsunit_"+qt).val());
		var totqty=parseInt(unit)*parseInt(totreq);
		$("#totqty_"+qt).val(totqty);
		var unitprice=parseFloat($("#unitprice_"+qt).val());
		var totalprice=parseFloat(unitprice)*parseFloat(totqty);
		totalprice=totalprice.toFixed(2);
		$("#totalmrp_"+qt).val(totalprice);
		//var unutpr=$().val()
		
		
		
		
	}
}
function getalltotalassablevalue(cst,vat)
{
	var totreq=parseInt($("#reqty").val());
	var totrw=parseInt($("#totrw").val());
	var alltot=0;
	for(var qt=1;qt<=totrw;qt++)
	{
		if($("#chkbx_"+qt).prop('checked') == true)
		{
			var unit= parseInt($("#partsunit_"+qt).val());
			var totqty=parseInt(unit)*parseInt(totreq);
			//$("#totqty_"+qt).val(totqty);
			var unitprice=parseFloat($("#unitprice_"+qt).val());
			var totalprice=parseFloat(unitprice)*parseFloat(totqty);
			alltot=parseFloat(alltot)+parseFloat(totalprice);
			//totalprice=totalprice.toFixed(2);
			
			//$("#totalmrp_"+qt).val(totalprice);
			//var unutpr=$().val()
			
		
		}
		
		
		
		
	}
	alltot=alltot.toFixed(2);
	$("#netassableval").val(alltot);
    //var excisetx=(parseFloat(netassval)*parseFloat(excise))/100;
  	var totnet=parseFloat(alltot);
  	totnet=totnet.toFixed(2);
  	 $("#cstvat").html('<div class="col-md-9"style="text-align: right;"><select class="form-control" id="castvat" name="cstvat" onchange="getcst_vatdetails()"><option value="">--Select Tax --</option><option value="cst@'+cst+'">CST@'+cst+'%</option><option value="vat@'+vat+'">VAT @ '+vat+'%</option></select></div><div class="col-md-3" style="text-align: center;"><input type="text" name="cstv" id="cstv" style="border:none;font-weight: bolder;"/></div>');
  	$("#nettoal").html('<div class="col-md-9" style="text-align: right;"><b>Net Total:</b></div><div class="col-md-3" style="text-align: center;"><input type="text" name="nettl" value="'+totnet+'" id="nettl" style="border:none;font-weight: bolder;"/></div>');
  	$("#submit").show();
	console.log(alltot);
}
function getcst_vatdetails()
{
	var castvat1=$("#castvat").val();
	console.log(castvat1);
	castvat2=castvat1.split("@");
	castvat=parseFloat(castvat2[1]);
	if(castvat=="" ||isNaN(castvat))
	{
		castvat=0;
	}
	var netassval=parseFloat($("#netassableval").val());
	console.log(netassval);
	//var rowCount = $('#particulars tr').length;
	//var excise=parseFloat($("#excise").val());
	//rowCount=rowCount-1;
	//netassval=0;
	// for(var nt=1;nt<=parseInt(rowCount);nt++)
  //	{
  	//	netassval=parseFloat(netassval)+parseFloat($("#total_"+nt).val());
  	//	
  //	}
  	var netto=parseFloat(netassval);
  	var cstamnt=(parseFloat(netto)*parseFloat(castvat))/100;
  	cstamnt=cstamnt.toFixed(2);
  	$("#cstv").val(cstamnt);
  	var net_net=parseFloat(netto)+parseFloat(cstamnt);
  	net_net=net_net.toFixed(2);
  	$("#nettl").val(net_net);
  	console.log(net_net);
}

</script>
