<?php  include('conection.php');  ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>


<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $(document).(function(){
    $("#example").dataTable();
  })
  </script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		input[type="text"]{
			text-transform: uppercase;
		}
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"><?php  if(isset($title)){ echo $title; } ?></li>
						</ol>

		</div>
		<div class="section-body contain-lg">
		<form class="form" action="<?php echo base_url(); ?>Bokking_controller/bookingsave" method="post"  >
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">
				

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<!--<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create Salesman</a></li>
								<!--<li><a href="<?php// echo base_url(); ?>newBrand_controller/viewmodel">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							<!--</ul>
						</div>--><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				
				
						<div class="card">
							<div class="card-head style-primary">
								<header>Booking Summery</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											
											<input type="text"  class="form-control" id="tags" onblur="getcstdtls()" name="search" required />
											<label for="search">Search by Email / Company Name / Client ID</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											
											<input type="text" class="form-control" id="comname"  name="compn" value="" readonly />
											<label for="cname">Company Name</label>
										</div>
									</div>
								</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="cmpmail" name="compn" value="" readonly />
												<label for="cEmail"> Company Email</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="compid" name="compid" value="" readonly/>
												<label for="cID"> Company ID Name</label>
											</div>
										</div>										
									</div>	
									<div class="row">
										<div class="col-md-6">
										<div class="form-group">
											
											<input type="text" class="form-control" id="custname" name="custname" value="" readonly />
											<label for="custname">Customer Name</label>
										</div>
									    </div>
									    <div class="col-md-6">
										<div class="form-group">
											<input type="text" class="form-control" id="dat" name="dat" value="<?php echo date('Y-m-d'); ?>" readonly />
											<label for="dat">Date</label>
										</div>
										<input type="hidden" name="sid" id="sid" value="">
										<input type="hidden" name="sname" id="sname" value="">
									    </div>
									</div>
									<div class="row">
										<div class="col-md-6">
										<div class="form-group">
											<select name="type" class="form-control" id="cattyp" onchange="gettypedetails()" >
																			<option value="">--Select type--</option>
																			<option value="product">Model</option>
																			<option value="parts">Spare Parts</option>
																			
																		</select>
											<label for="custName"></label>
										</div>
									    </div>
									    <div class="col-md-6" id="model">
																	
										</div>
									</div>
									</div>
								</div>
								
								<?php if(isset($models) && !empty($models)){ $x=1;;
																		    foreach($models as $row){
																			  $productid=$row->id;
																				$withbatr=0;
																				$withoutbatr=0;
																				//$withcrg=$row->
																			 ?>

																	    																
																	     <!-- BEGIN SIMPLE MODAL MARKUP -->
																		 
																			<div id="simpleModal_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
																				<div class="modal-dialog modal-lg">
																					<div class="modal-content">
																						<div class="modal-header">
																								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																									<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
																										<?php //$res=new Purchase_controller();
																			
																												$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
																			
																												<!--<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																												<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
																			
																												<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
																												-->
																						</div>
																						<div class="modal-body">
																							<div class="row">
																								<div class="col-md-9"><div class="col-md-3"><h4>Total Qty:-</h4></div><div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqty_<?php echo $x; ?>" name="productqty"  placeholder="Required No Of Quantity" onblur="getmodelqty(this.id);" ></div></div></div>
																								<div class="col-md-9"><div class="col-md-3"><h4>Choose :</h4></div>
																								<div class="col-md-6">
																									<div class="form-group floating-label">
																									 <input type="checkbox" name="choose[]" value="2000" id="erickshaw_<?php echo $x; ?>_1" onclick="getericksakwval(this.id)" >E-Rickshaw &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="100" id="erickshaw_<?php echo $x; ?>_2" onclick="getericksakwval(this.id)">Batery &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="50" id="erickshaw_<?php echo $x; ?>_3" onclick="getericksakwval(this.id)">Charger &nbsp;&nbsp;
																									<input type="hidden" id="cat_<?php echo $x; ?>" >
																									<input type="hidden" id="cate2_<?php echo $x; ?>" >
																									  </div>
																								    </div>
																								</div>
																									<table id="example8" style="width:80%;"><thead><tr><th colspan="10">Specify Quantity for Different Color</th></tr></thead>
																										<tr>
																											<?php if(isset($getcolorcode)){ $colorcode=1;
																														foreach($getcolorcode as $rowcolor)
																											{ ?>
																												<td data-column="<?php echo $rowcolor->color_name; ?>"><input type="text" id="colorqty_<?php echo $x; ?>_<?php echo $colorcode;  ?>" style="text-align:center;width:85px;background-color: <?php echo $rowcolor->code_hex; ?>;color:white;font-weight:bold;" onkeyup="getcolorquantity(this.id)"/></td>
																											<?php $colorcode++;  }
																											}   ?>
																											
																										</tr>
																									</table>
																								<div class="col-md-9">
																									<div class="col-md-3"><h4>Rest Of Quantity:-</h4></div>
																									<div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqtycolor_<?php echo $x; ?>" name="productqty"  readonly></div></div>
																								</div>
																						  </div>
																						     <input type="hidden" value="<?php echo $colorcode; ?>" id="colorcode">
																							<input type="hidden" name="modelid" value="<?php echo $row->productid; ?>" id="modid_<?php echo $x ;  ?>"/>
																							<input type="hidden" name="modelnme" value="<?php echo $row->productname; ?>" id="modname_<?php echo $x;  ?>"/>
																			
																							<br>
																								
																			
																		</div>
																		<div class="modal-footer">
																			<input type="hidden" id="notr" value=""/>
																			<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																			<button type="button"  class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetails(this.id,<?php echo $x; ?>)">GO</button>
																		</div>
																	</div><!-- /.modal-content -->
																</div><!-- /.modal-dialog -->
															</div><!-- /.modal -->
															
															<!-- END SIMPLE MODAL MARKUP -->
												
							                  <?php $x++;  } }  $gt=$x; ?>
											  
											  
											
  
											  <input type="hidden" id="dynamicmodal" value="<?php echo $gt; ?>"/>
											  
											  <?php  
							                    if(isset($models)&& !empty($models))
												{  $x=1; ?>
													 <?php foreach($models as $row){ 
													 	  $mname=$row->productname;
													 	?>
															<div id="modalparts_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
																						<div class="modal-dialog modal-lg">
																							<div class="modal-content">
																								<div class="modal-header">
																										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																											<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
																												<?php //$res=new Purchase_controller();
																					
																														$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
																					
																														<!--<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																														<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
																					
																														<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
																														-->
																								</div>
																								<div class="modal-body">
																									<div class="row">
																										<center>REQUIRED QTY: <input type="text" name="noqty" id="noqty_<?php echo $x; ?>" onkeyup="gettotallist(this.id)" ></center>
																									</div>
																									<div class="row">
																										<div class="col-md-12">
																											<table class="table">
																												<thead>
																													<tr>
																														<td>SL NO.</td>
																														<td><input type="checkbox" id="checkAll"></td>
																														<td>PARTSCODE</td>
																														<td>PARTSNAME</td>
																														<td>PARTSUNIT</td>
																														<td>TOTALQNTY</td>
																														<td>UNITPRICE</td>
																														<td>AMOUNT</td>
																													</tr>
																												</thead>
																												<tbody>
																													<?php    $queryparts2=mysqli_query($con,"select * from materiel_master where mName='".trim($mname)."'"); 
																													       $re=1;
																														  while($rowparts=mysqli_fetch_array($queryparts2)){
																													    ?>
																													<tr>
																														<td><?php echo $re; ?></td>
																														<td><input type="checkbox" id="checked_<?php echo $x."_".$re ; ?>" class="spr" ></td>
																														<td><?php echo $rowparts['materiel_id'] ; ?></td>
																														<td><?php echo $rowparts['materialname'];  ?><input type="hidden" name="matname" value="<?php echo $rowparts['materialname']."($mname)";  ?>" id="matnam_<?php echo $x."_".$re; ?>">
																															<input type="hidden" name="matid" id="matid_<?php echo $x."_".$re; ?>" value="<?php echo $rowparts['materiel_id']; ?>"/>
																															
																														</td>
																														<td><?php echo $rowparts['unit'];  ?><input type="hidden" name="" id="unitpartsd_<?php echo  $x."_".$re; ?>" value="<?php echo $rowparts['unit']; ?>"></td>
																														<td><input type="text" style="width:50px;" id="totqnty_<?php echo $x."_".$re; ?>"></td>
																														<td><?php echo $rowparts['dispr'];  ?><input type="hidden" name="partamnt" id="partsamnt_<?php echo $x."_".$re; ?>" value="<?php echo $rowparts['dispr']; ?>"/></td>
																														<td><input type="text" style="width:80px;" id="totvalue_<?php echo $x."_".$re; ?>" readonly><input type="hidden" name="totval" id="totval_<?php echo $x."_".$re; ?>" /></td>
																														
																													</tr>
																													<?php $re++; }  ?>
																												</tbody>
																											</table>
																											<input type="hidden" value="<?php echo $re; ?>"  id="tottable_<?php echo $x; ?>">
																										</div>
																										
																									</div>
																								     
																					
																				                </div>
																				<div class="modal-footer">
																					<input type="hidden" id="notr" value=""/>
																					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																					<button type="button"  class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetltsbymodal(this.id)">GO</button>
																				</div>
																			</div><!-- /.modal-content -->
																		</div><!-- /.modal-dialog -->
																	</div><!-- /.modal -->
													
											<?php $x++;	} }
							                  
							                  ?>
											 
											  <input type="hidden" id="hiddenparts" value="<?php echo $x; ?>">
											  
											  
	
							<div class="row" id="table1">
														    <div class="col-xs-12">
														    	<table class="col-xs-12" id="example">
														    		<tr>
														    			<td>SL NO</td>
														    			<td>PARTICULARS</td>
														    			<td>QNTY</td>
														    			<td>UNITPRICE</td>
														    			<td>TOTAL </td>
														    			<td>ACTION</td>
														    		</tr>
														    		
														    	</table>
															</div>
															<hr>
															
														   <hr>
															<div class="row">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-3">
																		NET TOTAL
																	</div>
																	<div class="col-sm-3">
																		
																	</div>
																	<div class="col-sm-3">
																		
																	</div>
																	<div class="col-sm-3" id="nettot" style="font-size: 15px;text-align: right;font-weight: bold;">
																	  
																	</div>
																</div>
															    	
															    </div>
														   </div>
														   <div class="row" id="exciseduty">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-9">
																		EXCISETAX @2.00%
																	</div>
																	
																	
																		<input type="hidden" id="excisetax" style="width:70px;" name="excise">
																	
																	<div class="col-sm-3" id="examnt" style="font-size: 15px;text-align: right;font-weight: bold;">
																		
																	</div>
																	<input type="hidden" name="excise_amnt" id="excise_amnt"/>
																</div>
															    	
															    </div>
														   </div>
														  
														   <div class="row">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-3">
																		VAT/CST
																	</div>
																	<div class="col-sm-3">
																		<select id="vatcst" name="vatcst" onchange="getvatamount();">
																			<option value="">--select VAT/CST--</option>
																			<option value="cst">CST</option>
																			<option value="vat">VAT</option>
																		</select>
																	</div>
																	<div class="col-sm-3">
																		<input type="text" id="vatcs" name="vatcstpercent" style="width:70px;">
																	</div>
																	<div class="col-sm-3" id="vatamnt" name="vatamnt" style="font-size: 15px;text-align: right;font-weight: bold;">
																		
																	</div>
																	<input type="hidden" name="vat_amnt" id="vat_amnt"/>
																</div>
															    	
															    </div>
														   </div>
														  
														   
														   <div class="row">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-3">
																		
																	</div>
																	<div class="col-sm-6">
																		
																	
																	
																		<b><h2>GRAND TOTAL</h2></b>
																	</div>
																	<div class="col-sm-3" id="grandtot" style="font-size: 15px;text-align: right;font-weight: bold;">
																		
																	</div>
																	<input type="hidden" name="grandtotal" id="grandtotal"/>
																</div>
															    	
															    </div>
														   </div>
															<div class="row">
															    <div class="col-xs-12">
															    	 <div class="clearfix form-actions">
																		<div class="col-md-offset-3 col-md-9">
																			<button class="btn btn-info" type="submit" id="submit">
																				<i class="ace-icon fa fa-check bigger-110"></i>
																				Submit
																			</button>
								
																			&nbsp; &nbsp; &nbsp;
																			
																		</div>
																	</div>
															    </div>
														   </div>
															<input type="hidden" name="numofrows" id="tbalerow"/>
   					 										<input type="hidden" name="vendorid[]" id="vendorid">
   					 										<input type="hidden" name="dupven" id="dupven" />
													    </div>
														
								
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						    	</div>
							    	
							    	
							    	
							</div>
				</div>
				
											
											  
											  
											  
											  <div class="col-xs-12 col-sm-3" style="display:none;">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Model List</h4>

													
												</div>

												<div class="widget-body">
													<div class="widget-main">
														<!-- ############################################################## ######################################################################-->
														<div class="list-type1">
															
														<ol>
																				
																<?php if(isset($models) && !empty($models)){ $x=1;;
																		    foreach($models as $row){
																			  $productid=$row->id;
																				$withbatr=$row->dis_excld;
																				$withoutbatr=$row->dis_incld;
																				//$withcrg=$row->
																			 ?>
																	     
																	     <li>
																	     	<a id="product__<?php echo $x; ?>" href="javascript:product_test(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#simpleModal_<?php echo $x; ?>">
																	     	<div class="tile-content">
																						
																						<div class="tile-text"><?php echo $row->productname; ?></div>
																			</div>
																			
																	     	
																	     	</a>
																	     </li>
																	    																
																	     <!-- BEGIN SIMPLE MODAL MARKUP -->
																			<div class="modal fade" id="simpleModal_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
																				<div class="modal-dialog modal-lg">
																					<div class="modal-content">
																						<div class="modal-header">
																								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																									<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
																										<?php //$res=new Purchase_controller();
																			
																												$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
																			
																												<!--<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																												<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
																			
																												<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
																												-->
																						</div>
																						<div class="modal-body">
																							<div class="row">
																								<div class="col-md-9"><div class="col-md-3"><h4>Total Qty:-</h4></div><div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqty_<?php echo $x; ?>" name="productqty"  placeholder="Required No Of Quantity" onblur="getmodelqty(this.id);" ></div></div></div>
																								<div class="col-md-9"><div class="col-md-3"><h4>Choose :</h4></div>
																								<div class="col-md-6">
																									<div class="form-group floating-label">
																									 <input type="checkbox" name="choose[]" value="2000" id="erickshaw_<?php echo $x; ?>_1" onclick="getericksakwval(this.id)" >E-Rickshaw &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="100" id="erickshaw_<?php echo $x; ?>_2" onclick="getericksakwval(this.id)">Batery &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="50" id="erickshaw_<?php echo $x; ?>_3" onclick="getericksakwval(this.id)">Charger &nbsp;&nbsp;
																									<input type="text" id="cat_<?php echo $x; ?>" >
																									<input type="text" id="cate2_<?php echo $x; ?>" >
																									  </div>
																								    </div>
																								</div>
																									<table id="example8" style="width:80%;"><thead><tr><th colspan="10">Specify Quantity for Different Color</th></tr></thead>
																										<tr>
																											<?php if(isset($getcolorcode)){ $colorcode=1;
																														foreach($getcolorcode as $rowcolor)
																											{ ?>
																												<td data-column="<?php echo $rowcolor->color_name; ?>"><input type="text" id="colorqty_<?php echo $x; ?>_<?php echo $colorcode;  ?>" style="text-align:center;width:85px;background-color: <?php echo $rowcolor->code_hex; ?>;color:white;font-weight:bold;" onkeyup="getcolorquantity(this.id)"/></td>
																											<?php $colorcode++;  }
																											}   ?>
																											
																										</tr>
																									</table>
																								<div class="col-md-9">
																									<div class="col-md-3"><h4>Rest Of Quantity:-</h4></div>
																									<div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqtycolor_<?php echo $x; ?>" name="productqty"  readonly></div></div>
																								</div>
																						  </div>
																						     <input type="hidden" value="<?php echo $colorcode; ?>" id="colorcode">
																							<input type="hidden" name="modelid" value="<?php echo $row->productid; ?>" id="modid_<?php echo $x ;  ?>"/>
																							<input type="hidden" name="modelnme" value="<?php echo $row->productname; ?>" id="modname_<?php echo $x;  ?>"/>
																			
																							<br>
																								
																			
																		</div>
																		<div class="modal-footer">
																			<input type="hidden" id="notr" value=""/>
																			<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																			<button type="button"  class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetails(this.id,<?php echo $x; ?>)">SUBMIT</button>
																		</div>
																	</div><!-- /.modal-content -->
																</div><!-- /.modal-dialog -->
															</div><!-- /.modal -->
															<!-- END SIMPLE MODAL MARKUP -->
												
																	 <?php $x++;  } } ?>
														</ol>
														</div>
														
<!-- #################################################################################################################################### -->
	
													</div>
												</div>
											</div>
										</div><!-- /.span -->
										<div class="col-xs-12 col-sm-3" style="display:none;">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Spare Parts</h4>

													
												</div>

												<div class="widget-body">
													<div class="widget-main">
														<div class="">
															<ul class="list divider-full-bleed">
																<li>
																	
																		<div class="tile-text">
																			<?php if(isset($getallproduct)){ ?>
													 								<select name="modelname" id="modelname" class="form-control select2-list" onchange="getallspareparts();"><option value="">--select model--</option><?php foreach($getallproduct as $row){ ?><option value="<?php echo $row->productid."_".$row->productname ; ?>"><?php echo $row->productname; ?></option> <?php } ?></select>
													 						<?php } ?></div>
																	
																	
																</li>
														    </ul>
														</div>
														<div class="prts">
																<ol>
																<?php if(isset($allmaterial)){ $i=1; ?>
															<?php foreach($allmaterial as $row){ 
																$diff=$row->diff;
																$reoder=$row->reorderlevel; ?>
																
															 <li   class="tile" title="<?php  echo $row->materialname."(".$row->qnty.")";  ?>">
															 	<a  id="item_<?php echo $i; ?>" href="javascript:anchor_test(<?php echo $row->id; ?>)"  >
															 	 <div class="tile-content">
																		
																		<div class="tile-text" <?php if($diff<$reoder){ ?> style="font-weight: bold;"  <?php } ?>><small><?php  echo $row->materialname;  ?> (<?php echo $row->qnty;  ?>)</small></div>
																	</div>
															   </a>
															 	</li>
															 	<!--<li <?php if($diff<$reoder){?> class="btn btn-block ink-reaction btn-danger" <?php } ?> title="<?php  echo $row->materialname."(".$row->qnty.")";  ?>"><a  id="item_<?php echo $i; ?>" href="#" data-toggle="modal" data-target="#myModal_<?php echo $i;  ?>" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small><?php  echo $row->materialname;  ?> (<?php echo $row->qnty;  ?>)</small></a></li>-->
															   				
															
														<?php  $i++; } } ?>
																
															</ol>
														</div>
												    </div>
												</div>
											</div>
										</div><!-- /.span -->
         
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</form>	
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>

<script>
	function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLvoter(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLpan(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah2').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLadhar(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah3').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#imgInp").change(function(){
        readURL(this);
    });
    $("#imgInp1").change(function(){
        readURLvoter(this);
    });
    $("#imgInp2").change(function(){
        readURLpan(this);
    });
    $("#imgInp3").change(function(){
        readURLadhar(this);
    });
</script>











<script>
function getcolorquantity(id)
{
	var idsplit=id.split("_");
	var divmodalid=idsplit[1];
	var tot=0;var gettot;
	var colorcdno=$("#colorcode").val();
	for( var n=1;n<colorcdno;n++)
	{
		
		gettot=$("#colorqty_"+divmodalid+"_"+n).val();
		if(gettot=="")
		{
			gettot=0;
			
		}
		tot=tot+parseInt(gettot);
		//alert(tot);
	}
	var existtot=$("#productqty_"+divmodalid).val();
	if(existtot==""){existtot=0;}
	var resttot=parseInt(existtot)-parseInt(tot);
	if(resttot==0){resttot="";}
	if(resttot<0)
	{
		alert('please type right number of quantity');
		
	}else{
		
		$("#productqtycolor_"+divmodalid).val(resttot);
	}
	
	
}
function getallspareparts()
{
	//alert('hello');
	var modelname=$("#modelname").val();
	//alert(modelname);
	var idsplit=modelname.split("_");
	var modcode=idsplit[0];
	var modnam=idsplit[1];
	//alert(modnam);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getallspare_parts_sort_by_modelname",
  			data :{'modcode':modcode,'modnam':modnam},
  			success : function(data){
  				 				 
  				//alert(data);
  				$(".prts").html(data);
  			  
              }  
           });
}
function getmodelqty(id)
{
	var idsplit=id.split("_");
	var idx=idsplit[1];
	var noqty=$("#productqty_"+idsplit[1]).val();
	var partssp=parseInt($("#partssp_"+idsplit[1]).val());
	for(var c=1;c<partssp;c++)
	{
		var ptaqty=$("#ptsap_"+idx+"_"+c).val();
		var hidpty=$("#ptsaphidden_"+idx+"_"+c).val();
		 if(noqty=="")
		 {
		 	$("#ptsap_"+idx+"_"+c).val(hidpty);
		 }else
		 {
		 	var noqty1=parseInt(noqty)*parseInt(ptaqty);
		    $("#ptsap_"+idx+"_"+c).val(noqty1);
		 }
		
		//alert(ptaqty);
	}
	//alert(idx);
	//alert(noqty);
	
}
function getpartsdetails(id,divid)
{
	$("#table1").show();
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var ds=divid;
	var notr=$("#notr").val();
	//alert(notr);
	//var notr1=notr-1;
	var colorcode23=parseInt($("#colorcode").val());
	var req="";
	var valid=0;
	var nettot=0;
	for(var c=1;c<notr;c++)
	{
		var prtsqty=$("#ptsap_"+ds+"_"+c).val();
		//alert(prtsqty);
		
		if(($("#req_"+ds+"_"+c).prop('checked') == true) && ($("#specification_"+ds+"_"+c).val()!="9999")){
			req +=$("#req_"+ds+"_"+c).val()+"@"+prtsqty+"||";
    
         }else
         { 
         	if($("#req_"+ds+"_"+c).prop('checked') == true){
         		valid++;
         	}else
         	{
         		
         	}
         	
         }
		
	}
	//alert(valid);
	
	var color="";
	for(var d=1;d<colorcode23;d++)
	{
		gettot=$("#colorqty_"+ds+"_"+d).val();
		if(gettot=="")
		{
			
		}else
		{
			color +=$("#colorqty_"+ds+"_"+d).val()+"->"+d+"#";
		}
	}
   //  alert(color);
	var modelid=$("#modid_"+idsplit[1]).val();
	var modelname=$("#modname_"+idsplit[1]).val();
	var prqty=$("#productqty_"+idsplit[1]).val();
	if(prqty=="")
	{
		prqty=0;
	}
	//alert(prqty);
	
	var modelnm=$("#cate2_"+idsplit[1]).val();
	//alert(modelnm);
	if(modelnm=="")
	{
		ctr="0";
	}
	//modelnmsp=modelnm.split("_");
	
	var amount=parseFloat($("#cat_"+idsplit[1]).val());
	//alert(amount);
	var ctr=modelnm;
	//alert(ctr);
	if(ctr=="1,")
	{
		var catr="without battery & charger";
	}
	if(ctr=="1,2,")
	{
		var catr="with Battery";
	}
	if(ctr=="1,2,3,")
	{
		var catr="with Battery & Charger";
	}
	amount=parseFloat(amount).toFixed(2);
	//alert(amount);
	var amnyt=parseFloat(amount)*parseInt(prqty);
	var amnt=amnyt.toFixed(2);
	//alert(amnt);
	//$('.inputr').append("<input type='text'");
  			    
     //$('.inputr').append("<input type='text' name='modelname_"+tr2+"' value='"+modelname+"'/>");
    // $('.inputr').append("<input type='text' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prqty+"' />");
    // $('.inputr').append("<input type='text'/>");
	//alert(modelid);
	//alert(modelname);;
	//alert(color);
	
	var rowCount = $('#example tr').length;
	var tr=rowCount-1;
	var tr2=tr+1;
	$("#tbalerow").val(tr2);
	//var rew=$("#product_spec").val(req);
	//alert(req);
	if(valid<1 && parseInt(prqty)>0 && ctr!="" ){
	$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+modelname+'<br>('+catr+')<input type="hidden" name="specif_'+tr2+'" id="specif_'+tr2+'" value="'+catr+'"/><input type="hidden" name="colorspe_'+tr2+'" value="'+color+'"/><input type="hidden" value="'+modelname+'" name="modelname_'+tr2+'" id="modelname_'+tr2+'"/></td><td>'+prqty+'<input type="hidden" value="'+prqty+'" name="prqty_'+tr2+'" id="prqty_'+tr2+'"/></td><td>'+amount+'<input type="hidden" value="'+amount+'" name="amount_'+tr2+'" id="amount_'+tr2+'"/></td><td>'+amnt+'<input type="hidden" name="tot1_'+tr2+'" id="tot1_'+tr2+'" value="'+amnt+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
	$('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='modelid1_"+tr2+"' value='"+modelid+"'/>");
  			    
  $('.inputr').append("<input type='hidden' name='particular_"+tr2+"' value='"+modelname+"'/>");
  $('.inputr').append("<input type='hidden' name='specfic_"+tr2+"' id='specfic_"+tr2+"' value='"+catr+"'/>");
   $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prqty+"' />");
    $('.inputr').append("<input type='hidden' name='unitpr1_"+tr2+"' id='unitpr1_"+tr2+"' value='"+amount+"'  />");
    $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+amnt+"' />");
    $('.inputr').append("<input type='hidden' name='colorspe_"+tr2+"' value='"+color+"' />");
   //$('.inputr').append("<input type='hidden' name='specification_"+tr2+"' value='"+req+"' />");
  // $('.inputr').append("<input type='hidden' name='colorspe_"+tr2+"' value='"+color+"' />");
   
  for(var tre=1;tre<=parseInt(tr2);tre++)
    {
           var tt=$("#tot1_"+tre).val();
		   var specif=$("#specif_"+tre).val();
		  console.log(specif);
		   if(tt=="" || isNaN(tt)){
		   tt=0;
		   }else{
           nettot=parseFloat(nettot)+parseFloat(tt);
           nettot=nettot.toFixed(2);
		   
		   }
		  
    }
                   $("#nettot").text(nettot);
                  // $("#grandtot").text(nettot);
                   var grandtot=parseFloat(nettot);
	                var excise=2;
	                var exciseamnt=(parseFloat(grandtot)*parseFloat(2))/100;
	                var grtot=parseFloat(grandtot)+parseFloat(exciseamnt);
	                $("#excisetax").val(excise);
  				 	$("#examnt").text(exciseamnt.toFixed(2));
  				 	$("#excise_amnt").val(exciseamnt.toFixed(2));
  				 	$("#grandtot").text(grtot.toFixed(2));	
  				 	$("#grandtotal").val(grtot.toFixed(2));		 
  				  
            
			
                  // $(nettoinput).
                  	$("#submit").show();
   	                  $("#exciseduty").show();
   	             $("#simpleModal_"+idsplit[1]).modal('hide');
   
  }else
  {
  	alert('Please Fill required Filled');
  }
  
   
   
   
	// $('.inputr').append("<input type='text'/>");
	//$('.inputr').append("<input type='text'");
}
function anchor_test(id)
{
	//var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var id1=id;
	var matid1="matid";
	var specid=$("#speci_"+id1).val();
	var prtsqt=parseInt($("#noprts_"+id1).val());
	var model=$("#modelname").val();
	if(model==""){
		 //alert("Please Select Model Name");
		 modal({
				type: 'warning',
				title: 'Message!',
				text: '<h4><b>Please Select Model Name</b></h4>',
			});
			
			
	}else{
		//alert(specid);
	var rowCount = $('#example tr').length;
	var modelsplit=model.split("_");
	var modelid=modelsplit[0];
	var modelname=modelsplit[1];
	var tr=rowCount-1;
	var tr2=tr+1;
	var prtsamnt=$("#prtsamnt_"+id).val();
	$("#tbalerow").val(tr2);
	var nettot=0;
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getdetails_purchase",
  			data :{'id':id1,'specid':specid},
  			success : function(data){
  				//alert('hello');
  				var json=JSON.parse(data);
  				
  				var matid=json.matid;
  				//alert(matid);
  				var unit=parseInt(json.unit);
  				var matname=json.matname;
  				var specif=json.specif;
  				var prtd=parseInt(prtsqt*unit);
  					var tot=parseFloat(prtsamnt)*parseInt(prtd);
  					tot=tot.toFixed(2);
  				//$("#matid").val(matid);
  				$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+ matname +'<br><i>('+specif+')</i><input type="hidden" name="specif_'+tr2+'" value="'+specif+'"/><input type="hidden" name="matname_'+tr2+'" value="'+matname+'"/></td><td>'+prtd+'<br><i>('+prtsqt+'X'+unit+')</i></td><td>'+prtsamnt+'</td><td>'+tot+'<input type="hidden" id="tot1_'+tr2+'" value="'+tot+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
				//$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+modelname+'<br>('+catr+')<input type="hidden" name="specif_'+tr2+'" id="specif_'+tr2+'" value="'+catr+'"/><input type="hidden" name="colorspe_'+tr2+'" value="'+color+'"/><input type="hidden" value="'+modelname+'" name="modelname_'+tr2+'" id="modelname_'+tr2+'"/></td><td>'+prqty+'<input type="hidden" value="'+prqty+'" name="prqty_'+tr2+'" id="prqty_'+tr2+'"/></td><td>'+amount+'<input type="hidden" value="'+amount+'" name="amount_'+tr2+'" id="amount_'+tr2+'"/></td><td>'+amnt+'<input type="hidden" name="tot1_'+tr2+'" id="tot1_'+tr2+'" value="'+amnt+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
				
  			    $('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='particular_"+tr2+"' value='"+matid+"'/>");
  			    $('.inputr').append("<input type='hidden' id='specif_"+tr2+"' name='specif_"+tr2+"' value='"+specif+"'/>");
  			      $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			      $('.inputr').append("<input type='hidden' name='unitpr_"+tr2+"' id='unitpr_"+tr2+"' value='"+prtsamnt+"'  />");
  			     $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			    /*$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			     $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			     $('.inputr').append("<input type='hidden' name='prtspecif_"+tr2+"' id='prtspecif_"+tr2+"' value='"+specid+"'  />");*/
  			    // $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			     for(var tre=1;tre<=parseInt(tr2);tre++)
                 {
           	      var tt=$("#tot_"+tre).val();
           	           nettot=parseFloat(nettot)+parseFloat(tt);
           	           nettot=nettot.toFixed(2);
                 }
                   $("#nettot").text(nettot);
              }  
           });
           
         
          
     //alert(matid);
     
   	   $("#submit").show();
   
	
	}
	//alert('hello');
	//alert(id);
	//$('#example tr:last').after('<tr><td>'+ tr2 +'</td><td>'+ matid1+'</td><td>'+ matname1 +'</td><td><input type="text" name="matqty" /> </td><td><button>Delete</button></td></tr>');
}
 function deletetrrow(id)
{
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var rowCount = $('#example tr').length;
	var result=confirm("Want to delete?");
	//alert(result);
	if(result==true)
	{
		//alert(this);
		//$(this).closest('tr').remove();
		$(".getrow_"+idsplit[1]).css("background-color","#a94442");

		$(".getrow_"+idsplit[1]).fadeOut(400, function(){
			$(".getrow_"+idsplit[1]).remove();
		});
	}
	rowCount=rowCount-1;
	if( rowCount<2)
	{
		$("#submit").hide();
	}
	
	
	
	// alert('hello');
}
function getcstdtls()
{
	//alert('hello');
	var custmail=$("#tags").val();
	//alert(custmail);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getcustmer",
  			data :{'custmail':custmail},
  			success : function(data){
  				 				 
  				//console.log(data);
  				
  				var json=JSON.parse(data);
  				
  				var cmpnme=json.comp;
  				var name=json.name;
  				var custid=json.custid;
  				var cmpmail=json.email;
				var sid=json.sid;
				var sname=json.sname;
  				$("#cmpmail").val(cmpmail);
  				$("#comname").val(cmpnme);
  				$("#compid").val(custid);
  				$("#custname").val(name);
				$("#sid").val(sid);
				$("#sname").val(sname);
  				
  				
  				//$(".prts").html(data);
  			  
              }  
       });
}
function gettypedetails()
{
	var cattyp=$("#cattyp").val(); 
	//alert(cattyp);
	//console.log(cattyp);
	if(cattyp=="product")
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getmodeldet",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					$("#model").show();
  				  $("#model").html(data);
              }  
       });
	}else
	{
		//$("#model").hide();
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getmodellistbyparts",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					$("#model").show();
  				  $("#model").html(data);
              }  
       });
		
		//if(cattyp=="parts")
		//{
			
		//}else
		//{
			
		//}
	}
}
function getmodeltype()
{

	var type1=$("#modeltype").val();
	var typesplit=type1.split("_");
	var type=typesplit[0];
	var id=typesplit[1];
	
	
	//alert(id);
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getmodelprice",
  			data :{'type':type},
  			success : function(data){
  					
  				  $("#simpleModal_"+id).show();
				  
              }  
       });
	  
	
}

function getmodeltypebyparts()
{
	var type1=$("#modeltype").val();
	var typesplit=type1.split("_");
	var type=typesplit[0];
	var id=typesplit[1];
	//alert("parts");
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getmodelprice",
  			data :{'type':type},
  			success : function(data){
  					
  				  $("#modalparts_"+id).show();
				 
              }  
       });
	
	
}
function getericksakwval(id)
{
	var idsplit=id.split("_");
	var catval=0;
	var cate2="";
	for(var d=1;d<4;d++){
	    var eric=$("#erickshaw_"+idsplit[1]+"_"+d).val();
	    
		if($("#erickshaw_"+idsplit[1]+"_"+d).prop('checked') == true)
		{
			//alert(eric);
			catval=parseFloat(catval)+parseFloat(eric);
			cate2 += d +",";
			
		}
	
	}
	//console.log(cate2);
	$("#cate2_"+idsplit[1]).val(cate2);
	$("#cat_"+idsplit[1]).val(catval);
	
}
function getpartsdetltsbymodal(id)
{
	
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	//var id1=id;
	//var matid1="matid";
	//var specid=$("#speci_"+id1).val();
	//var prtsqt=parseInt($("#noprts_"+id1).val());
	//var model=$("#modelname").val();
	var retoto=$("#noqty_"+idsplit[1]).val();
	if(retoto==""){
		 //alert("Please Select Model Name");
		 modal({
				type: 'warning',
				title: 'Message!',
				text: '<h4><b>Please Enter Required No Qty</b></h4>',
			});
			
	}else{		
	
		//alert(specid);
	var tottable=parseInt($("#tottable_"+idsplit[1]).val());
	var totqnty1=parseInt($("#noqty_"+idsplit[1]).val());
	
	//alert(tottable);
	var rest=0;
	var grandtot=0;
	for(var i=1;i<tottable;i++)
	{
		 var prtd=$("#totqnty_"+idsplit[1]+"_"+i).val();
	  //var totval= $("#totval_"+idsplit[1]+"_"+i).val(totval);
	    var tot= $("#totvalue_"+idsplit[1]+"_"+i).val();
	    //tot=tot.toFixed(2);
		var matname=$("#matnam_"+idsplit[1]+"_"+i).val();
		var matid=$("#matid_"+idsplit[1]+"_"+i).val();
		var partsamnt=$("#partsamnt_"+idsplit[1]+"_"+i).val();
		//console.log("#partsamnt_"+idsplit[1]+i);
		if($("#checked_"+idsplit[1]+"_"+i).prop('checked') == true)
		{
			grandtot=grandtot+parseInt(tot);
			var rowCount = $('#example tr').length;
			var specif="";
			var tr=rowCount-1;
	   	 	var tr2=tr+1;
	   	 	$("#tbalerow").val(tr2);
	   	 	$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+ matname +'<br><i>('+specif+')</i><input type="hidden" name="modelname_'+tr2+'" value="'+matname+'"/></td><td>'+prtd+'<input type="hidden" value="'+prtd+'" name="prqty_'+tr2+'" id="prqty_'+tr2+'"/><br><i></i></td><td>'+partsamnt+'<input type="hidden" value="'+partsamnt+'" name="amount_'+tr2+'" id="amount_'+tr2+'"/></td><td>'+tot+'<input type="hidden" name="tot1_'+tr2+'" id="tot1_'+tr2+'" value="'+tot+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
			//$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+modelname+'<br>('+catr+')<input type="hidden" name="specif_'+tr2+'" id="specif_'+tr2+'" value="'+catr+'"/><input type="hidden" name="colorspe_'+tr2+'" value="'+color+'"/><input type="hidden" value="'+modelname+'" name="modelname_'+tr2+'" id="modelname_'+tr2+'"/></td><td>'+prqty+'<input type="hidden" value="'+prqty+'" name="prqty_'+tr2+'" id="prqty_'+tr2+'"/></td><td>'+amount+'<input type="hidden" value="'+amount+'" name="amount_'+tr2+'" id="amount_'+tr2+'"/></td><td>'+amnt+'<input type="hidden" name="tot1_'+tr2+'" id="tot1_'+tr2+'" value="'+amnt+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
	   	 	
			$('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='particular_"+tr2+"' value='"+matid+"'/>");
  			$('.inputr').append("<input type='hidden' id='specfic_"+tr2+"' name='specfic_"+tr2+"' value='"+specif+"'/>");
  			$('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			$('.inputr').append("<input type='hidden' name='unitpr_"+tr2+"' id='unitpr_"+tr2+"' value='"+partsamnt+"'  />");
  			$('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			    /*$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			     $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			     $('.inputr').append("<input type='hidden' name='prtspecif_"+tr2+"' id='prtspecif_"+tr2+"' value='"+specid+"'  />");*/
  			    // $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			    
	   	 	
	   	 	
	   	 	
	   	 	
	   	 	
	   }else
	   {
	   	 rest++;
	   }
	}
	   alert(rest);
	     $("#nettot").text(parseInt(grandtot).toFixed(2));
	  	$("#grandtot").text(parseInt(grandtot).toFixed(2));
  	   	$("#grandtotal").val(parseInt(grandtot).toFixed(2));	
	
	
     //alert(matid);
     
   	   $("#submit").show();
	   $("#table1").show();
   
	}
	
	//alert('hello');
	//alert(id);
	//$('#example tr:last').after('<tr><td>'+ tr2 +'</td><td>'+ matid1+'</td><td>'+ matname1 +'</td><td><input type="text" name="matqty" /> </td><td><button>Delete</button></td></tr>');
 
}
function gettotallist(id)
{
	var idsplit=id.split("_");
	//alert(idsplit);
	var tottable=parseInt($("#tottable_"+idsplit[1]).val());
	var totqnty1=parseInt($("#noqty_"+idsplit[1]).val());
	if(totqnty1=="" || isNaN(totqnty1))
	{
		totqnty1=1;
	}
	//alert(tottable);
	
	for(var i=1;i<tottable;i++)
	{
		var unit=$("#unitpartsd_"+idsplit[1]+"_"+i).val();
		//alert(unit);
		//alert(totqnty1);
		
		var prtsamnt=parseFloat($("#partsamnt_"+idsplit[1]+"_"+i).val());
		var totqnt=parseInt(totqnty1) * parseInt(unit);
		var totval=parseFloat(prtsamnt) * totqnt;
		//$().val();
		$("#totqnty_"+idsplit[1]+"_"+i).val(totqnt);
	   $("#totval_"+idsplit[1]+"_"+i).val(totval);
	    $("#totvalue_"+idsplit[1]+"_"+i).val(totval.toFixed(2));
		
	}
	
	
}
function getvatamount()
{
	var nettot=parseFloat($("#grandtot").text());
	var vatcst=$("#vatcst").val();
	if(vatcst==""){
		alert("please select VAT/CST");
		$("#vatcs").val('');
  	    $("#vatamnt").text("");
  		$("#grandtot").text(nettot.toFixed(2));
  		$("#grandtotal").val(nettot.toFixed(2));
  		$("#vat_amnt").val('');
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getvatdetails",
  			data :{'vatcst':vatcst,'nettot':nettot},
  			success : function(data){
  				//console.log(data);
  				 	var json=JSON.parse(data);
  				 	var vatamnt=parseFloat(json.vat);
  				 	vatamnt=vatamnt.toFixed(2)+"%";
  				 	var vatamnt2=parseFloat(json.vatamnt);
  				 	vatamnt2=vatamnt2.toFixed(2);
  				 	var grtot=parseFloat(json.grandtot);
  				 	$("#vatcs").val(vatamnt);
  				 	$("#vatamnt").text(vatamnt2);
  				 	$("#vat_amnt").val(vatamnt2);
  				 	$("#grandtot").text(grtot.toFixed(2));
  				 	$("#grandtotal").val(grtot.toFixed(2));			 
  				  
              }  
       });
	}
	//alert(vatcst);
}
function getcstamount()
{
	
	var nettot=parseFloat($("#nettot").text());
	var vatamnt=parseFloat($("#vatamnt").text());
	var grandtot=parseFloat($("#grandtot").text());
	var excise=$("#excise").val();
	if(excise==3){
		var grandtot2=parseFloat(nettot)+parseFloat(vatamnt);
		alert("please select Excise tax");
		$("#excisetax").val('');
  	   $("#examnt").text("");
  	   $("#excise_amnt").val('');
  	   	$("#grandtot").text(grandtot2.toFixed(2));
  	   	$("#grandtotal").val(grandtot2.toFixed(2));
	}else
	{
		if(excise==1){
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Bokking_controller/getexcisedetails",
  			data :{'excise':excise,'grandtot':grandtot},
  			success : function(data){
  				console.log(data);
  				 	var json=JSON.parse(data);
  				 	var excise=parseFloat(json.excise);
  				 	excise=excise.toFixed(2)+"%";
  				 	var exciseamnt=parseFloat(json.exciseamnt);
  				 	exciseamnt=exciseamnt.toFixed(2);
  				 	var grtot=parseFloat(json.grandtot);
  				 	$("#excisetax").val(excise);
  				 	$("#examnt").text(exciseamnt);
  				 	$("#excise_amnt").val(exciseamnt);
  				 	$("#grandtot").text(grtot.toFixed(2));	
  				 	$("#grandtotal").val(grtot.toFixed(2));		 
  				  
              }  
       });
       
      }
      else
      {
      	var grandtot2=parseFloat(nettot)+parseFloat(vatamnt);
		//alert("please select Excise tax");
		$("#excisetax").val('');
  	   $("#examnt").text("");
  	   $("#excise_amnt").val('');
  	   	$("#grandtot").text(grandtot2.toFixed(2));
  	   	$("#grandtotal").val(randtot2.toFixed(2));		 
      }
	}
}
</script>
<script>
$(document).ready(function(){
	//$("#modalparts").hide();
	var dynamic=parseInt($("#dynamicmodal").val());
	for(var as=1;as<dynamic;as++)
	{
		$("#simpleModal_"+as).hide();
	}
	$("#table1").hide();
	var hiddenparts=parseInt($("#hiddenparts").val());
	for(var a=1;a<hiddenparts;a++)
	{
		$("#modalparts_"+a).hide();
	}
	

    $( "#tags" ).autocomplete({
      source: "<?php echo base_url(); ?>Bokking_controller/autocomplete"
    });
	

});
		</script>
		
		

