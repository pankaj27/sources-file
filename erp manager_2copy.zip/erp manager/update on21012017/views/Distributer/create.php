<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php  if(isset($getalldistributer) && !empty($getalldistributer)){ ?>
	<?php foreach($getalldistributer as $row) {
		$lastid=$row->clientid;
		$custname=$row->name;
		$image1=$row->image;
		$compname=$row->compname;
		$ph1=$row->phone;
		$ph2=$row->phno2;
		$email=$row->email;
		$email2=$row->email2;
		$password=$row->pass;
		$openbal=$row->openbal;
		$acname=$row->acname1;
		$acname2=$row->acname2;
		$custtyp=$row->custtype;
		$agreement=$row->agreemnt_validity;
		$interest=$row->interest;
		$add1=$row->add1;
		$add2=$row->add2;
		$country2=$row->country;
		$state=$row->state;
		$district=$row->district;
		$area=$row->area;
		$pin=$row->pin;
		$pan=$row->pan;
		$tin_vat=$row->tin_vat;
		$cst=$row->cst;
		$excise=$row->excise;
		$acno1=$row->acno1;
		$bankname1=$row->bank1;
		$branch1=$row->branch1;
		$ifsc1=$row->ifsc1;
		$swift1=$row->swift1;
		$swift2=$row->swift2;
		$acno2=$row->acno2;
		$bankname2=$row->bank2;
		$branch2=$row->branch2;
		$ifsc2=$row->ifsc2;
		$fact1=$row->factory1;
		$fact2=$row->factory2;
		$fact3=$row->factory3;
		$shr1=$row->showroom1;
		$shr2=$row->showroom2;
		$shr3=$row->showroom3;
		$id=$row->id;
		//$excise=$row->excise;
		
		
	}
	
	 ?>
	
<?php  } ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Create New Customer</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" <?php if(isset($id)){ ?>action="<?php echo base_url(); ?>Manage_distributer/updatedistributer"<?php }else{ ?>action="<?php echo base_url(); ?>Manage_distributer/savenewdistributer" <?php } ?>  method="post" enctype="multipart/form-data" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Personal Information</header>
							</div>
							<div class="card-body floating-label">
								   
								
								    <div class="col-md-8">
										<div class="form-group">
											<input type="hidden" name="dist_id" value="<?php if(isset($id)){ echo $id;} ?>"/>
										<input type="hidden"  value="" name="divnorow" id="abcd"/>
										<input type="file" class="form-control" id="imgInp" name="image1" >
										<input type="hidden" name="image2" value="<?php if(isset($image1)){ echo $image1 ; } ?>" />	
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
										<img id="blah" <?php if(isset($image1)&& !empty($image1)){ ?> src="<?php echo base_url(); ?>uploads/clientpics/<?php echo $image1; ?>"<?php }else{ ?>src="<?php echo base_url(); ?>assets/favicon/anonymous-man.png"<?php  } ?> alt="your image" width="150" height="150"/>
											
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="text" name="compname" class="form-control" required="required" value="<?php if(isset($compname)){echo $compname; } ?>">
											<label for="mName">COMPANY NAME</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="text" name="custid" class="form-control" readonly="readonly" value="<?php if(isset($lastid)){ echo $lastid; } ?>">
											<label for="mName">DISTRIBUTER ID</label>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
										
										<input type="text" name="custname" class="form-control" required="required" value="<?php if(isset($custname)){ echo $custname ; }  ?>">
											<label for="mName">CUSTOMER  NAME</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="number" name="ph" class="form-control" required="required" value="<?php if(isset($ph1)){ echo $ph1; } ?>">
											<label for="mName">PHONE NO 1</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="email" name="email" class="form-control" required="required" value="<?php if(isset($email)){ echo $email; }  ?>">
											<label for="mName">EMAIL ID 1</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="number" name="ph2" class="form-control" required="required" value="<?php if(isset($ph2)){ echo $ph2 ; } ?>">
											<label for="mName">PHONE NO 2</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="email" name="email2" class="form-control" value="<?php if(isset($email2)){ echo $email2 ; } ?>">
											<label for="mName">EMAIL ID 2</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="password" name="password" class="form-control" required="required" value="<?php if(isset($password)){ echo $password; } ?>">
											<label for="mName">CREATE PASSWORD</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="number" name="openbal" class="form-control" required="required" value="<?php if(isset($openbal)){ echo $openbal; } ?>">
											<label for="mName">SECURITY DEPOSIT AMOUNT</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="number" name="percentage" class="form-control" required="required" value="<?php  if(isset($interest) && !empty($interest)){ echo $interest; }?>">
											<label for="mName">PERCENTAGE(%)</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
										<input type="text" name="agreement" class="form-control" required="required" value="<?php if(isset($agreement) && !empty($agreement)) { echo $agreement; } ?>">
											<label for="mName">AGREEMENT VALIDITY TIME</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
										
											<select name="custtype" id="custtype" class="form-control" onchange="customertype();" required >
												  <?php if(isset($custtyp) && !empty($custtyp)){ ?>
												  	 <option value="<?php echo $custtyp; ?>" selected><?php echo $custtyp;  ?></option>
												  	 <?php if(isset($customertype) && !empty($customertype))
														{ ?>
															<?php foreach($customertype as $row3) {  ?>
																<option value="<?php echo $row3->custtyp; ?>"><?php echo $row3->custtyp;  ?></option>
																
																
														<?php 	}?>
															
															
													    <?php  }
													
												   }else{ ?>
														 <option value=""></option>
														<?php if(isset($customertype) && !empty($customertype))
														{ ?>
															<?php foreach($customertype as $row3) {  ?>
																<option value="<?php echo $row3->custtyp; ?>"><?php echo $row3->custtyp;  ?></option>
																
																
														<?php 	}?>
															
															
													    <?php  }	} ?>
											</select>
											<label for="mName">CUSTOMER TYPE</label>
										</div>
									</div>
									
									<div class="col-md-6" id="cnflist">
										
									</div>
									<div class="col-md-6" id="dealerlist">
										
									</div>
									</div>
						</div>
								

								<div class="card">
									<div class="card-head style-primary">
										<header>ADDRESS INFORMATION</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="d_inc_battery" name="add1" required="required" value="<?php if(isset($add1)){echo $add1; } ?>">
												<label for="d_inc_battery">ADDRESS 1</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" value="<?php if(isset($add2)){ echo $add2; } ?>" id="d_ex_battery" name="add2">
													<label for="d_ex_battery">ADDRESS2</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" value="<?php if(isset($area)){ echo $area ; } ?>" id="d_inc_battery" name="area" required="required">
												<label for="d_inc_battery">AREA</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<select name="country" id="country" class="form-control" onchange="getstate();">
														<?php if(isset($country2) && !empty($country2)){ ?>
															<option value="<?php echo $country2; ?>" selected><?php  echo $country2; ?></option>
															<?php if(isset($country) && !empty($country))
														{
															foreach($country as $row)
															{
																?>
															    <option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
														       <?php 	
															}
														}
													 	}else{  ?>
														<option value=""></option>
													<?php if(isset($country) && !empty($country))
													{
														foreach($country as $row)
														{
															?>
															<option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
													<?php 	}
													}
														}
													
													
													 ?>
											     </select>
													<label for="d_ex_battery">COUNTRY</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group" id="state">
												<?php if(isset($state) && !empty($state)){
													if(isset($country2)=="India"){ ?>
														<select id='state2' name='state' class='form-control'>
															<option value="<?php echo $state ?>" selected><?php echo $state; ?></option>
														<?php foreach($getstate2 as $rowstate)
														{   ?>
														 <option value="<?php echo  $rowstate->statename; ?>"><?php  echo $rowstate->statename; ?></option>
													<?php } ?>
														</select>
													<?php }else{ ?>
												    <input type="text" class="form-control" id="state" name="state" value="<?php echo $state; ?>">
												    <label for="d_inc_battery">STATE</label>
														
												<?php	}	} ?>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="district" name="district" value="<?php  if(isset($district)){ echo $district;}  ?>">
													<label for="d_ex_battery">DISTRICT</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" pattern="[0-9]" class="form-control" id="d_inc_battery" name="pin" required="required" value="<?php if(isset($pin)){ echo $pin ; } ?>">
												<label for="d_inc_battery">PIN</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													
												</div>
										</div>
									</div>
									
									</div>
									</div>
								

								<div class="card">
									<div class="card-head style-primary">
										<header>BANK INFORMATION</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="s_inc_battary" name="bankname1" required="required" value="<?php if(isset($bankname1)){echo $bankname1;} ?>">
												<label for="s_inc_battary">BANK NAME 1</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="s_ex_battary" name="acname1" required="required" value="<?php if(isset($acname)){ echo $acname; }  ?>">
													<label for="s_ex_battary">ACCOUNT  NAME 1</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="s_inc_charger" name="acno1" required="required" value="<?php if(isset($acno1)){ echo $acno1 ; }  ?>">
												<label for="s_inc_charger">ACCOUNT NO 1</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="s_ex_charger" name="branch1" value="<?php if(isset($branch1)){ echo $branch1 ; } ?>" >
													<label for="s_ex_charger">BRANCH NAME 1</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="s_inc_charger" name="ifsc1" required="required" value="<?php if(isset($ifsc1)){ echo $ifsc1; } ?>">
												<label for="s_inc_charger">BRANCH IFSC CODE 1</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="s_ex_charger" name="swift1" value="<?php if(isset($swift1)){ echo $swift1;} ?>">
													<label for="s_ex_charger">BRANCH SWIFT CODE 1</label>
												</div>
										</div>
									</div>
									<hr>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="s_inc_battary" name="bank2" value="<?php if(isset($bankname2)){  echo $bankname2;} ?>">
												<label for="s_inc_battary">BANK NAME 2</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="s_ex_battary" name="acname2" value="<?php  if(isset($acname2)){ echo $acname2; } ?>">
													<label for="s_ex_battary">ACCOUNT  NAME 2</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="s_inc_charger" name="acno2" value="<?php if(isset($acno2)){ echo $acno2;} ?>">
												<label for="s_inc_charger">ACCOUNT NO 2</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="s_ex_charger" name="branch2" value="<?php if(isset($branch2)){ echo $branch2; } ?>">
													<label for="s_ex_charger">BRANCH NAME 2</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="s_inc_charger" name="ifsc2" value="<?php if(isset($ifsc2)){ echo $ifsc2; } ?>">
												<label for="s_inc_charger">BRANCH IFSC CODE 2</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="s_ex_charger" name="swift2" value="<?php if(isset($swift2)){ echo $swift2; } ?>">
													<label for="s_ex_charger">BRANCH SWIFT CODE 2</label>
												</div>
										</div>
									</div>
									
								</div>
								</div>
								<div class="card">
									<div class="card-head style-primary">
										<header>VAT/TIN/CST INFORMATION</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="r_inc_battary" name="tin" required="required" value="<?php if(isset($tin_vat)){ echo $tin_vat ; } ?>">
												<label for="r_inc_battary">TIN/VAT NO</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="r_ex_battary" name="cst" value="<?php if(isset($cst)){ echo $cst; } ?>" >
													<label for="r_ex_battary">CST NO</label>
												</div>
										</div>
										
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="r_inc_battary" name="excise" value="<?php if(isset($excise)){ echo $excise; } ?>">
												<label for="r_inc_battary">EXCISE DUTY</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="r_ex_battary" name="pan" required="required" value="<?php if(isset($pan)){ echo $pan; } ?>">
													<label for="r_ex_battary">PAN NO</label>
												</div>
										</div>
										
									</div>
									
									
								

								
							
				</div>
				</div>
								
								<div class="card">
									<div class="card-head style-primary">
										<header>COMPANY INFORMATION</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="r_inc_battary" name="fact1" required="required" value="<?php if(isset($fact1)){ echo $fact1;} ?>">
												<label for="r_inc_battary">WAREHOUSE 1</label>
											</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="r_ex_battary" name="fact2" value="<?php if(isset($fact2) ){ echo $fact2 ; }  ?>">
													<label for="r_ex_battary">WAREHOUSE 2</label>
												</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="r_ex_battary" name="fact3" value="<?php if(isset($fact2)){ echo $fact2; } ?>">
													<label for="r_ex_battary">WAREHOUSE 3</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="r_inc_battary" name="shr1" required="required" value="<?php if(isset($shr1)){ echo $shr1 ;} ?>">
												<label for="r_inc_battary">SHOWROOM 1</label>
											</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="r_ex_battary" name="shr2" value="<?php if(isset($shr2)){ echo $shr2; } ?>">
													<label for="r_ex_battary">SHOWROOM 2</label>
												</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="r_ex_battary" name="shr3" value="<?php if(isset($shr3)){ echo $shr3; } ?>">
													<label for="r_ex_battary">SHOWROOM 3</label>
												</div>
										</div>
									</div>
									
									
								

								
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction"><?php if(isset($id)){ echo "Update"; }else{ echo "Submit"; } ?></button>
								</div>
							</div>
				</div>
				</div>
				</form>	
         
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLvoter(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLpan(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah2').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLadhar(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah3').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function getstate()
    {
    	var country=$("#country").val();
    	if(country=="")
    	{
    		alert('please select country');
    		//$("#state").hide();
    		$("#state2").remove();
    	}else
    	{
    		if(country=="India")
    		{
	    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_distributer/getstate",
	  			data :{'country':country},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				$("#state").html(data);
	  			  
	              }  
                });
    		}else
    		{
    			//alert('hello');
    			$("#state").html('<input type="text" class="form-control" id="state" name="state"><label for="d_inc_battery">STATE</label>');
    		}
    	}
    }
    function customertype()
    {
    	//alert('hello');
    	var custype=$("#custtype").val();
    	alert(custype);
    	if(custype=="DEALER")
    	{
    		//alert('hello');
    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_distributer/get_cnflist",
	  			data :{'custype':custype},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				$("#cnflist").html(data);
	  			  
	              }  
                });
    		
    	}
    	
    	 if(custype=="SUB-DEALER")
    	{
    		//alert('hello2');
    		//$("#cnflist").hide();
    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_distributer/get_cnflist",
	  			data :{'custype':custype},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				$("#cnflist").html(data);
	  			  
	              }  
              });
             
    	}
    	 if(custype=="RETAILER/DIRECT")
    	{
    		
    	}
    	
    	
    }
    function getdealer()
    {
    	var cnf=$("#cnf").val();
    	  alert(cnf);
    	
    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_distributer/getdelaerlist",
	  			data :{'cnf':cnf},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				console.log(data);
	  				$("#dealerlist").html(data);
	  			  
	              }  
                });
    }
    
    $("#imgInp").change(function(){
        readURL(this);
    });
    $("#imgInp1").change(function(){
        readURLvoter(this);
    });
    $("#imgInp2").change(function(){
        readURLpan(this);
    });
    $("#imgInp3").change(function(){
        readURLadhar(this);
    });
</script>
