<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>

<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $(document).(function(){
    $("#example").dataTable();
  })
  </script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Cash / Check Entry</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Cash / Check Entry </a></li>
								<!--<li><a href="<?php echo base_url(); ?>newBrand_controller/viewmodel">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				
						<div class="card">
							<div class="card-head style-primary">
								<header>Accounts Information</header>
							</div>
							<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/fetch_cashinfo"  method="post" >
							<div class="card-body floating-label">
								 <div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<?php if(isset($cashinfo) && !empty($cashinfo)){?>
										<?php foreach($cashinfo as $row){?>
											<input type="text" class="form-control" id="clientID" name="clientID" value="<?php echo $row->clientid; ?>">
											<?php }}else{ ?>
												<input type="text" class="form-control" id="clientID" name="clientID">
											<?php } ?>
											<label for="clientID">Client Id</label>
										</div>
									</div>
									<div class="col-md-1">
										<div class="form-group">
											
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getForm()">Go</button>
										</div>
									</div>
									</div>
								</div>
								</form>
									</div>
									<?php if(isset($cashinfo) && !empty($cashinfo)){?>
										<?php foreach($cashinfo as $row){?>
							<div class="form" id="form23">
							<div class="card">
							<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/save_cashinfo"  method="post" >
							<div class="card-head style-primary">
								<header>Customer Information</header>
							</div>
							<div class="card-body floating-label">
								<input type="hidden" name="clientID" id="clientID" value="<?php echo $row->clientid; ?>">
								<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="custid" name="custid" value="<?php echo $row->clientid; ?>" readonly >
												<label for="custid">Customer ID</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="custname" name="custname" value="<?php echo $row->name; ?>" readonly >
												<label for="custname">Customer Name</label>
											</div>
										</div>	
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="custtype" name="custtype" value="<?php echo $row->custtype; ?>" readonly  required="">
												<label for="custtype">Customer Type</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control"  name="add1" value="<?php $row->add1; ?>" readonly required="">
												<label for="add1">Address</label>
											</div>
										</div>	
									</div>
								
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						</div>
							<div class="form" id="form">
							<div class="card">
							<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/save_cashinfo"  method="post" >
							<div class="card-head style-primary">
								<header>Accounts Information</header>
							</div>
							<div class="card-body floating-label">
								<input type="hidden" name="clientID" id="clientID" value="<?php echo $row->clientid; ?>">
								
								<input type="hidden" name="securityamountpaid" id="securityamountpaid" value="<?php echo $row->securityamountpaid; ?>">
								<input type="hidden" name="pamnt" id="pamnt" value="">
								<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="securdepot" name="securdepot" value="<?php echo $row->openbal; ?>" readonly >
												<label for="securdepot">Security Deposite</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												
												<select class="form-control" id="Purpose" name="Purpose" onchange="securitydetails()" required>
													<option value="">--Purpose--</option>
													<option value="Security">Security </option>
													<option value="Advance">Advance </option>
													<option value="Others">Others </option>
													
												</select>
												<!--<label for="modelName">Paid Amount</label>-->
											</div>
										</div>
										<input type="hidden" name="balence" id="balence" value="<?php echo $row->balance; ?>">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="agreval" name="agreval" value="<?php echo $row->agreemnt_validity; ?>" readonly >
												<label for="agreval">Agreement Validity</label>
											</div>
										</div>	
									</div>
									<div id="security">
									
									</div>
									<div id="others">
									
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												
												<select class="form-control" id="pdamount" name="pdatype" onchange="chaquedetails()" required>
													<option value="">--Paid Type--</option>
													<option value="Cash">Cash </option>
													<option value="Cheque">Cheque </option>
													<option value="RTGS_NEFT">RTGS, NEFT </option>
													
												</select>
												<!--<label for="modelName">Paid Amount</label>-->
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="date1" name="date1" required="">
												<label for="date1">Date</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="remark" name="remark" >
												<label for="remark">Remark</label>
											</div>
										</div>
									</div>
									<div id="chque_hide">
									
									</div>		
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>
								
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						</div>
						<?php } } ?>
						    	</div>


							</div>
				</div>
				</form>	
				
				
				
         
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script>
 $(document).ready(function(){
    $("#date1").datepicker();
  });
  </script>
<!--<script type="text/javascript">
$(document).ready(function() {
    $("#form").hide();
});
</script>-->
<script>
function getForm(){
	$("#form").show();
	
}
</script>
<script>
function chaquedetails()
{
	var pdamount=$("#pdamount").val();
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/get_chqu",
  			data :{'pdamount':pdamount},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#chque_hide").html(data);
  			  
              }  
           });
}
	</script>
	<script>
	function securitydetails()
{
	var Purpose=$("#Purpose").val();
	var securityamountpaid=$("#securityamountpaid").val();
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getsecurityDetails",
  			data :{'Purpose':Purpose,'securityamountpaid':securityamountpaid},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#security").html(data);
  			  
              }  
           });
}
function getduebalence()
{
	var paidamnt=parseFloat($("#paidamnt").val());
	//alert(paidamnt);
	if(paidamnt=="" || isNaN(paidamnt))
	{
		paidamnt=0;
	}
	
	var payamnt=parseFloat($("#payamnt").val());
	//alert(payamnt);
	if(payamnt=="" || isNaN(payamnt))
	{
		payamnt=0;
	}
	var securdepot=parseFloat($("#securdepot").val());
	//alert(securdepot);

	var paidamntto=parseFloat(paidamnt)+parseFloat(payamnt);
	//alert(paidamntto);
	
	if(parseFloat(securdepot)>=parseFloat(paidamntto)){
		var duebalence=parseFloat(securdepot)-parseFloat(paidamntto);
	}else{
		var duebalence=parseFloat(paidamntto)-parseFloat(securdepot);
	}
	duebalence=duebalence.toFixed(2);
	payamnt=payamnt.toFixed(2);
	$("#Dueblnce").val(duebalence);
	$("#pamnt").val(payamnt);
	//$("#payamnt").val(payamnt);
	
	
}
function getpbalence()
{
	var payamnt=parseFloat($("#payamnt1").val());
	$("#pamnt").val(payamnt);
	
	
}
	</script>
