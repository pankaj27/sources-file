<?php include('connection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<script src="<?php echo base_url(); ?>jscolor.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>

</script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">Latest Booking List </li>
				</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View</a></li>-->
								
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
            	<th>BOOKINGID</th>
                <th>CUST ID</th>
                <th>COMPANY</th>
                <th>DOE</th>
                <th>ORDER BAL.</th>
                <th>CURRENT BAL.</th>
				<th>STATUS</th>
				<th>SALESMAN NAME</th>
				<th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($getbookinglist) && !empty($getbookinglist)){ $bkid2="abcdef";  $i=1; ?>
			<?php foreach($getbookinglist as $row){ ?>
				<?php $bkid=$row->bokingid ; $nettot=0;?>
				<?php if($bkid!=$bkid2){
					$cus=$row->custid;
					$qry=mysqli_query($con,"select * from clientmaster where clientid='".trim($cus)."'");
					$row1=mysqli_fetch_array($qry);
					$custnme=$row1['compname'];
					$balance=$row1['balance'];
					$qry2=mysqli_query($con,"select * from bookingorder where bokingid='".trim($row->bokingid)."'");
				  while($row2=mysqli_fetch_array($qry2)){ $nettot=$nettot+floatval($row2['total']); }
					
					
					 ?>
            <tr>
               <td><?php echo $i ?></td>
                <td><?php echo $row->bokingid; ?></td>
               <td><?php echo $row->custid; ?></td>
               <td><?php echo $custnme; ?></td>
              
               <td><?php echo $row->doe; ?></td>
               <td><?php echo '<i class="fa fa-inr" aria-hidden="true"></i> '.number_format($nettot, 2); ?>      		              	
               </td>
               <td><?php echo '<i class="fa fa-inr" aria-hidden="true"></i> '.number_format($balance, 2); ?></td>
               <td></td>
               <td> <?php echo $row->sname; ?></td>
			   <td>
			   	<a title="view Booking Details" href="<?php echo base_url(); ?>AcountsManage_Controller/getsalesorderdetails/<?php echo $row->bokingid;  ?>"><i class="fa fa-eye" aria-hidden="true"></i></a> 
			   	&nbsp;<a href="" title="Cancel"><i class="fa fa-ban" aria-hidden="true"></i></a>
			   	<!--<a href="" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true" ></i></a>&nbsp;&nbsp;
			   	<a href="" title="Delete"><i class="fa fa-trash" aria-hidden="true" ></i></a>-->
			    <!-- <a title="Generate Invoice" href="<?php echo base_url(); ?>AcountsManage_Controller/generateinvoice/<?php echo $row->bokingid;  ?>"><i class="fa fa-eye" aria-hidden="true"></i></a> 
			   	&nbsp;<a href="" title="Cancel"><i class="fa fa-ban" aria-hidden="true"></i></a>-->
			   	&nbsp;
			   <a href="#" title="Send To Accounts">	<i class="fa fa-share-square" aria-hidden="true"></i></a>
			   	&nbsp;
			   <a href="" title="Mail To customer">	<i class="fa fa-envelope" aria-hidden="true"></i></a>
			   &nbsp;
			   <a href="<?php echo base_url(); ?>AcountsManage_Controller/print_invoice/<?php echo $row->bokingid; ?>" title="Print Invoice"><i class="fa fa-print" aria-hidden="true"></i></a>
			   </td>
            </tr>
            <?php $i++;$bkid2=$bkid; } } } ?>
        </tbody>
    </table>
				</div>
				</form>	
         <div class="tab-pane" id="second1">
	</div>
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							<div class="tab-pane" id="third1"><p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p><p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p></div>
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
 