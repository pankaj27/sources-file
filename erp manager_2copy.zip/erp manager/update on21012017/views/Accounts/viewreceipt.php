<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<script src="<?php echo base_url(); ?>jscolor.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">View Model Price Entry</li>
				</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1" style="overflow-x: scroll;">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>SL NO.</th>
            	<th>DATE</th>
                <th>CUST ID</th>
                <th>CUST NAME</th>
                <th>CUST TYPE</th>
                <th>PURPOSE</th>
                <th>PAYMENT TYPE</th>
                <th>CHEQUE/RTGS NO</th>
                <th>BANK</th>
                <th>BRANCH</th>
				<th>AMOUNT</th>
				<th>RECEIPT BY</th>
				<th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($getreceipt) && !empty($getreceipt)){$sl=1;//print_r($getreceipt); ?>
			<?php foreach($getreceipt as $row){ ?>
            <tr>
                <td><?php echo $sl; ?></td>
                <td><?php echo $row->doe; ?></td>
                <td><?php echo $row->clientID; ?></td>
                <td><?php echo $row->name; ?></td>
                <td><?php echo $row->custtype; ?></td>
                <td><?php echo $row->purpose; ?></td>
                <td><?php echo $row->type; ?></td>
                <th><?php echo $row->cheque_no; ?></th>
                <td><?php echo $row->bankName; ?></td>
                <td><?php echo $row->branchName; ?></td>
                <td><?php echo $row->paid_amt; ?></td>
                
                <td><?php echo $row->submitby; ?></td>
                
                <td>
                	
                	<?php 
                	 $st=intval($row->acstatus);
                	
                	
                	if($st==0){ ?>
                		<button type="button" data-toggle="modal" data-target="#myModal_<?php echo $sl; ?>"  class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-thumbs-up" aria-hidden="true"></i> </button>
						
                <?php 	}else{ ?>
                		<button type="button"   class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-check" aria-hidden="true"></i></button>
                		
                <?php	} ?>
                	<!--<button type="button" data-toggle="modal" data-target="#myModal_<?php echo $sl; ?>"  class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-thumbs-up" aria-hidden="true"></i> </button>-->
                	
                	<!--
                		---------------------------------------------------------------------------------------------------
                	                            Modal    
                	    --------------------------------------------------------------------------------------------------->
                	<div class="modal fade" id="myModal_<?php echo $sl; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel"> Payment Receipt Confirmation for  <?php  echo $row->name."(".$row->clientID.")" ;   ?></h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <div class="row">
					        	<div class="col-md-12">
					        		 <h3><b>Payment Details</b></h3>
					        	</div>
					        	<div class="col-md-12" style="overflow-x: scroll;">
					        		<table class="table table-bordered table-hover">
					        			<tbody>
					        				<tr>
					        					<td><b>CUST ID</b></td>
					        					<td><?php echo $row->clientID; ?></td>
					        					<td><b>CUST NAME</b></td>
					        					<td><?php echo $row->name; ?></td>
					        					<td><b>PURPOSE</b></td>
					        					<td><?php echo $row->purpose; ?></td>
					        				</tr>
					        				<tr>
					        					<td><b>PAYMENT TYPE</b></td>
					        					<td><?php echo $row->type; ?></td>
					        					<td><b>CHEQUE NO</b></td>
					        					<td><?php echo $row->cheque_no; ?></td>
					        					<td><b>BANK/BRANCH</b></td>
					        					<td><?php echo $row->bankName."(".$row->branchName.")"; ?></td>
					        				</tr>
					        				<tr>
					        					<td><b>RECEIPT AMOUNT</b></td>
					        					<td><?php echo $row->paid_amt; ?></td>
					        					<td><b>RECEIPT BY</b></td>
					        					<td><?php echo $row->submitby; ?></td>
					        					<td><b>DATE OF RECEIPT</b></td>
					        					<td><?php echo $row->doe; ?></td>
					        				</tr>
					        				<!--<tr>
					        					<td></td>
					        				</tr>-->
					        			</tbody>
					        		</table>
					        	</div>
					        	<form action="<?php echo base_url(); ?>AcountsManage_Controller/savebankinfo" method="post">
					        	<div class="col-md-12">
					        		 <h3><b>Payment Confirmation</b></h3>
					        	</div>
					        	<div class="col-md-12">
					        		<div class="form-group">
					        		<div class="col-md-3"><b>Bank Name:</b></div>
					        		<div class="col-md-3">
					        			<select onchange="getbranch(this.id)" id="bankname_<?php echo $sl; ?>" required="required" class="form-control">
					        				<option value="">--select--</option>
					        				<?php if(isset($bankinfo) && !empty($bankinfo))
											{
												foreach($bankinfo as $row2)
												{
													echo '<option value="'.$row2->id.'">'.$row2->bankname.'</option>';
												}
												
												
											} ?>
					        				
					        			
					        			</select>
					        		</div>
					        		<div class="col-md-3"><b>Branch Name:</b></div>
					        		<div class="col-md-3">
					        			<input type="text" name="branchname" id="branch_<?php echo $sl; ?>" readonly class="form-control" />
					        		</div>
					        		</div>
					        	</div>
					        	<div class="col-md-12">
					        		<div class="form-group">
					        		<div class="col-md-3"><b>Account No:</b></div>
					        		<div class="col-md-3">
					        			<input type="text" name="accno" id="accno_<?php echo $sl; ?>" readonly class="form-control" />
					        			<input type="hidden" name="txnid"  value="<?php echo $row->id; ?>"/>
					        			<input type="hidden" name="payamnttyp" value="<?php echo $row->type; ?>" />
					        			<input type="hidden" name="chqno" value="<?php echo $row->cheque_no; ?>" />
					        			<input type="hidden" name="purpose" value="<?php echo $row->purpose; ?>"/>
					        			<input type="hidden" name="custid" value="<?php echo $row->clientID; ?>"/>
					        			<!--<input type="hidden" name="payamnttyp" />
					        			<input type="hidden" name="payamnttyp" />
					        			<input type="hidden" name="payamnttyp" />
					        			
					        			<input type="hidden" name="payamnttyp" />-->
					        		</div>
					        		<div class="col-md-3"><b>Deposit Amount:</b></div>
					        		<div class="col-md-3">
					        			<input type="text" name="payamnt" value="<?php echo $row->paid_amt; ?>" class="form-control" />
					        		</div>
					        		</div>
					        	</div>
					        	<div class="col-md-12">
					        		<div class="col-md-3"><b>Account Name:</b></div>
					        		<div class="col-md-3"><input type="text" name="accame" id="accname_<?php echo $sl; ?>" class="form-control" readonly/></div>
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        		
					        	</div>
					        	<div class="col-md-12">
					        		<div class="form-group">
					        		<div class="col-md-3"><b>Clg./Dpst Date:</b></div>
					        		<div class="col-md-3"><input type="text" name="dte" id="datepicker_<?php echo $sl; ?>" class="form-control"  /></div>
					        		<div class="col-md-3"><b>Deposit By:</b></div>
					        		<div class="col-md-3"><input type="text" name="depositby" class="form-control" /></div>
					        		</div>
					        	</div>
					        	<div class="col-md-12">
					        		<div class="col-md-2">
					        		 <b> Remark:</b>
					        		</div>
					        		<div class="col-md-10">
					        		     <div class="form-group">
					        			<textarea  cols="50" rows="3" placeholder="remark" class="form-control"></textarea>
					        		</div>
					        		</div>
					        	</div>
					        	<!--<div class="col-md-12">
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        	</div>
					        	<div class="col-md-12">
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        		<div class="col-md-3"></div>
					        	</div>
					        	<div class="col-md-12">
					        		
					        	</div>-->
					        	
					        </div>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					        <button type="submit" class="btn btn-primary">Save changes</button>
					      </div>
					      </form>
					    </div>
					  </div>
					</div>
					
                	
                	<!--
                		---------------------------------------------------------------------------------------------------
                	                            Modal    
                	    --------------------------------------------------------------------------------------------------->
                	
                	
                	&nbsp;<button type="button"  class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-thumbs-down" aria-hidden="true"></i></button></td>
                
            </tr>
            <?php $sl++; } } ?>
        </tbody>
    </table>
				</div>
				
            <input type="hidden" name="totrow" id="totrow" value="<?php echo $sl; ?>"/>
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
 <script>
 	function getbranch(id)
 	{
 		var idsplit=id.split("_");
 		var bankname=$("#bankname_"+idsplit[1]).val();
 		//alert()
 		if(bankname==""){
 			 $("#branch_"+idsplit[1]).val("");
  				$("#accno_"+idsplit[1]).val("");
  				$("#accname_"+idsplit[1]).val("");
 		
          }else
          {
          	  $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getbanifo",
  			data :{'bankname':bankname},
  			success : function(data){
  				//console.log(data);
  				 	var json=JSON.parse(data);
  				 	var accname=json.accname;
  				 	var branch=json.branch;
  				 	var acno=json.accno	;		 
  				//alert(data);
  				//$("#prts").html(data);
  				$("#branch_"+idsplit[1]).val(branch);
  				$("#accno_"+idsplit[1]).val(acno);
  				$("#accname_"+idsplit[1]).val(accname);
  				
  			  
              }  
           }); 
          }
 	}
 </script>
 <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  
 <script>
  $(document).ready(function(){
  	var totrw=parseInt($("#totrow").val());
  	for(var k=1;k<totrw;k++)
  	{
  		$("#datepicker_"+k).datepicker({dateFormat:'yy-mm-dd'})
  	}
  	
    //$("#datepicker").datepicker({dateFormat:'yy-mm-dd'});
    
  });
  
  </script>
