<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php //include("connection.php"); ?>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
		<section>
			<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">PURCHASE PRICE  LIST</li>
				</ol>

			</div>
			<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
						 <div class="alert alert-danger alert-dismissible">
					           <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
					                <?php echo $this->session->flashdata('message'); ?>
						   </div>
		            <?php }?>
		       <div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">PURCHASE PRICE</a></li>
																
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								
								<div class="col-md-12">
							    <div class="card">
							    	<form action="<?php echo base_url();  ?>AcountsManage_Controller/getallsparepartspurchsaeprice" method="post">
									<div class="card-head style-primary">
										<header>Select  Model</header>
									</div>
									<div class="card-body floating-label">
										
										<div class="col-md-3">
											<div class="form-group">
												
												<select class="form-control select2-list" data-placeholder="Select an item" name="mName"  required >
													<?php if(isset($modelname) && !empty($modelname)){ ?>
														<option value="<?php echo $modelname;  ?>" selected><?php echo $modelname;  ?></option>
														<option value="">--select Model---</option>
														<?php   if(isset($model) && !empty($model)){ ?><?php    foreach($model as $row) {   ?><option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option><?php  		} }?> ?>
														
												<?php	}else{ ?>
														
													
													<option value="">--select Model---</option>
													<?php if(isset($model) && !empty($model)){ ?><?php    foreach($model as $row) {   ?><option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option><?php  		} }?>											
												<?php 	} ?>
												</select>
												<!--<input type="text" class="form-control" id="brand" name="brand">-->
												
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<div class="card-actionbar">
													<div class="card-actionbar-row">
														<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
													</div>
												</div>
											</div>
										</div>
					              	</div><!--end .section-body -->
					              	 </form>
					             </div>
					            </div>
					           
	<!--                              all spareparts list                              -->
					            <?php if(isset($partsprice) && !empty($partsprice)){ $sl=1; ?>
					            <div class="col-md-12">
							    <div class="card">
									<div class="card-head style-primary">
										<header>Sparepats Prchase Price Details for <?php  echo $modelname ;  ?></header>
									</div>
									<div class="card-body floating-label">
										<div class="col-md-12">
											 <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
											<form action="<?php echo base_url(); ?>StockManage_controller/savestocknorml" method="POST">
											<div class="form-group" style="overflow-y: scroll;">
												<table class="table table-hover table-bordered" id="example1">
													<thead>
														<tr>
															<th>Sl No.</th>
															<th>Model</th>
															<th>Parts name</th>
															<th>Parts Code</th>
															<th>Seller Price</th>
														<!--	<th>Tax</th>-->
															<th>Tax</th>
															<th>Others Expenc</th>
															<th>Purchase Price</th>
															
															<th>Po No/Invoice No</th>
															<th>Last Update On</th>
															<th>Created by</th>
														 </tr>
														
													</thead>
													<tbody>
														<?php foreach($partsprice as $row){
																		
																	$taxinfo=$row->taxinfo;
																	if(!empty($taxinfo)){
																		$taxinfoexplode=explode(",",$taxinfo);
																	}else{
																		$taxinfo="";
																	}
																	
																
															 ?>
														<tr>
															<td><?php echo $sl; ?></td>
															<td><?php echo $row->mName; ?></td>
															<td><?php echo $row->materialname; ?></td>
															<td><?php echo $row->materiel_id; ?></td>
															<td><?php echo $row->sellerpr; ?></td>
															<!--<td><?php 
																	if(isset($taxinfo) && !empty($taxinfo))
																	{
																		foreach($taxinfoexplode as $rowtx)
																		{
																			$rowtxex=explode(";",$rowtx);
																			echo $rowtxtit=$rowtxex[0];
																			echo "<br>";
																		}
																		
																	}else{
																		echo $taxinfo;
																		
																	}
															
															
															
															 ?></td> -->
															<td><?php echo $row->tax; ?></td>
															<td><?php echo $row->others; ?></td>
															<td><?php echo $row->buypr; ?></td>
															<td><?php echo $row->pono; ?></td>
															<td><?php echo $row->purchseupdte; ?></td>
															
															
															<td><?php echo $row->purchsecrtd; ?></td>
														</tr>
														
												<?php $sl++; }   ?>
													</tbody>
													
												</table>
												</div>
												
											</form>
											</div>
											
										</div>
					              	</div><!--end .section-body -->
					             </div>
					            </div>
					            <?php  } ?>
	<!----                end of card                                            -->
					          </div>
					         </div>
					        </div>
					      </div>
					    </div>
	        </section>
		</div><!--end #content-->
		</div>		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function getexceldata(){
		//alert('hello');
      $("#example1").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function closetock(id)
  {
  	
  }
  function savespecificationwisestock(id)
  {
  	var idsplit=id.split("_");
  	
  	//----get openning stock
  	  	var openstockoverall=$("#openstockoverall_"+idsplit[1]).val();
	  	//if(openstockoverall=="")
	  	if(openstockoverall=="" || isNaN(openstockoverall))
	  	{
	  		openstockoverall=0;
	  	}
	 //-----  get change stock
		//var chnstock=$("#changestockoverall_"+idsplit[1]).val();
	  	// if(chnstock=="" || isNaN(chnstock))
	  	// {
	  	 	chnstock=0;
	  	// }  
  	//
  	var sperow=parseInt($("#sperow_"+idsplit[1]).val());
  	var newst=0;
  	for(var k=1;k<sperow;k++)
  	{
  		var curntstock=$("#specf_"+idsplit[1]+"_"+k).val();
  		//console.log(curntstock);
  		//----getcurrentstock in specif
  		if(curntstock=="" || isNaN(curntstock))
	  	{
	  		curntstock=0;
	  	}
	  	newst=parseInt(newst)+parseInt(curntstock);
	  	// console.log(newst);
  		
  	}
  	      chnstock=parseInt(chnstock)+parseInt(newst);
  	      // console.log(chnstock);
	  	  $("#changestockoverall_"+idsplit[1]).val(chnstock);
	  	  var closestockoverall=parseInt(openstockoverall)+parseInt(chnstock);
  	  //console.log(closestockoverall);
  	      $("#closestockoverall_"+idsplit[1]).val(closestockoverall);
  
  }
  function currentstockdt(id)
  {
  	 var idsplit=id.split("_");
  	    var openstockoverall=$("#openstockoverall_"+idsplit[1]).val();
	  	//if(openstockoverall=="")
	  	if(openstockoverall=="" || isNaN(openstockoverall))
	  	{
	  		openstockoverall=0;
	  	}
	  	var curntstock=$("#currentwrehouse_"+idsplit[1]).val();
	  	if(curntstock=="" || isNaN(curntstock))
	  	{
	  		curntstock=0;
	  	}
	  	var chnstock=parseInt(curntstock);
	  	$("#changestockoverall_"+idsplit[1]).val(curntstock);
	  	 var closestockoverall=parseInt(openstockoverall)+parseInt(chnstock);
  	  //console.log(closestockoverall);
  	      $("#closestockoverall_"+idsplit[1]).val(closestockoverall);
  	 
  }
  
</script>
<script src="<?php echo base_url(); ?>assets/js/src/jquery.table2excel.js"></script>
 
