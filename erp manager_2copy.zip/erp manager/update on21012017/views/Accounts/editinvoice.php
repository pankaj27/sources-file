<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php  include('connection.php'); ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>


	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"> Edit Invoice Information </li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
  <?php if(isset($getallinvoiceinfo) && !empty($getallinvoiceinfo)){
  	
	foreach($getallinvoiceinfo as $rowinv)
	{
		$invoice=$rowinv->invoiceno;
		$orderno=$rowinv->orderno;
		$orderdte=$rowinv->orderdate;
		$custtyp=$rowinv->custtyp;
		$custid=$rowinv->custid;
		$cusname=$rowinv->custname;
		$custadd=$rowinv->custadd;
		$custvat=$rowinv->custvat;
		$custtin=$rowinv->custtin;
		$consigname=$rowinv->consigname;
		$consigneeadd=$rowinv->consigneeadd;
		$consigneevat=$rowinv->consigneevat;
		$consigneetin=$rowinv->consigneetin;
		$dateofremo=$rowinv->dateofremo;
		$batteryinfo=$rowinv->batteryno;
		$charger=$rowinv->chargerno;
		$transportmanner=$rowinv->transportmanner;
		$transportname=$rowinv->transportname;
		$vehicleno=$rowinv->vehicleno;
		$transporteraddress=$rowinv->transporteraddress;
		$serialno=$rowinv->serialno;
		$prglrno=$rowinv->prglrno;
		$despt=$rowinv->despt;
		$particulars=$rowinv->particulars;
		$drivername=$rowinv->drivername;
		$drivercontact=$rowinv->drivercontact;
		$despatched=$rowinv->despatched;
		
		
	}
	$prtexplode=explode("(",$particulars);
	$product=$prtexplode[0];
	echo $partsn=$prtexplode[1];
	 $prt=rtrim($partsn,")");
	
	
	
  } ?>
			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Edit Invoice</a></li>
								<!--<li><a href="#second">Edit/View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
							<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/updateinvoiceinfo" method="post" >
					<div class="card">
							<div class="card-head style-primary">
								<header>INVOICE INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="invoicno" class="form-control"  id="invoiceno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($invoice) && !empty($invoice)){ echo $invoice; } ?>" readonly />
												<label for="mName">Invoice No</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderno" class="form-control"  id="orderno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($orderno) && !empty($orderno)){ echo $orderno; } ?>" onblur="getorderdate();" />
												<label for="mName">Order No</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderdate" class="form-control"  id="orderdate" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($orderdte) && !empty($orderdte)){ echo $orderdte; } ?>" />
												<label for="mName">Order Date</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<!--<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>-->
											</div>
										</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>CUSTOMER  & CONSIGNEE INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" name="custdet" class="form-control"  id="custinfo" placeholder="" style="text-transform: uppercase;" onblur="custdetails()" value="<?php if(isset($custid) && !empty($custid)){echo $custid; } ?>"/>
											<label for="mName">Search Customer ID/Name/Company</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="custid" id="custid" value="<?php if(isset($custid) && !empty($custid)){ echo $custid; } ?>" readonly/>
												<input type="hidden" name="custcomp" id="custcomp" value=""/>
												<!--<input type="hidden" name="add1" id="add1"/>
												<input type="hidden" name="add2" id="add2">
												<input type="hidden" name="add3" id="add3"/>
												<input type="hidden" name="pin" id="pin"/>-->
												<label for="mName"> Customer ID</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custaddress" class="form-control"  id="custaddress" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($custadd) && !empty($custadd)){ echo $custadd ; } ?>" />
												<label for="mName">Enter Customer Address</label>
											</div>
										</div>
										<!--<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custbalance" class="form-control"  id="custbalance" placeholder="" style="text-transform: uppercase;" value="" />
												<label for="mName">Accounts Balance</label>
											</div>
										</div>-->
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custtyp" class="form-control"  id="custtyp" placeholder="" style="text-transform: uppercase;" readonly value="<?php if(isset($custtyp) && !empty($custtyp)){ echo $custtyp;} ?>" />
												<label for="mName">Customer Type</label>
											</div>
										</div>
										
									</div>
								</div>
								<div class="row"><hr></div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="custvat" class="form-control"  id="custvat" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($custvat) && !empty($custvat)){ echo $custvat; } ?>" />
												<label for="mName">Customer VAT No</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="custtin" class="form-control"  id="custtin" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($custtin) && !empty($custtin)){ echo $custtin; } ?>" />
												<label for="mName"> Customer TIN No</label>
											</div>
										</div>
										<!--<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custbalance" class="form-control"  id="custbalance" placeholder="" />
												<label for="mName">Accounts Balance</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>
											</div>
										</div>-->
										
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" id="sameasc" onclick="checksameasaddress()"><span><b>Same as Customer</b></span>
												</label>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneename" class="form-control"  id="consigneename" placeholder="Enter Consignee Name" value="<?php if(isset($consigname) && !empty($consigname)){ echo $consigname; } ?>" />
												
												<!--<input type="hidden" name="consigneecom" id="consigneecom" value=""/>
												<input type="hidden" name="consigneeadd1" id="consigneeadd1"/>
												<input type="hidden" name="consineeadd2" id="consineeadd2">
												<input type="hidden" name="consigneeadd3" id="consigneeadd3"/>
												<input type="hidden" name="consihgneepin" id="consihgneepin"/>-->
												
												<!--<label for="mName">Enter Consignee Name </label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneeadd" class="form-control"  id="consigneeadd" placeholder="Enter Consignee  Address" style="text-transform: uppercase;" value="<?php if(isset($consigneeadd) && !empty($consigneeadd)){ echo $consigneeadd; } ?>" />
												<!--<label for="mName">Enter Consignee  Address</label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneevat" class="form-control"  id="consigneevat" placeholder="Consignee VAT No" style="text-transform: uppercase;" value="<?php if(isset($consigneevat) && !empty($consigneevat)){ echo $consigneevat; } ?>" />
												<!--<label for="mName">Consignee VAT No</label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneetin" class="form-control"  id="consigneetin" placeholder="Consignee TIN No" style="text-transform: uppercase;"  value="<?php if(isset($consigneetin) && !empty($consigneetin)){ echo $consigneetin; } ?>" />
												<!--<label for="mName">Consignee TIN No</label>-->
											</div>
										</div>
										
									</div>
								</div>
								
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>ORDER DETAILS</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<select id="cattyp" class="form-control select2-list" name="cattyp"  required onchange="gettypedetails()" >
													<?php  if(isset($product)=="E-RIckshaw")
													{ ?>
														<option value="product" selected>Model</option>
														<option value="0">-select -</option>
													<option value="product">Model</option>
													<option value="parts">Spare Parts</option>
													<?php }else if(isset($product)=="Spareparts")
													{ ?>
														<option value="parts" selected >Spare Parts</option>
														<option value="0">-select -</option>
													<option value="product">Model</option>
													<option value="parts">Spare Parts</option>
													
														
												<?php 	}else{ ?>
														<option value="0"></option>
													<option value="product">Model</option>
													<option value="parts">Spare Parts</option>
														
														
												<?php  	} ?>
													
												</select>
										       <label for="mName"> Select Product Type</label>
											</div>
										</div>
										<div class="col-md-16">
										
										<div class="col-md-6">
											
												
										
											<div class="form-group" id="modeldetails">
												  <?php if(isset($models) && !empty($models)){ ?>
												 <?php  
												 		echo '<select id="mname" class="form-control select2-list"  name="mName"  required onchange="getmodeltypebyparts()" >';
														echo '<option value="'.$prt.'" selected>'.$prt.'</option>';
														echo '<option value="0">--select--</option>';
														$i=1;
														foreach($models as $row)
														{
															
																echo '<option value="'.$row->productname.'">'.$row->productname.'</option>';
																								
														$i++;	
														}
													echo '</select>';
													echo '<label for="mName">Select Model</label>';
												 
												 
												 
												 ?>
										<?php	} ?>
											</div>
											
										</div>
									</div>
									</div>
								</div>
<!--###########################################################################  Model details  Information   --->
								<div class="row" id="model_details">
									<div class="col-md-12">
											 <div class="form-group">
											 <div class="checkbox checkbox-inline checkbox-styled">
											 	
													<label class="checkbox-inline checkbox-styled checkbox-primary">
														<input type="checkbox" name="erick" value="" checked><span><b>E- Rickshaw</b></span>
													</label>
											  </div>
											  <div class="checkbox checkbox-inline checkbox-styled">
													<label class="checkbox-inline checkbox-styled checkbox-primary">
														<input type="checkbox" id="battery" name="battery" value="" <?php if(isset($batteryinfo) && strlen($batteryinfo)>4){  echo "checked"; } ?>><span><b>Battery</b></span>
													</label>
											  </div>
											  <div class="checkbox checkbox-inline checkbox-styled">
													<label class="checkbox-inline checkbox-styled checkbox-primary">
														<input type="checkbox" id="charger" name="charger" value="" <?php if(isset($charger) &&  !empty($charger)){  echo "checked"; } ?>><span><b>Charger</b></span>
													</label>
											  </div>
										</div>
										</div>
										<div class="col-md-12">
											<div class="col-md-6">
												<div class="form-group">
													 <input type="text" name="reqty" class="form-control"  id="reqty" placeholder=""  onblur="getallchassisinfo();"/>
													 <label for="mName">Enter Required Qty</label>
												</div>
											</div>
										</div>
								</div>
								<hr>
								<div class="row" id="getchassisin">
									 <table class="table table-bordered table-hover">
									 	<thead>
									 		<tr>
									 			<th>Sl No</th>
									 			<th>Particulars</th>
									 			<th>Chassis No</th>
									 			<th>Motor No</th>
									 			<th>Charger No </th>
									 			<th>Battery No</th>
									 			<th>Qty</th>
									 			<th>Unit Price</th>
									 			<th>Total</th>
									 			<th>Action</th>
									 		</tr>
									 	</thead>
									 	<tbody>
									 		<?php  
									 		if(isset($getallinvoiceinfo) && !empty($getallinvoiceinfo)){
  												$sl=1;
												foreach($getallinvoiceinfo as $row)
												{
					?>				 		<tr>
									 			<td><?php echo $sl; ?></td>
									 			<td><?php echo $row->particulars; ?></td>
									 			<td><input type="text" style="border: none;" name="chassisno_<?php echo $sl; ?>" value="<?php echo $row->chasisno; ?>"/></td>
									 			<td><input type="text"  style="border: none;" name="chassisno_<?php echo $sl; ?>" value="<?php echo $row->motorno; ?>"/></td>
									 			<td><input type="text" style="border: none;" name="chassisno_<?php echo $sl; ?>" value="<?php echo $row->chargerno; ?>"/></td>
									 			<td><input type="text" style="border: none;" name="chassisno_<?php echo $sl; ?>" value="<?php echo $row->batteryno; ?>"/></td>
									 			<td><input type="text" style="border: none;" name="chassisno_<?php echo $sl; ?>" value="<?php echo $row->qty; ?>" readonly/></td>
									 			<td><?php echo $row->unitprice; ?></td>
									 			<td><?php echo $row->total; ?></td>
									 			<td></td>
									 		</tr>
									 		
									 		<?php  $sl++; }} ?>
									 	</tbody>
									 	
									 </table>
								</div>
							</div>
						</div>
						
							
				 </form>	
    						
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
<!--########################################################################################################################-->
<!--  -                                        Second Tab  -->
<!-- #############################################################################################################-->
					
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
 
<script>
	function gettypedetails()
	{
		var cattyp=$("#cattyp").val(); 
	//alert(cattyp);
	//console.log(cattyp);
	if(cattyp=="0")
	{
		//$("#model").show();
  	    //$("#model").html(data);
  	    $("#modeldetails").remove();
  	    
	}else
	{
		//$("#model").hide();
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodellistbyparts",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					//$("#model").show();
  				  $("#modeldetails").html(data);
              }  
       });
		
		//if(cattyp=="parts")
		//{
			
		//}else
		//{
			
		//}
	}
	}
	function getmodeltypebyparts()
    {
	var type1=$("#mname").val();
	var custype=$("#custtype").val();
	//var custype="CNF";
	//alert(type1);
	//var typesplit=type1.split("_");
	//var type=typesplit[0];
	//var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodelprice",
  			data :{'type':type1,'custype':custype},
  			success : function(data){
  					
  				  //$("#modalparts_"+id).modal('show');
  				  $("#model_details").html(data);
              }  
       });
	
	
}
function getallchassisinfo()
{
	var reqty=parseInt($("#reqty").val());
	//alert(reqty);
	if($('#battery').is(':checked'))
	{
		var battery=parseFloat($("#battery").val());
	}else
	{
		var battery=999999;
	}
	if($('#charger').is(':checked'))
	{
		var charger=parseFloat($("#charger").val());
	}else
	{
		var charger=999999;
	}
	//alert(battery);
	//alert(charger);
	//var battery=$().val()
	if(reqty=="" || isNaN(reqty))
	{
		$("#getchassisin").remove();
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getchassisdetails",
  			data :{'reqty':reqty,'battery':battery,'charger':charger},
  			success : function(data){
  					//alert(data);
  					console.log(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#getchassisin").html(data);
              }  
       });
	}
}
function checksameasaddress()
{
	if($("#sameasc").is(':checked'))
	{
		//alert('checked');
		var custdet=$("#custinfo").val();
		var custadd=$("#custaddress").val();
		var custvat=$("#custvat").val();
		var custtin=$("#custtin").val();
		//consignee details
		$("#consigneename").val(custdet);
		$("#consigneeadd").val(custadd);
		$("#consigneevat").val(custvat);
		$("#consigneetin").val(custtin);
		
	}else
	{
		alert('notchecked');
		$("#consigneename").val("");
		$("#consigneeadd").val("");
		$("#consigneevat").val("");
		$("#consigneetin").val("");
	}
}
function getorderdate()
{
	var orderno=$("#orderno").val();
	alert(orderno);
	if(isNaN(orderno) && orderno=="" )
	{
		 $("#orderdate").val("");
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getorderdate",
  			data :{'orderno':orderno},
  			success : function(data){
  					alert(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#orderdate").val(data);
              }  
       });
	}
	
}
function custdetails()
{
	//console.log("hello");
	var custinfo=$("#custinfo").val();
	if(custinfo=="")
	{
		
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getcustinformation",
  			data :{'custinfo':custinfo},
  			success : function(data){
  				
  					console.log(data);
  					//var custcomp=
  					var json=JSON.parse(data);
  					var comp=json.compname;
  					var name=json.name;
  					var clientid=json.clientid;
  					var type=json.type;
  					var address=json.address;
  					var balance=json.balance;
  					var tinvat=json.tinvat;
  					var cst=json.cst;
  				  //$("#modalparts_"+id).modal('show');
  				 // $("#orderdate").val(data);
  				 $("#custid").val(clientid);
  				 $("#custcomp").val(comp);
  				 $("#custaddress").val(address);
  				 $("#custbalance").val(balance);
  				 $("#custtyp").val(type);
  				 $("#custvat").val(tinvat);
  				 $("#custtin").val(cst);
  				 //$().val();
  				 
  				// $().val();
              }  
       });
	}
}

</script>
