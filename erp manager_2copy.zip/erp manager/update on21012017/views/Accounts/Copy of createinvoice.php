<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php  include('connection.php'); ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>


	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"> Invoice Information </li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create Invoice</a></li>
								<li><a href="#second">Edit/View</a></li>
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
							<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/saveinvoicetemp" method="post" >
					<div class="card">
							<div class="card-head style-primary">
								<header>INVOICE INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="invoicno" class="form-control"  id="invoiceno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($invoice) && !empty($invoice)){ echo $invoice; } ?>" readonly />
												<label for="mName">Invoice No</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderno" class="form-control"  id="orderno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($booking) && !empty($booking)){ echo $booking; } ?>" onblur="getorderdate();" />
												<label for="mName">Order No</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderdate" class="form-control"  id="orderdate" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">Order Date</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<!--<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>-->
											</div>
										</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>CUSTOMER  & CONSIGNEE INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" name="custdet" class="form-control"  id="custinfo" placeholder="" style="text-transform: uppercase;" onblur="custdetails()"/>
											<label for="mName">Search Customer ID/Name/Company</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="custid" id="custid" value="" readonly/>
												<input type="hidden" name="custcomp" id="custcomp" value=""/>
												<!--<input type="hidden" name="add1" id="add1"/>
												<input type="hidden" name="add2" id="add2">
												<input type="hidden" name="add3" id="add3"/>
												<input type="hidden" name="pin" id="pin"/>-->
												<label for="mName"> Customer ID</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custaddress" class="form-control"  id="custaddress" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">Enter Customer Address</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custbalance" class="form-control"  id="custbalance" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">Accounts Balance</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custtyp" class="form-control"  id="custtyp" placeholder="" style="text-transform: uppercase;" readonly />
												<label for="mName">Customer Type</label>
											</div>
										</div>
										
									</div>
								</div>
								<div class="row"><hr></div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="custvat" class="form-control"  id="custvat" placeholder="" style="text-transform: uppercase;" />
												<label for="mName">Customer VAT No</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="custtin" class="form-control"  id="custtin" placeholder="" style="text-transform: uppercase;" />
												<label for="mName"> Customer TIN No</label>
											</div>
										</div>
										<!--<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custbalance" class="form-control"  id="custbalance" placeholder="" />
												<label for="mName">Accounts Balance</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>
											</div>
										</div>-->
										
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" id="sameasc" onclick="checksameasaddress()"><span><b>Same as Customer</b></span>
												</label>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneename" class="form-control"  id="consigneename" placeholder="Enter Consignee Name" />
												
												<!--<input type="hidden" name="consigneecom" id="consigneecom" value=""/>
												<input type="hidden" name="consigneeadd1" id="consigneeadd1"/>
												<input type="hidden" name="consineeadd2" id="consineeadd2">
												<input type="hidden" name="consigneeadd3" id="consigneeadd3"/>
												<input type="hidden" name="consihgneepin" id="consihgneepin"/>-->
												
												<!--<label for="mName">Enter Consignee Name </label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneeadd" class="form-control"  id="consigneeadd" placeholder="Enter Consignee  Address" style="text-transform: uppercase;" />
												<!--<label for="mName">Enter Consignee  Address</label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneevat" class="form-control"  id="consigneevat" placeholder="Consignee VAT No" style="text-transform: uppercase;" />
												<!--<label for="mName">Consignee VAT No</label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneetin" class="form-control"  id="consigneetin" placeholder="Consignee TIN No" style="text-transform: uppercase;" />
												<!--<label for="mName">Consignee TIN No</label>-->
											</div>
										</div>
										
									</div>
								</div>
								
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>ORDER DETAILS</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<select id="cattyp" class="form-control select2-list" name="cattyp"  required onchange="gettypedetails()" >
													<option value="0"></option>
													<option value="product">Model</option>
													<option value="parts">Spare Parts</option>
												</select>
										       <label for="mName"> Select Product Type</label>
											</div>
										</div>
										<div class="col-md-16">
										
										<div class="col-md-6">
											<div class="form-group" id="modeldetails">
												
											</div>
										</div>
									</div>
									</div>
								</div>
<!--###########################################################################  Model details  Information   --->
								<div class="row" id="model_details">
									 
								</div>
								<hr>
								<div class="row" id="getchassisin">
									 
								</div>
							</div>
						</div>
						
							
				 </form>	
    						
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
<!--########################################################################################################################-->
<!--  -                                        Second Tab  -->
<!-- #############################################################################################################-->
					<div class="tab-pane" id="second">
						<div class="col-md-12">
				
					<div class="card">
							<div class="card-head style-primary">
								<header>View All Invoice</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<table class="table table-bordered table-hover">
											<thead>
												<tr>
													<th>Sl No</th>
													<th>Invoice No</th>
													<th>Company Name/Customer </th>
													<th>Order No</th>
													
													<th>Particulars</th>
													<th>Total</th>
													<th>Doe</th>
													<th>Ordr Date</th>
													<th>Action</th>
													
												</tr>
											</thead>
											<tbody>
												<?php if(isset($allinvoice) && !empty($allinvoice)){$in=1; $invoicen=""; ?>
													<?php foreach($allinvoice as $rowinvoice){
														$invoicen1=$rowinvoice->invoiceno;
														if($invoicen1!=$invoicen){
														$custname=$rowinvoice->custname;
														$custtype=$rowinvoice->custtyp;
														if(strtoupper($custtype)!="RETAILER")
														{
															$getqr=mysqli_query($con,"select * from clientmaster where 	ucase(clientid)='".trim(strtoupper($custname))."'");
															$getro=mysqli_fetch_array($getqr);
															$custname=$getro['compname'];
														}else
														{
															$custname=$custname;
														}
													?>
												<tr>
													<td><?php echo $in; ?></td>
													<td><?php echo $rowinvoice->invoiceno; ?></td>
													<td><?php echo $custname;   ?></td>
													<td><?php echo $rowinvoice->orderno; ?></td>
													<td><?php echo $rowinvoice->particulars; ?></td>
													<td><?php echo $rowinvoice->gtotal; ?></td>
													<td><?php echo $rowinvoice->doe; ?></td>
													<td><?php echo $rowinvoice->orderdate; ?></td>
													<td><a href="<?php echo base_url(); ?>AcountsManage_Controller/editinvoice/<?php echo $rowinvoice->invoiceno; ?>"><button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a> &nbsp;&nbsp;
														<a href="<?php echo base_url(); ?>AcountsManage_Controller/print_invoice2/<?php echo $rowinvoice->invoiceno; ?>"><button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-print" aria-hidden="true"></i></button>
															
														</a>
														</td>
												</tr>
												<?php $in++; $invoicen=$invoicen1; } } } ?>
											</tbody>
											
										</table>
									</div>
								</div>
							</div>
						</div>
						
						
						
							
				
    						
						</div><!--end .card-body -->
					</div>
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
 
<script>
	function gettypedetails()
	{
		var cattyp=$("#cattyp").val(); 
	//alert(cattyp);
	//console.log(cattyp);
	if(cattyp=="0")
	{
		//$("#model").show();
  	    //$("#model").html(data);
  	    $("#modeldetails").remove();
  	    
	}else
	{
		//$("#model").hide();
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodellistbyparts",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					//$("#model").show();
  				  $("#modeldetails").html(data);
              }  
       });
		
		//if(cattyp=="parts")
		//{
			
		//}else
		//{
			
		//}
	}
	}
	function getmodeltypebyparts()
    {
	var type1=$("#mname").val();
	var custype=$("#custtype").val();
	//var custype="CNF";
	//alert(type1);
	//var typesplit=type1.split("_");
	//var type=typesplit[0];
	//var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodelprice",
  			data :{'type':type1,'custype':custype},
  			success : function(data){
  					
  				  //$("#modalparts_"+id).modal('show');
  				  $("#model_details").html(data);
              }  
       });
	
	
}
function getallchassisinfo()
{
	var reqty=parseInt($("#reqty").val());
	//alert(reqty);
	if($('#battery').is(':checked'))
	{
		var battery=parseFloat($("#battery").val());
	}else
	{
		var battery=999999;
	}
	if($('#charger').is(':checked'))
	{
		var charger=parseFloat($("#charger").val());
	}else
	{
		var charger=999999;
	}
	//alert(battery);
	//alert(charger);
	//var battery=$().val()
	if(reqty=="" || isNaN(reqty))
	{
		$("#getchassisin").remove();
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getchassisdetails",
  			data :{'reqty':reqty,'battery':battery,'charger':charger},
  			success : function(data){
  					//alert(data);
  					console.log(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#getchassisin").html(data);
              }  
       });
	}
}
function checksameasaddress()
{
	if($("#sameasc").is(':checked'))
	{
		//alert('checked');
		var custdet=$("#custinfo").val();
		var custadd=$("#custaddress").val();
		var custvat=$("#custvat").val();
		var custtin=$("#custtin").val();
		//consignee details
		$("#consigneename").val(custdet);
		$("#consigneeadd").val(custadd);
		$("#consigneevat").val(custvat);
		$("#consigneetin").val(custtin);
		
	}else
	{
		alert('notchecked');
		$("#consigneename").val("");
		$("#consigneeadd").val("");
		$("#consigneevat").val("");
		$("#consigneetin").val("");
	}
}
function getorderdate()
{
	var orderno=$("#orderno").val();
	alert(orderno);
	if(isNaN(orderno) && orderno=="" )
	{
		 $("#orderdate").val("");
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getorderdate",
  			data :{'orderno':orderno},
  			success : function(data){
  					alert(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#orderdate").val(data);
              }  
       });
	}
	
}
function custdetails()
{
	//console.log("hello");
	var custinfo=$("#custinfo").val();
	if(custinfo=="")
	{
		
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getcustinformation",
  			data :{'custinfo':custinfo},
  			success : function(data){
  				
  					console.log(data);
  					//var custcomp=
  					var json=JSON.parse(data);
  					var comp=json.compname;
  					var name=json.name;
  					var clientid=json.clientid;
  					var type=json.type;
  					var address=json.address;
  					var balance=json.balance;
  					var tinvat=json.tinvat;
  					var cst=json.cst;
  				  //$("#modalparts_"+id).modal('show');
  				 // $("#orderdate").val(data);
  				 $("#custid").val(clientid);
  				 $("#custcomp").val(comp);
  				 $("#custaddress").val(address);
  				 $("#custbalance").val(balance);
  				 $("#custtyp").val(type);
  				 $("#custvat").val(tinvat);
  				 $("#custtin").val(cst);
  				 //$().val();
  				 
  				// $().val();
              }  
       });
	}
}

</script>
