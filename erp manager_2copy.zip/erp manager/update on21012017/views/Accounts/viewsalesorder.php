<?php include('conection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	
<?php if(isset($custdetails) && !empty($custdetails)){
	$addre="";
	  foreach($custdetails as $rowcust)
	  {
	  	$custid=$rowcust->clientid;
		$comp=$rowcust->compname;
		$add1=$rowcust->add1;
		$add2=$rowcust->add2;
		$disti=$rowcust->district;
		$country=$rowcust->country;
		$state=$rowcust->state;
		$area=$rowcust->area;
		$pin=$rowcust->pin;
		$balance=$rowcust->balance;		
		
	  }
	  $addre=$add1." ".$add2;
	
	
} ?>

<style>
	
    .print-clean{
    	border: none;
       background: transparent;
    }
    #partstble,#partstble2{
    	width:100%;
    }
    #optr{
    	width:100%;
    }
    #partstble tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #partstble2 tr td{
    	line-height: 30px;
    	border-top: 1px solid #0aa89e;
    }
    #optr tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    .datatr tr,th,td{
    	 	border:1px solid #0aa89e;
    	    text-align: center;
    }
    .datatr1{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    #partstble3{
    	width:100%;
    }
     #partstble3 tr {
     	line-height:15px;
    	border-top: 1px solid #0aa89e;
     }
    .table12{
    	width:100%;
    	
    }
    /*.table12 tr{
    	height:6px;
    	border-bottom: 1px solid black;
    }*/
    .table12 td{
    	padding:0px;
    	margin:0px;
    	
    }
    .thred,.trhide{
    	display: none;
    }
    #ordertable {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

#ordertable th, td {
    border: none;
    text-align: left;
    padding: 8px;
}

#ordertable tr:nth-child(even){background-color: #f2f2f2}

</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			
			
	   </div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
	<!-- BEGIN BLANK SECTION -->
	<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li><a href="<?php echo base_url(); ?>">home</a></li>
												<li class="active"><?php if(isset($title)){ echo $title ; } ?></li>
						</ol>

		</div><!--end .section-header -->
		<div class="section-body">
			<div class="row">
				<div class="col-md-12">
					
					<div class="card card-bordered style-primary">
						<div class="card-head">
							
							<header><i class="fa fa-fw fa-tag"></i>View Order Details</header>
						</div><!--end .card-head -->
						<div class="card-body style-default-bright">
										 <div>
												
													<div class="card-body floating-label">
														<div class="row">
															   <form action="<?php echo base_url(); ?>AcountsManage_Controller/vieworder_details" class="form" method="POST">
																	<div class="col-md-3">
																		<div class="form-group">
																			<input type="text" class="form-control" name="orderno"  value="<?php if(isset($bkid)){ echo $bkid; } ?>" placeholder="Enter Booking ID" >
																			<label for="orderno"></label>
																		</div>
																		
																	</div>
																	<div class="col-md-1"></div>
																	<div class="col-md-2">
																		<div class="form-group">
																			<button type="submit" class="btn btn-primary" >View Order </button>
																		</div>
																		
																	</div>
																</form>
													   </div>
													   
													   <?php if(isset($orderdetals) && !empty($orderdetals)){  $i=1; ?>
													   	<hr>
													   <div class="row">
															 <div class="col-md-12">
															 	<div class="col-md-6">
															 		
															 		
															 		<div class="row">
															 		<div class="col-md-12" >
															 			<div class="col-md-3"><h4>Customer ID: </h4></div>
															 			<div class="col-md-3"><h4><?php if(isset($custid)){echo $custid; } ?></h4></div>
															 			<div class="col-md-3"><h4>Company Name: </h4></div>
															 			<div class="col-md-3"><h4><?php if(isset($comp)){ echo $comp;} ?></h4></div>
															 			
															 		</div>	
															 		</div>
															 		<div class="row">
															 		<div class="col-md-12">
															 			<div class="col-md-3"><h4>Address:</h4></div>
															 			<div class="col-md-3"><h4><?php if(isset($addre)){ echo $addre; }  ?></h4></div>
															 			<div class="col-md-3"><h4>Area: </h4></div>
															 			<div class="col-md-3"><h4><?php if(isset($area)){ echo $area; } ?></h4></div>
															 			
															 		</div>	
															 		</div>
															 		<div class="row">
															 		<div class="col-md-12">
															 			<div class="col-md-3"><h3>Current Balance:</h3></div>
															 			<div class="col-md-6"><h3><?php if(isset($balance)){ echo $balance; } ?></h3></div>
															 			
															 			
															 		</div>	
															 		</div>
															 	</div>
															 	<div class="col-md-6">
															 		<div class="row">
															 		<div class="col-md-12" >
															 			<div class="col-md-3"><h4>Booking ID </h4></div>
															 			<div class="col-md-3"><h4><?php if(isset($bkid)){echo $bkid; } ?></h4></div>
															 			<div class="col-md-3"><h4>Booking Date </h4></div>
															 			<div class="col-md-3"><h4><?php if(isset($bkdt)){ echo $bkdt;} ?></h4></div>
															 			
															 		</div>	
															 		</div>
															 	</div>
															 </div>  
													   </div>
													   <div class="row">
															 <div class="col-md-12">
															 	<table id="ordertable">
															 		<tr style="background-color: #0aa89e;color:white;">
															 			<th>Sl No.</th>
															 			<th>Particulars</th>
															 			<th>Qty(Pcs)</th>
															 			<th>Rate(INR)</th>
															 			<th style="text-align: right;">Value(INR)</th>
															 			<th style="text-align: right;">Action</th>
															 		</tr>
															 		<?php foreach($orderdetals as $roworder){ ?>
															 		<tr>
															 			<td><?php echo $i; ?></td>
															 			<td><?php echo $roworder->particulars." (".strtolower($roworder->cate).")"; ?><br>
															 				<?php $color=$roworder->color; ?>
															 				<?php if(isset($color) && !empty($color)){
															 					$colorex=explode("#",$color);
																				$colorcount=(count($colorex)-1);
																				for($c=0;$c<$colorcount;$c++)
																				{
																					
																					$colorcode=explode("->",$colorex[$c]);
																					$cval=$colorcode[0];
																					$cod=$colorcode[1];
																					$querycolor=mysqli_query($con,"select * from color_code where id='".trim($cod)."'");
																					$res=mysqli_fetch_array($querycolor);	
																					$gethex=$res['code_hex'];
																					$cnam=$res['color_name'];
																					echo '<input title="'.$cnam.'" type="text" style="width:15px; height:15px;background-color:'.$gethex.'" readonly>'.$cval." ";
																				}
															 				
																				
																				
															 				} ?>
															 			</td>
															 			<td><?php echo $roworder->qnty; ?></td>
															 			<td><?php echo $roworder->unitpr; ?></td>
															 			<td style="text-align: right;"><?php echo $roworder->total; ?></td>
															 			<td></td>
															 		</tr>
															 		<?php $i++; $cst=$roworder->tax;$taxa=$roworder->taxpercent;$taxamnt=$roworder->taxamount;$excise=$roworder->excise1;$exciseamnt=$roworder->exciseamount;$gtot=$roworder->grand; }  ?>
															 		<?php if(floatval($taxamnt)>0){ ?>
															 		<tr>
															 			<td colspan="4" style="text-align: right;"><?php echo $cst." @ ". $taxa; ?></td>
															 			<td style="text-align: right;"><?php echo $taxamnt; ?></td>
															 			<td></td>
															 			
															 		</tr>
															 		<?php } ?>
															 		<?php if(floatval($exciseamnt)>0){ ?>
															 		<tr>
															 			<td colspan="4" style="text-align: right;"><?php echo "Excise Duty  @  6.00% " ; ?></td>
															 			<td style="text-align: right;"><?php echo $exciseamnt; ?></td>
															 			<td></td>
															 			
															 		</tr>
															 		<?php } ?>
															 		<tr>
															 			<td colspan="4" style="text-align: right;"><h4>Grand Total(INR)</h4></td>
															 			<td style="text-align: right;"><?php echo number_format($gtot,2); ?></td>
															 			<td></td>
															 		</tr>
															 	</table>
															 </div>  
													   </div>
												      
														
													</div>
												
										</div>
									</div>
								<!--end .col -->
						</div>
					
						</div><!--end .card-body -->
					</div><!--end .card -->
					<div class="row">
							<div class="col-md-12">
								
								<div class="card card-bordered style-primary">
									<div class="card-head">
										
											<header><i class="fa fa-fw fa-tag"></i>Send Order to Stock</header>
									</div><!--end .card-head -->
									<div class="card-body style-default-bright">
										
														<div>
																<form action="<?php echo base_url(); ?>AcountsManage_Controller/getstockdata" class="form" method="POST">
																<div class="card-body floating-label">
																	<div class="row">
																		
																		<div class="col-md-3">
																			<div class="form-group">
																				<input type="text" class="form-control" name="orderno2" id="orderno" value="<?php if(isset($ordercodes)){ echo $ordercodes; } ?>" readonly="readonly">
																				
																				<label for="orderno"></label>
																			</div>
																			
																		</div>
																		<div class="col-md-1"></div>
																		<div class="col-md-2">
																			<div class="form-group">
																				<button type="button" class="btn btn-primary" onclick="getorderid()">New Order</button>
																				<input type="text" name="bkid1" value="<?php if(isset($bkid)){ echo $bkid; } ?>"/>
																			</div>
																			
																		</div>
																	</div>
																	<div class="row">
																		<div class="col-md-12">
																			
																			<div class="col-md-3">
																			<div class="form-group">
																				
																				<select id="model" name="model" class="form-control">
																					<option value="">&nbsp;</option>
																					<?php if(isset($model) && !empty($model)){
																						 foreach($model as $row)
																						 { ?>
																						 	<option value="<?php  echo $row->productname; ?>"><?php echo $row->productname;  ?></option>
																					<?php }
																						
																					} ?>
																				</select>
																				<label for="model">SELECT MODEL</label>
																				</div>
																			</div>
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																				
																				<select id="transfer" name="transfer" class="form-control select2-list" onchange="getsales()">
																					<option value=""></option>
																					<option value="sales">Transfer to Sales</option>
																					<option value="godown">Transfer to Godown</option>
																					<option value="manf">Transfer to Manufacturer</option>
																					
																				</select>
																				<label for="transfer">TRANSFER TYPE</label>
																				</div>
																			</div>
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																				
																				<select id="godown" name="godown" class="form-control">
																					<option value="">&nbsp;</option>
																					<?php if(isset($godown) && !empty($godown)){
																						 foreach($godown as $row)
																						 { ?>
																						 	<option value="<?php  echo $row->gdowncode; ?>"><?php echo $row->gdname;  ?></option>
																					<?php }
																						
																					} ?>
																				</select>
																				<label for="godown">WAREHOUSE</label>
																				</div>
																			</div>
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																				
																				<input type="text" name="trackno" class="form-control"/>
																				<label for="godown">TRUCK NO</label>
																				</div>
																			</div>
																			</div>
																			</div>
																			<div class="row">
																			<div class="col-md-12">
																			
																			<div class="col-md-3">
																				<div class="form-group" id="particode">
																				
																				
																				</div>
																			</div>
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																				
																				<input type="text" id="partiname" name="partyname" placeholder="BUYER NAME" class="form-control" readonly="readonly"/>
																				<input type="hidden" name="bookingord" value="<?php if(isset($bkid)){ echo $bkid;} ?>" />
																				<!--<label for="godown">PARTY NAME</label>-->
																				</div>
																			</div>
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																				
																				<input type="text" id="balance" name="balance" placeholder="BALANCE" class="form-control" readonly="readonly"/>
																				<!--<label for="godown">BALANCE</label>-->
																				</div>
																			</div>
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																				
																				<input type="text" name="drivercontact" class="form-control"/>
																				<label for="godown">DRIVER CONTACT</label>
																				</div>
																			</div>
																			</div>
																			</div>
																			<div class="row">
																			<div cloass="col-md-12">
																			<div class="col-md-1"></div>
																			<div class="col-md-2">
																				<div class="form-group">
																					<button type="submit" class="btn btn-primary">GO</button>
																				</div>
																			</div>
																		</div>
																		
																		
															        </div> 
															        
																</div>
															</form>
												</div>
												
											
											<div class="col-md-12">
								
												
													
													<div class="card-body style-default-bright">
																<div class="row">
																	
			                                                         
																</div>
																<hr>
																    <div class="row">
																	<?php if(isset($modelnme)){ ?>
																	
																		<div class="col-md-6">
																			<div class="col-md-12">
																				<div class="panel-group" id="accordion12">
									     
							<!-------------------------------------------------------------------------------------------------------->
																				<div class="card panel">
																					<div class="card-head style-primary collapsed" data-toggle="collapse" data-parent="#accordion6" data-target="#accordion6-2" >
																						<header><?php echo $modelnme; ?></header>
																							<div class="tools">
																								<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
																							</div>
																					</div>
																					<div id="accordion6-2" class="collapse in" aria-expanded="true">
																						<div class="card-body">	
																							<div class="row">
																								<div class="col-md-12">
																									<div class="col-md-6">
																										<form class="form">
																										<div class="form-group">
																											<input type="text" name="drivercontact" class="form-control" value="<?php if(isset($modelnme)){ echo "PRODUCT NAME:". $modelnme; } ?>" readonly/>
																											
																										</div>
																									</div>
																									<div class="col-md-6">
																										<div class="form-group">
																											<input type="text" name="drivercontact" class="form-control" id="totalqty" value="" placeholder="QTY" onkeyup="alltotalproduct()"/>
																											
																										</div>
																									</div>
																									</form>
																								</div>
																							</div>
																							 <div class="row">
																							 	<div class="col-md-12">
																							 		<table class="datatr" style="width: 100%;">
																							 			<tbody>
																							 				<tr style="background-color:#0aa89e;color:white;font-weight:normal;height: 20px;font-size: 15px;padding: 1px;text-align:center;">
																							 					<th>SL NO.</th>
																							 					<th>
																							 						<label class="checkbox-inline checkbox-styled checkbox-warning" style="color:white;">
																												         <input type="checkbox" value="" id="checkAll"  name="val[]" ><span></span>
																											        </label>
																							 						
																							 						
																							 						</th>
																							 					<th>PARTS NAME</th>
																							 					<th>UNIT</th>
																							 					<th>TOTAL</th>
																							 					<th>AVAILABLE</th>
																							 					<th>REQUIRED</th>
																							 				</tr>
																							 			
																							 			<?php if(isset($getpareparts) && !empty($getpareparts)){ $j=1; ?>
																							 				<?php foreach($getpareparts as $row){ ?>
																							 				<tr>
																							 					<td><?php echo $j; ?></td>
																							 					<td>
																							 						<label class="checkbox-inline checkbox-styled checkbox-primary">
																												         <input type="checkbox" class="spre"   name="val[]" ><span></span>
																											        </label>
													        													</td>
																								 				<td><?php echo $row->materialname; ?></td>
																								 				<td><?php echo $row->unit;  ?><input type="hidden" name="unit" id="unit_<?php echo $j; ?>" value="<?php echo $row->unit; ?>"/></td>
																								 				<td><div id="totvalqty_<?php echo $j; ?>"></div><input type="hidden" name="totqty" id="totvalqtyhidd_<?php echo  $j; ?>" value=""/></td>
																								 				<td id="avlb_<?php echo $j; ?>"><b><?php echo $row->qnty; ?></b><input type="hidden" id="available_<?php echo $j; ?>" value="<?php echo $row->qnty ; ?>"/></td>
																								 				<td><div id="reqid_<?php echo $j; ?>" style="font-weight: bold;"></div>
																								 					<input type="hidden" name="required_<?php echo $j;  ?>" id="required_<?php echo $j; ?>" value=""/>
																								 					<input type="hidden" name="prtsidreq_<?php echo $j;  ?>" id="prtsidreq_<?php echo $j; ?>" value="<?php echo $row->id;  ?>"/>
																								 					
																								 				</td>
																								 			</tr>
																								 			
																								 			<?php $j++; } } ?>
																							 			</tbody>
																							 		</table>
																							 		<input type="hidden" id="tottblrowmodel" value="<?php if(isset($j)){ echo $j;} ?>" />
																							 	</div>
																							 </div>
																						</div>
																					</div>
																				</div><!--end .panel -->
									<!------------------------------------------------------------------------------------------------------>
									
									
																				</div><!--end .panel-group -->
								
																				</div>
																		</div>
																		
																		
																	
																	<?php } ?>
																
																	<form action="<?php echo base_url(); ?>stockManage_controller/getallgetpass" method="post">
														<div class="col-md-6">
															<input type="hidden" name="ordername" value="<?php if(isset($ordernme)){ echo $ordernme ; } ?>"/>
															<input type="hidden" name="modelnme" value="<?php if(isset($modelnme)){ echo $modelnme;} ?>"/>
															<input type="hidden" name="transfertp" value="<?php if(isset($transfr)){ echo $transfr ;}  ?>"/>
															<input type="hidden" name="warehouse" value="<?php if(isset($godwn)){ echo $godwn; } ?>"/>
															<input type="hidden" name="trackno" value="<?php if(isset($trackno)){ echo $trackno; } ?>"/>
															<input type="hidden" name="partyname" value="<?php if(isset($partyname)){ echo $partyname; } ?>"/>
															<input type="hidden" name="drivername" value="<?php if(isset($drivername)){ echo $drivername; } ?>"/>
															<input type="hidden" name="drivercontact" value="<?php if(isset($drivercontact)){ echo $drivercontact; } ?>"/>
															<input type="hidden" name="customerid" value="<?php if(isset($custcode)){ echo $custcode; } ?>"/>
															<input type="hidden" name="custbaln" value="<?php if(isset($balance)){ echo $balance; } ?>"/>
															
															<?php if(isset($temp_data) && !empty($temp_data)){$fd=1; $k=1;$pono1="";$model366="";$pon=1;$prts=1;$boxno=1;$bxprts=1;$indiprts=1; ?>
															<div class="card panel">
																<div class="card-head style-primary collapsed"  >
																			<header>STOCKED MATERIAL</header>
																				
																</div>
																<div class="card-body">
															<table  id="partstble2">
																	<tbody>
																		 <tr style="text-align: center;">
																			<th style="text-align: center;"><h4><b>Sl No.</h4></b></th>
																			<th style="text-align: center;"><h4><b>Details</h4></b></th>
																			<th style="text-align: center;"><h4><b>PO No</h4></b></th>
																			
																		</tr>
																			<?php foreach($temp_data as $row) {
																				
																				$model45=$row->modelname;
																				
																				
																				 
																				 $pono23=$row->pono;
																				 if($model45!=$model366){ ?>
																					<tr>
																						<td colspan="3" style="background-color:#681a7f;color:white;height: 35px;">
																						     <?php  echo "&nbsp;&nbsp;".$model45;  ?>
																						</td>
																					</tr>
																					
																					<?php
																					   $model366=$model45;
																					
																					  } 
																						 if($pono23!=$pono1){
																						 
																						?>
																					
																								<tr id="qty_<?php echo $k; ?>" style="text-align: center;">
																									<td><?php echo $k; ?></td>
																									<td><button type="button" id="open_<?php echo $k; ?>" onclick="opentable(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-plus" aria-hidden="true"></i></button></td>
																									<td><?php echo $row->pono; ?><input type="hidden" name="pono_<?php   echo $pon; ?>" value="<?php echo $row->pono; ?>"/></td>
																									
																								</tr>
																								<tr id="opntr1_<?php echo $k; ?>" class="trhide">
																								<td colspan="3">
																									<center>
																									<table  id="partstble2" style="width: 100%;line-height:30px;">
																									<tbody>
																										<tr style="text-align: center;line-height: 5px;background-color: green;color:white; ">
																											<th style="text-align: center;"><h4>SL NO.</h4></th>
																											<th style="text-align: center;">
																												<label class="checkbox-inline checkbox-styled checkbox-warning" style="color:white;">
																											         <input type="checkbox" class="form-control" name="checkallpono" id="checkallnew_<?php echo $k;  ?>" onclick="checkall(this.id)" />
																										        </label>
																											</th>
																											<th>BOX NO</th>	
																											<th style="text-align: center;"><h4>NAME</h4></th>
																											<th>BOX QTY</th>
																											<th>PARTS QTY</th>
																											<th style="text-align: center;" colspan="3"><h4>TOTAL QTY</h4></th>
																											<th style="text-align: center;">REQ. QTY</th>
								
																										</tr>
																										<?php $h=1; ?>
																										<?php $querytem=mysqli_query($con,"select * from temp_table where pono='".trim($pono23)."'" );
																										while($row=mysqli_fetch_array($querytem)){
																											$updtst=$row['updtno'];
																											 $id=$row['id'];
																											$pono=$row['pono'];
																											$warehouse=$row['warehouse'];
																											//$boxno=$row->
																											$wrhse=$row['warehouse'];
																											$boxname=$row['boxname'];
																											$totalbox=$row['totalbox'];
																											$stock=$row['stock'];
																											$bxty=$row['totalbox'];
																											$stockindi=$row['stockindi'];
																											$stockimplode=explode(",",$stock);
																											//print_r($stockimplode);
																											$stockimplodeindi=explode(",",$stockindi);
																											$stockimplodeindicount=count($stockimplodeindi);
																											$stockimplodecount=count($stockimplode);
																											?>
																											<?php if(isset($boxname) && !empty($boxname))
																											{ ?>
																										
																											<?php  $u=1; $boxname1="";$bxty1="";
																											 for($g=0;$g<$stockimplodecount;$g++){
																											
																											$stock=$stockimplode[$g];
																											$stocvex=explode(";",$stock);
																											$prtsid=$stocvex[0];
																											//$prtsqty=intval($stocvex[1])*intval($totalbox);
																											$prtsqty=intval($stocvex[1]);
																											$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																											$getrow=mysqli_fetch_array($querygetprtsname);
																											$prtsnme=$getrow['materialname'];
																											$prtscode=$getrow['materiel_id'];
																											$mcode=$getrow['id'];
																											$mname=$getrow['mName'];
																											$unit=$stocvex[2];
																											$getunit=mysqli_query($con,"select * from unit_tbl where id='".trim($unit)."'");
																											$rowgetnme=mysqli_fetch_array($getunit);
																											$unitnme=$rowgetnme['unitname'];
																											 
																											 ?>
																												<tr style="text-align: center;line-height:15px;" onclick="getdetailstr()">
																													<td><?php echo $h; ?></td>
																													<td style="padding: 3px;">
																														<label class="checkbox-inline checkbox-styled checkbox-primary" >
																														<input type="checkbox" class="chksl_<?php echo $k; ?>_<?php echo $h; ?>" name="slnobox_<?php echo $k; ?>[]" value="" id="slnobox_<?php echo $k; ?>_<?php echo $h; ?>" />
																														</label>
																													</td>
																													<?php if($boxname!=$boxname1){ ?>
																													<td rowspan="<?php echo $stockimplodecount; ?>"><?php if($boxname!=$boxname1){ echo $boxname;} ?><input type="hidden" name="boxno_<?php echo $pon; ?>_<?php echo $boxno; ?>" value="<?php echo $boxname; ?>"/></td>
																													<?php } ?>	
																													<td><?php echo $prtsnme."($mname)" ; ?>
																														<input type="hidden" id="boxprtsname_<?php echo $k; ?>_<?php echo $h; ?>" name="boxprtsname_<?php echo $k; ?>_<?php echo $h ;  ?>" value="<?php echo $mcode; ?>"/>
																														<input type="hidden" name="boxnme_<?php echo $k;  ?>_<?php echo $h; ?>" value="<?php echo $boxname; ?>"/>
																														</td>
																													<?php if($bxty!=$bxty1){ ?>
																													<td rowspan="<?php echo $stockimplodecount; ?>"><?php if($bxty!=$bxty1){ echo $bxty;} ?><br>
																														<input type="hidden" value="<?php echo $stockimplodecount; ?>" name="" id="boxcounttmp_<?php echo $fd; ?>">
																														<input type="text" id="bxtybx_<?php echo $boxno; ?>_<?php echo $k; ?>_<?php echo $h; ?>" name="currentbx_<?php echo $k; ?>_<?php echo $h; ?>" size="8" onkeyup="getallbxqty(this.id);"/>
																														<input type="hidden" name="bxty_<?php echo $h; ?>" value="<?php echo $bxty; ?>"/></td>
																													<?php } ?>	
																													<td><?php echo "$prtsqty X $bxty" ;?></td>
																													<td colspan="3"><?php echo  intval($prtsqty)*intval($bxty) ; ?><input type="hidden" name="" id="boxprtsqty_<?php echo $k; ?>_<?php echo $h; ?>" value="<?php echo $res=intval($prtsqty); ?>"</td>
																													
																													<td><input type="text" name="boxprtsqty_<?php echo $k; ?>_<?php echo $h ;  ?>" size="8" readonly="readonly"  id="currentbox_<?php echo $k; ?>_<?php echo $h; ?>"/></td>
																													
																												</tr>
																										<?php $u++; $bxprts++; $boxname1=$boxname;$bxty1=$bxty;$h++; } ?>
																												
																											
																												
																											<?php  $fd++;  $boxno++; }else{ ?>
																												
																												<?php  $u=1;
																												 $stockimplodeindicount;
																												// array_pop($stockimplodeindi);
																											 for($g=0;$g<$stockimplodeindicount;$g++){; 
																											
																											$stock=$stockimplodeindi[$g];
																											$stocvex=explode(";",$stock);
																											//print_r($stocvex);
																											$prtsid=$stocvex[0];
																											 $prtsqty=intval($stocvex[1]);
																											$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																											$getrow=mysqli_fetch_array($querygetprtsname);
																											$prtsnme=$getrow['materialname'];
																											$prtsd=$getrow['id'];
																											$mname=$getrow['mName'];
																											$unit=$stocvex[2];
																											$getunit=mysqli_query($con,"select * from unit_tbl where id='".trim($unit)."'");
																											$rowgetnme=mysqli_fetch_array($getunit);
																											$unitnme=$rowgetnme['unitname'];
																											$pkg=$stocvex[3];
																											 
																											 ?>
																												<tr style="text-align: center;line-height:15px;">
																													<td><?php echo $h; ?></td>
																													
																													<td>
																														<label class="checkbox-inline checkbox-styled checkbox-primary" >
																														<input type="checkbox" class="chksl_<?php echo $k;  ?>_<?php echo $h; ?>" name="slnoindi_<?php echo $k; ?>[]" id="indislno_<?php echo $k; ?>_<?php echo $h;  ?>"  value=""/>
																													  </label>
																													  </td>
																													  <td></td>
																													<td><?php echo $prtsnme."($mname)"; ?>
																														<input type="hidden" id="partsini_<?php echo $k; ?>_<?php echo $h; ?>" name="partsini_<?php echo $k;  ?>_<?php echo $h; ?>" value="<?php echo $prtsd; ?>"/></td>
																													<td></td>
																													<td></td>
																													<td colspan="3"><?php echo intval($prtsqty)*intval($pkg); ?></td>
																													
																													<td><input type="text" id="individualprts_<?php echo $k; ?>_<?php echo $h; ?>" name="indiprtsqty_<?php echo $k;  ?>_<?php echo $h; ?>" size="8" onkeyup="getindividprtsval(this.id);" /></td>
																													
																												</tr>
																										<?php $u++;$h++; $indiprts++; } ?>
																											
																												
																												
																												
																												
																												
																										<?php 	} ?>
																											
																											
																											
																											
																									<?php $h++;	 } ?>
																																												
																										
																											<?php /* $u=1;
																											 for($g=0;$g<$stockimplodecount;$g++){; 
																											
																											$stock=$stockimplode[$g];
																											$stocvex=explode(";",$stock);
																											$prtsid=$stocvex[0];
																											$prtsqty=intval($stocvex[1])*intval($totalbox);
																											$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																											$getrow=mysqli_fetch_array($querygetprtsname);
																											$prtsnme=$getrow['materialname'];
																											 
																											*/ ?>
																									<!--<tr id="qty_<?php echo $u; ?>">
																											<td><?php echo $u; ?></td>
																											<td><?php echo $prtsnme ?></td>
																											<td></td>
																											<td><?php echo $prtsqty; ?></td>
																											<td><button type="button" id="close_<?php echo $u; ?>" onclick="delete_rowqty(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td>
																									</tr>-->
																										<?php //$u++; } ?>
																										<tr>
																											<td colspan="10" style="padding: 2px;text-align: right;"><button type="button" id="button_<?php echo $k; ?>_<?php echo $h; ?>" class="btn btn-primary" onclick="getallcheckedid(this.id)">ADD</button></td>
																											
																											<input type="hidden" name="totporow_<?php echo $pon; ?>" value="<?php echo $h; ?>"
																										</tr>
																									</tbody>
																							</table>
																			</center>
																		</td>
																	</tr>		
															<?php $k++; $pon++;	}  $pono1=$pono23;}	} ?>	

																			<?php /* $u=1;
																			 for($g=0;$g<$stockimplodecount;$g++){; 
																			
																			$stock=$stockimplode[$g];
																			$stocvex=explode(";",$stock);
																			$prtsid=$stocvex[0];
																			$prtsqty=intval($stocvex[1])*intval($totalbox);
																			$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																			$getrow=mysqli_fetch_array($querygetprtsname);
																			$prtsnme=$getrow['materialname'];
																			 
																			*/ ?>
																	<!--<tr id="qty_<?php echo $u; ?>">
																			<td><?php echo $u; ?></td>
																			<td><?php echo $prtsnme ?></td>
																			<td></td>
																			<td><?php echo $prtsqty; ?></td>
																			<td><button type="button" id="close_<?php echo $u; ?>" onclick="delete_rowqty(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td>
																	</tr>-->
																		<?php //$u++; } ?>
																	</tbody>
															</table>
															</div>
															</div>
															
															
														</div>
													</div>
													<div class="row">
														<div class="card-actionbar">
															<div class="card-actionbar-row">
																<input type="hidden" name="ponocount" value="<?php  if(isset($pon)){ echo $pon; } ?>"/>
																<input type="hidden" name="boxcount" value="<?php if(isset($boxno)){ echo $boxno;} ?>"/>
																<input type="hidden" name="boxprts" value="<?php if(isset($bxprts)){ echo $bxprts;} ?>"/>
																<input type="hidden" name="indiprts" value="<?php if(isset($indiprts)){ echo $indiprts; } ?>"/>
																<?php if(isset($temp_data) && !empty($temp_data)){ ?><button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button><?php   } ?>
															</div>
														</div>
														
													</div>	
														
														
													</div>
												
									
									</div><!--end .card -->
					                 </form>
								              
											</div>
										<!--end .col -->
						</div>
								
										
										
										
										
																
												
									</div><!--end .card-body -->
					</div><!--end .card -->
					<?php } ?>
				</div><!--end .col -->
			</div>
		</div><!--end .section-body -->
	</section>
	<!-- BEGIN BLANK SECTION -->

		</div><!--end #content-->		
		<!-- END CONTENT -->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function opentable(id)
	{
		var idsplit=id.split("_");
		//alert('hello');
		
		$("#opntr1_"+idsplit[1]).toggle();
	}
	function opentable2(id)
	{
		var idsplit=id.split("_");
		//alert('hello');
		
		$("#opntr2_"+idsplit[1]).toggle();
	}
</script>
<script>
$(document).ready(function(){
	
	//alert('hello');
	$(".trhide,.thred").hide();
	$("#boxhd").hide();
	$("#nohead_box").hide();
	
});
	
	function getallbxqty(id)
	{
		var idsplit=id.split("_");
		//alert(idsplit);
		var abcval=parseInt($("#bxtybx_"+idsplit[1]+"_"+idsplit[2]+"_"+idsplit[3]).val());
		//alert(abcval);
		if(abcval=="" || isNaN(abcval))
		{
			abcval=0;
		}
		var fs1=parseInt(idsplit[3]);
		var boxinprtscount=$("#boxcounttmp_"+idsplit[1]).val();
		for(var fs=0;fs<boxinprtscount;fs++)
		{
			
			//var 
			var bxval=parseInt($("#boxprtsqty_"+idsplit[2]+"_"+fs1).val());
			//alert(fs1);
			var currntval=parseInt(bxval)*parseInt(abcval);
		    var boxprts=$("#boxprtsname_"+idsplit[2]+"_"+fs1).val();
		   // alert(boxprts);
		    var chkval=boxprts+"_"+currntval;
			$("#currentbox_"+idsplit[2]+"_"+fs1).val(currntval);
			//$("#boxprtsname_"+idsplit[2]+"_"+idsplit[3]).val();
			$("#slnobox_"+idsplit[2]+"_"+fs1).val(chkval);
			
			//console.log(currntval);
			fs1++;
		}
		//alert(boxinprtscount);
		//alert(abcval);
	}
	function getallselect(id)
	{
		var idsplit=id.split("_");
		//alert(idsplit);
		 $("#checkallnew_"+idsplit[1]).click(function() {
           var checkBoxes = $("input[name=slnoindi\\[\\]]");
           checkBoxes.prop("checked", !checkBoxes.prop("checked"));
    });
	}
	function getorderid()
	{
		var oid=$("#orderno").val();
		//alert(oid);
		var idsplit=oid.split("/");
		var t1=idsplit[0];
		
		var t2=idsplit[1];
		var t3=idsplit[2];
		var newoid=parseInt(t3)+1;
		//alert(newoid);
		var neid=t1+"/"+t2+"/"+newoid
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/savestocklist",
  			data :{'oid':oid},
  			success : function(data){
  				 				 
  			//	alert(data);
  				$("#orderno").val(neid);
  			  
              }  
           });
	}
	function getsales()
	{
		var gettrst=$("#transfer").val();
		//alert(gettrst);
		//var particode;
		if(gettrst=="sales")
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>StockManage_controller/getpartycode",
  			data :{'gettrst':gettrst},
  			success : function(data){
  				 				 
  			//	alert(data);
  				$("#particode").html(data);
  			  
              }  
           });
		}else
		{
			//$("#particode").html("<input type='text' name='drivername' class='form-control'/><label for='godown'>PARTY CODE</label>");
			$("#partycode").hide();
			$("#particode").html();
		}
	}
	function getbalance()
	{
		var prticode=$("#partycode").val();
		//alert(prticode);
		if(prticode=="")
		{
			$("#partiname").val("");
  			  $("#balance").val("");
		}else
		{
			//alert('hello');
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>StockManage_controller/getclientdetails",
  			data :{'prticode':prticode},
  			success : function(data){
  				 var json=JSON.parse(data);			 
  			  //  alert(data);
  				//$("#particode").html(data);
  				var clientname=json.clientname;
  				var balance=json.balance;
  			    $("#partiname").val(clientname);
  			    $("#balance").val(balance);
              }  
           });
		}
	}
	function alltotalproduct()
	{
		var totqty=$("#totalqty").val();
		var tottblrowmodel=$("#tottblrowmodel").val();
		for( var vf=1;vf<parseInt(tottblrowmodel);vf++)
		{
		var unit=parseInt($("#unit_"+vf).val());
		var available=parseInt($("#available_"+vf).val());
			if(isNaN(totqty)||totqty=="")
			{
				totqty=1;
			}
			var totqty2=parseInt(totqty)*parseInt(unit);
			//alert(totqty2);
			$("#totvalqty_"+vf).text(totqty2);
			$("#totvalqtyhidd_"+vf).val(totqty2);
			if(available<totqty2)
			{
				$("#avlb_"+vf).css({"background-color":"red","color":"white"});
			}else
			{
				$("#avlb_"+vf).css({"background-color":"white","color":"black"});
			}
		}
		//alert(totqty);
	}
	function checkall(id){
		var idsplit=id.split("_");
		//alert('hello');
		 $("#checkallnew_"+idsplit[1]).change(function () {
   $("input:checkbox[name='slnoindi_"+idsplit[1]+"[]']").prop('checked', $(this).prop("checked"));
   $("input:checkbox[name='slnobox_"+idsplit[1]+"[]']").prop('checked', $(this).prop("checked"));
    });
   }
   function checkas(id)
   {
   	//var idsplit=id.split("_");
   	
     //$("input:checkbox[name='checkallpono']").change(function () {
   // $("input:checkbox[name='slno']").prop('checked', $(this).prop("checked"));
     // });
   }
   function getallcheckedid(id)
   {
   	//alert('hello');
   	var idsplit=id.split("_");
   //	alert(idsplit);
   	var totrow=parseInt(idsplit[2]);
  // alert(totrow);
   	var producttotrow=parseInt($("#tottblrowmodel").val());
   //	alert(producttotrow);
   	for(var tr=1;tr<producttotrow;tr++)
   	{
   			//$("#required_"+tr).val(0);
	   		var abcd=$("#required_"+tr).val(0);
	   		$("#reqid_"+tr).text("");
	   		//alert(abcd);
	   		
   	}
   	//alert(producttotrow);
   var chk=0;var chcked=0;
   	for( var totchk=1;totchk<totrow;totchk++)
   	{
   		
   		var chksl=$(".chksl_"+idsplit[1]+"_"+totchk).val();
   		
   		//alert(chksl);
   		  if(chksl=="")
   		  {
   		  	//alert('hell0000'+totchk);
   		  }else
   		  { 
   		  	
   		  	//alert(chksl);
   		  	if(typeof chksl!=="undefined" && ($(".chksl_"+idsplit[1]+"_"+totchk).prop('checked')==true))
   		  	{
   		  		var chkslsplt=chksl.split("_");
   		  		chcked++;
   				var prtscode=chkslsplt[0];
   				var prtsqty=parseInt(chkslsplt[1]);
   				//alert('assd_'+prtscode);
   				for(var tr=1;tr<producttotrow;tr++)
   				{
   					//$("#required_"+tr).val(0);
	   				var prtscode2=$("#prtsidreq_"+tr).val();
	   				//alert('upeer_'+prtscode);
	   				if(prtscode2==prtscode)
	   				{
	   					//alert(prtsqty);alert(chksl);
	   					var req=parseInt($("#required_"+tr).val());
	   					
	   					if(isNaN(req))
	   					{
	   						req=0;
	   					}
	   					//alert(req);
	   				 var req1=parseInt(req)+parseInt(prtsqty);
	   				 $("#required_"+tr).val(req1);
	   				 $("#reqid_"+tr).text(req1);
	   					//alert(req1);
	   				}
   				//alert(prtscode);
   				}
   		  	}else
   		  	{
   		  		chk++;
   		  	}
   			/*var chkslsplt=chksl.split("_");
   			var prtscode=chkslsplt[0];
   			var prtsqty=chkslsplt[1];
   			alert(prtscode);
   			for(var tr=1;tr<producttotrow;tr++)
   			{
   				var prtscode=$("#prtsidreq_"+tr).val();
   				if(prtscode==prtsqty)
   				{
   					//alert(chksl);
   				}
   				//alert(prtscode);
   			}*/
   			}
   		
   	}
   
   	if(chk>0 && chcked==0)
   	{
   	  alert('please check required checkbox');
   	}
  // 	alert(producttotrow);
   	
   	
   }
   function getindividprtsval(id)
   {
   //	alert('hello');
   	var idsplit=id.split("_");
   //	alert(idsplit);
   	var posl=idsplit[1];
   	var prtssl=idsplit[2];
   	var prtsval=$("#individualprts_"+posl+"_"+prtssl).val();
   //	alert(prtsval);
   	var prtscode=$("#partsini_"+posl+"_"+prtssl).val();
   //	alert(prtscode);
   	var checkval=prtscode+"_"+prtsval;
  // 	alert(checkval);
   	$("#indislno_"+posl+"_"+prtssl).val(checkval);
 //  	alert(prtsval);
   }
   function getdetailstr()
   {
   	 alert('hello');
   }
   $("#checkAll").change(function () {
    $("input:checkbox[class='spre']").prop('checked', $(this).prop("checked"));
});

</script>