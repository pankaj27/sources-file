<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php  include('connection.php'); ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<?php  
$qnty="";
	if(isset($bokingdetails) && !empty($bokingdetails))
	{
		foreach($bokingdetails as $rowinv)
		{
			$booking=$rowinv->bokingid;
			$custid=$rowinv->custid;
		   $particulars=$rowinv->particulars;
			$qnty=intval($rowinv->qnty);
			 $color=$rowinv->color;
			$doe=$rowinv->doe;
			$category=$rowinv->cate;
		}
		$particularsex=explode("(",$particulars);
		 $parti=$particularsex[0];
		$pname=$particularsex[1];
		 $pnme2=explode(")",$pname);
		 $pname2=$pnme2[0];
		$getcustinfo=mysqli_query($con,"select * from clientmaster where clientid='".trim(strtoupper($custid))."'");
		$getr=mysqli_fetch_array($getcustinfo);
		$custname=$getr['name'];
		$custyp=$getr['custtype'];
		$custcomp=$getr['compname'];
		$add1=$getr['add1'];
		$add2=$getr['add2'];
		$district=$getr['district'];
		$state=$getr['state'];
		$pin=$getr['pin'];
		$tin_vat=$getr['tin_vat'];
		$cst=$getr['cst'];
		$balance=$getr['balance'];
		$address="$add1 $add2 $district $state $pin";
		
	}
	
	
	
	
if(isset($getpartspr) && !empty($getpartspr))
	{
		foreach($getpartspr as $rowbattery)
		{
			$cnbateery=$rowbattery->cnfpr;
			$distpr=$rowbattery->distpr;
			$subdist=$rowbattery->subdistpr;
			$mrp=$rowbattery->buyprcrnt;
		}
		if($custyp=="RETAILER")
		{
			$batterydis=$mrp;
		}
		if($custyp=="SUB-DEALER")
		{
			$batterydis=$subdist;
		}
		if($custyp=="DEALER")
		{
			$batterydis=$distpr;
		}
		if($custyp=="CNF")
		{
			$batterydis=$cnbateery;
		}
	}
	if(isset($batterydis) && !empty($batterydis))	
	{
		$batterydis=$batterydis;
	}else{
		$batterydis=99999;
	}

  if(isset($getmodel) && !empty($getmodel))
  {
  	foreach($getmodel as $rowmodelmrp)
	{
		//$modelmrp=
		$cnfpr=$rowmodelmrp->cnfprice;
		$distpr=$rowmodelmrp->distprice;
		$subdistpr=$rowmodelmrp->subdistprice;
		$mrp=$rowmodelmrp->mainpr;
	}
	if($custyp=="RETAILER")
		{
			$modelmrp=$mrp;
		}
		if($custyp=="SUB-DEALER")
		{
			$modelmrp=$subdistpr;
		}
		if($custyp=="DEALER")
		{
			$modelmrp=$distpr;
		}
		if($custyp=="CNF")
		{
			$modelmrp=$cnfpr;
		}
  }
  if(isset($getcharger) && !empty($getcharger))
  {
  	foreach($getcharger as $rowcharger)
	{
		$cnfcharger=$rowcharger->cnfpr;
		$discharger=$rowcharger->distpr;
		$subdistpr=$rowcharger->subdistpr;
		$mrp=$rowcharger->buyprcrnt;
	}
	if($custyp=="RETAILER")
		{
			$chargerpr=$mrp;
		}
		if($custyp=="SUB-DEALER")
		{
			$chargerpr=$subdistpr;
		}
		if($custyp=="DEALER")
		{
			$chargerpr=$discharger;
		}
		if($custyp=="CNF")
		{
			$chargerpr=$cnfcharger;
		}
  }
if(isset($chargerpr) && !empty($chargerpr))	
	{
		$cnfcghpr=$chargerpr;
	}else{
		$cnfcghpr=99999;
	}
	$batt=0;
if(isset($category)&& !empty($category))
{
	if ((strpos($category, 'Battery') !== false) || (strpos($category, 'battery') !== false)) {
    $batt=1;
}
}	
	
	$charg=0;
	if(isset($category) && !empty($category))
	{
		if ((strpos($category, 'Charger') !== false) || (strpos($category, 'charger') !== false)) {
   echo  $charg=1;
}
	}
	


 ?>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"> Invoice Information </li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create Invoice</a></li>
								<li><a href="#second">Edit/View</a></li>
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
							<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
					<div class="card">
							<div class="card-head style-primary">
								<header>INVOICE INFORMATION <?php  $particulars ?></header>
							</div>
							<div class="card-body floating-label">
								 <div class="row">
									<div class="col-md-12">
										<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/generate_invoice_orderno" method="post" >
										<div class="col-md-6">
												<div class="form-group">
												<input type="text" name="orderno" class="form-control"  id="orderno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($booking) && !empty($booking)){ echo $booking; } ?>"  />
												<label for="mName">Order No</label>
											</div>
										</div>
										<div class="col-md-1">
												<div class="form-group">
												<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
												
											</div>
										</div>
										
									</form>	
										
									</div>
								</div>
								
								<form class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/saveinvoicetemp" method="post" >
				
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="invoicno" class="form-control"  id="invoiceno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($invoice) && !empty($invoice)){ echo $invoice; } ?>" readonly />
												<label for="mName">Invoice No</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderno" class="form-control"  id="orderno" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($booking) && !empty($booking)){ echo $booking; } ?>" onblur="getorderdate();" />
												<label for="mName">Order No</label>
											</div>
										</div>
										
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="orderdate" class="form-control"  id="orderdate" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($doe) && !empty($doe)){ echo $doe;} ?>" />
												<label for="mName">Order Date</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<!--<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>-->
											</div>
										</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>CUSTOMER  & CONSIGNEE INFORMATION</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" name="custdet" class="form-control"  id="custinfo" placeholder="" style="text-transform: uppercase;" onblur="custdetails()" value="<?php if(isset($custname) && !empty($custname)){ echo $custname; } ?>"/>
											<label for="mName">Search Customer ID/Name/Company</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												
												<input type="text"  class="form-control"  name="custid" id="custid" value="<?php  if(isset($custid) && !empty($custid)){ echo $custid ;}  ?>" readonly/>
												<input type="hidden" name="custcomp" id="custcomp" value=""/>
												<!--<input type="hidden" name="add1" id="add1"/>
												<input type="hidden" name="add2" id="add2">
												<input type="hidden" name="add3" id="add3"/>
												<input type="hidden" name="pin" id="pin"/>-->
												<label for="mName"> Customer ID</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custaddress" class="form-control"  id="custaddress" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($address) && !empty($address)){ echo $address ; } ?>" />
												<label for="mName">Enter Customer Address</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custbalance" class="form-control"  id="custbalance" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($balance)&& !empty($balance)){ echo $balance; }  ?>" />
												<label for="mName">Accounts Balance</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custtyp" class="form-control"  id="custtyp" placeholder="" style="text-transform: uppercase;" readonly value="<?php if(isset($custyp) && !empty($custyp)){ echo $custyp ; } ?>" />
												<label for="mName">Customer Type</label>
											</div>
										</div>
										
									</div>
								</div>
								<div class="row"><hr></div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="custvat" class="form-control"  id="custvat" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($tin_vat) && !empty($tin_vat)){ echo $tin_vat ; } ?>" />
												<label for="mName">Customer VAT/TIN No</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" name="custtin" class="form-control"  id="custtin" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($cst) && !empty($cst)){ echo $cst ;} ?>" />
												<label for="mName"> Customer CST No</label>
											</div>
										</div>
										<!--<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custbalance" class="form-control"  id="custbalance" placeholder="" />
												<label for="mName">Accounts Balance</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="custdet" class="form-control"  id="custdet" placeholder="" />
												<label for="mName">Customer Type</label>
											</div>
										</div>-->
										
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" id="sameasc" onclick="checksameasaddress()"><span><b>Same as Customer</b></span>
												</label>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneename" class="form-control"  id="consigneename" placeholder="Enter Consignee Name" />
												
												<!--<input type="hidden" name="consigneecom" id="consigneecom" value=""/>
												<input type="hidden" name="consigneeadd1" id="consigneeadd1"/>
												<input type="hidden" name="consineeadd2" id="consineeadd2">
												<input type="hidden" name="consigneeadd3" id="consigneeadd3"/>
												<input type="hidden" name="consihgneepin" id="consihgneepin"/>-->
												
												<!--<label for="mName">Enter Consignee Name </label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneeadd" class="form-control"  id="consigneeadd" placeholder="Enter Consignee  Address" style="text-transform: uppercase;" />
												<!--<label for="mName">Enter Consignee  Address</label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneevat" class="form-control"  id="consigneevat" placeholder="Consignee VAT No" style="text-transform: uppercase;" />
												<!--<label for="mName">Consignee VAT No</label>-->
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" name="consigneetin" class="form-control"  id="consigneetin" placeholder="Consignee TIN No" style="text-transform: uppercase;" />
												<!--<label for="mName">Consignee TIN No</label>-->
											</div>
										</div>
										
									</div>
								</div>
								
							</div>
						</div>
						<div class="card">
							<div class="card-head style-primary">
								<header>ORDER DETAILS</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<div class="col-md-6">
											<div class="form-group">
												<select id="cattyp" class="form-control select2-list" name="cattyp"  required onchange="gettypedetails()" >
													<?php  if(isset($parti)=="E-Rickshaw" ){ ?>
														<option value="product" selected>Model</option>
														<option value="0">--select--</option>
														<option value="product">Model</option>
														<option value="parts">Spare Parts</option>
															
															
														
													<?php }else if(isset($parti)!="E-Rickshaw"){ ?>
															<option value="parts" selected>Spare Parts</option>
															<option value="0">--select--</option>
															<option value="product">Model</option>
															<option value="parts">Spare Parts</option>
															
													<?php }else{ ?>
														<option value="0"></option>
														<option value="product">Model</option>
														<option value="parts">Spare Parts</option>
													<?php 	} ?>
													
												</select>
										       <label for="mName"> Select Product Type</label>
											</div>
										</div>
										
										
										<div class="col-md-6">
											<div class="form-group" id="modeldetails">
												
												<?php if(isset($pname2) && !empty($pname2)){
															echo '<select id="mname" class="form-control select2-list"  name="mName"  required onchange="getmodeltypebyparts()" >';
															echo '<option value="'.$pname2.'" selected>'.$pname2.'</option>';
															echo '<option value="0"></option>';
															$i=1;
															foreach($models as $row)
															{
																
																	echo '<option value="'.$row->productname.'">'.$row->productname.'</option>';
																									
															$i++;	
															}
																echo '</select>';
																echo '<label for="mName">Select Model</label>';
													
													
													
												} ?>
												
											</div>
										</div>
									
									</div>
								</div>
<!--###########################################################################  Model details  Information   --->
								<div class="row" id="model_details">
									<?php if(isset($pname2) && !empty($pname2)){  
														
											echo '
										<hr class="dotted">
										<div class="col-md-12">
													<div class="col-md-6">
														<div class="form-group">
															 <div class="checkbox checkbox-inline checkbox-styled">
																	<label class="checkbox-inline checkbox-styled checkbox-primary">
																		<input type="checkbox" name="erick" value="'.$modelmrp.'" checked><span><b>E- Rickshaw</b></span>
																	</label>
															  </div>
															  <div class="checkbox checkbox-inline checkbox-styled">
																	<label class="checkbox-inline checkbox-styled checkbox-primary">';
																	if($batt==1)
																	{
																		echo '<input type="checkbox" id="battery" name="battery" value="'.$batterydis.'" checked><span><b>Battery</b></span>';
																	}else{
																		echo '<input type="checkbox" id="battery" name="battery" value="'.$batterydis.'"><span><b>Battery</b></span>';
																	}
																		
																	echo '</label>
															  </div>
															  <div class="checkbox checkbox-inline checkbox-styled">
																	<label class="checkbox-inline checkbox-styled checkbox-primary"> 
																	';
																	if($charg==1)
																	{
																		
																		echo '<input type="checkbox" id="charger" name="charger" value="'.$cnfcghpr.'" ckecked><span><b>Charger</b></span>';
																	}else
																		{
																			echo '<input type="checkbox" id="charger" name="charger" value="'.$cnfcghpr.'"><span><b>Charger</b></span>';
																		}
																		
																	echo '</label>
															  </div>
														</div>
													</div>
										        </div>
										        ';
												echo ' <hr class="dotted">
												<div class="col-md-12">
													<div class="col-md-6">
														<div class="form-group">
															 <input type="text" name="reqty" class="form-control"  id="reqty" placeholder=""  onblur="getallchassisinfo();" required value="'.$qnty.'"/>
															 <label for="mName">Enter Required Qty</label>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															 
														</div>
													</div>
													<div class="col-md-12" style="overflow-x:scroll;" >
														<div class="form-group">
															 <table class="table table-bordered table-hover">
															 	<thead>
															 	   
															 		<tr>';
																	if(isset($getcolorcode) && !empty($getcolorcode))
																	{
																		foreach($getcolorcode as $rowcolor)
																		{
																			
																			echo '<td>'.$rowcolor->color_name.'</td>';
																		}
																	}
																	
															 			
															 		echo '</tr>
															 	</thead>
															 	<tbody>
															 		<tr>';
															 			if(isset($getcolorcode) && !empty($getcolorcode))
																	{
																		$color=1;
																		foreach($getcolorcode as $rowcolor)
																		{
																		
																			echo '<td><input type="text" name="color_'.$color.'" style="background-color:'.$rowcolor->code_hex.';color:white;font-weight:bolder;text-align:center;" id="color_'.$color.'" onblur="getmodelrate(this.id);"/></td>';
																			$color++;
																		}
																	}
															 			
																	echo '</tr>
																	
															 	</tbody>
															 </table>
															 <input type="hidden" name="colorrow" id="colorrow" value="'.$color.'"/>
														</div>
													</div>
										        </div>
										       ';
														
													
													
												
									}  ?>			
									 
								</div>
								<hr>
								<div class="row" id="getchassisin">
									 <?php  
									$reqty=$qnty;
									 	if(isset($reqty) && !empty($reqty) && $batt==1 && $charg==1 )
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									<th>Charger No</th>
									<th>Battery 1</th>
									<th>Battery 2</th>
									<th>Battery 3</th>
									<th>Battery 4</th>
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'"  style="text-transform: uppercase;" /></td>
					<td><input type="text" name="charger_'.$t.'" id="charger_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery1_'.$t.'" id="battery1_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery2_'.$t.'" id="battery2_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery3_'.$t.'" id="battery3_'.$t.'"  style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery4_'.$t.'" id="battery4_'.$t.'" style="text-transform: uppercase;" /></td>
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div><div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    ';
	
	}
    if(isset($reqty) && !empty($reqty) && $batt==0 && $charg==0)
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'" style="text-transform: uppercase;" /></td>
					
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div>
		    <div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    ';
	
	}
	if(isset($reqty) && !empty($reqty) && $batt==1 && $charg==0)
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									
									<th>Battery 1</th>
									<th>Battery 2</th>
									<th>Battery 3</th>
									<th>Battery 4</th>
									
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;"  /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'" style="text-transform: uppercase;" /></td>
					
					<td><input type="text" name="battery1_'.$t.'" id="battery1_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery2_'.$t.'" id="battery2_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery3_'.$t.'" id="battery3_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="battery4_'.$t.'" id="battery4_'.$t.'" style="text-transform: uppercase;" /></td>
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div>
		    <div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    ';
	
	}
  if(isset($reqty) && !empty($reqty) && $batt==0 && $charg==1)
	{
		echo ' <hr class="dotted">
			<div class="col-md-12" style="overflow-y:scroll;">
				
					<div class="form-group">';
					echo '<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Chassis No.</th>
									<th>Motor No.</th>
									<th>Charger No</th>
									
									
									
								</tr>
							</thead><tbody>';
			
		for($t=1;$t<=$reqty;$t++)
		{
			echo '<tr>
					<td>'.$t.'</td>
					<td><input type="text" name="chassis_'.$t.'" id="chassis_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="motor_'.$t.'" id="motor_'.$t.'" style="text-transform: uppercase;" /></td>
					<td><input type="text" name="charger_'.$t.'" id="charger_'.$t.'" style="text-transform: uppercase;" /></td>
					
				</tr>
				';
			
			
			
		}
		echo       '
		            </tbody>
		             </table></div>
		
		    </div>
		    <div class="col-md-12">
		    	<div class="card-actionbar">
						<div class="card-actionbar-row">
								<button type="submit" class="btn btn-flat btn-primary ink-reaction">Next</button>
						</div>
				</div>
			</div>
		    
		    ';
	
	}
   
	
									 
									 
									 
									 
									  ?>
								</div>
							</div>
						</div>
						
							
				 </form>	
    						
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
<!--########################################################################################################################-->
<!--  -                                        Second Tab  -->
<!-- #############################################################################################################-->
					<div class="tab-pane" id="second">
						<div class="col-md-12">
				
					<div class="card">
							<div class="card-head style-primary">
								<header>View All Invoice</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-md-12">
										
										<table class="table table-bordered table-hover">
											<thead>
												<tr>
													<th>Sl No</th>
													<th>Invoice No</th>
													<th>Company Name/Customer </th>
													<th>Order No</th>
													
													<th>Particulars</th>
													<th>Total</th>
													<th>Doe</th>
													<th>Ordr Date</th>
													<th>Action</th>
													
												</tr>
											</thead>
											<tbody>
												<?php if(isset($allinvoice) && !empty($allinvoice)){$in=1; $invoicen=""; ?>
													<?php foreach($allinvoice as $rowinvoice){
														$invoicen1=$rowinvoice->invoiceno;
														if($invoicen1!=$invoicen){
														$custname=$rowinvoice->custname;
														$custtype=$rowinvoice->custtyp;
														if(strtoupper($custtype)!="RETAILER")
														{
															$getqr=mysqli_query($con,"select * from clientmaster where 	ucase(clientid)='".trim(strtoupper($custname))."'");
															$getro=mysqli_fetch_array($getqr);
															$custname=$getro['compname'];
														}else
														{
															$custname=$custname;
														}
													?>
												<tr>
													<td><?php echo $in; ?></td>
													<td><?php echo $rowinvoice->invoiceno; ?></td>
													<td><?php echo $custname;   ?></td>
													<td><?php echo $rowinvoice->orderno; ?></td>
													<td><?php echo $rowinvoice->particulars; ?></td>
													<td><?php echo $rowinvoice->gtotal; ?></td>
													<td><?php echo $rowinvoice->doe; ?></td>
													<td><?php echo $rowinvoice->orderdate; ?></td>
													<td><a href="<?php echo base_url(); ?>AcountsManage_Controller/editinvoice/<?php echo $rowinvoice->invoiceno; ?>"><button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a> &nbsp;&nbsp;
														<a href="<?php echo base_url(); ?>AcountsManage_Controller/print_invoice2/<?php echo $rowinvoice->invoiceno; ?>"><button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-print" aria-hidden="true"></i></button>
															
														</a>
														</td>
												</tr>
												<?php $in++; $invoicen=$invoicen1; } } } ?>
											</tbody>
											
										</table>
									</div>
								</div>
							</div>
						</div>
						
						
						
							
				
    						
						</div><!--end .card-body -->
					</div>
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
 
<script>
	function gettypedetails()
	{
		var cattyp=$("#cattyp").val(); 
	//alert(cattyp);
	//console.log(cattyp);
	if(cattyp=="0")
	{
		//$("#model").show();
  	    //$("#model").html(data);
  	    $("#modeldetails").remove();
  	    
	}else
	{
		//$("#model").hide();
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodellistbyparts",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					//$("#model").show();
  				  $("#modeldetails").html(data);
              }  
       });
		
		//if(cattyp=="parts")
		//{
			
		//}else
		//{
			
		//}
	}
	}
	function getmodeltypebyparts()
    {
	var type1=$("#mname").val();
	var custype=$("#custtype").val();
	//var custype="CNF";
	//alert(type1);
	//var typesplit=type1.split("_");
	//var type=typesplit[0];
	//var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getmodelprice",
  			data :{'type':type1,'custype':custype},
  			success : function(data){
  					
  				  //$("#modalparts_"+id).modal('show');
  				  $("#model_details").html(data);
              }  
       });
	
	
}
function getallchassisinfo()
{
	var reqty=parseInt($("#reqty").val());
	//alert(reqty);
	if($('#battery').is(':checked'))
	{
		var battery=parseFloat($("#battery").val());
	}else
	{
		var battery=999999;
	}
	if($('#charger').is(':checked'))
	{
		var charger=parseFloat($("#charger").val());
	}else
	{
		var charger=999999;
	}
	//alert(battery);
	//alert(charger);
	//var battery=$().val()
	if(reqty=="" || isNaN(reqty))
	{
		$("#getchassisin").remove();
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getchassisdetails",
  			data :{'reqty':reqty,'battery':battery,'charger':charger},
  			success : function(data){
  					//alert(data);
  					console.log(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#getchassisin").html(data);
              }  
       });
	}
}
function checksameasaddress()
{
	if($("#sameasc").is(':checked'))
	{
		//alert('checked');
		var custdet=$("#custinfo").val();
		var custadd=$("#custaddress").val();
		var custvat=$("#custvat").val();
		var custtin=$("#custtin").val();
		//consignee details
		$("#consigneename").val(custdet);
		$("#consigneeadd").val(custadd);
		$("#consigneevat").val(custvat);
		$("#consigneetin").val(custtin);
		
	}else
	{
		alert('notchecked');
		$("#consigneename").val("");
		$("#consigneeadd").val("");
		$("#consigneevat").val("");
		$("#consigneetin").val("");
	}
}
function getorderdate()
{
	var orderno=$("#orderno").val();
	alert(orderno);
	if(isNaN(orderno) && orderno=="" )
	{
		 $("#orderdate").val("");
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getorderdate",
  			data :{'orderno':orderno},
  			success : function(data){
  					alert(data);
  				  //$("#modalparts_"+id).modal('show');
  				  $("#orderdate").val(data);
              }  
       });
	}
	
}
function custdetails()
{
	//console.log("hello");
	var custinfo=$("#custinfo").val();
	if(custinfo=="")
	{
		
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getcustinformation",
  			data :{'custinfo':custinfo},
  			success : function(data){
  				
  					console.log(data);
  					//var custcomp=
  					var json=JSON.parse(data);
  					var comp=json.compname;
  					var name=json.name;
  					var clientid=json.clientid;
  					var type=json.type;
  					var address=json.address;
  					var balance=json.balance;
  					var tinvat=json.tinvat;
  					var cst=json.cst;
  				  //$("#modalparts_"+id).modal('show');
  				 // $("#orderdate").val(data);
  				 $("#custid").val(clientid);
  				 $("#custcomp").val(comp);
  				 $("#custaddress").val(address);
  				 $("#custbalance").val(balance);
  				 $("#custtyp").val(type);
  				 $("#custvat").val(tinvat);
  				 $("#custtin").val(cst);
  				 //$().val();
  				 
  				// $().val();
              }  
       });
	}
}

</script>
