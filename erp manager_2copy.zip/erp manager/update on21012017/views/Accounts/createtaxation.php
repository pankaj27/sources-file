<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>

<?php //include("connection.php"); ?>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
		<section>
			<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">Taxation Entry</li>
				</ol>

			</div>
			<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
						 <div class="alert alert-danger alert-dismissible">
					           <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
					                <?php echo $this->session->flashdata('message'); ?>
						   </div>
		            <?php }?>
		       <div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Tax Details</a></li>
																
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								
								<div class="col-md-12">
							    <div class="card">
							    	<?php  
   if(isset($taxinfo) && !empty($taxinfo) )
   {
   	foreach($taxinfo as $rowtax)
	{
		 $vat=$rowtax->vatno;
		 $vatamnt=$rowtax->vatamnt;
		 $cst=$rowtax->cstno;
		 $cstamnt=$rowtax->cstamnt;
		 $excis=$rowtax->exciseno;
		 $eciamnt=$rowtax->exciswamnt;
		 
		 $tds=$rowtax->tdsno;
		 $tdsamnt=$rowtax->tdsamnt;
		 $custom=$rowtax->custom;
		 $customant=$rowtax->customamnt;
		 
		 $ptax=$rowtax->ptax;
		 $ptaxamnt=$rowtax->ptaxamnt;
		 
		 $serv=$rowtax->stax;
		 $servamn=$rowtax->staxamnt;
		 
		 $incom=$rowtax->intax;
		 $incomtaxmn=$rowtax->intaxamnt;
		 $rowid=$rowtax->id;
		 
	}
	
   }

?>
							    	<form  <?php  if(isset($rowid) && !empty($rowid)){ ?>  action="<?php echo base_url();  ?>AcountsManage_Controller/updatetaxtaion"  <?php   }else{  ?> action="<?php echo base_url();  ?>AcountsManage_Controller/savetaxation"   <?php }  ?> method="post">
									<div class="card-head style-primary">
										<header>Taxation Entry</header>
									</div>
									<div class="card-body floating-label">
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>VAT Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="hidden"  name="rowid" value="<?php if(isset($rowid) && !empty($rowid)) { echo $rowid;}  ?>"  />
												<input type="text" class="form-control" id="vat" name="vat"    placeholder="VAT NO" value="<?php if(isset($vat) && !empty($vat)){  echo $vat; } ?>"> 
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="vatamount" name="vatamount"   placeholder="VAT AMOUNT(%)" value="<?php if(isset($vatamnt) && !empty($vatamnt)){  echo $vatamnt; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>CST  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="cst" name="cst"    placeholder="CST NO" value="<?php if(isset($cst) && !empty($cst)){  echo $cst; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="cstamount" name="cstamount"    placeholder="CST AMOUNT(%)" value="<?php if(isset($cstamnt) && !empty($cstamnt)){  echo $cstamnt; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>EXCISE  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="excise" name="excise"    placeholder="EXCISE NO" value="<?php if(isset($excis) && !empty($excis)){  echo $excis; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="exciseamount" name="exciseamount"    placeholder="EXCISE AMOUNT(%)" value="<?php if(isset($eciamnt) && !empty($eciamnt)){  echo $eciamnt; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>TDS  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="tds" name="tds"    placeholder="TDS NO" value="<?php if(isset($tds) && !empty($tds)){  echo $vat; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="tdsamount" name="tdsamount"    placeholder="TDS AMOUNT(%)" value="<?php if(isset($tdsamnt) && !empty($tdsamnt)){  echo $tdsamnt; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>CUSTOM DUTY  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="custom" name="custom"    placeholder="CUSTOM DUTY NO" value="<?php if(isset($custom) && !empty($custom)){  echo $custom; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="customamount" name="customamount"    placeholder="CUSTOM AMOUNT(%)" value="<?php if(isset($customant) && !empty($customant)){  echo $customant; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>P-TAX  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="ptax" name="ptax"    placeholder="P-TAX NO" value="<?php if(isset($ptax) && !empty($ptax)){  echo $ptax; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="ptaxamount" name="ptaxamount"    placeholder="P-TAX AMOUNT(%)" value="<?php if(isset($ptaxamnt) && !empty($ptaxamnt)){  echo $ptaxamnt; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>SERVICE TAX  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="stax" name="stax"    placeholder="SEVICE TAX " value="<?php if(isset($serv) && !empty($serv)){  echo $serv; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="staxamount" name="staxamount"    placeholder="S-TAX AMOUNT(%)" value="<?php if(isset($servamn) && !empty($servamn)){  echo $servamn; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<h4>INCOME TAX  Details:</h4>
											    
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<input type="text" class="form-control" id="incometax" name="incometax"    placeholder="INCOME TAX " value="<?php if(isset($incom) && !empty($incom)){  echo $incom; } ?>">
											    
											</div>
										</div>
										<div class="col-md-1">
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<input type="number" class="form-control" id="incometaxamount" name="incometaxamount"    placeholder="INCOME TAX AMOUNT(%)" value="<?php if(isset($incomtaxmn) && !empty($incomtaxmn)){  echo $incomtaxmn; } ?>">
											    
											</div>
										</div>
										</div>
										<div class="col-md-12">
											<div class="card-actionbar">
												<div class="card-actionbar-row">
													<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
												</div>
											</div>
										</div>
										
					              	</div><!--end .section-body -->
					              	 </form>
					             </div>
					            </div>
					           
	<!--                              all spareparts list                              -->
					            
	<!----                end of card                                            -->
					          </div>
					         </div>
					        </div>
					      </div>
					    </div>
	        </section>
		</div><!--end #content-->
		</div>		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
