<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php  include('connection.php'); ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

<?php 
//$dis=10;
$excise=6;
echo $mainpr;
if(isset($taxinfo) && !empty($taxinfo))
{
	foreach($taxinfo as $row)
	{
		$vat=$row->vatamnt;
		$cst=$row->cstamnt;
	}
}
if(isset($model) && !empty($model))
{
	$model=$model;
}
if(isset($custtyp) && !empty($custtyp))
{
	if(strtoupper($custtyp)=="RETAILER")
	{
		$dis=0;
	}
	if(strtoupper($custtyp)=="CNF")
	{
		$dis=cnfper;
	}
	if(strtoupper($custtyp)=="DEALER")
	{
		$dis=$distper;
	}
	if(strtoupper($custtyp)=="SUB-DEALER")
	{
		$dis=$subdistpercentage;
	}
}





 ?>

<?php //if(isset($allinfo) && !empty($allinfo)){ print_r($allinfo);} ?>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"> Create Invoice </li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Setting Price</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
							<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
										<form target="_blank" class="form" action="<?php echo base_url(); ?>AcountsManage_Controller/updateinvoicedata" method="post" >
											<?php if(isset($allinfo) && !empty($allinfo)){ ?>
											<!--<div class="card">
													<div class="card-head style-primary">
														<header>BILLING DETAILS</header>
													</div>
													<div class="card-body floating-label">
														<div class="row">
															<div class="col-md-12">
																
																
															</div>
														</div>
													</div>
										 </div>-->
											<div class="card">
													<div class="card-head style-primary">
														<header>PARTICULARS INFORMATION</header>
													</div>
													<div class="card-body floating-label">
														<div class="row">
															<div class="col-md-12">
																<div class="col-md-6">
																	<div class="form-group">
																		<input type="text" name="mrp" class="form-control"  id="mrp" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($mainpr) && !empty($mainpr)){ echo $mainpr; } ?>" readonly />
																		<label for="mName">Product MRP Price</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="Custtype" class="form-control"  id="custvat" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($custtyp) && !empty($custtyp)){ echo $custtyp; } ?>" readonly />
																		<label for="mName">Customer Type</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="discount" class="form-control"  id="discount" placeholder="" style="text-transform: uppercase;" value="<?php if(isset($dis) && !empty($dis)) { echo $dis ; }  ?>" readonly />
																		<label for="mName">Discount</label>
																	</div>
																</div>
															</div>
														</div>
														<div class="row">
															<div class="col-md-12" style="overflow-y:scroll;">
																<div class="form-group">
																		<table class="table table-bordered table-hover">
																			<thead>
																				<tr>
																					<th>Sl No</th>
																					<th>Particulars</th>
																					<th>Chassis No</th>
																					<th>Motor No</th>
																					<th>Charger No</th>
																					<th>Battery No</th>
																					<th>Qnty</th>
																					<th>Unit Price</th>
																					<th>Total</th>
																					<th>Action</th>
																					
																				</tr>
																				
																			</thead>
																			<tbody>
																				<?php  $sl=1;
																					$tot=0;
																				 ?>
																					<?php foreach($allinfo as $row){
																						
																						$invloce=$row->invoiceno;
																						$custid=$row->custid;
																						$custtyp=$row->custtyp;
																						 ?>
																				<tr>
																					<td><?php echo $sl; ?><input type="hidden" name="rowid_<?php echo $sl; ?>" id="rowid_<?php echo $sl; ?>" value="<?php echo $row->id; ?>"/></td>
																					<td><?php echo $row->particulars."($model)"; ?><input type="hidden" name="particulars_<?php echo $sl; ?>" id="particulars_<?php echo $sl; ?>" value="<?php echo $row->particulars."($model)";  ?>"/></td>
																					<td><?php echo $row->chasisno; ?><input type="hidden" name="chassisno_<?php echo $sl; ?>" id="chassisno_<?php echo $sl; ?>" value="<?php echo $row->chasisno;  ?>"/></td>
																					<td><?php echo $row->motorno; ?><input type="hidden" name="motorno_<?php echo $sl; ?>" id="motorno_<?php echo $sl; ?>" value="<?php echo $row->motorno;  ?>"/></td>
																					<td><?php echo $row->chargerno; ?><input type="hidden" name="chargerno_<?php echo $sl; ?>" id="chargerno_<?php echo $sl; ?>" value="<?php echo $row->chargerno;  ?>"/></td>
																					<td><?php echo $row->batteryno; ?><input type="hidden" name="batteryno_<?php echo $sl; ?>" id="batteryno_<?php echo $sl; ?>" value="<?php echo $row->batteryno;  ?>"/></td>
																					<td><?php echo $qt=1; ?><input type="hidden" name="qty_<?php  echo $sl;?>" id="qty_<?php echo $sl; ?>" value="<?php echo $qt; ?>"</td>
																					<td><?php if(isset($mainpr) && !empty($mainpr)){ echo $unitpr=floatval($mainpr); } ?><input type="hidden" name="unitpr_<?php echo $sl; ?>" id="unitpr_<?php echo $sl; ?>" value="<?php echo $unitpr;  ?>"/></td>
																					<?php $tot1=floatval($unitpr) * intval($qt) ?>
																					<td><?php echo $total=number_format(round($tot1),2); ?><input type="hidden" name="total_<?php echo $sl; ?>" id="total_<?php echo $sl; ?>" value="<?php echo $tot1;  ?>"/></td>
																					<td></td>
																				</tr>
																				<?php
																				$tot=floatval($tot)+floatval($tot1);
																				
																				
																				 $sl++; }  ?>
																				<tr>
																					<td colspan="6" style="text-align:right;">Net Assesable Value</td>
																					<td><?php echo intval($sl)-1; ?></td>
																					<td></td>
																					<td><?php echo number_format($tot,2); ?><input type="hidden" name="netassbleval" id="netassbleval" value="<?php echo $tot; ?>"/></td>
																					<td></td>
																				</tr>
																				<tr>
																					<td colspan="7" style="text-align:right;"><input type="text" style="border: none;width:200px;" name="distext" id="distext" value="Discount @ " readonly/><input type="text" style="border: none;width:50px;" onblur="getoriginalval()" name="distextprcnt" id="distextprcnt" value="<?php echo $dis; ?>"/><input type="text" style="border: none;width:20px;" readonly name="distxtpercent" id="distext" value="%"/>
																						<input type="hidden" name="discountprorig" id="discountprorig" value="<?php echo $dis; ?>" />
																					</td>
																					<?php $disc=(floatval($tot) * floatval($dis))/100 ; ?>
																					<?php  $disamnt=floatval($tot)-floatval($disc) ?>
																					<td>
																						<input type="text" style="border:none;" name="nbdiscval" id="nbdiscval" value="<?php echo number_format(round($disc),2) ; ?>" readonly />
																					</td>
																					<td>
																						<input type="text" style="border:none;" name="afterdicountsval" id="afterdicountsval" value="<?php echo number_format(round($disamnt),2); ?>"  />
																					   <input type="hidden" name="dis" id="dis" value="<?php echo $dis; ?>"/>
																						<input type="hidden" name="disval" id="disval" value="<?php echo (round($disc)) ; ?>"/>
																						<input type="hidden" name="noofprod" id="noofprod" value="<?php echo $sl; ?>" />
																						<!--<input type="hidden" name="disval" id="disval" value="<?php echo (round($disc)) ; ?>"/>-->
																					</td>
																					<td></td>
																				</tr>
																				<tr>
																					<td colspan="7" style="text-align:right;">Excise Tax @ <?php echo  $excise; ?>%</td>
																					
																					<?php $exciseval=(floatval($disamnt) * floatval($excise))/100 ; ?>
																					<?php  $exisetx=floatval($disamnt)+floatval($exciseval) ?>
																					<td><input type="text" style="border:none;" readonly name="excisetx" id="excisetx" value="<?php echo number_format(round($exciseval),2) ; ?>"/></td>
																					<td>
																						<input type="text" style="border:none;" readonly name="afterexcisetx" id="afterexcisetx" value="<?php echo number_format(round($exisetx),2); ?>"/>
																						<input type="hidden" name="excisetaxpercent" id="excisetaxpercent" value="<?php echo $excise;  ?>"/>
																						<input type="hidden" name="excisetaxval" id="excisetaxval" value="<?php  echo $exciseval;  ?>"/>
																						<input type="hidden" name="afterexiceamnt" id="afterexiceamnt" value="<?php  echo $exisetx;  ?>"/>
																						<input type="hidden" name="invoice" id="invoice" value="<?php echo $invloce; ?>" />
																					</td>
																					<td></td>
																				</tr>
																				<tr>
																					<td colspan="7" style="text-align:right;">Select VAT/CST:<select name="vatcst" id="vatcst" onchange="getvatcst()"><option value="0">--select--</option><option value="<?php echo $vat."_vat"; ?>">VAT @ <?php echo $vat; ?>%</option><option value="<?php echo $cst."_cst"; ?>">CST @ <?php echo $cst; ?>%</option></select></td>
																					
																					<td><input type="hidden" name="vatpercent" id="vatpercent" value=""/>
																						
																						<input type="text" name="vatamnt" id="vatamnt" style="border:none;" readonly/></td>
																					<td><input type="text" name="aftervat" id="aftervat" style="border:none;" readonly/></td>
																					<td></td>
																				</tr>
																				<tr>
																					<td colspan="8" style="text-align:right;"><b><h4>Grand Total</h4></b></td>
																					<td><input type="text" name="gtotal" id="gtotal" style="border:none;" readonly value="<?php echo number_format((round($exisetx)),2); ?>"/>
																						<input type="hidden" name="gtotal2" id="gtotal2" style="border:none;" readonly value="<?php echo (round($exisetx)); ?>"/>
																						
																					</td>
																					<td></td>
																					
																				</tr>
																			</tbody>
																			
																			
																			
																		</table>
																</div>
															</div>
														</div>
														
													</div>
										  	</div>
										  	<div class="card">
													<div class="card-head style-primary">
														<header>TRANSPORT & OTHER INFORMATION</header>
													</div>
													<div class="card-body floating-label">
														<div class="row">
															<div class="col-md-12">
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="serialno" class="form-control"  id="serialno" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Serial No. in PLA/RG-23</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="prglrno" class="form-control"  id="prglrno" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">PR/GC Node No/L.R NO</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="mot" class="form-control"  id="mot" placeholder="" style="text-transform: uppercase;" value="" />
																		<input type="hidden" name="custid" value="<?php if(isset($custid)&& !empty($custid)){ echo $custid; } ?>"/>
																		<input type="hidden" name="custyp" value="<?php if(isset($custtyp) && !empty($custtyp)){ echo $custtyp ; }  ?>"/>
																		<label for="mName">Manner Of Transport</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="trnspname" class="form-control"  id="trnspname" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Transporter Name</label>
																	</div>
																</div>
																
																
															</div>
															
														</div>
														<div class="row">
															<hr>
														</div>
														<div class="row">
															<div class="col-md-12">
																
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="vehicleno" class="form-control"  id="vehicleno" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Vehicle No</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="drivercontact" class="form-control"  id="drivercontact" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Driver Contacts</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="despatched" class="form-control"  id="despatched" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Despatched through</label>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="text" name="date" class="form-control"  id="dte" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Date</label>
																	</div>
																</div>
																
															</div>
															
														</div>
														<div class="row">
															<hr>
														</div>
														<div class="row">
															<div class="col-md-12">
																
																<div class="col-md-3">
																	<div class="form-group">
																		<input type="date" name="dotm" class="form-control"  id="dotm" placeholder="" style="text-transform: uppercase;" value="" />
																		<label for="mName">Date & Time of Removal</label>
																		
																			    <!--<input data-format="dd/MM/yyyy hh:mm:ss" type="text" id=""></input>-->
																			    
																	</div>
																</div>
																
																
															</div>
															
														</div>
														<div class="row">
															<div class="col-md-12">
																<div class="card-actionbar">
																		<div class="card-actionbar-row">
																				<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
																		</div>
																</div>
															</div>
														</div>
													</div>
										    </div>
												
											<?php  } ?>	
												
													
										 </form>	
    						
									</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
 
<script>
	function getvatcst()
	{
		var vatcst=($("#vatcst").val());
		//alert(vatcst);
		var vatex=vatcst.split("_");
		//alert(vatex);
		var vatamnt=parseFloat(vatex[0]);
		var vattxt=vatex[1];
		
		var gtotal=parseFloat($("#afterexiceamnt").val());
		alert(gtotal);
		if(vatcst=="0")
		{
			//alert(vatcst);
			$("#vatpercent").val("");
			//alert(ctx);
			//var vatamnt=parseFloat(gtotal)*parseFloat(vatamnt)/100;
			//var gtot2=parseFloat(gtotal)+parseFloat(vatamnt);
			
			gtot23=gtotal.toFixed(2);
			$("#vatamnt").val("");
			$("#aftervat").val("");
			$("#gtotal").val(gtot23);
			$("#gtotal2").val(gtot23);
		}else
		{
			var ctx=vattxt+" @ "+vatamnt;
			$("#vatpercent").val(ctx);
			//alert(ctx);
			var vatamnt=parseFloat(gtotal)*parseFloat(vatamnt)/100;
			var gtot2=parseFloat(gtotal)+parseFloat(vatamnt);
			
			gtot23=gtot2.toFixed(2);
			$("#vatamnt").val(vatamnt);
			$("#aftervat").val(gtot23);
			$("#gtotal").val(gtot23);
			$("#gtotal2").val(gtot23);
		}
	}
	function getoriginalval()
	{
		//alert('hello');
		var distextprcnt=parseFloat($("#distextprcnt").val());
		var discountprorig=parseFloat($("#discountprorig").val());
		var netassbleval=parseFloat($("#netassbleval").val());
		var excisetaxpercent=parseFloat($("#excisetaxpercent").val());
		if(discountprorig!=distextprcnt)
		{
			var txt="Special discount @";
			$("#distext").val(txt);
		}else
		{
			var txt="Discount @";
			$("#distext").val(txt);
		}
		
		var nbdiscval=(parseFloat(netassbleval)*parseFloat(distextprcnt))/100;
		nbdiscval2=nbdiscval.toFixed(2);
		$("#nbdiscval").val(nbdiscval2);
		var afterdisvount=parseFloat(netassbleval)-parseFloat(nbdiscval);
		//alert(afterdisvount);
		afterdisvount=afterdisvount.toFixed(2);
		$("#afterdicountsval").val(afterdisvount);
		$("#dis").val(distextprcnt);
		$("#disval").val(nbdiscval);
		
		var excisetax=(parseFloat(afterdisvount)*parseFloat(excisetaxpercent))/100;
	//	alert(excisetax);
		var afterexciseamnt=parseFloat(afterdisvount)+parseFloat(excisetax);
		//alert(afterexciseamnt);
		excisetax=excisetax.toFixed(2);
		afterexciseamnt=afterexciseamnt.toFixed(2);
		$("#excisetx").val(excisetax);
		$("#afterexiceamnt").val(afterexciseamnt);
		$("#afterexcisetx").val(afterexciseamnt);
		$("#excisetaxval").val(excisetax);
		var vatcst=($("#vatcst").val());
		//alert(vatcst);
		var vatex=vatcst.split("_");
		//alert(vatex);
		var vatamnt=parseFloat(vatex[0]);
		var vattxt=vatex[1];
		
		var gtotal=parseFloat($("#afterexiceamnt").val());
		if(vatcst=="0")
		{
			//alert(vatcst);
			$("#vatpercent").val("");
			//alert(ctx);
			//var vatamnt=parseFloat(gtotal)*parseFloat(vatamnt)/100;
			//var gtot2=parseFloat(gtotal)+parseFloat(vatamnt);
			
			gtot23=Math.round(gtotal).toFixed(2);
			$("#vatamnt").val("");
			$("#aftervat").val("");
			$("#gtotal").val(gtot23);
			$("#gtotal2").val(gtot23);
		}else
		{
			var ctx=vattxt+" @ "+vatamnt;
			$("#vatpercent").val(ctx);
			//alert(ctx);
			var vatamnt=parseFloat(gtotal)*parseFloat(vatamnt)/100;
			var gtot2=parseFloat(gtotal)+parseFloat(vatamnt);
			
			gtot23=Math.round(gtot2).toFixed(2);
			$("#vatamnt").val(vatamnt);
			$("#aftervat").val(gtot23);
			$("#gtotal").val(gtot23);
			$("#gtotal2").val(gtot23);
		}
	
		
	}
</script>
