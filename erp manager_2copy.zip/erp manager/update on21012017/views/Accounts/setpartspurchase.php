<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Set Parts Purchase Price & Other Expences </li>
						</ol>

		</div>
	    <div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Set</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<?php 
											
					   ?>
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" <?php if(isset($id) && !empty($id)){  ?>  action="<?php echo base_url(); ?>Manage_price/updatemodelprice"  <?php   }else{  ?> action="<?php echo base_url(); ?>Manage_price/savemodelprice"  <?php } ?> method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>SELECT PO DATE</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-4">
										<div class="form-group">
											
										<input type="hidden"  value="" name="divnorow" id="abcd"/>
										<input type="text" name="dte" class="form-control" id="datepicker" readonly placeholder="Select Date" onblur="getallpodetails()" />
										
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											
										<input type="hidden"  value="" name="divnorow" id="abcd"/>
										<input type="text" name="podetail" class="form-control" id="podet"  placeholder="Enter Po No" onblur="getallpurcsaeprts()" />
										
										</div>
									</div>
									
									</div>
									</div>
<!--##################################################################  Get All Spare Parts  ##############################-->
									<div class="card" id="prtcard">
									
								   </div>
								</form>	
   
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
 <script>
  $( function() {
    var availableTags = [
      "GK/16/17/00033",
      "GK/16/17/00032",
      "GK/16/17/00001"
    ];
    $( "#podet" ).autocomplete({
      source: availableTags
    });
  } );
  </script> 
<script>

  $(document).ready(function(){
    $("#datepicker").datepicker({dateFormat:'yy-mm-dd'});
  });

	
	
	function getallpodetails()
	{
		var dte= $("#datepicker").val();
		if(dte=="")
		{
			alert('Choose a Date');
		}else
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getallpodetails",
  			data :{'dte':dte},
  			success : function(data){
  				 				 
  				//alert(data);
  				//$("#prtcard").show();
  				//$("#prtcard").html(data);
  				//$("#submit").show();
  				
  			  
              }  
           });
		}
	}
	function getallpurcsaeprts()
	{
		var po=$("#podet").val();
		if(po=="")
		{
			
		}else
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getallprtsprice",
  			data :{'po':po},
  			success : function(data){
  				 				 
  				//alert(data);
  				//$("#prtcard").show();
  				$("#prtcard").html(data);
  				//$("#submit").show();
  				
  			  
              }  
           });
			
		}
	}
</script>
