<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Set Model Purchase Price & Other Expences </li>
						</ol>

		</div>
	    <div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Set</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<?php 
											
					   ?>
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" <?php if(isset($id) && !empty($id)){  ?>  action="<?php echo base_url(); ?>Manage_price/updatemodelprice"  <?php   }else{  ?> action="<?php echo base_url(); ?>Manage_price/savemodelprice"  <?php } ?> method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>SELECT MODEL</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-12">
										<div class="form-group">
											
										<input type="hidden"  value="" name="divnorow" id="abcd"/>
										<select class="form-control select2-list" data-placeholder="Select an item" name="mName" id="mdole"  onchange="getallspareparts();" >
												
												<?php 
												  if(isset($model2) && !empty($model2))
												  {  ?>
												  	<option value="<?php echo $model2; ?>" selected><?php echo $model2; ?></option>
												  	
												 <?php 	if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
												  }else{ ?>
													<option value="0"></option>
													<?php  if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
												  }
												 ?>
										</select>
											<label for="mName">Model Name</label>
										</div>
									</div>
									
									</div>
									</div>
<!--##################################################################  Get All Spare Parts  ##############################-->
									<div class="card" id="prtcard">
									
											</div>
								</form>	
   
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
  $(document).ready(function(){
  	//$("#submit").hide();
  	//$("#prtcard").hide();
  	
  });
	function getallspareparts()
	{
		var model=$("#mdole").val();
		if(model==0)
		{
			$("#prtcard").html("");
			//$("#submit").hide();
			//$("#prtcard").hide();
				
		}else
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>AcountsManage_Controller/getallparts",
  			data :{'model':model},
  			success : function(data){
  				 				 
  				//alert(data);
  				//$("#prtcard").show();
  				$("#prtcard").html(data);
  				//$("#submit").show();
  			  
              }  
           });
		}
	}
	function gettotalpartspr(id)
  {
  	var idsplit=id.split("_");
  	//alert();
  	var qty=parseInt($("#qty_"+idsplit[1]).val());
  	var totrow=parseInt($("#totrow").val());
  	if(qty=="" || isNaN(qty))
  	{
  		qty=0;
  	}
  	var unitpr=parseFloat($("#sellerpr_"+idsplit[1]).val());
  	if(unitpr=="" || isNaN(unitpr))
  	{
  		unitpr=0;
  	}
  	var tot=qty*unitpr;
  	tot=tot.toFixed(2);
  	$("#tot_"+idsplit[1]).val(tot);
  	var totqt=0;
  	var totalpr=0;
  	//####################  total qty
  	for(var totr=1;totr<totrow;totr++)
  	{
  		var totqty=parseInt($("#qty_"+totr).val());
  		if(totqty=="" || isNaN(totqty))
  		{
  			totqty=0;
  		}
  		totqt=parseInt(totqt)+parseInt(totqty);
  	}
  	//####################  total Price
  	for(var totprice=1;totprice<totrow;totprice++)
  	{
  		var totalprice=parseFloat($("#tot_"+totprice).val());
  		if(totalprice=="" || isNaN(totalprice))
  		{
  			totalprice=0;
  		}
  		totalpr=parseInt(totalpr)+parseInt(totalprice);
  	}
  	//alert(totalpr);
  	totalpr=totalpr.toFixed(2);
  	//alert(totqt);
  	
  	$("#totqty").val(totqt);
  	$("#totprice").val(totalpr);
  	
  }
</script>
