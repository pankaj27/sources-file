<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>

<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $(document).(function(){
    $("#example").dataTable();
  })
  </script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		input[type="text"]{
			text-transform: uppercase;
		}
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"><?php  if(isset($title)){ echo $title; } ?></li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">
				<?php if(isset($salesman) && !empty($salesman)){
					 //print_r($salesman);
					foreach($salesman as $row)
					{
						$empid=$row->salesmanid;
						$name=$row->name;
						$email=$row->email;
						$add=$row->address;
						$phno=$row->phno;
						$whatapp=$row->whatsapp;
						$dept=$row->deprts;
						$desg=$row->desig;
						$pwd=$row->passwod;
						$salary=$row->salary;
						$image1=$row->image;
						$voter=$row->voterid;
						 $image2=$row->voterimg;
						$pan=$row->panno;
					    $image3=$row->panimg;
						$adhar=$row->adharno;
						 $image4=$row->adharimg;
						 $id=$row->id;
					}
					
					
					
					
				} ?>

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create Salesman</a></li>
								<!--<li><a href="<?php echo base_url(); ?>newBrand_controller/viewmodel">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" <?php if(isset($id) && !empty($id)){  ?> action="<?php  echo base_url();  ?>manage_salesman/updatesalesman" <?php  }else{ ?>  action="<?php  echo base_url();?>manage_salesman/savesalesman" <?php } ?>  method="post" enctype="multipart/form-data" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Create</header>
							</div>
							<div class="card-body floating-label">
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											
											<input type="text" class="form-control" id="brand" name="salesman" required value="<?php if(isset($name)){ echo $name; } ?>" >
											<input type="hidden" name="sidd" value="<?php  if(isset($id) && !empty($id)){ echo $id; } ?> />"
											<label for="brand"> Name</label>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											
											<input type="text" class="form-control" id="brand" name="" readonly value="<?php if(isset($empid) && !empty($empid)){ echo $empid ; } ?>" >
											<label for="brand"> Employee ID</label>
										</div>
									</div>
								</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="email" class="form-control" id="salemail" name="salemail" required="required" value="<?php if(isset($email)){ echo $email; } ?>">
												<label for="modelName"> Email</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<!--<input type="text" class="form-control" id="departments" name="departments" value="" required="required">-->
												<select class="form-control" name="departments">
													<option value=""></option>
													<?php if(isset($dept)  && !empty($dept)){ ?>
														<option value="<?php echo $dept; ?>" selected><?php echo $dept; ?></option>
														<?php if(isset($departments) && !empty($departments)){ ?>
													      <?php foreach($departments as $row){ ?>
														
															<option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
													
												         <?php 
														  }
														} 
														 
												 	}else{ ?>
												<?php if(isset($departments) && !empty($departments)){ ?>
													<?php foreach($departments as $row){ ?>
														
															<option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
													
												<?php } }
													}  ?>
												 </select>
												<label for="modelcode">Departments</label>
											</div>
										</div>
									</div>
									<br><br>
									
									<div class="row">
										<div class="col-md-12">
										<div class="form-group">
											<input type="text" class="form-control" id="address" name="address" value="<?php if(isset($add)){ echo $add; } ?>" >
											<label for="brand">Address</label>
										</div>
									</div>
									</div>
									<div class="row">
										<div class="col-md-6">
										<div class="form-group">
											<input type="text" class="form-control" id="desig" name="desig" required="required" value="<?php if(isset($desg)){ echo $desg; } ?>" >
											<label for="brand">Designation</label>
										</div>
									    </div>
									    <div class="col-md-6">
										<div class="form-group">
											<input type="number" class="form-control" id="phone" name="phone" required="required" maxlength="13" value="<?php if(isset($phno)){ echo $phno; } ?>" >
											<label for="brand">Phone</label>
										</div>
									    </div>
									</div>
									<div class="row">
										<div class="col-md-6">
										<div class="form-group">
											<input type="number" class="form-control" id="whatapp" name="whatapp" maxlength="13" value="<?php if(isset($whatapp)){ echo $whatapp; } ?>" >
											<label for="brand">Whatsapp No</label>
										</div>
									    </div>
									    <div class="col-md-6">
										<div class="form-group">
											<input type="password" class="form-control" id="pwd" name="pwd" required  value="<?php if(isset($pwd)){ echo $pwd; } ?>">
											<label for="brand">Password</label>
										</div>
									    </div>
									</div>
									<div class="row">
										<div class="col-md-12">
										<div class="form-group">
											<input type="number" class="form-control" id="area" name="salary" required="required" value="<?php if(isset($salary)){ echo $salary; } ?>" >
											<label for="brand">Salary</label>
										</div>
									    </div>
									    
									</div>
									<div class="row">
										<div class="col-md-3">
											Image
									   </div>
										<div class="col-md-6">
										
											<input type="file" class="form-control" id="imgInp" name="image1" >
											<input type="hidden" name="image1ed" value="<?php  if(isset($image1) && !empty($image1)){ echo $image1;  } ?>" />
											<!--<label for="brand">Upload Image</label>-->
										</div>
									   
									    <div class="col-md-3">
									    	<div class="form-group">
												<img id="blah" <?php if(isset($image1) && !empty($image1)){ ?> src="<?php echo base_url(); ?>uploads/Salesman/<?php echo $image1; ?>" <?php }else{ ?>  src="<?php echo base_url(); ?>assets/favicon/anonymous-man.png" <?php } ?>  alt="your image" width="150" height="150"/>
											</div>
									    </div>
									    
									</div>
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
											<input type="text" class="form-control"  name="voterid"  value="<?php if(isset($voter)){ echo $voter; } ?>" >
											<label for="brand">Voter ID No</label>
										</div>
									   </div>
										<div class="col-md-6">
										<div class="form-group">
											<input type="file" class="form-control" id="imgInp1" name="image2"  >
											<input type="hidden" name="image2ed" value="<?php  if(isset($image2) && !empty($image2)){ echo $image2;  } ?>" />
											
										</div>
									    </div>
									    
									    <div class="col-md-3">
									    	<div class="form-group">
												<img id="blah1" <?php if(isset($image2) && !empty($image2)){ ?> src="<?php echo base_url(); ?>uploads/Salesman/<?php echo $image2; ?>" <?php }else{ ?>  src="<?php echo base_url(); ?>assets/favicon/imagebr.png" <?php } ?>  alt="your image" width="150" height="150"/>
											</div>
									    </div>
									</div>
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
											<input type="text" class="form-control"  name="panno"  value="<?php if(isset($pan)){ echo $pan; } ?>" >
											<label for="brand">Pan Card (If Any)</label>
										</div>
									   </div>
										<div class="col-md-6">
										<div class="form-group">
											<input type="file" class="form-control" id="imgInp2" name="image3"  >
											<input type="hidden" name="image3ed" value="<?php  if(isset($image3) && !empty($image3)){ echo $image3;  } ?>" />
											<label for="brand"></label>
										</div>
									    </div>
									    
									    <div class="col-md-3">
									    	<div class="form-group">
												<img id="blah2" <?php if(isset($image3) && !empty($image3)){ ?> src="<?php echo base_url(); ?>uploads/Salesman/<?php echo $image3; ?>" <?php }else{ ?>  src="<?php echo base_url(); ?>assets/favicon/imagebr.png" <?php } ?>   alt="your image" width="150" height="150"/>
											</div>
									    </div>
									</div>
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
											<input type="text" class="form-control"  name="adharno" value="<?php if(isset($adhar)){ echo $adhar; } ?>"  >
											<label for="brand">Adhar No(If Any)</label>
										</div>
									   </div>
										<div class="col-md-6">
										<div class="form-group">
											<input type="file" class="form-control" id="imgInp3" name="image4"  >
											<input type="hidden" name="image4ed" value="<?php  if(isset($image4) && !empty($image4)){ echo $image4;  } ?>" />
											<label for="brand"></label>
										</div>
									    </div>
									    
									    <div class="col-md-3">
									    	<div class="form-group">
												<img id="blah3" <?php if(isset($image4) && !empty($image4)){ ?> src="<?php echo base_url(); ?>uploads/Salesman/<?php echo $image4; ?>" <?php }else{ ?>  src="<?php echo base_url(); ?>assets/favicon/imagebr.png" <?php } ?> alt="your image" width="150" height="150"/>
											</div>
									    </div>
									</div>
									
									
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>
								
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						    	</div>
							    	
							    	
							    	
							</div>
				</div>
				</form>	
         
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLvoter(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLpan(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah2').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLadhar(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah3').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#imgInp").change(function(){
        readURL(this);
    });
    $("#imgInp1").change(function(){
        readURLvoter(this);
    });
    $("#imgInp2").change(function(){
        readURLpan(this);
    });
    $("#imgInp3").change(function(){
        readURLadhar(this);
    });
</script>
