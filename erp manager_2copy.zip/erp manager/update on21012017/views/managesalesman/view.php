<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			
		}
		#example tr{
			line-height:5px;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"><?php echo $title; ?></li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View all Employeelist</a></li>
								<!--<li><a href="<?php// echo base_url(); ?>newBrand_controller/modelEntry">Create</a></li>>-->
								<!--<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1" style="overflow-x: scroll;">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
                <th>EMPLOYEE NAME</th>
                <th>EMPLOYEE ID</th>
                <th>DESIGNATION</th>
                <th>DEPARTSMENT</th>
                <th>CONTACTS</th>
                <th>LOGIN DETAILS</th>
                <th>AREA</th>
				 <th>IMAGE</th>
				 <th>STATUS</th>
				 
				 <th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($salesman) && !empty($salesman)){  $i=1; ?>
				
				
			<?php foreach($salesman as $row){ ?>
				
				<?php  $add=$row->address; $email=$row->email;$pwd=$row->passwod;$phno=$row->phno;$wht=$row->whatsapp  ?>
            <tr>
               <th><?php echo $i ?> </th>
                <th><?php echo $row->name; ?></th>
                <th><?php echo $row->salesmanid; ?></th>
                <th><?php echo $row->desig; ?></th>
                <th><?php echo $row->deprts; ?></th>
                
                <th><?php echo"<b>Address:</b> $add<br>" ?>
                	<i class="fa fa-phone"></i><?php echo $phno;  ?><br>
                	<i class="fa fa-whatsapp"></i><?php echo $phno;  ?><br>
                	<i class="fa fa-message"></i><?php echo $email;  ?><br>
                	
                </th>
                <th>Username:<?php echo $email; ?><br>
                	Password:<?php echo $pwd; ?>
                </th>
                <th><?php echo $row->area; ?></th>
                <th><img width="70" height="70" src="<?php echo base_url(); ?>uploads/Salesman/<?php echo $row->image; ?>" style="border-radius:50%;" ></th>
                <td><?php $st=$row->status;if($st==1){ echo "<img src='".base_url()."assets/img/green.png' width='40' height='40' />" ; }else{ echo "<img src='".base_url()."assets/img/red.png' width='40' height='40' />"; } ?></td>
				<td>
					<input type="hidden" name="sid_<?php echo $i; ?>" value="<?php echo $row->id; ?>" id="sid_<?php echo $i; ?>"/>
					<button type="button" id="button_<?php echo $i; ?>" class="btn btn-flat btn-primary ink-reaction" onclick="getstatus(this.id);"><i class="fa fa-toggle-on" aria-hidden="true"></i></button>
					<a href="<?php echo base_url(); ?>Manage_salesman/editemployee/<?php echo $row->id; ?>" class="tooltip-success">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-info"><i class="ace-icon fa fa-times bigger-125">-->
					<button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
					
					<a href="<?php echo base_url(); ?>Manage_salesman/deletesalesman/<?php echo $row->id; ?>" class="tooltip-success">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-info"><i class="ace-icon fa fa-times bigger-125">-->
					<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-flat btn-primary ink-reaction"></i><i class="fa fa-trash" aria-hidden="true"></i></button></a>
														
				</td>
            </tr>
            <?php $i++; } } ?>
        </tbody>
    </table>
				</div>
				</form>	


						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->

		</div><!--end .section-body -->
	</section>
	<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
<script>
	function getstatus(id)
	{
		var idsplit=id.split("_");
		var sid=$("#sid_"+idsplit[1]).val();
		 $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url(); ?>Sales_Controller/acticedeactive",
  			data :{'sid':sid},
  			success : function(data){
  				//console.log(data); 
				alert(data);
				window.location.reload();				
  				//alert('Data Inserted Successful');
				
              }  
           }); 	
	}
</script>
