<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />
	<!--jQuery-->
<?php  //require_once(base_url().'Purchase_controller');$purchase=new Purchase_controller();$purchase->gethell();?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	
<?php $con=mysqli_connect("localhost","root","","erp_manager"); ?>	
<style>
	header{
		color:white;
	}
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			font-size: 10px;
			font-weight: normal;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			height:44px;
		}
		tr{
			text-align: center;
		}
		
		#exmple3 td{
			width:150px;
		}
		#exmple4 td{
			width:250px;
		}
		#exmple5 td{
			width:300px;
		}
		#exam td{
			width:400px;
		}
		#example8 td{
			width:40px;
		}
		
	</style>			

	<!-- BEGIN BASE-->
	<div id="base">
		<div id="content">
						
	<section>

		<!-- BEGIN INBOX -->
		<div class="section-body">
			<div class="row">
				
				<!-- BEGIN TODOS -->
				<div class="col-md-12">
					<div class="card card-bordered">
						<div class="card-head">
							<header style="color:black;">Create New Purchase Order</header>
							
						</div><!--end .card-head -->
						<!--end .card-body -->
					</div><!--end .card -->
				</div><!--end .col -->
								
			</div>
			<div class="row">
				
				<!-- BEGIN TODOS -->
				<div class="col-md-3">
					<div class="card ">
						<div class="card-head card-head-xs style-primary">
							<header>Products</header>
							
						</div><!--end .card-head -->
						<div class="card-body no-padding height-9 scroll" style="overflow-y: scroll;">
							<ul class="list divider-full-bleed">
<!--  #################################################################################################################################################  -->
<!--  #                                                            Start of products Dropdown And Modal popup                                           #    -->
<!--  ################################################################################################################################################# -->			

								
								<?php if(isset($getallproduct)){ $x=1;;
						    foreach($getallproduct as $row){
							  $productid=$row->id;
							 ?>
					     
					     <li class="tile"><a id="product__<?php echo $x; ?>" href="javascript:product_test(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#simpleModal_<?php echo $x; ?>">
					     	<div class="tile-content">
										<div class="tile-icon">
											<i class="fa fa-arrows" aria-hidden="true"></i>
										</div>
										<div class="tile-text"><?php echo $row->productname; ?></div>
							</div>
					     	
					     	</a>
					     </li>
					    
					     <!-- BEGIN SIMPLE MODAL MARKUP -->
							<div class="modal fade" id="simpleModal_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
								<div class="modal-dialog modal-lg">
									<div class="modal-content">
										<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
													<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
														<?php //$res=new Purchase_controller();
							
																$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
							
																<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
							
																<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
							
										</div>
										<div class="modal-body">
											<div class="row">
												<div class="col-md-9"><div class="col-md-3"><h4>Total Quantity:-</h4></div><div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqty_<?php echo $x; ?>" name="productqty"  placeholder="Required No Of Quantity" onblur="getmodelqty(this.id);" ></div></div></div>
													<table id="example8"><thead><tr><th colspan="10">Specify Quantity for Different Color</th></tr></thead>
														<tr>
															<?php if(isset($getcolorcode)){ $colorcode=1;
																		foreach($getcolorcode as $rowcolor)
															{ ?>
																<td><input type="text" id="colorqty_<?php echo $x; ?>_<?php echo $colorcode;  ?>" style="text-align:center;width:85px;background-color: <?php echo $rowcolor->code_hex; ?>;color:white;font-weight:bold;" onkeyup="getcolorquantity(this.id)"/></td>
															<?php $colorcode++;  }
															}   ?>
															
														</tr>
													</table>
												<div class="col-md-9">
													<div class="col-md-3"><h4>Rest Of Quantity:-</h4></div>
													<div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqtycolor_<?php echo $x; ?>" name="productqty"  readonly></div></div>
												</div>
										  </div>
										     <input type="hidden" value="<?php echo $colorcode; ?>" id="colorcode">
											<input type="hidden" name="modelid" value="<?php echo $row->productid; ?>" id="modid_<?php echo $x ;  ?>"/>
											<input type="hidden" name="modelnme" value="<?php echo $row->productname; ?>" id="modname_<?php echo $x;  ?>"/>
							
											<br>
												<table id="example5" style="width:100%;">
								<thead><tr><th colspan="6">Spare Parts Used For <?php  echo $row->productname ; ?> </th></tr></thead>
								<tr>
									<td><b>Sl No.</b></td>
									<td><b>Parts ID</b></td>
									<td><b>Parts Name</b></td>
									<td><b>Specification</b></td>
									<td>Qnty</td>
									<td><b>Action</b></td>
								</tr>
								<?php //if(isset($allmaterial) && !empty($allmaterial)){$m=1; ?>
									<?php $querymater=mysqli_query($con,"select * from materiel_master where mName='".trim($row->productname)."'"); ?>
									<?php $nomate=mysqli_num_rows($querymater); ?>
									<?php if($nomate >0) {$m=1;  ?>
									<?php while($row1=mysqli_fetch_array ($querymater)){ ?>
									
									<?php //foreach($allmaterial as $row1){ ?>
									     <tr>
											<td><?php echo $m; ?><input type="hidden" id="lastmodelqty_<?php echo $m ; ?>" </td>
											<td><?php echo $mat=$row1['materiel_id'] ;  ?></td>
											<td><?php echo $row1['materialname'] ;  ?></td>
											<td>
												
												<?php $query=mysqli_query($con,"select * from spareparts_specification where parts_id='".trim($mat)."'");  ?>
												<?php $norow=mysqli_num_rows($query); ?>
							
							 					<?php if($norow>0){ ?>
													<select id="specification_<?php echo $x; ?>_<?php echo $m; ?>" onblur="addspecification(id,<?php echo $x; ?>);"><option value="">--select Specification--</option>
													<?php while($row=mysqli_fetch_array($query)){ ?>
													<option value="<?php echo $row['id']; ?>"><?php echo $row['specification']; ?></option> 
													
										         <?php  } ?>
										        </select>
												<?php	} ?>
												
												
											</td>
											<td><input type="text" readonly style="text-align: center;font-weight: bold;" id="ptsap_<?php echo $x.'_'.$m; ?>" name="ptsap_<?php echo $x.'_'.$m; ?>" value="<?php echo $row1['unit']; ?>"/>
												<input type="hidden" style="text-align: center;font-weight: bold;" id="ptsaphidden_<?php echo $x.'_'.$m; ?>" name="ptsap_<?php echo $x.'_'.$m; ?>" value="<?php echo $row1['unit']; ?>"/>  </td>
											<td>
												<label class="checkbox-inline checkbox-styled checkbox-primary">
											         <input type="checkbox" value="<?php echo $mat;  ?>" id="req_<?php echo $x; ?>_<?php echo $m ; ?>" checked="" name="val[]"><span>Required</span>
										        </label>
											</td>
								</tr>
									
									<?php $m++; } ?>
										<input type="hidden" name="partnosp" id="partssp_<?php echo $x; ?>" value="<?php echo $m; ?>"/>
									<?php  }else{ ?>
										
										<tr><td colspan="5" style="text-align: center;color: red;font-style: italic;font-weight: bolder;">Spare Pats Not Available</td></tr>
										
								<?php	} ?>
									
								
							</table>
							
						</div>
						<div class="modal-footer">
							<input type="hidden" id="notr" value="<?php echo $m; ?>"/>
							<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
							<button type="button" class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetails(this.id,<?php echo $x; ?>)">SUBMIT</button>
						</div>
					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div><!-- /.modal -->
			<!-- END SIMPLE MODAL MARKUP -->

					 <?php $x++;  } } ?>
<!--  #################################################################################################################################################  -->
<!--  #                                                            End Of products Dropdown And Modal popup                                           #    -->
<!--  ################################################################################################################################################# -->			
							</ul>
						</div><!--end .card-body -->
					</div><!--end .card -->
				</div><!--end .col -->
				<!-- END TODOS -->
				
				<!-- BEGIN REGISTRATION HISTORY -->
				<form action="<?php echo base_url(); ?>Purchase_controller/save_purchaseorder" method="post" class="form">
				<div class="col-md-6">
					<div class="card">
						<div class="card-head card-head-xs style-primary">
							<header>Purchase order summery </header>
							
						</div><!--end .card-head -->
						<div class="card-body floating-label height-9">
							<div  class="row">
								
						<div class="col-md-6 col-lg-6">
							
							
							<div class="form-group floating-label">
											<input type="text" class="form-control" id="Firstname2" name="pono" value="<?php if(isset($purchaseorder)){ echo $purchaseorder; } ?>" >
											
											<label for="Firstname2">P.O No</label>
											
							</div>
							<div class="form-group">
											<div class="inputr"></div>
											
							</div>
							<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="dte" value="<?php echo date('Y-m-d') ?>" >
											<label for="Firstname2">Date</label>
							</div>
							<div class="form-group">
											<input type="text" class="form-control" id="refno" name="refno" value="<?php if(isset($refno)){ echo $refno ; } ?>">
											<label for="Firstname2">Ref No</label>
							</div>
						</div>
					</div>
							
					<div class="row">

						<div class="col-md-12 col-lg-12">
							<table id="example" cellspacing="0" width="100%">
        						<thead>
            							<tr>
            								<th>Sl No.</th>
                							<th>Products Id </th>
                							<th>Name</th>
                							<th>Model ID</th>
                							<th>Model Name</th>
                							<th>Quantity</th>
                							<th>Action</th>
            							</tr>
        						</thead>
        
        						<tbody>
        	
            							<tr>
                							<td></td>
                							<td></td>
                							<td></td>
                							<td></td>
                							<td></td>
                							<td></td>
                							<td></td>
           								 </tr>
           
        						 </tbody>
   					 	</table>
   					 	<input type="hidden" name="numofrows" id="tbalerow"/><input type="hidden" name="vendorid[]" id="vendorid">
						</div><!--end .col -->
						<!-- END EMAIL CONTENT -->

					</div><!--end .row -->
					<hr class="ruler-xxl">
					<div class="row">
						<div class="col-md-12 col-lg-12">
							<div class="col-md-6 col-lg-6">
							<div class="form-group">
									<select class="form-control select2-list" data-placeholder="Select an vendors" name="vendors" onblur="getvendorsid();" id="vendor">
										<option value="">Select Vendors</option>
										<?php if(isset($allvendors)){ ?>
											<?php foreach($allvendors as $row){ ?>
										   <option value="<?php echo $row->vender_id; ?>"><?php echo strtoupper($row->vcompany); ?></option>
										<?php  }} ?>
									</select>
									<!--<label>Select Vendors</label>-->
								</div>
							
						</div>
						<div class="col-md-3 col-lg-3">
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" id="submit1" class="btn ink-reaction btn-raised btn-primary">Submit</button>
								</div>
							</div>
							
						</div>
						
						</div>
						<div  class="row" id="getvendors">
						 
					    </div>
						
						
					</div>
  								
							<div class="stick-bottom-left-right force-padding">
								<div id="flot-registrations" class="flot height-5" data-title="Registration history" data-color="#0aa89e"></div>
							</div>
						</div><!--end .card-body -->
					</div><!--end .card -->
				</div><!--end .col -->
				<div class="col-md-3">
					<div class="card">
						<div class="card-head card-head-xs style-primary">
							<header>Spare Parts</header>
							
						</div><!--end .card-head -->
						<div class="card-body no-padding height-9 scroll" style="overflow-y: scroll;">
							<ul class="list divider-full-bleed">
								<li class="tile">
									
										<div class="tile-text">
											<?php if(isset($getallproduct)){ ?>
					 								<select name="modelname" id="modelname" class="form-control select2-list" onchange="getallspareparts();"><option value="">--select model--</option><?php foreach($getallproduct as $row){ ?><option value="<?php echo $row->productid."_".$row->	productname ; ?>"><?php echo $row->	productname; ?></option> <?php } ?></select>
					 						<?php } ?></div>
									
									
								</li>
								</ul>
								<div id="prts">
								<ul class="list divider-full-bleed">
								<?php if(isset($allmaterial)){ $i=1; ?>
							<?php foreach($allmaterial as $row){ 
								$diff=$row->diff;
								$reoder=$row->reorderlevel; ?>
								
							 <li   class="tile" title="<?php  echo $row->materialname."(".$row->qnty.")";  ?>">
							 	<a  id="item_<?php echo $i; ?>" href="javascript:anchor_test(<?php echo $row->id; ?>)" >
							 	 <div class="tile-content">
										<div class="tile-icon">
											<i class="fa fa-crosshairs" aria-hidden="true"></i>
										</div>
										<div class="tile-text" <?php if($diff<$reoder){ ?> style="color:red;font-weight: bold;"  <?php } ?>><small><?php  echo $row->materialname;  ?> (<?php echo $row->qnty;  ?>)</small></div>
									</div>
							   </a>
							 	</li>
							 	<!--<li <?php if($diff<$reoder){?> class="btn btn-block ink-reaction btn-danger" <?php } ?> title="<?php  echo $row->materialname."(".$row->qnty.")";  ?>"><a  id="item_<?php echo $i; ?>" href="#" data-toggle="modal" data-target="#myModal_<?php echo $i;  ?>" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small><?php  echo $row->materialname;  ?> (<?php echo $row->qnty;  ?>)</small></a></li>-->
							
							
								
							
						<?php  $i++; } } ?>
								
							</ul>
							</div>
						</div><!--end .card-body -->
					</div><!--end .card -->
				</div><!--end .col -->
				<!-- END REGISTRATION HISTORY -->
				
				<!-- BEGIN NEW REGISTRATIONS -->
				
				<!-- END NEW REGISTRATIONS -->
				
			</div>
			
			
		</div><!--end .section-body -->
		<!-- END INBOX -->
  </form>
		<!-- BEGIN SECTION ACTION -->
		<!--end .section-action -->
		<!-- END SECTION ACTION -->

	</section>

		</div><!--end #content-->		
		<!-- END CONTENT -->
          
		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>login_assets/jquerymodal/js/jquery.modal.js"></script>

<script>
$(window).load(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
 
 $("#submit1").hide();
 //$(".decimal-2-places").numeric({ decimalPlaces: 2 });
});
function anchor_test(id)
{
	//var idsplit=id.split("_");
	var id1=id;
	var matid1="matid";
	var model=$("#modelname").val();
	if(model==""){
		 //alert("Please Select Model Name");
		 modal({
				type: 'warning',
				title: 'Message!',
				text: '<h4><b>Please Select Model Name</b></h4>',
			});
			
			
	}else{
	var rowCount = $('#example tr').length;
	var modelsplit=model.split("_");
	var modelid=modelsplit[0];
	var modelname=modelsplit[1];
	var tr=rowCount-2;
	var tr2=tr+1;
	$("#tbalerow").val(tr2);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Purchase_controller/getdetails_purchase",
  			data :{'id':id1},
  			success : function(data){
  				//alert('hello');
  				var json=JSON.parse(data);
  				
  				var matid=json.matid;
  				//alert(matid);
  				var matname=json.matname;
  				//$("#matid").val(matid);
  				$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+ matid+'<input type="hidden" name="matid_'+tr2+'" value="'+matid+'"/></td><td>'+ matname +'<input type="hidden" name="matname_'+tr2+'" value="'+matname+'"/></td><td>'+modelid+'<input type="hidden" value="'+modelid+'" id="modelid_'+tr2+'"/></td><td>'+modelname+'<input type="hidden" value="'+modelname+'" id="modelname_'+tr2+'"/></td><td><input style="width:50px;" required type="text" id="matqty12_'+tr2+'" name="matqty_'+tr2+'" onkeyup="getqtyval(this.id)" /> </td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='matid_"+tr2+"' value='"+matid+"'/>");
  			    
  			    $('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			     $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' />");
              }  
           });
     //alert(matid);
	
	}
	//alert('hello');
	//alert(id);
	//$('#example tr:last').after('<tr><td>'+ tr2 +'</td><td>'+ matid1+'</td><td>'+ matname1 +'</td><td><input type="text" name="matqty" /> </td><td><button>Delete</button></td></tr>');
}
function getvendorsid()
{
	
	var vendors=$("#vendor").val();
	var venid=$("#vendorid").val();
	if(vendors=="")
	{
		$("#submit1").hide();
	}else{
		$("#submit1").show();
	}
	if(venid=="")
	{
		var vend=[];
		vend.push(vendors);
		vend.toString();
		$("#vendorid").val(vend);
	}else
	{
		var vend=venid.split(" ");
		vend.push(vendors);
		vend.toString();
		$("#vendorid").val(vend);
		
	}
	
	//vendors_id.toString();
	//console.log(vendors_id);
	//alert(vend);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Purchase_controller/getvender_list",
  			data :{'vendors':vendors},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				
  				var vcompany=json.vcompany;
  				var venderlastrans=json.venderlastrans;
  				var purchasedate=json.lastrandt;
  				var qatationno=json.lastquatation;
  				var purchaseorderno=json.purchaseorder;
  				var vender_id=json.vender_id;
  			    var branch2=json.branch2;
  			    var bankswift2=json.bankswift2;
  			    var bankifsc2=json.bankifsc2;
  			    var bankacc2=json.bankacc2;
  				var bankname2=json.bankname2;
  				var branch1=json.branch1;
  				var bankswift1=json.bankswift1;
  				var bankifsc1=json.bankifsc1;
  				var bankacc1=json.bankacc1;
  				var bankname1=json.bankname1;
  				var contactphno2=json.contactphno2;
  				var contactemail2=json.contactemail2;
  				var contactname2=json.contactname2;
  				var contactphno1=json.contactphno1;
  				var contactemail1=json.contactemail1;
  				var vender_id=json.vender_id;
  				var vemail=json.vemail;
  				var vphone=json.vphone;
  				var add1=json.add1;
  				var cst=json.cst;
  				var vat=json.vat;
  				var country=json.country;
  				var contact1=json.contact1;
  				
  				
  				 				
  				 $("#getvendors").append('<div class="col-md-12" id="vendlst_'+vender_id+'"><div class="card"><div class="card-head card-head-xs style-primary"><header>'+ vcompany +'</header><div class="tools"><a class="btn btn-icon-toggle btn-close" id="close_'+vender_id+'" onclick="closediv(this.id)"><i class="fa fa-close"></i></a></div></div><div class="card-body"><div class="col-md-6"><b>Last Trans. Date:-</b>'+purchasedate+' </div><div class="col-md-6"><b>Quatation No:-</b>'+qatationno+' </div><div class="col-md-6"><b>Amount:-</b>'+venderlastrans+'</div><div class="col-md-6"><b>Purchase Order NO:-</b>'+purchaseorderno+'</div><div class="col-md-6"><b>Balance:-</b>'+venderlastrans+'</div><div class="col-md-6"><button type="button" data-toggle="modal" data-target="#myModal" class="btn ink-reaction btn-xs btn-info">View Details</button></div></div></div></div><div class="modal fade" id="myModal" role="dialog"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">'+vcompany+'</h4><h5><i>Vendor,s Id:-'+vender_id +'</i></h5></div><div class="modal-body"><table id="exmple3"><thead><tr><th colspan="7">Company Information</th></tr></thead><tbody><tr><td><b>ID<b></td><td><b>Name</b></td><td><b>Address</b></td><td></b>Phno</b></td><td><b>Country</b></td><td></b>CST</b></td><td><b>VAT</b></td></tr><tr><td>'+vender_id+'</td><td>'+vcompany+'</td><td>'+add1+'</td><td>'+vphone+'</td><td>'+country+'</td><td>'+cst+'</td><td>'+vat+'</td></tr></tbody></table><hr><table id="exmple4"><thead><tr><th colspan="7">Contact Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Name</b></td><td><b>Email </b></td><td><b>Phno</b></td></tr><tr><td><b>1.<b></td><td>'+contact1+'</td><td>'+contactemail1+'</td><td>'+contactphno1+'</td></tr><tr><td><b>2.<b></td><td>'+contactname2+'</td><td>'+contactemail2+'</td><td>'+contactphno2+'</td></tr></tbody></table><hr><table id="exmple3"><thead><tr><th colspan="7">Bank Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Bank Name</b></td><td><b>Bank Account No </b></td><td><b>Branch Name</b></td><td><b>IFSC CODE</b></td><td><b>SWIFT CODE</b></td></tr><tr><td><b>1<b></td><td>'+bankname1+'</td><td>'+bankacc1+'</td><td>'+branch1+'</td><td>'+bankifsc1+'</td><td>'+bankswift1+'</td></tr><tr><td><b>2<b></td><td>'+bankname2+'</td><td>'+bankacc2+'</td><td>'+branch2+'</td><td>'+bankifsc2+'</td><td>'+bankswift2+'</td></tr></tbody></table><hr><table id="exmple3"><thead><tr><th colspan="7">Last Transaction Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Quatation No</b></td><td><b>PI No. </b></td><td></b>Date</b></td><td></b>Dr.</b></td><td></b>Cr.</b></td><td></b>Balance</b></td></tr><tr><td><b>1<b></td><td>'+qatationno+'</td><td>'+purchaseorderno+'</td><td>'+purchasedate+'</td><td>'+venderlastrans+'</td><td></td><td>'+venderlastrans+'</td></tr></tbody><table></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div><div>');
  				
  			  
              }  
           });
          
	//alert(vendors);
	// $("#getvendors").append('<div class="col-lg-3 col-sm-6"><div class="card"><div class="card-head card-head-xs style-primary"><header>XS header</header><div class="tools"><a class="btn btn-icon-toggle btn-close"><i class="fa fa-close"></i></a></div></div><div class="card-body">Rather have larger or smaller card headers? There are 4 different sizes.<blockquote><small>card-head-xs, card-head-sm, regular, card-head-lg</small></blockquote></div></div></div>');
	//alert(vendors);
	//alert('hello');

}
function deletetrrow(id)
{
	var idsplit=id.split("_");
	var result=confirm("Want to delete?");
	//alert(result);
	if(result==true)
	{
		//alert(this);
		//$(this).closest('tr').remove();
		$(".getrow_"+idsplit[1]).css("background-color","#a94442");

		$(".getrow_"+idsplit[1]).fadeOut(400, function(){
			$(".getrow_"+idsplit[1]).remove();
		});
	}
	// alert('hello');
}
function product_test(id)
{
	//alert('hello');
}
function closediv(id)
{
	var idsplit=id.split("_");
	//alert(idsplit);
	var result=confirm("Want to Delete?");
	if(result==true)
	{
		
		//alert(this);
		//$(this).closest('tr').remove();
		//$("#vendlst_"+idsplit[1]).css("background-color","#a94442");

		//$("#vendlst_"+idsplit[1]).fadeOut(400, function(){
			
		//});
	}
	alert('hello');
}
function getpartsdetails(id,divid)
{
	var idsplit=id.split("_");
	var ds=divid;
	var notr=$("#notr").val();
	alert(notr);
	//var notr1=notr-1;
	
	var req="";
	for(var c=1;c<notr;c++)
	{
		var prtsqty=$("#ptsap_"+ds+"_"+c).val();
		//alert(prtsqty);
		if($("#req_"+ds+"_"+c).prop('checked') == true){
			req +=$("#req_"+ds+"_"+c).val()+"@"+prtsqty+"||";
    
         }
		
	}
	var color="";
	for(var d=1;d<11;d++)
	{
		gettot=$("#colorqty_"+ds+"_"+d).val();
		if(gettot=="")
		{
			
		}else
		{
			color +=$("#colorqty_"+ds+"_"+d).val()+"->"+d+"#";
		}
	}
	 //alert(req);
	var modelid=$("#modid_"+idsplit[1]).val();
	var modelname=$("#modname_"+idsplit[1]).val();
	var prqty=$("#productqty_"+idsplit[1]).val();
	//$('.inputr').append("<input type='text'");
  			    
     //$('.inputr').append("<input type='text' name='modelname_"+tr2+"' value='"+modelname+"'/>");
    // $('.inputr').append("<input type='text' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prqty+"' />");
    // $('.inputr').append("<input type='text'/>");
	//alert(modelid);
	//alert(modelname);;
	//alert(color);
	
	var rowCount = $('#example tr').length;
	var tr=rowCount-2;
	var tr2=tr+1;
	$("#tbalerow").val(tr2);
	//var rew=$("#product_spec").val(req);
	//alert(req);
	$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td><input type="hidden" name="productspec" value="'+req+'" id="productspec_'+tr2+'"  /><input type="hidden" name="matid_'+tr2+'" value=""/></td><td><input type="hidden" name="" value=""/></td><td>'+modelid+'<input type="hidden" value="'+modelid+'" id="modelid_'+tr2+'"/></td><td>'+modelname+'<input type="hidden" value="'+modelname+'" id="modelname_'+tr2+'"/></td><td><input style="width:50px;" required type="text" name="matqty_'+tr2+'" value="'+prqty+'" /> </td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
	$('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='modelid1_"+tr2+"' value='"+modelid+"'/>");
  			    
  $('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
   $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' value='"+prqty+"' />");
   $('.inputr').append("<input type='hidden' name='specification_"+tr2+"' value='"+req+"' />");
   $('.inputr').append("<input type='hidden' name='colorspe_"+tr2+"' value='"+color+"' />");
   
   
   
   
	// $('.inputr').append("<input type='text'/>");
	//$('.inputr').append("<input type='text'");
}
function addspecification(id,spd)
{
	var idsplit=id.split("_");
	var divis=spd;
	var specification=$("#specification_"+divis+"_"+idsplit[2]).val();
	//alert(specification);
	var req=$("#req_"+divis+"_"+idsplit[2]).val();
	req += '_'+specification;

//str += ' ' + 'and some more blah';
$("#req_"+divis+"_"+idsplit[2]).val(req);
	//alert(req);
}
function gettotal_qty(id)
{
	var idsplit=id.split("_");
	var totqt=$("#totqnty_"+idsplit[1]).val();
	var totrow=$("#totrow").val();
	var tot=0;
	for(var f=1;f<totrow; f++)
	{
		var vt=$("#totqnty_"+f).val();
		if(vt=="")
		{
			vt=0;
			
		}
		tot=tot+parseInt(vt);
	}
	//alert(totqt);
	$("#totcolorqnty").val(tot);
	
}
function getqtyval(id)
{
	//alert('hello');
	var idsplit=id.split("_");
	//var txt="hello";var 
	//var txt=5;
	var rest=$("#matqty12_"+idsplit[1]).val();
	//alert(rest);
	$("#prqty1_"+idsplit[1]).val(rest);
}
function getmodelqty(id)
{
	var idsplit=id.split("_");
	var idx=idsplit[1];
	var noqty=$("#productqty_"+idsplit[1]).val();
	var partssp=parseInt($("#partssp_"+idsplit[1]).val());
	for(var c=1;c<partssp;c++)
	{
		var ptaqty=$("#ptsap_"+idx+"_"+c).val();
		var hidpty=$("#ptsaphidden_"+idx+"_"+c).val();
		 if(noqty=="")
		 {
		 	$("#ptsap_"+idx+"_"+c).val(hidpty);
		 }else
		 {
		 	var noqty1=parseInt(noqty)*parseInt(ptaqty);
		    $("#ptsap_"+idx+"_"+c).val(noqty1);
		 }
		
		//alert(ptaqty);
	}
	//alert(idx);
	//alert(noqty);
	
}

function getcolorquantity(id)
{
	var idsplit=id.split("_");
	var divmodalid=idsplit[1];
	var tot=0;var gettot;
	var colorcdno=$("#colorcode").val();
	for( var n=1;n<colorcdno;n++)
	{
		
		gettot=$("#colorqty_"+divmodalid+"_"+n).val();
		if(gettot=="")
		{
			gettot=0;
			
		}
		tot=tot+parseInt(gettot);
		//alert(tot);
	}
	var existtot=$("#productqty_"+divmodalid).val();
	if(existtot==""){existtot=0;}
	var resttot=parseInt(existtot)-parseInt(tot);
	if(resttot==0){resttot="";}
	if(resttot<0)
	{
		alert('please type right number of quantity');
		
	}else{
		
		$("#productqtycolor_"+divmodalid).val(resttot);
	}
	//alert(resttot);
	
	//alert(resttot);
	//if(resttot==0)
	//{
		
	//}
	
}
function getallspareparts()
{
	//alert('hello');
	var modelname=$("#modelname").val();
	var idsplit=modelname.split("_");
	var modcode=idsplit[0];
	var modnam=idsplit[1];
	//alert(modnam);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Purchase_controller/getallspare_parts_sort_by_modelname",
  			data :{'modcode':modcode,'modnam':modnam},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#prts").html(data);
  			  
              }  
           });
}
</script>