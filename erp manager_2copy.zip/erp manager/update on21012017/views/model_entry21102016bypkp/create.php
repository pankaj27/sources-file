<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $(document).(function(){
    $("#example").dataTable();
  })
  </script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">New Model Entry</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">New Entry</a></li>
								<!--<li><a href="<?php echo base_url(); ?>newBrand_controller/viewmodel">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" action="<?php echo base_url(); ?>newBrand_controller/save_new_stock"  method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Information</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-12">
										<div class="form-group">
											<!--<select class="form-control select2-list" data-placeholder="Select an item" name="brand">
												<option value=""></option>
												<option value="g5red">G5(Red)</option>
												<option value="g5green">G5(Green)</option>
												<option value="g5blue">G5(Blue)</option>
												   <option value="k9red">K9(Red)</option>
											</select>
											<label>Brand</label>-->
											<input type="text" class="form-control" id="brand" name="brand" value="GK" readonly>
											<label for="brand">Brand Name</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="modelName" name="modelName" required="required">
												<label for="modelName">Model Name</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="modelcode" name="modelcode" value="<?php if(isset($modelcodes)){ echo $modelcodes; } ?>" readonly>
												<label for="modelcode">Model Code</label>
											</div>
										</div>
									</div>
									<br><br>
									<div class="card-head style-primary">
										<header>Battery Information</header>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="batteryPower" name="batteryPower" required="">
												<label for="batteryPower">Battery Power</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="batteryModel" name="batteryModel">
												<label for="batteryModel">Battery Model</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="clsModel" name="clsModel">
												<label for="clsModel">Class of Model</label>
											</div>
										</div>
									</div>
									<br><br>
									<div class="card-head style-primary">
										<header>Price Information</header>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="disPric_excld" name="disPric_excld" required="required">
												<label for="disPric_excld">Distributer Price (Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="disPric_incld" name="disPric_incld" required="required">
												<label for="disPric_incld">Distributer Price (Including Battery):</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="dis2subPric_excld" name="dis2subPric_excld" required="required">
												<label for="dis2subPric_excld">Distributer to sub-distributer Price (Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="dis2subPric_incld" name="dis2subPric_incld" required="required">
												<label for="dis2subPric_incld">Distributer to sub-distributer Price (Including Battery):</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="sub2dis_excld" name="sub2dis_excld" required="required">
												<label for="sub2dis_excld">Sub-Distributer To Retailer Price(Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="sub2dis_incld" name="sub2dis_incld" required="required">
												<label for="sub2dis_incld">Sub-Distributer To Retailer Price(Including Battery):</label>
											</div>
										</div>
									</div>
									<br><br>
									<div class="card-head style-primary">
										<header>Tax Information</header>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="vat" name="vat">
												<label for="vat">Vat % :</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="Sales" name="Sales">
													<label for="Sales">Sales % :</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="Road" name="Road">
												<label for="Road">Excise Tax:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="cst" name="cst">
													<label for="cst">CST</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="Road" name="custom">
												<label for="Road">Custom duty:</label>
											</div>
										</div>
										<!--<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="cst" name="cst">
													<label for="cst">CST</label>
												</div>
										</div>-->
									</div>
									<div class="card-head style-primary">
										<header>Others Information</header>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="servpaid" name="servpaid">
												<label for="servpaid">Service Paid:</label>
											</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="servday" name="servday">
													<label for="servday">Service Days/Km :</label>
												</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="motorPower" name="motorPower">
													<label for="motorPower">Motor Power:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="seatcap" name="seatcap">
												<label for="seatcap">Seat. Capacity:</label>
											</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="grossvhc" name="grossvhc">
													<label for="grossvhc">Gross Vhc. Wt:</label>
												</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="bodyType" name="bodyType">
													<label for="bodyType">Types of Body:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<!--<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="fuelUsed" name="fuelUsed">
												<label for="fuelUsed">Fuel used:</label>
											</div>
										</div>-->
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="mfgYear" name="mfgYear">
													<label for="mfgYear">Mfg. Year :</label>
												</div>
										</div>
										<!--<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="unLoadwt" name="unLoadwt">
													<label for="unLoadwt">Unloaden Weight:</label>
												</div>
										</div>-->
									</div>
									<div class="row">
										<!--<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="octrail" name="octrail">
												<label for="octrail">Octrai No :</label>
											</div>
										</div>-->
									</div>
									
									
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>
								
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						    	</div>
							    	<!--<div class="col-md-6">
							    		<div class="card">
							<div class="card-head style-primary">
								<header>Contact Information</header>
							</div>
							<div class="card-body floating-label">
					              <div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactname1">
											<label for="Firstname2">Contact Name1</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="email" class="form-control" id="Lastname2" name="contactemail1">
											<label for="Lastname2">Contact Email1</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactphno1">
											<label for="Firstname2">Contact Phno1</label>
										</div>
									</div>
									
								</div>
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactname2">
											<label for="Firstname2">Contact Name2</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="email" class="form-control" id="Lastname2" name="contactemail2" >
											<label for="Lastname2">Contact Email2</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactphno2"> 
											<label for="Firstname2">Contact Phno2</label>
										</div>
									</div>
									
								</div>
								
								
							</div><!--end .card-body -->
							
						<!--</div>
							    	<!--</div>-->
							    	<div class="col-md-12">
							    		<div class="card">
							<!--<div class="card-head style-primary">
								<header>Bank  & Company Information</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bank1">
											<label for="Firstname2">Bank Name</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankac1">
											<label for="Lastname2">Bank A/c NO.</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankifsc1">
											<label for="Firstname2">IFSC Code</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankswift1">
											<label for="Lastname2">Swift Code</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankbr1">
											<label for="Firstname2">Branch Name</label>
										</div>
									</div>
									
								</div>
								 
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bank2">
											<label for="Firstname2">Bank Name</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankac2">
											<label for="Lastname2">Bank A/c NO.</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankifsc2">
											<label for="Firstname2">IFSC Code</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankswift2">
											<label for="Lastname2">Swift Code</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankbr1">
											<label for="Firstname2">Branch Name</label>
										</div>
									</div>
									
								</div>
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											
											<label for="Firstname2"><b>Company Information:</b></label>
										</div>
									</div>
									
								</div>
								
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="cstno">
											<label for="Firstname2">CST No:</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="vatno">
											<label for="Lastname2">VAT No</label>
										</div>
									</div>
								</div>
								 
								
					              
							</div><!--end .card-body -->
							
						</div>
							    	</div>
							    	<div class="col-md-12">
							    		<div class="card">
							<!--<div class="card-head style-primary">
								<header>Suppiler Product Information</header>
							</div>
							<div class="card-body floating-label">
								 <div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											<div class="col-md-12">
											<?php $k=1;   for($i=1;$i<10;$i++){ ?>
											  <?php if($k<10){ ?>
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" name="material[]" value="materiel_<?php echo $i;  ?>"><span></span>Material<?php echo $i; ?>
												</label>
											</div>
											
											
											<?php $k++; } } ?>
											</div>
										     </div>
										
										
									</div>
								</div>
								<hr class="ruler-xxl">
								<div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											<div class="col-md-12">
											<?php $k=1;   for($i=1;$i<10;$i++){ ?>
											  <?php if($k<10){ ?>
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" name="product[];" value="product_<?php echo $i; ?>"><span></span>Product<?php echo $i; ?>
												</label>
											</div>
											
											
											<?php $k++; } } ?>
											</div>
										     </div>
										
										
									</div>
								</div>
					              
							</div><!--end .card-body -->
							<!--<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>-->
						</div>
							    	</div>
							</div>
				</div>
				</form>	
         <div class="tab-pane" id="second1"><table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
                <th>MODEL NAME</th>
                <th>MODEL CODE</th>
                <th>BATTERY POWER</th>
                <th>BATTERY MODEL</th>
                <th>FUEL USED</th>
                <th>MFG. YEAR</th>
				 <th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($model)){  $i=1; ?>
			<?php foreach($model as $row){ ?>
            <tr>
               <th><?php echo $i ?> </th>
                <th><?php echo $row->productname; ?></th>
                <th><?php echo $row->productid; ?></th>
                <th><?php echo $row->batteryPower; ?></th>
                <th><?php echo $row->batteryModel; ?></th>
                <th><?php echo $row->fuelUsed; ?></th>
                <th><?php echo $row->mfgYear; ?></th>
				<td><a href="<?php echo base_url();?>newBrand_controller/editModelEntry/<?php echo $row->id;  ?>" class="tooltip-success">
							 <!--<button type="button" class="btn btn-sm btn-success"><i class="ace-icon fa fa-check">-->
							 <button type="button" class="btn btn-flat btn-primary ink-reaction"></i> Edit</button></a>
					&nbsp;&nbsp;									
					<a href="<?php echo base_url(); ?>newBrand_controller/deleteModelEntry/<?php echo $row->id; ?>" class="tooltip-success">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-info"><i class="ace-icon fa fa-times bigger-125">-->
					<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-flat btn-primary ink-reaction"></i>Delete</button></a>
														
				</td>
            </tr>
            <?php $i++; } } ?>
        </tbody>
    </table>
	</div>
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							<div class="tab-pane" id="third1"><p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p><p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p></div>
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
