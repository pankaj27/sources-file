<div class="ino navbar-form">
    <div id="navigation_bar"   class="col-sm-12 col-xs-12 col-md-10 col-md-offset-2 mainbar">
     <div id="header_top_quick_nav" class='hidden-xs' >
      <ul class="list-group inline_list">
       <li role="presentation"><i class="fa fa-toggle-left clickable right_bar_navigation_menu" title="Toggle Navigation Menu"></i></li>
       <li role="presentation"><a  href="#"><i class="fa fa-home" title="Home"></i></a></li>
       <li role="presentation"><a   href=""><i class="fa fa-info" title="Messages"></i></a></li>
       <li role="presentation"><a   href="<?php echo base_url(); ?>login"><i class="fa fa-dashboard" title="Dashborad"></i></a></li>
       <!--<li role="presentation"><i class="fa fa-gears right-click-menu clickable" title="Actions"></i></li>-->
       <li role="presentation"><a  class="erp-links search-list-page" href="#"><i class="fa fa-search" title="Search & List Page"></i></a></li>
       <li role="presentation"><a  class="erp-links form-page" href="#"><i class="fa fa-list-alt" title="Form Page"></i></a></li>
       <li id="unsaved_fields" data-no_of_fields="0"></li>
       <li class="show_loading_small">
        <div class="ino-spinner ino-sm" >
         <div class="rect1" style="background-color:#1f6dad"></div>
         <div class="rect2" style="background-color:#1f6dad"></div>
         <div class="rect3" style="background-color:#1f6dad"></div>
         <div class="rect4" style="background-color:#1f6dad"></div>
         <div class="rect5" style="background-color:#1f6dad"></div>
        </div>
       </li>
      </ul>
     </div>
     
     
   </div>