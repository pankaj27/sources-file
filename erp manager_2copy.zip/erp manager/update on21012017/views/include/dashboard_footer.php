<div class="list_filter row">  
    <div class="col-md-3 col-sm-3  form-group">
     <span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
     <input type="text" class="form-control field_name" name="field_name">
    </div>  
    <div class="col-md-2 col-sm-2  form-group">   
     <select class="condition_name form-control" name="condition_name">    <option value="=">=</option>    
      <option value="">Like</option>    <option value="&gt;=">&gt;=</option>    
      <option value="&lt;=">&lt;=</option>    <option value="&gt;">&gt;</option>    <option value="&lt;">&lt;</option>    
      <option value="IN">In</option>    <option value="!=">!=</option>   </select>  
    </div>  
    <div class="col-md-3 col-sm-3">
     <div class="form-group control">
      <input type="text" class="input-with-feedback form-control condition_value" name="condition_value"  data-fieldtype="Link" data-fieldname="name">
     </div>
    </div>  
    <div class="col-md-4 col-sm-4  condition_action">
     <button class="button btn btn-success apply-filter" type="submit"  name="applyFilter">Apply</button>  
     <button class="button btn btn-info add-element" name="addElement"> + </button> 
     <button class="button btn btn-info remove-element" name="removeElement"> - </button> 
    </div>  
   </div>