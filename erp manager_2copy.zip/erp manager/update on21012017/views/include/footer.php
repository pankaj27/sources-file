<!--  Load JavaScrips-->
   <script src="<?php echo base_url(); ?>template_assets/includes/js/jquery-2.0.3.min.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/includes/js/jquery-ui.min.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/tparty/bootstrap/js/bootstrap.min.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/tparty/bootstrap/js/menu.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/includes/js/custom/tinymce/tinymce.min.js"></script>
   <!--<script type="text/javascript" src="includes/basics/js_control.php"></script>-->
   <script src="<?php echo base_url(); ?>template_assets/includes/js/save.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/includes/js/custom_plugins.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/includes/js/basics.js"></script>
   <script src="<?php echo base_url(); ?>template_assets/themes/default/js/theme.js"></script>
   