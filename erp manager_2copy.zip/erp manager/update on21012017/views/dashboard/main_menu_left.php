		<!-- BEGIN MENUBAR-->
		<?php
		$user=$this->session->userdata('user_name');
		
		?>
		<div id="menubar" class="menubar-inverse animate">
			<div class="menubar-fixed-panel">
				<div>
					<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
						<i class="fa fa-bars"></i>
					</a>
				</div>
				<div class="expanded">
					<a href="<?php echo base_url(); ?>">
						<span class="text-lg text-bold text-primary "><?php echo $sd=$this->session->userdata('user_name');  ?></span>
					</a>
				</div>
			</div>
			<div class="nano has-scrollbar">
				<div class="nano-content" >
			<div class="menubar-scroll-panel" >
				<!-- BEGIN MAIN MENU -->
				



<ul id="main-menu" class="gui-controls" style="overflow: auto;">
	<!-- BEGIN DASHBOARD -->
	<li>
		<a href="<?php echo base_url(); ?>" id="dash">
			<div class="gui-icon"><i class="fa fa-home"></i></div>
			<span class="title"><?php $sd=$this->session->userdata('user_name'); ?></span>
		</a>
	</li><!--end /menu-li -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-truck"></i></div>
			<span class="title">Master Entry</span>
		</a>
		<!--start submenu -->
		<ul>
			
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/modelEntry" ><span class="title">Model Entry</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/viewmodel" ><span class="title">View Model</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/sparePartsEntry" ><span class="title">Spare Parts Entry</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/viewspareparts" ><span class="title">View Spareparts</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/newsparepartsenry" ><span class="title">Spare Parts Entry</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/newsparepartsentry" ><span class="title">New  Spareparts</span></a></li>
            <li><a href="<?php echo base_url(); ?>colourManage_controller/addColour"><span class="title">Add Model Colour</span></a></li>
			<li><a href="<?php echo base_url(); ?>colourManage_controller/viewcolour" ><span class="title">View Model Colour</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>Venders_controller/createVenders"  ><span class="title">Create Vendors</span></a></li>
			<li id="viewVenders"><a href="<?php echo base_url(); ?>Venders_controller/viewvendors" ><span class="title">View Vendors</span></a></li>
			<!--<li><a href="<?php echo base_url(); ?>Manage_price/modelprice"><span class="title">Add Model Price</span></a></li>-->
			
			<li><a id="createVenders" href="<?php echo base_url(); ?>Manage_distributer/createnew"  ><span class="title">Create Customer</span></a></li>
			<li id="viewVenders"><a href="<?php echo base_url(); ?>Manage_distributer" ><span class="title">View Customer</span></a></li>
			<li id="viewVenders"><a href="<?php echo base_url(); ?>AcountsManage_Controller/createtax"><span class="title">Create Sales Taxation</span></a></li>
			<li id="viewVenders"><a href="<?php echo base_url(); ?>AcountsManage_Controller/vioewtaxtaion"><span class="title">Edit/View Sales Taxation</span></a></li>


		</ul><!--end /submenu -->
	</li>
	
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-users" aria-hidden="true"></i></div>
			<span class="title">Vendor Master</span>
		</a>
		<!--start submenu -->
		<ul>
			
		</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-shopping-cart" aria-hidden="true"></i></div>
			<span class="title">Purchase Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>Purchase_controller/createNew" id="purchaseorder" ><span class="title">Purchase Order</span></a></li>

			<li><a href="<?php echo base_url(); ?>Purchase_controller/viewquotation" ><span class="title">view Quotation List</span></a></li>
			<li><a href="<?php echo base_url(); ?>Purchase_controller/viewpilist" ><span class="title">PO List</span></a></li>
    	</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	<?php if($user=="admin" || $user=="stock"){ ?>
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-list" aria-hidden="true"></i></div>
			<span class="title">Stock Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<!--<li><a href="<?php echo base_url(); ?>stockManage_controller/createNew" id="purchaseorder" ><span class="title">Stock Entry(PO No)</span></a></li>-->
            <li><a href="<?php echo base_url(); ?>stockManage_controller/stockpreentry" ><span class="title">Stock Entry</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/stockentrybox" ><span class="title">Stock Entry(Box)/PO No</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallstockentry" ><span class="title">View Stock Entry</span></a></li>
			<!--<li><a href="<?php echo base_url(); ?>stockManage_controller/checkingstock" ><span class="title">checking Stock</span></a></li>-->
			<!--<li><a href="<?php echo base_url(); ?>stockManage_controller/purchaseorder" ><span class="title">Order/Transf</span></a></li>-->
			<li><a href="<?php echo base_url(); ?>stockManage_controller/purchaseorder_new" ><span class="title">Order New/Transf. New</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallorderlist" ><span class="title">View Transf/Order</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/checkinggetpass" ><span class="title">Checking Gatepass</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallstock" ><span class="title">View All Stock</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewmodelstock" ><span class="title">View Stock Model</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/bxwsestock" ><span class="title">Boxwise Stockentry</span></a></li>
			
    	</ul>
	</li><!--end /menu-li -->
	<?php } ?>
	<?php if($user=="admin" || $user=="accounts"){ ?>
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-balance-scale" aria-hidden="true"></i></div>
			<span class="title">Accounts Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/accounts" id="purchaseorder" ><span class="title">Accounts</span></a></li>
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/cash_entry" id="purchaseorder" ><span class="title">Cash/Cheque Entry</span></a></li>
			<!--<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/viewpurchaseprice" id="purchaseorder" ><span class="title">View Purchase Price</span></a></li>-->
			
			<!--<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/setmodelprice" id="purchaseorder" ><span class="title">Set Model Purchase Price</span></a></li>
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/getpartspurchaseprice" id="purchaseorder" ><span class="title">Set Parts Purchase Price(PO NO)</span></a></li>-->
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/createinvoice" id="purchaseorder" ><span class="title">Create Invoice</span></a></li>
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/viewreceiptamnt" id="purchaseorder" ><span class="title">View Receipt Amnount</span></a></li>
			<li><a href="<?php echo base_url(); ?>Bankinfo_Controller/creat" id="" ><span class="title">Creat Bank Info</span></a></li>
			<li><a href="<?php echo base_url(); ?>Bankinfo_Controller/viewinfo" id="" ><span class="title">View Bank Info</span></a></li>
			<li><a href="<?php echo base_url(); ?>Accounts_controller/viewinfo" id="" ><span class="title">Tax Liabilities</span></a></li>
			
			
			<!--<li><a href="<?php echo base_url(); ?>stockManage_controller/stockentrybox" ><span class="title">Stock Entry(Box)</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallstockentry" ><span class="title">View Stock Entry</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/checkingstock" ><span class="title">checking Stock</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/purchaseorder" ><span class="title">Order/Transf</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/purchaseorder_new" ><span class="title">Order New/Transf. New</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallorderlist" ><span class="title">View Transf/Order</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/checkinggetpass" ><span class="title">Checking Gatepass</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallstock" ><span class="title">View All Stock</span></a></li>-->
    	</ul>
	</li><!--end /menu-li -->
	<?php  }  ?>
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-university" aria-hidden="true"></i></div>
			<span class="title">Manufacturer Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>Manufactarer_Controller/craeteModel" id="purchaseorder" ><span class="title">Create Model</span></a></li>
			<li><a href="#" id="purchaseorder" ><span class="title">Show Stock </span></a></li>
		</ul>
	</li><!--end /menu-li -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-book" aria-hidden="true"></i></div>
			<span class="title">Booking Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>Bokking_controller/createorder" id="" ><span class="title">Creat Booking</span></a></li>
			<!--<li><a href="<?php echo base_url(); ?>Manage_price/fixedprice"><span class="title">Create New Booking</span></a></li>-->
			<li><a href="<?php echo base_url(); ?>Bokking_controller/createretailbooking"><span class="title">Create Retail Booking</span></a></li>
		    <!--<li><a href="<?php echo base_url(); ?>Manage_price/viewfixedprice" ><span class="title">View Model Price</span></a></li>
			<li><a href="<?php echo base_url(); ?>Manage_price/sparepartsprice"><span class="title">Add Spareparts price</span></a></li>
			<li><a href="<?php echo base_url(); ?>Manage_price/viewspareprtspr" ><span class="title">View Spareparts Price</span></a></li>
	    	
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/vieworder" id="purchaseorder" ><span class="title">View All sales Order</span></a></li>
			<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/viewsalesorder" id="purchaseorder" ><span class="title">View Sales Order</span></a></li>
			
			<li><a href="<?php echo base_url(); ?>sales_Controller/vieworder" id="purchaseorder" ><span class="title">View Current Booking</span></a></li>
			<li><a href="<?php echo base_url(); ?>Sales_Controller/sales_terget" ><span class="title">Set Sales Terget</span></a></li>-->
    	</ul>
	</li><!--end /menu-li -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-th-large" aria-hidden="true"></i></div>
			<span class="title">Sales Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>Manage_price/fixedprice"><span class="title">Add Model Price(Back Cal.)</span></a></li>
		    <li><a href="<?php echo base_url(); ?>Manage_price/viewfixedprice" ><span class="title">View Model Price</span></a></li>
			<li><a href="<?php echo base_url(); ?>Manage_price/sparepartsprice"><span class="title">Add Spareparts price</span></a></li>
			<li><a href="<?php echo base_url(); ?>Manage_price/viewspareprtspr" ><span class="title">View Spareparts Price</span></a></li>
			<li><a href="<?php echo base_url(); ?>Sales_Controller/sparepartsprice" ><span class="title">Print Sparepats Price</span></a></li>
			<li><a href="<?php echo base_url(); ?>Sales_Controller/printallmodelprice" target="_blank" ><span class="title">Print Modelprice List</span></a></li>
	    	
			
			<li><a href="<?php echo base_url(); ?>sales_Controller/vieworder" id="purchaseorder" ><span class="title">View Current Booking</span></a></li>
			<li><a href="<?php echo base_url(); ?>Sales_Controller/sales_terget" ><span class="title">Set Sales Terget</span></a></li>
			<li><a href="<?php echo base_url(); ?>Sales_Controller/incentive_slab" ><span class="title">Edit/View Incentive Slab</span></a></li>
  
    	</ul>
	</li><!--end /menu-li -->
	
         <li class="gui-folder">
			<a>
				<div class="gui-icon"><i class="fa fa-user-plus" aria-hidden="true"></i></div>
				<span class="title">HR Manager</span>
			</a>
			<!--start submenu -->
			<ul>
				<li><a href="<?php echo base_url(); ?>Manage_salesman/create"><span class="title">Create Employee</span></a></li>
				<li><a href="<?php echo base_url(); ?>Manage_salesman/view" ><span class="title">View Employeelist</span></a></li>
	    	</ul><!--end /submenu -->
	    </li><!--end /menu-li -->
	    <li class="gui-folder">
			<a>
				<div class="gui-icon"><i class="fa fa-bar-chart" aria-hidden="true"></i></div>
				<span class="title">Manage Report</span>
			</a>
			<!--start submenu -->
			<ul>
				<li class="gui-folder">
					<a   href="javascript:void(0);" href="<?php echo base_url(); ?>Manage_salesman/create"><span class="title">Sales Executive Report</span></a>
					 <ul>
										<li><a href="<?php echo base_url(); ?>Manage_report/salesexecutivereport"><span class="title">Visiting Report</span></a></li>
										<li><a href="<?php echo base_url(); ?>"><span class="title">Planning report</span></a></li>
								</ul><!--end /submenu -->
					
				</li>
				
				<li><a href="<?php echo base_url(); ?>Manage_salesman/view" ><span class="title">View Employeelist</span></a></li>
	    	</ul><!--end /submenu -->
	    </li><!--end /menu-li -->
	  <!--  <li class="gui-folder">
			<a>
				<div class="gui-icon"><i class="fa fa-money" aria-hidden="true"></i></div>
				<span class="title">Price Master</span>
			</a>
			<!--start submenu -->
			<!--<ul>
				<li><a href="<?php echo base_url(); ?>Manage_price/modelprice"><span class="title">Add Model Price</span></a></li>
				<li><a href="<?php echo base_url(); ?>Manage_price/viewprice" ><span class="title">View Model Price</span></a></li>
				<li><a href="<?php echo base_url(); ?>Manage_price/sparepartsprice"><span class="title">Add Spareparts price</span></a></li>
				<li><a href="<?php echo base_url(); ?>Manage_price/viewspareparts" ><span class="title">View Spareparts Price</span></a></li>
	    	
	    	</ul><!--end /submenu -->
	  <!--  </li><!--end /menu-li -->
	    <li class="gui-folder">
			<a>
				<div class="gui-icon"><i class="fa fa-money" aria-hidden="true"></i></div>
				<span class="title">Cashier</span>
			</a>
			<!--start submenu -->
			<ul>
				<li><a href="<?php echo base_url(); ?>AcountsManage_Controller/vieworder" id="purchaseorder" ><span class="title">View All sales Order</span></a></li>
			    <li><a href="<?php echo base_url(); ?>AcountsManage_Controller/viewsalesorder" id="purchaseorder" ><span class="title">View Sales Order</span></a></li>
			
	    	</ul><!--end /submenu -->
	    </li><!--end /menu-li -->
	<!-- END UI -->
	
	<!-- BEGIN TABLES -->
	
	
	<!-- BEGIN FORMS -->
	
	<!-- BEGIN PAGES -->
	
	<!-- BEGIN CHARTS -->
	
	<!-- END CHARTS -->
	
	<!-- BEGIN LEVELS -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-folder-open fa-fw"></i></div>
			<span class="title">Demo</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="#"><span class="title">Item 1</span></a></li>
			<li><a href="#"><span class="title">Item 1</span></a></li>
			<li class="gui-folder">
				<a href="javascript:void(0);">
					<span class="title">Open level 2</span>
				</a>
				<!--start submenu -->
				<ul>
					<li><a href="#"><span class="title">Item 2</span></a></li>
					<li class="gui-folder">
						<a href="javascript:void(0);">
							<span class="title">Open level 3</span>
						</a>
						<!--start submenu -->
						<ul>
							<li><a href="#"><span class="title">Item 3</span></a></li>
							<li><a href="#"><span class="title">Item 3</span></a></li>
							<li class="gui-folder">
								<a href="javascript:void(0);">
									<span class="title">Open level 4</span>
								</a>
								<!--start submenu -->
								<ul>
									<li><a href="#"><span class="title">Item 4</span></a></li>
									<li class="gui-folder">
										<a href="javascript:void(0);">
											<span class="title">Open level 5</span>
										</a>
										<!--start submenu -->
										<ul>
											<li><a href="#"><span class="title">Item 5</span></a></li>
											<li><a href="#"><span class="title">Item 5</span></a></li>
										</ul><!--end /submenu -->
									</li><!--end /submenu-li -->
								</ul><!--end /submenu -->
							</li><!--end /submenu-li -->
						</ul><!--end /submenu -->
					</li><!--end /submenu-li -->
				</ul><!--end /submenu -->
			</li><!--end /submenu-li -->
		</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	<!-- END LEVELS -->
	
</ul><!--end .main-menu -->
				<!-- END MAIN MENU -->

				
			</div><!--end .menubar-scroll-panel-->
			
		</div>	
	</div>
		</div><!--end #menubar-->
		<!-- END MENUBAR -->
