				
	
<style>
	
</style>
	
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
	<section>
		<div class="section-body">
			<div class="row">
				<center><h1>WELCOME TO GKRICKSHAW PVT LTD</h1></center>
				<br>
				<center><img src="<?php echo base_url(); ?>assets/logo/logo.png" ></center>
			</div>
			
			
		</div><!--end .section-body -->
	</section>

		</div><!--end #content-->		
		<!-- END CONTENT -->
