<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>

<?php $this->load->view('dashboard/top_offcanvas.php'); ?>			
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- BEGIN OFFCANVAS RIGHT -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
