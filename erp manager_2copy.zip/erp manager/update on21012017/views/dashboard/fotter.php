		
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/jquery/jquery-1.11.2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/jquery/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/spin.js/spin.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/autosize/jquery.autosize.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/core/cache/ec2c8835c9f9fbb7b8cd36464b491e73.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/jquery-knob/jquery.knob.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/nanoscroller/jquery.nanoscroller.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/core/cache/43ef607ee92d94826432d1d6f09372e1.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/rickshaw/rickshaw.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/core/cache/63d0445130d69b2868a8d28c93309746.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/core/demo/Demo.js"></script>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/core/demo/DemoDashboard.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="<?php echo base_url(); ?>assets/preloading/js/vendor/jquery-1.9.1.min.js"><\/script>')</script>
	<script src="<?php echo base_url(); ?>assets/preloading/js/main.js"></script>

	
	<!-- END JAVASCRIPT -->

	
	
	</body>
</html>
<script src="<?php echo base_url(); ?>assets/js/modules/materialadmin/libs/jquery/jquery-1.11.2.min.js"></script>
  <!-- noty -->
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/notify/js/noty/packaged/jquery.noty.packaged.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/notify/notification_html.js"></script>

   <script type="text/javascript">

  
   </script>

<script>
	/*function highlightMatching() {
    var index = $(".gui-controls .active").index();
    $(".gui-controls a").each(function() {
        $(this).children("li").removeClass("highlight").eq(index)
            .not(".active").addClass("highlight");
    });
}

highlightMatching();

$(".gui-controls li a").click(function() {
    $(".gui-controls li ").removeClass("active");
    $(this).closest("li").addClass("active");
    $(this).closest("li a").addClass("active");
    highlightMatching();
    return(false);
}); */
$(window).load(function() {
	
    
	var notification_html = [];

    notification_html[1] = '<div class="activity-item"> <i class="fa fa-check text-success"></i> <div class="activity"> Mail server was updated. See <a href="#">changelog</a> <span>About 2 hours ago</span> </div> </div>',
    notification_html[2] = '<div class="activity-item"> <i class="fa fa-heart text-danger"></i> <div class="activity"> Your <a href="#">latest post</a> was liked by <a href="#">Audrey Mall</a> <span>35 minutes ago</span> </div> </div>',
    notification_html[3] = '<div class="activity-item"> <i class="fa fa-shopping-cart text-success"></i> <div class="activity"> <a href="#">Eugene</a> ordered 2 copies of <a href="#">OEM license</a> <span>14 minutes ago</span> </div> </div>';

	setInterval(function(){
		
		var id=1;
				$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Notify_controller/get_quatationstatus",
  			data :{'id':id},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				var vid=json.stat;
  				
  				
  			  // generateAll();
  			 
  			  if(parseInt(vid)>0)
  			  {
  			  	console.log(vid);
  			  	var av=$("#not").html("<sup class='badge style-danger'>"+vid+"</sup>");
  			  	 notification_html[3] = '<div class="activity-item"> <i class="fa fa-shopping-cart text-success"></i> <div class="activity"> <a href="#">One User Send You A quotation</a>  <a href="#">OEM license</a> <span>@ 2016-12-10</span> </div> </div>';
  			     generate('success', notification_html[3]);
  			  }
  			  else
  			  {
  			  	console.log(vid);
  			  	var av=$("#not").html("");
  			  }
  			  
              }  
           });
		
		}, 500);
		 function generate(type, text) {
           
            var n = noty({
                text        : text,
                type        : type,
                dismissQueue: true,
                layout      : 'bottomRight',
                closeWith   : ['click'],
                theme       : 'relax',
                maxVisible  : 5,
                animation   : {
                    open  : 'animated bounceInRight',
                    close : 'animated bounceOutRight',
                    easing: 'swing',
                    speed : 500
                }
            });
            console.log('html: ' + n.options.id);
        }
        

        
        

});
function stat12()
	{
		//alert('hello');
		var id=1;
				$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Notify_controller/setstatus",
  			data :{'id':id},
  			success : function(data){
  				//alert(data);
  				//$("#not").html(data);
  			   // generateAll();
              }  
           });
	}
        
</script>

<!--Script by hscripts.com-->

<!--Script by hscripts.com-->

<script type="text/javascript">
/*Edit the message as your wish*/
/*var msg_box ="Right click disabled in this page"; function dis_rightclickIE(){
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3))
alert(msg_box)
}
function dis_rightclickNS(e){
if ((document.layers||document.getElementById&&!document.all) && (e.which==2||e.which==3))
{
alert(msg_box)
return false;
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=dis_rightclickNS;
}
else if (document.all&&!document.getElementById){
document.onmousedown=dis_rightclickIE;
}
document.oncontextmenu=new Function("alert(msg_box);return false")*/
</script>
<!-- Script by hscripts.com -->

