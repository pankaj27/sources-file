<!DOCTYPE html>
<html lang="en">



	<head>
		<title>ERP-Manager</title>
		
		<!-- BEGIN META -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="your,keywords">
		<meta name="description" content="Short explanation about this website">
		<!-- END META -->
        
		<!-- END STYLESHEETS -->
		<!-- BEGIN STYLESHEETS -->
		    <link rel="shortcut icon" type="image/png" href="<?php echo base_url(); ?>assets/favicon/favicon-96x96.png"/>
            <!--<link rel="shortcut icon" type="image/png" href="<?php echo base_url(); ?>assets/favicon/favicon.ico"/>-->
			<link href='http://fonts.googleapis.com/css?family=Roboto:300italic,400italic,300,400,500,700,900' rel='stylesheet' type='text/css'/>
			<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/modules/materialadmin/css/theme-default/bootstrap.css?1422823238" />

			<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/modules/materialadmin/css/theme-default/materialadmin.css?1422823243" />

			<!--<link type="text/css" rel="stylesheet" href="assets/css/modules/materialadmin/css/theme-default/font-awesome.min.css?1422823239" />-->
			<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

			<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/modules/materialadmin/css/theme-default/material-design-iconic-font.min.css?1422823240" />

	
		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/modules/materialadmin/css/theme-default/libs/rickshaw/rickshaw.css?1422823372" />

		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/modules/materialadmin/css/theme-default/libs/morris/morris.core.css?1422823370" />
       <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/notify/buttons.css"/>-->
   			 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/notify/animate.css"/>
    		<!--<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css"/>-->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
	<script type="text/javascript" src="assets/js/modules/materialadmin/libs/utils/html5shiv.js?1422823601"></script>
	<script type="text/javascript" src="assets/js/modules/materialadmin/libs/utils/respond.min.js?1422823601"></script>
    <![endif]-->
	</head>


	
	