<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php include('connection.php'); ?>


  
  
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $(document).(function(){
    $("#example").dataTable();
  })
  </script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"><?php  if(isset($title)){ echo $title; } ?></li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">
				

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<!--<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create Salesman</a></li>
								<!--<li><a href="<?php// echo base_url(); ?>newBrand_controller/viewmodel">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							<!--</ul>
						</div>--><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="row">
									<div class="col-md-12">
											<div class="card tabs-right style-default-light">
																		<ul class="card-head nav nav-tabs text-center" data-toggle="tabs">
																		<li class="active"><a href="#second7"><i class="fa fa-lg fa-clock-o"></i><br><h4>Achieve<br><small>Target</small></h4></a></li>
																		<li class=""><a href="#second8"><i class="fa fa-lg fa-clock-o"></i><br><small></small><h4>Sales Executive<br>Tour Plane<br><small>Monthwise/</small><br><small>Day by Day</small></h4></a></li>
																		<!--<li class=""><a href=""><i class="fa fa-lg fa-user"></i><br><h4>Profile<br><small>Personal details</small></h4></a></li>
																		<li class=""><a href=""><i class="fa fa-lg fa-clock-o"></i><br><h4>History<br><small>About us</small></h4></a></li>-->
																		
												</ul>
												<div class="card-body tab-content style-default-bright">
													<div class="tab-pane" id="first6">			
														<h3 class="text-light">Daniel <strong>Johnson</strong></h3>
														
														<p>
															Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Dicant vituperata consequuntur.</p>
									
														<dl class="dl-horizontal">
															<dt>Description lists</dt>
															<dd>A description list is perfect for defining terms.</dd>
															<dt>Euismod</dt>
															<dd>Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.</dd>
															<dd>Donec id elit non mi porta gravida.</dd>
															<dt>Malesuada porta</dt>
															<dd>Etiam porta sem malesuada magna mollis euismod.</dd>
														</dl>
													</div>
													<div class="tab-pane " id="second6">
														<h1><i class="fa fa-clock-o text-accent"></i> History</h1>
														<p class="lead">Ad ius duis dissentiunt, an sit harum primis persecuti, adipisci tacimates mediocrem sit et. Id illud voluptaria omittantur qui, te affert nostro mel. Cu conceptam vituperata temporibus has.</p>
																				<p>Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Dicant vituperata consequuntur.</p>
									
													</div>
													<div class="tab-pane active" id="second7">
														<h1><i class="fa fa-bar-chart text-accent" aria-hidden="true"></i>Target Statistics</h1>
														<p class="lead">Achieve Target for <?php echo date('F , Y'); ?></p>
														<p></p>
														<div class="row">
															<div class="col-md-12">
																<?php if(isset($tergetachieve) && !empty($tergetachieve)){ ?>
																<table class="table table-bordered table-hover">
																	<thead>
																		<tr>
																			<th>Sl No</th>
																			<th>Sales Executive ID</th>
																			<th>Sales Executive Name</th>
																			<th>Target For <?php echo date('F ,Y'); ?></th>
																			<th>Completed Target</th>
																			<th>Incentive</th>
																			<!--<th>Action</th>-->
																			
																		</tr>
																	</thead>
																	<tbody>
																		<?php $sl=1; foreach($tergetachieve as $rowsales){
																			 $sidid=$rowsales->id;
																			 $sid=$rowsales->salesmanid;
																			 $getcurrenttarget=mysqli_query($con,"select * from sales_terget where 	monthcode='".date('F')."' and yearcode='".date('Y')."' and salesmanid='".trim(strtoupper($sid))."'");
																			 $gettargte=mysqli_fetch_array($getcurrenttarget);
																			 $target=$gettargte['terget'];
																			 $getcolpletetarget=mysqli_query($con,"select * from invoicegenerate where sid='".trim($sidid)."' and mnthcd='".date('m')."' and yrcode='".date('Y')."'");
																			 $countr=mysqli_num_rows($getcolpletetarget);
																			// if(isset($countr)>0){
																			 $tencenticveposi=mysqli_query($con,"select * from incentive where min_length < $countr and max_length > $countr");
																				 //echo "select * from incentive where min_length < $countr and max_length > $countr";
																			// echo "select * from incentive where min_length<=$countr and max_length=>$countr";
																			 //$tencenticveposi=mysqli_num_rows($tencenticveposi);
																			 
																			 $getincenticesalb=mysqli_fetch_array($tencenticveposi);
																			   $getslabpos=$getincenticesalb['id'];
																			// }
																			 if(isset($getincenticesalb) && !empty($getincenticesalb))
																			 {
																			 	$getslabpos1=$getslabpos;
																			 }else
																			 	{
																			 		$getslabpos1="Not Recognized";
																			 	}
																			 //$getres=mysqli_fetch_array($getcolpletetarget);
																			// $res2=$getres[];																			
																			 ?>
																		
																		<tr>
																			<td><?php echo $sl; ?></td>
																			<td><?php echo $sid=$rowsales->salesmanid; ?></td>
																			<td><?php echo strtoupper($rowsales->name); ?></td>
																			<td><?php echo $target; ?></td>
																			<td><?php echo $countr;  ?></td>
																			<td><?php //echo $getslabpos1; ?>
																				<!----------------------------  -->
																				<?php  
																				     $temp=0 ;
																					//$terget=72;
																					$tr1=mysqli_query($con,"select count(*) as nor from invoicegenerate as inv,salesman as sl where sl.salesmanid='".trim($sid)."' and sl.id=inv.sid and  inv.mnthcd='".date('m')."' and inv.yrcode='".date('Y')."' ");
																					$getr=mysqli_fetch_array($tr1);//print_r($getr);
																					$terget=$getr['nor'];
																					$terget=251;
																					 $inct=0;
																					 $queryincen=mysqli_query($con,"select * from incentive where min_length<=$terget and  max_length>=$terget order by id desc limit 1");
																					 
																					 $rores=mysqli_fetch_array($queryincen);
																					   $getrw=intval($rores['id']);
																					 $minlen=intval($rores['min_length']);
																					$maxlen=intval($rores['max_length']);
																					$pric=floatval($rores['price']);
																					$slot="$minlen-$maxlen";
																					  $extra=(intval($terget)-intval($minlen))+1;;
																					$totslot=floatval($extra)*floatval($pric);
																					// print_r($rores);
																					
																						 //$minln=intval($roslab->min_length);
																					     //$maxln=intval($roslab->max_length);
																						
																					//echo "select * from incentive where min_length<$terget and  max_length>=$terget order by id desc limit 1";	
																					?>
																					<?php  $tot2=0; for($ij=1;$ij<intval($getrw);$ij++){
												          					
																												$getqt=mysqli_query($con,"select (max_length-min_length) as con,price,max_length,min_length from incentive where id='".trim($ij)."'");
																												$rowrs=mysqli_fetch_array($getqt);
																												$con12=intval($rowrs['con'])+1;
																												$pr=floatval($rowrs['price']);
																												$max_length=$rowrs['max_length'];
																												$min_length=$rowrs['min_length'];
																												$slot1="$min_length-$max_length";
																												$tot=$pr*$con12;
																												$tot2=floatval($tot2)+floatval($tot);
																												
																						}  $tot2=floatval($tot2)+floatval($totslot);
																					  ?>
																					<a href="#" data-toggle="modal" data-target="#myModal_<?php echo $sl; ?>"><?php  echo round($tot2); ?>
																					</a>	
																					<div class="modal fade" id="myModal_<?php echo $sl; ?>" role="dialog">
																					    <div class="modal-dialog">
																					    
																					      <!-- Modal content-->
																					      <div class="modal-content">
																					        <div class="modal-header">
																					          <button type="button" class="close" data-dismiss="modal">&times;</button>
																					          <h4 class="modal-title">Total Incentice Structure Details</h4>
																					        </div>
																					        <div class="modal-body" >
																					        	<div class="row">
																					          	
																					            </div>
																					          <div class="row">
																					          	 <div class="col-md-6"><center><h4><b>Incentie Slot Structure</b></h4></center></div>
																					          	  <div class="col-md-6"><center><h5><b>Incentive Details For <?php echo $this->session->userdata('uname'); ?></b></h5> </center></div>
																					          </div>
																					          <div class="row">
																					          	<div class="col-md-6" style="overflow-y: scroll; height: 400px;">
																					          			<table class="table table-bordered table-hover">
																					          				<thead>
																					          					<tr>
																					          						<td>Sl No</td>
																					          						<td>Slot</td>
																					          						<td>Intentive Prize</td>
																					          					</tr>
																					          				</thead>
																					          				<tbody>
																					          					<?php $queryincentiveslt=mysqli_query($con,"select * from incentive order by id asc"); ?>
																					          					<?php $ids=1; while( $getres=mysqli_fetch_array($queryincentiveslt)){ ?>
																					          					<tr>
																					          						<td><?php echo $ids; ?></td>
																					          						<td><?php echo $getres['min_length']."-".$getres['max_length']; ?></td>
																					          						<td><?php echo $getres['price']; ?></td>
																					          						
																					          					</tr>
																					          					<?php $ids++; }  ?>
																					          				</tbody>
																					          			</table>
																					          		
																					          	</div>
																					          	<div class="col-md-6">
									<?php if($terget>50){ ?>
																					          		<table class="table table-bordered table-hover">
																					          			<thead>
																					          				<tr>
																					          					<td colspan="4">Total Target Competed</td>
																					          					<td><?php echo $terget; ?></td>
																					          				</tr>
																					          				<tr>
																					          					<td>Sl No</td>
																					          					<td>Slot</td>
																					          					<td>Price</td>
																					          					<td>Qty</td>
																					          					<td>Total</td>
																					          				</tr>
																					          			</thead>
																					          			<tbody>
																					          				<?php  $tot2=0; for($ij=1;$ij<intval($getrw);$ij++){
																					          					
																												$getqt=mysqli_query($con,"select (max_length-min_length) as con,price,max_length,min_length from incentive where id='".trim($ij)."'");
																												$rowrs=mysqli_fetch_array($getqt);
																												$con12=intval($rowrs['con'])+1;
																												$pr=floatval($rowrs['price']);
																												$max_length=$rowrs['max_length'];
																												$min_length=$rowrs['min_length'];
																												$slot1="$min_length-$max_length";
																												$tot=$pr*$con12;
																												$tot2=floatval($tot2)+floatval($tot);
																												
																												  ?>
																					          				<tr>
																					          					<td><?php echo $ij; ?></td>
																					          					<td><?php echo $slot1; ?></td>
																					          					<td><?php echo number_format($pr,2); ?></td>
																					          					<td><?php echo $con12; ?></td>
																					          					<td><?php echo number_format($tot,2); ?></td>
																					          				</tr>
																					          				<?php  }  $tot2=floatval($tot2)+floatval($totslot);  ?>
																					          				<tr>
																					          					<td><?php echo $ij; ?></td>
																					          					<td><?php echo $slot; ?></td>
																					          					<td><?php echo number_format($pric,2); ?></td>
																					          					<td><?php echo $extra; ?></td>
																					          					<td><?php echo number_format($totslot,2); ?></td>
																					          				</tr>
																					          				<tr>
																					          					<td colspan="4"> Total Incentive</td>
																					          					<td><?php echo number_format(round($tot2),2)."/-"; ?></td>
																					          				</tr>
																					          			</tbody>
																					          			
																					          		</table>
																					          		<?php } ?>
																					          		
																					          	</div>
																					          </div>
																					          
																					        </div>
																					        <div class="modal-footer">
																					          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																					        </div>
																					      </div>
																					      
																					    </div>
																					 </div>
																			
																				
																				
																			</td>
																			<!--<td><?php  ?></td>-->
																		</tr>
																	<?php   $sl++ ; } ?>
																	</tbody>
																	
																</table>
																<?php } ?>
															</div>
														</div>
									
													</div>
													
													<div class="tab-pane" id="second8">
														<h1><i class="fa fa-bar-chart text-accent" aria-hidden="true"></i>Tour Plane Statistics For <?php echo date('F , Y'); ?></h1>
														<!--<p class="lead">Achieve Target for </p>-->
														<p></p>
														<br><br>
														<div class="row">
															<div class="col-md-12">
																<?php if(isset($tergetachieve) && !empty($tergetachieve)){ ?>
																<table class="table table-bordered table-hover">
																	<thead>
																		<tr>
																			<th>Sl No</th>
																			<th>Sales Executive ID</th>
																			<th>Sales Executive Name</th>
																			<th>Target For <?php echo date('F ,Y'); ?></th>
																			<th>Daywise Plane</th>
																			<th>Monthwise Plane</th>
																			<!--<th>Action</th>-->
																			
																		</tr>
																	</thead>
																	<tbody>
																		<?php $sl=1; foreach($tergetachieve as $rowsales){
																			 $sidid=$rowsales->id;
																			 $sid=$rowsales->salesmanid;
																			 $getcurrenttarget=mysqli_query($con,"select * from sales_terget where 	monthcode='".date('F')."' and yearcode='".date('Y')."' and salesmanid='".trim(strtoupper($sid))."'");
																			// print_r($getcurrenttarget);
																			 
																			 $gettargte=mysqli_fetch_array($getcurrenttarget);
																			 $target=$gettargte['terget'];
																			 
																			// $getcurrenttarget1=mysqli_query($con,"select * from tour_plan where salesmanid='".trim(strtoupper($sid))."'");
																			// $gettargte1=mysqli_fetch_array($getcurrenttarget1);
																			// $dte=$gettargte1['dte'];
																			// $formloc=$gettargte1['formloc'];
																			// $toloca=$gettargte1['toloca'];
																			// $custname=$gettargte1['custname'];
																			 
																			 $getcolpletetarget=mysqli_query($con,"select * from invoicegenerate where sid='".trim($sidid)."' and mnthcd='".date('m')."' and yrcode='".date('Y')."'");
																			 $countr=mysqli_num_rows($getcolpletetarget);
																			// if(isset($countr)>0){
																			 $tencenticveposi=mysqli_query($con,"select * from incentive where min_length < $countr and max_length > $countr");
																				 //echo "select * from incentive where min_length < $countr and max_length > $countr";
																			// echo "select * from incentive where min_length<=$countr and max_length=>$countr";
																			 //$tencenticveposi=mysqli_num_rows($tencenticveposi);
																			 
																			 $getincenticesalb=mysqli_fetch_array($tencenticveposi);
																			   $getslabpos=$getincenticesalb['id'];
																			// }
																			 if(isset($getincenticesalb) && !empty($getincenticesalb))
																			 {
																			 	$getslabpos1=$getslabpos;
																			 }else
																			 	{
																			 		$getslabpos1="Not Recognized";
																			 	}
																			 //$getres=mysqli_fetch_array($getcolpletetarget);
																			// $res2=$getres[];																			
																			 ?>
																		
																		<tr>
																			<td><?php echo $sl; ?></td>
																			<td><?php echo $sid=$rowsales->salesmanid; ?></td>
																			<td><?php echo strtoupper($rowsales->name); ?></td>
																			<td><?php echo $target; ?></td>
																			<td><i class="fa fa-eye" style="color:green" data-toggle="modal" data-target="#myModal1_<?php echo $sl; ?>"  aria-hidden="true"></i>
																					<div class="modal fade" id="myModal1_<?php echo $sl; ?>" role="dialog">
																			<div class="modal-dialog modal-lg">
																			  <div class="modal-content">
																				<div class="modal-header">
																				  <button type="button" class="close" data-dismiss="modal">&times;</button>
																				  <h4 class="modal-title">Visiting Report of <?php echo strtoupper($rowsales->name); ?>(<?php echo $sid; ?>) For the month <?php echo date('M-Y'); ?></h4>
																				</div>
																				<div class="modal-body">
																				
																				
																				<table class="table table-bordered table-hover">
																					<thead>
																						<tr>
																							<th>Date</th>
																							<th>From Location</th>
																							<th>To Location</th>
																							<th>Contact Person</th>
																							<th>Contact Number</th>
																							<th>Expence</th>
																							<th>Remark</th>
																							
																						</tr>
																					</thead>
																					<tbody>
																						<?php
																						$exp=0.00;
																					$todayplane=mysqli_query($con,"select * from daybydayplan where yrcode='".date('Y')."' and mnthcode='".date('m')."' and salesmanid='".trim($sid)."' order by dte desc");
																					if ($todayplane->num_rows > 0) {$k=1;
																						while($row4 = $todayplane->fetch_assoc()) {
																				?>
																						<tr>
																							<td><?php echo $row4["dte"]; ?></td>
																							<td><?php echo $row4["formloc"]; ?></td>
																							<td><?php echo $row4["toloca"]; ?></td>
																							<td><?php echo $row4["custname"]; ?></td>
																							<td><?php echo $row4["contactinfo"]; ?></td>
																							<td><div id="expnc_<?php echo $k; ?>"><?php echo $row4["dailyexpen"]; ?></div></td>
																							<td><?php echo $row4["remarks"]; ?></td>
																						</tr>
																						
																						<?php
																						
																						$exp=floatval($exp)+floatval($row4["dailyexpen"]);
																						$k++; }} ?>
																						
																						<tr>
																							<td></td>
																							<td></td>
																							<td></td>
																							<td></td>
																							<td><b>Total Expence</b></td>
																							<td><div><b><?php echo number_format($exp,2); ?></b></div></td>
																							<td></td>
																						</tr>
																					</tbody>
																				</table>
	
																				</div>
																				<div class="modal-footer">
																				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																				</div>
																			  </div>
																			</div>
																		  </div>
																		  </td>
																			
																			
																			<td><i class="fa fa-eye" style="color:green" data-toggle="modal" data-target="#myModal2_<?php echo $sl; ?>"  aria-hidden="true"></i>
																			
																			<div class="modal fade" id="myModal2_<?php echo $sl; ?>" role="dialog">
																			<div class="modal-dialog modal-lg">
																			  <div class="modal-content">
																				<div class="modal-header">
																				  <button type="button" class="close" data-dismiss="modal">&times;</button>
																				  <h4 class="modal-title"><?php echo date('M-Y'); ?> Visiting Report for <?php echo strtoupper($rowsales->name); ?>(<?php echo $sid; ?>)</h4>
																				</div>
																				<div class="modal-body">
																				<table class="table table-bordered table-hover">
																					<thead>
																						<tr>
																							<th>Date</th>
																							<th>From Location</th>
																							<th>To Location</th>
																							<th>Contact Person</th>
																							<th>Contact Number</th>
																							
																						</tr>
																					</thead>
																					<tbody>
																						<?php
																					$fetchtrgt=mysqli_query($con,"select * from tour_plan where salesmanid='$sid' order by dte desc");
																					if ($fetchtrgt->num_rows > 0) {
																						while($row5 = $fetchtrgt->fetch_assoc()) {
																				?>
																						<tr>
																							<td><?php echo $row5["dte"]; ?></td>
																							<td><?php echo $row5["formloc"]; ?></td>
																							<td><?php echo $row5["toloca"]; ?></td>
																							<td><?php echo $row5["custname"]; ?></td>
																							<td><?php echo $row5["contactinfo"]; ?></td>
																						</tr>
																						<?php }} ?>
																					</tbody>
																				</table>
																				</div>
																				<div class="modal-footer">
																				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																				</div>
																			  </div>
																			</div>
																		  </div>
																			
																			
																			</td>
																			<!--<td><?php  ?></td>-->
																		</tr>
																		
																		
																		
																		
																		
																		
																		
																	<?php   $sl++ ; } ?>
																	</tbody>
																	
																</table>
																<?php } ?>
															</div>
														</div>
									
													</div>
												</div>
											</div><!--end .card -->
					                         <!--<em class="text-caption">Right sidebar layout</em>-->
				                      </div>
									
								</div>
						    	</div>
							    	
							    	
							    	
							</div>
				</div>
				
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->	
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->
		
		
		

		

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>

