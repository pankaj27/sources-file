
<?php //include('conection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<style>
	#verticalLine {
    border-left: 1px solid black;
   }
    .print-clean{
    	border: none;
       background: transparent;
    }
    #partstble,#partstble2{
    	width:100%;
    }
    #optr{
    	width:100%;
    }
    #partstble tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #partstble2 tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #optr tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    .datatr{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    .datatr1{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    #partstble3{
    	width:100%;
    }
     #partstble3 tr {
     	line-height:15px;
    	border-top: 1px solid #0aa89e;
     }
    .table12{
    	width:100%;
    	
    }
    .table12 tr{
    	height:6px;
    	border-bottom: 1px solid black;
    }
    .table12 td{
    	padding:0px;
    	margin:0px;
    	
    }
    .thred,.trhide{
    	display: none;
    }

</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
	<!-- BEGIN BLANK SECTION -->
	<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li><a href="<?php echo base_url(); ?>">home</a></li>
												<li class="active"><?php if(isset($title)){ echo $title ; } ?></li>
						</ol>

		</div><!--end .section-header -->
		<div class="section-body">
			<div class="row">
				<div class="col-md-12">
					
					<div class="card card-bordered style-primary">
						<div class="card-head">
							
							<header><i class="fa fa-fw fa-tag"></i>Create Model Details</header>
						</div><!--end .card-head -->
						<div class="card-body style-default-bright">
							<div class="row">
								
								<form action="<?php echo base_url();  ?>Manufactarer_Controller/getchasis" method="post">
								<div class="col-md-12">
								<div class="col-md-2">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="orderid" value="" required="required" placeholder="SELECT DATE">
									<!--<label for="Username2">Enter PO NO</label>-->
								    </div>
								</div>
								<div class="col-md-1">
									
								</div>
								
								<div class="col-md-2">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="orderid" value="" required="required" placeholder="SELECT MODEL">
									<!--<label for="Username2">Enter PO NO</label>-->
									</div>
								</div>
								<div class="col-md-1">
									
								</div>
								<div class="col-md-2">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="orderid" value="" required="required" placeholder="COLOR">
									<!--<label for="Username2">Enter PO NO</label>-->
									</div>
								</div>
								<div class="col-md-1">
									
								</div>
								<div class="col-md-2">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="orderid" value="" required="required" placeholder="QTY">
									<!--<label for="Username2">Enter PO NO</label>-->
									</div>
								</div>
								<div class="col-md-1">
									
								</div>
								</div>
								</div>
								<div class="row">
								<div class="col-md-2">
									<div class="form-group">
								     <button type="submit" class="btn btn-flat btn-primary ink-reaction">SUBMIT</button>
									<!--<label for="Username2">Enter PO NO</label>-->
								</div>
								</div>
								
							<!--end .col -->
							</form>
						</div>
							
						</div> 
							<!--end .col -->
						</div>
					
							
							
							
							
													
									
						</div><!--end .card-body -->
					</div><!--end .card -->
					
				</div><!--end .col -->
			</div>
		</div><!--end .section-body -->
	</section>
	<!-- BEGIN BLANK SECTION -->

		</div><!--end #content-->		
		<!-- END CONTENT -->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
  $(function(){
    $("#example").dataTable();
   // alert('hello');
  })
  function getexceldata(){
		//alert('hello');
      $("#example").table2excel({
    name: "Excel Document Name",
	filename: "orderdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function gettotal(id)
  {
  	var idsplit=id.split("_");
  	var prtsqty=parseInt($("#prtsq_"+idsplit[1]).val());
  	var shortage=parseInt($("#shortage_"+idsplit[1]).val());
  	if(shortage=="" || isNaN(shortage))
  	{
  		shortage=0;
  	}
  	var tot=prtsqty-shortage;
  	$("#tottal_"+idsplit[1]).val(tot);
  	
  }
  function saveeditorder(id)
  {
  	var idsplit=id.split("_");
  	alert(idsplit);
  	var ordid=$("#orderid_"+idsplit[1]).val();
  	var prtsq=$("#prtsq_"+idsplit[1]).val();
  	var shortage=$("#shortage_"+idsplit[1]).val();
  	var checkAll1=$("#checkAll1_"+idsplit[1]).val();
  	var checkAll2=$("#checkAll2_"+idsplit[1]).val();
  	if(($("#checkAll1_"+idsplit[1])).prop('checked') == true)
  	{
  		var checkAll1=$("#checkAll1_"+idsplit[1]).val();
  	}else
  	{
  		var checkAll1=0;
  	}
  	
  	if(($("#checkAll2_"+idsplit[1]).prop('checked') == true)
  	{
  		var checkAll2=$("#checkAll2_"+idsplit[1]).val();
  	}else
  	{
  		var checkAll2=0;
  	}
  	alert(checkAll1);
 
  	if(shortage=="")
  	{
  		shortage=0;
  	}
  	alert(prtsq);
  	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>StockManage_controller/savefinalgetpass",
  			data :{'ordid':ordid,'prtsq':prtsq,'shortage':shortage},
  			success : function(data){
  				 				 
  				//alert(data);
  				//$("#tt").text(data);
  			     $("#prtsq_"+idsplit[1]).val(data);
              }  
           });
  	
  }
  </script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
 <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>-->
<script src="<?php echo base_url(); ?>assets/js/src/jquery.table2excel.js"></script>
