<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Edit Model Price</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Edit</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
									<?php if(isset($price) && !empty($price)){?>
									<?php foreach($price as $row){?>
									
				<form class="form" action="<?php echo base_url(); ?>Manage_price/saveprice"  method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Information</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-12">
										<div class="form-group">
										<input type="hidden"  value="<?php $row->id; ?>" name="id" id="id"/>
										<select class="form-control select2-list" data-placeholder="Select an item" name="mName"  required >
												<option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option>
												<?php 
													if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
												 ?>
											</select>
											<label for="mName">Model Name</label>
										</div>
									</div>
									</div>
									</div>
									
									<div class="card">
									<div class="card-head style-primary">
										<header>Distributer Price</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="d_inc_battery" name="d_inc_battery" value="<?php echo $row->d_inc_battery; ?>" required \>
												<label for="d_inc_battery">Including Battery:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="d_ex_battery" name="d_ex_battery" value="<?php echo $row->d_ex_battery; ?>" required \>
													<label for="d_ex_battery">Excluding Battery:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="d_inc_charger" name="d_inc_charger" value="<?php echo $row->d_inc_charger; ?>" required \>
												<label for="d_inc_charger">Including Charger:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="d_ex_charger" name="d_ex_charger" value="<?php echo $row->d_ex_charger; ?>" required \>
													<label for="d_ex_charger">Excluding Charger:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="d_bat_chr" name="d_bat_chr" value="<?php echo $row->d_bat_chr; ?>" required \>
												<label for="d_bat_chr">Battery and Charger:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="d_wth_bat_chr" name="d_wth_bat_chr" value="<?php echo $row->d_wth_bat_chr; ?>" required \>
													<label for="d_wth_bat_chr">Without Battery and Charger:</label>
												</div>
										</div>
									</div>
									</div>
									</div>
									
									<div class="card">
									<div class="card-head style-primary">
										<header>Subdistributer Price</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="s_inc_battary" name="s_inc_battary" value="<?php echo $row->s_inc_battary; ?>" required \>
												<label for="s_inc_battary">Including Battery:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="s_ex_battary" name="s_ex_battary" value="<?php echo $row->s_ex_battary; ?>" required \>
													<label for="s_ex_battary">Excluding Battery:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="s_inc_charger" name="s_inc_charger" value="<?php echo $row->s_inc_charger; ?>" required \>
												<label for="s_inc_charger">Including Charger:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="s_ex_charger" name="s_ex_charger" value="<?php echo $row->s_ex_charger; ?>" required \>
													<label for="s_ex_charger">Excluding Charger:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="s_bat_chr" name="s_bat_chr" value="<?php echo $row->s_bat_chr; ?>" required \>
												<label for="s_bat_chr">Battery and Charger:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="s_wth_bat_chr" name="s_wth_bat_chr" value="<?php echo $row->s_wth_bat_chr; ?>" required \>
													<label for="s_wth_bat_chr">Without Battery and Charger:</label>
												</div>
										</div>
									</div>
									</div>
									</div>
									
									<div class="card">
									<div class="card-head style-primary">
										<header>Retailer Price</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="r_inc_battary" name="r_inc_battary" value="<?php echo $row->r_wth_bat_chr; ?>">
												<label for="r_inc_battary">Including Battery:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="r_ex_battary" name="r_ex_battary" value="<?php echo $row->r_wth_bat_chr; ?>">
													<label for="r_ex_battary">Excluding Battery:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="r_inc_charger" name="r_inc_charger" value="<?php echo $row->r_wth_bat_chr; ?>">
												<label for="r_inc_charger">Including Charger:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="r_ex_charger" name="r_ex_charger" value="<?php echo $row->r_wth_bat_chr; ?>">
													<label for="r_ex_charger">Excluding Charger:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="r_bat_chr" name="r_bat_chr" value="<?php echo $row->r_wth_bat_chr; ?>">
												<label for="r_bat_chr">Battery and Charger:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="r_wth_bat_chr" name="r_wth_bat_chr" value="<?php echo $row->r_wth_bat_chr; ?>">
													<label for="r_wth_bat_chr">Without Battery and Charger:</label>
												</div>
										</div>
									</div>

								
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>
				</div>
				</div>
				</form>	
         <?php }} ?>
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
