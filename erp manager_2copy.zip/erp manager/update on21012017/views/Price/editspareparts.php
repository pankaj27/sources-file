<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">SpareParts Price </li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Edit</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
									<?php if(isset($spare) && !empty($spare)){?>
									<?php foreach($spare as $row){?>
				<form class="form" action="<?php echo base_url(); ?>Manage_price/savesparepartsprice2"  method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Information</header>
							</div>
							<div class="card-body floating-label">
								<input type="hidden" name="matid" id="matid" value="<?php echo $row->materiel_id; ?>">
									<div class="col-md-12">
										<div class="form-group">
										<select class="form-control select2-list" name="mName" id="mName" readonly >
												<option value="<?php echo $row->mName; ?>"><?php echo $row->mName; ?></option>
											</select>
											<label for="mName">Model Name</label>
										</div>
									</div>
									<br><br><br>

									<div class="form-group" id="spareparts">
										<div class="form-group">
										<select class="form-control select2-list" name="spareparts" id="spareparts" readonly >
												<option value="<?php echo $row->materiel_id; ?>"><?php echo $row->materialname; ?></option>
											</select>
											<label for="spareparts">SpareParts Name</label>
										</div>

									</div>
									<br><br>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="orprice" name="orprice" value="<?php echo $row->ordr_price; ?>" readonly \>
												<label for="orprice">Order Price:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="slsprice" name="slsprice" value="<?php echo $row->sals_price; ?>">
													<label for="slsprice">Sales Price:</label>
												</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="dprice" name="dprice" value="<?php echo $row->dis_price; ?>">
												<label for="dprice">Distributer Price:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="number" class="form-control" id="sprice" name="sprice" value="<?php echo $row->sub_price; ?>">
													<label for="sprice">Subdistributer Price:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="number" class="form-control" id="rprice" name="rprice" value="<?php echo $row->retail_price; ?>">
												<label for="rprice">Retailer Price :</label>
											</div>
										</div>
									</div>
									

								
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="button" class="btn btn-flat btn-primary ink-reaction"><a href="<?php echo base_url(); ?>Manage_price/viewspareparts">Cancel</a></button>
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>
				</div>
				</div>
				</form>	
				<?php }} ?>
         
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>

