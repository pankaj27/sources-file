<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>


	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">SpareParts Price Entry</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Entry</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" action="<?php echo base_url(); ?>Manage_price/getsparepartsall"  method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>SELECT MODEL</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-8">
										<div class="form-group">
										<select class="form-control select2-list" data-placeholder="Select an item" name="mName" id="mName" required="required" >
												<option value=""></option>
												<?php 
												   if(isset($mdl) && !empty($mdl))
												   {
												   	?> 
												   	 <option value="<?php echo $mdl; ?>"selected="selected"><?php echo $mdl; ?></option>
												   	<?php  if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
											    }else{
													if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
												   }
												 ?>
											</select>
											<label for="mName">Model Name</label>
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<div class="card-actionbar">
												<div class="card-actionbar-row">
													<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
												</div>
											</div>
											
										</div>
									</div>
								
				</div>
				</div>
				</form>	
		<!-----------------------------------   GEt  all parts price Details  --------------------->
		<?php if(isset($getallparts) && !empty($getallparts)){ $sl1=1; ?>
				<div class="card">
							<div class="card-head style-primary">
								<header>ALL SPAREPARTS LIST</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-12">
										<form action="<?php  echo base_url();  ?>Manage_price/savespareprtsprice" method="POST">
										<div class="form-group" style="overflow-y: scroll;">
										  <table class="table table-bordered">
										  	<thead>
										  		<tr>
										  			<th colspan="4"></th>
										  			<td><!--<input type="text" id="mainpr_<?php echo $sl1; ?>" name="mainpr_<?php echo $sl1; ?>" value="<?php  ?>" />--></td>
										  			<td><input type="text" id="cnf" name="cnf" value="<?php  ?>" placeholder="ENTER CNF(%)" onblur="getcnfprice();" /></td>
										  			<td><input type="text" id="dist"  name="dist" value="<?php  ?>" placeholder="ENTER DISTRIBUTER(%)" onblur="getdistprice();"/></td>
										  			<td><input type="text" id="subdist" name="subdist" value="<?php  ?>" placeholder="ENTER SUB-DISTRIBUTER(%)" onblur="getsubdistprice();"/></td>
										  			<!--<td><input type="text" id="retail" name="retail" value="<?php  ?>" placeholder="ENTER RETAILER(%)" onblur="getretailprice();"/></td>-->
										  			<th></th>
										  			
										  		</tr>
										  		<tr>
										  			<th>SL NO.</th>
										  			<th>MODEL</th>
										  			<th>PARTS NAME</th>
										  			<th>PARTS CODE</th>
										  			<th>MRP PRICE</th>
										  			<th>CNF PRICE</th>
										  			<th>DISTRIBUTER PRICE</th>
										  			<th>SUB -DISTRIBUTER PRICE</th>
										  			<!--<th>RETAILER PRICE</th>-->
										  			<th>ACTION</th>
										  			
										  		</tr>
										  	</thead>
										  	<tbody>
										  		<?php  
										  		  $sl=1; foreach($getallparts as $row){
										  		 ?>
										  		<tr>
										  			<td><?php echo $sl; ?><input type="hidden" name="partsid_<?php echo $sl; ?>" id="partsid_<?php echo $sl; ?>" value="<?php echo $row->id; ?>" /> </td>
										  			<td><?php echo $row->mName; ?></td>
										  			<td><?php echo $row->materialname; ?></td>
										  			<td><?php echo $row->materiel_id; ?></td>
										  			<td><input type="text" id="mainpr_<?php echo $sl; ?>" name="mainpr_<?php echo $sl; ?>" value="<?php echo $row->buyprcrnt;  ?>" style="width: 75px;" onblur="getallpricedetails(this.id);" /></td>
										  			<td><input type="text" id="cnf_<?php echo $sl; ?>" name="cnf_<?php echo $sl; ?>" value="<?php   ?>" style="width: 75px;"/></td>
										  			<td><input type="text" id="dist_<?php echo $sl; ?>" name="dist_<?php echo $sl; ?>" value="<?php ?>" style="width: 75px;"/></td>
										  			<td><input  style="width: 75px;" type="text" id="subdist_<?php echo $sl; ?>" name="subdist_<?php  echo $sl; ?>" value="<?php  ?>"/></td>
										  			<!--<td><input style="width: 75px;" type="text" id="retail_<?php echo $sl; ?>" name="retail_<?php echo $sl;  ?>" value="<?php  ?>"/></td>-->
										  			<td>
										  				<button onclick() type="button" id="save_<?php echo $sl; ?>" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-floppy-o" aria-hidden="true"></i></button> 
										  			</td>
										  			
										  			
										  			
										  			
										  		</tr>
										  		<?php $sl++; } ?>
										  	</tbody>
										  	
										  </table>
											
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<div class="card-actionbar">
												<div class="card-actionbar-row">
													<input type="hidden" name="totrow" id="totrow" value="<?php echo $sl; ?>"/>
													<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
												</div>
											</div>
											
										</div>
									</div>
									</form>
								
				</div>
				</div>
				<?php } ?>		
		
		
		
		
		<!--##################################################  end of all parts details ------------------->
				
    							</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function getcnfprice()
	{
		var cnfpr=parseFloat($("#cnf").val());
		if(cnfpr=="" || isNaN(cnfpr)){ cnfpr=0; }
		var totrow=parseInt($("#totrow").val());
	 
		for(var k=1;k<parseInt(totrow);k++)
		{
			var mainpr=parseFloat($("#mainpr_"+k).val());
			var cnfamnt=parseFloat(mainpr)-((parseFloat(mainpr)*cnfpr)/100);
			cnfamnt=Math.round(cnfamnt).toFixed(2);
			$("#cnf_"+k).val(cnfamnt);
		}
	}
	function getdistprice()
	{
		var cnfpr=parseFloat($("#dist").val());
		if(cnfpr=="" || isNaN(cnfpr)){ cnfpr=0; }
		var totrow=parseInt($("#totrow").val());
	 
		for(var k=1;k<parseInt(totrow);k++)
		{
			var mainpr=parseFloat($("#mainpr_"+k).val());
			var cnfamnt=parseFloat(mainpr)-((parseFloat(mainpr)*cnfpr)/100);
			cnfamnt=Math.round(cnfamnt).toFixed(2);
			$("#dist_"+k).val(cnfamnt);
		}
	}
	function getsubdistprice()
	{
		var cnfpr=parseFloat($("#subdist").val());
		if(cnfpr=="" || isNaN(cnfpr)){ cnfpr=0; }
		var totrow=parseInt($("#totrow").val());
	 
		for(var k=1;k<parseInt(totrow);k++)
		{
			var mainpr=parseFloat($("#mainpr_"+k).val());
			var cnfamnt=parseFloat(mainpr)-((parseFloat(mainpr)*cnfpr)/100);
			cnfamnt=Math.round(cnfamnt).toFixed(2);
			$("#subdist_"+k).val(cnfamnt);
		}
	}
	/*function getretailprice()
	{
		var cnfpr=parseFloat($("#retail").val());
		if(cnfpr=="" || isNaN(cnfpr)){ cnfpr=0; }
		var totrow=parseInt($("#totrow").val());
	 
		for(var k=1;k<parseInt(totrow);k++)
		{
			var mainpr=parseFloat($("#mainpr_"+k).val());
			var cnfamnt=parseFloat(mainpr)+((parseFloat(mainpr)*cnfpr)/100);
			cnfamnt=cnfamnt.toFixed(2);
			$("#retail_"+k).val(cnfamnt);
		}
	}*/
</script>


