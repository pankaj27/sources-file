<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Model Price Entry</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Create</a></li>
								<!--<li><a href="#second1">View</a></li>
								<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<?php if(isset($getmodelpr) && !empty($getmodelpr)) 
											{
												foreach($getmodelpr as $row)
												{
													$model2=$row->productname;
													$mainpr=$row->mainpr;
													$cnfpr=$row->cnfprice;
													$cnfper=$row->cnfpercentage;
													$distprice=$row->distprice;
													$distpercentage=$row->distpercentage;
													$subdistprice=$row->subdistprice;
													$subdistpercentage=$row->subdistpercentage;
													$retailerprice=$row->retailerprice;
													$retailerpercentage=$row->retailerpercentage;
													$id=$row->id;
												}
											}
											
											?>
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
				<form class="form" <?php if(isset($id) && !empty($id)){  ?>  action="<?php echo base_url(); ?>Manage_price/updatemodelprice"  <?php   }else{  ?> action="<?php echo base_url(); ?>Manage_price/savemodelprice"  <?php } ?> method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>SELECT MODEL</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-6">
										<div class="form-group">
											
										
										<select id="mname" class="form-control select2-list" data-placeholder="Select an item" name="mName"  required onchange="getmodelprice();" >
												
												<?php 
												  if(isset($model2) && !empty($model2))
												  {  ?>
												  	<option value="<?php echo $model2; ?>" selected><?php echo $model2; ?></option>
												  	
												 <?php 	if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
												  }else{ ?>
													<option value="0"></option>
													<?php  if(isset($model)){
														foreach($model as $rowmodel)
														{?>
															<option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option>
													<?php 	}	
													}
												  }
												 ?>
										</select>
											<label for="mName">Model Name</label>
										</div>
									</div>
									<div class="col-md-4">
											<div class="form-group">
												<input type="hidden" name="rowid" value="<?php if(isset($id) && !empty($id)){ echo $id; } ?>"/>
												<input type="text" class="form-control" id="mainprice" name="mainprice" required="required" value="<?php if(isset($mainpr) && !empty($mainpr)){ echo $mainpr; } ?>" onblur="getallpricedet()">
												<label for="d_inc_battery">Enter Price (without Battery and Charger)</label>
												
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<div id="info"></div>
											</div>
										</div>
									</div>
									</div>
					<!--#####################################################  -->
					
					
					<!--########################################################33-->
								

								<div class="card">
									<div class="card-head style-primary">
										<header>CNF PRICE</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="cnfprice" name="cnfprice" placeholder="ENTER CNF PRICE" onkeyup="getcnfperventage()" value="<?php if(isset($cnfpr) && !empty($cnfpr)){ echo $cnfpr;} ?>">
												<!--<label for="d_inc_battery">ENTER CNF PRICE </label>-->
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="cnfpercentage" placeholder="ENTER CNF PERCENTAGE(%)" name="cnfpercentage" onkeyup="getcnfprice()" value="<?php if(isset($cnfper) && !empty($cnfper)){ echo $cnfper;} ?>">
													<!--<label for="d_ex_battery">ENTER CNF PERCENTAGE(%)</label>-->
												</div>
										</div>
									</div>
									
									
									</div>
									</div>
								

								<div class="card">
									<div class="card-head style-primary">
										<header>DISTRIBUTER PRICE</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="distprice" placeholder="ENTER DISTRIBUTER PRICE" name="distprice"  onkeyup="getdistpercentage()" value="<?php if(isset($distprice) && !empty($distprice)){ echo $distprice;} ?>">
												<!--<label for="d_inc_battery">ENTER DISTRIBUTER PRICE </label>-->
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" placeholder="ENTER DISTRIBUTER PERCENTAGE(%)" id="distpercent" name="distpercent" onkeyup="getdistprice()" value="<?php if(isset($distpercentage) && !empty($distpercentage)){ echo $distpercentage;} ?>">
													<!---<label for="d_ex_battery">ENTER DISTRIBUTER PERCENTAGE(%)</label>-->
												</div>
										</div>
									</div>
									
									
									</div>
									</div>
								
								<div class="card">
									<div class="card-head style-primary">
										<header>SUB-DISTRIBUTER PRICE</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="subdistprice" placeholder="ENTER SUB-DISTRIBUTER PRICE" name="subdistprice" onkeyup="getsubdistpercentage()" value="<?php if(isset($subdistprice) && !empty($subdistprice)){ echo $subdistprice;} ?>">
												<!--<label for="d_inc_battery">ENTER SUB-DISTRIBUTER PRICE </label>-->
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="subdistpercentage" placeholder="ENTER SUB-DISTRIBUTER PERCENTAGE(%)" name="subdistpercentage" onkeyup="getsubdistprice();" value="<?php if(isset($subdistpercentage) && !empty($subdistpercentage)){ echo $subdistpercentage;} ?>">
													<!--<label for="d_ex_battery">ENTER SUB-DISTRIBUTER PERCENTAGE(%)</label>-->
												</div>
										</div>
									</div>
									
									
									</div>
									</div>
									<div class="card">
									<div class="card-head style-primary">
										<header>RETAILER/DIRECT PRICE</header>
									</div>
									<div class="card-body floating-label">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="retailerprice" name="retailerprice" placeholder="ENTER RETAILER PRICE" onkeyup="getretailerpercentage()" value="<?php if(isset($retailerprice) && !empty($retailerprice)){ echo $retailerprice;} ?>">
												<!--<label for="d_inc_battery">ENTER RETAILER PRICE </label>-->
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="retailerpercentage" placeholder="ENTER RETAILER PERCENTAGE(%)" name="retailerpercentage" onkeyup="getretailerprice()" value="<?php if(isset($retailerpercentage) && !empty($retailerpercentage)){ echo $retailerpercentage;} ?>">
													<!--<label for="d_ex_battery">ENTER RETAILER PERCENTAGE(%)</label>-->
												</div>
										</div>
										<div class="col-md-12">
											<div class="card-actionbar">
												<div class="card-actionbar-row">
													<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
												</div>
											</div>
										</div>
									</div>
									
									
									</div>
									</div>
				</form>	
         
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function getcnfperventage()
	{
		var mainprice=$("#mainprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var per=parseFloat(mainprice);
		var cnfpr=parseFloat($("#cnfprice").val());
		per=((cnfpr-per)/per)*100;
		if(per>0){
			per=per.toFixed(2);
			$("#cnfpercentage").val(per);
		}else
		{
			$("#cnfpercentage").val("");
		}
		
		
	}
	function getcnfprice()
	{
		var mainprice=$("#mainprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var cnfpr1=parseFloat(mainprice);
		var cnfpr=parseFloat($("#cnfpercentage").val());
		cnfpr1=cnfpr1+((cnfpr1*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#cnfprice").val(cnfpr1);
		}else
		{
			$("#cnfprice").val("");
		}
		
	}
	
	function getdistpercentage()
	{
		var mainprice=$("#cnfprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var per=parseFloat(mainprice);
		var cnfpr=parseFloat($("#distprice").val());
		per=((cnfpr-per)/per)*100;
		if(per>0){
			per=per.toFixed(2);
			$("#distpercent").val(per);
		}else
		{
			$("#distpercent").val("");
		}
	}
	function getdistprice()
	{
		var mainprice=$("#cnfprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var cnfpr1=parseFloat(mainprice);
		var cnfpr=parseFloat($("#distpercent").val());
		cnfpr1=cnfpr1+((cnfpr1*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#distprice").val(cnfpr1);
		}else
		{
			$("#distprice").val("");
		}
		
	}
	function getsubdistpercentage()
	{
		var mainprice=$("#distprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var per=parseFloat(mainprice);
		var cnfpr=parseFloat($("#subdistprice").val());
		per=((cnfpr-per)/per)*100;
		if(per>0){
			per=per.toFixed(2);
			$("#subdistpercentage").val(per);
		}else
		{
			$("#subdistpercentage").val("");
		}
	}
	function getsubdistprice()
	{
		var mainprice=$("#distprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var cnfpr1=parseFloat(mainprice);
		var cnfpr=parseFloat($("#subdistpercentage").val());
		cnfpr1=cnfpr1+((cnfpr1*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#subdistprice").val(cnfpr1);
		}else
		{
			$("#subdistprice").val("");
		}
	}
	function getretailerpercentage()
	{
		var mainprice=$("#subdistprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var per=parseFloat(mainprice);
		var cnfpr=parseFloat($("#retailerprice").val());
		per=((cnfpr-per)/per)*100;
		if(per>0){
			per=per.toFixed(2);
			$("#retailerpercentage").val(per);
		}else
		{
			$("#retailerpercentage").val("");
		}
	}
	function getretailerprice()
	{
		var mainprice=$("#subdistprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=mainprice;
		}
		var cnfpr1=parseFloat(mainprice);
		var cnfpr=parseFloat($("#retailerpercentage").val());
		cnfpr1=cnfpr1+((cnfpr1*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#retailerprice").val(cnfpr1);
		}else
		{
			$("#retailerprice").val("");
		}
	}
	function getallpricedet()
	{
		var mainprice=$("#mainprice").val();
		if(mainprice=="" || isNaN(mainprice)){
			mainprice=0;
		}
		var per=parseFloat(mainprice);
		// ========= cnf price     ==================
		var cnfpr=parseFloat($("#cnfpercentage").val());
		cnfpr1=per-((per*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#cnfprice").val(cnfpr1);
		}else
		{
			$("#cnfprice").val("");
		}
		
		//==========  dist price===========================
		//var cnfpr=parseFloat($("#distpercent").val());
		var per2=parseFloat($("#mainprice").val());
		var cnfpr=parseFloat($("#distpercent").val());
		cnfpr1=per2-((per2*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#distprice").val(cnfpr1);
		}else
		{
			$("#distprice").val("");
		}
		//===========sub -dist price  =============================
		var per2=parseFloat($("#mainprice").val());
		var cnfpr=parseFloat($("#subdistpercentage").val());
		cnfpr1=per2-((per2*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#subdistprice").val(cnfpr1);
		}else
		{
			$("#subdistprice").val("");
		}
		//=== retailer price======================================
		/*var per2=parseFloat($("#subdistprice").val());
		var cnfpr=parseFloat($("#retailerpercentage").val());
		cnfpr1=per2+((per2*cnfpr)/100);
		if(cnfpr1>0){
			cnfpr1=cnfpr1.toFixed(2);
			$("#retailerprice").val(cnfpr1);
		}else
		{
			$("#retailerprice").val("");
		}
		*/
		
		
		//alert(cnfpr);
	}
//update  on 02-01-2017--------------
	function getmodelprice()
	{
		
		var model=$("#mname").val();
		if(model=="0")
		{
			alert('please select any model');
		}else
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Manage_price/getmodelpricebymodel",
  			data :{'model':model},
  			success : function(data){
  				 				 
  				//alert(data);
  				//$("#prtcard").show();
  				//$("#prtcard").html(data);
  				//$("#submit").show();
  				$("#mainprice").val(data);
  			  
              }  
           });
           $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Manage_price/getmodalprice",
  			data :{'model':model},
  			success : function(data){
  				 				 
  				//alert(data);
  				//$("#prtcard").show();
  				//$("#prtcard").html(data);
  				//$("#submit").show();
  				$("#info").html(data);
  			  
              }  
           });
		}
	}
</script>