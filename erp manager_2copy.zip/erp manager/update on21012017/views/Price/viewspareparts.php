<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<script src="<?php echo base_url(); ?>jscolor.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">View Spare Parts Price Details(With Discount %)</li>
				</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1" style="overflow-y: scroll;">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>SL NO</th>
                <th>MODEL NAME</th>
                <th>PARTS NAME </th>
                 <th>PARTS CODE </th>
                <th>MRP PRICE</th>
                <th>CNF PRICE & PERCENTAGE</th>
                <th>DISTRIBUTER PRICE & PERCENTAGE</th>
				<th>SUB-DISTRIBUTER PRICE & PERCENTAGE</th>
				<!--<th>RETAILER PRICE & PERCENTAGE</th>-->
				<th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($getsparepartsprice) && !empty($getsparepartsprice)){ $sl=1;?>
			<?php foreach($getsparepartsprice as $row){ ?>
            <tr>
                <td><?php echo $sl; ?></td>
                <td><?php echo $row->mName; ?></td>
                <td><?php echo $row->materialname; ?></td>
                <td><?php echo $row->materiel_id; ?></td>
                <td><?php echo $row->buyprcrnt; ?></td>
                <td><?php echo $row->cnfpr." (".$row->cnfprper."%)"; ?></td>
                <td><?php echo $row->distpr." (".$row->distprper."%)"; ?></td>
                <td><?php echo $row->subdistpr." (".$row->subdistprper."%)"; ?></td>
               <!-- <td><?php echo $row->retailpr." (".$row->retailprper."%)"; ?></td>-->
                <td>
                	<a href="<?php echo base_url();?>Manage_price/editsparepartsprice/<?php echo $row->id;  ?>" class="tooltip-success">
							 <!--<button type="button" class="btn btn-sm btn-success"><i class="ace-icon fa fa-check">-->
					<button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
					
                </td>
            </tr>
            <?php $sl++; } } ?>
        </tbody>
    </table>
				</div>
				</form>	
         <div class="tab-pane" id="second1">
	</div>
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							<div class="tab-pane" id="third1"><p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p><p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p></div>
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
 