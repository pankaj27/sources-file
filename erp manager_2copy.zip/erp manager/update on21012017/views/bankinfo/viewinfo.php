<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			
		}
		#example tr{
			line-height:5px;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active"> </li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<!--<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1"> </a></li>
								<!--<li><a href="<?php// echo base_url(); ?>newBrand_controller/modelEntry">Create</a></li>>-->
								<!--<!--<li><a href="#third1">Statistic</a></li>-->
								
							<!--</ul>
						</div>--><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
                <th>BANK NAME</th>
                <th>BRANCH NAME</th>
                <th>A/C NUMBER</th>
                <th>A/C NAME</th>
                <th>BALENCE</th>
				 <th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($alldata) && !empty($alldata)){  $i=1; ?>
				
				
			<?php foreach($alldata as $row){ ?>
	
            <tr>
               <th><?php echo $i ?> </th>
                <th><?php echo $row->bankname; ?></th>
                <th><?php echo $row->branchname; ?></th>
                <th><?php echo $row->accno; ?></th>
                <th><?php echo $row->accname; ?></th>
                <th><?php echo $row->balance; ?></th>
                <td>
					<a href="<?php echo base_url(); ?>Bankinfo_Controller/editinfo/<?php echo $row->id; ?>" class="tooltip-success">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-info"><i class="ace-icon fa fa-times bigger-125">-->
					<button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
					
					<a href="<?php echo base_url(); ?>Bankinfo_Controller/deleteinfo/<?php echo $row->id; ?>" class="tooltip-success">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-info"><i class="ace-icon fa fa-times bigger-125">-->
					<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-flat btn-primary ink-reaction"></i><i class="fa fa-trash" aria-hidden="true"></i></button></a>
														
				</td>
            </tr>
            <?php $i++; } } ?>
        </tbody>
    </table>
				</div>
				</form>	


						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->

		</div><!--end .section-body -->
	</section>
	<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

