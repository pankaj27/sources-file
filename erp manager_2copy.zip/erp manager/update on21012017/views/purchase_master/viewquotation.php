<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>

<?php include('conection.php'); ?>
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">View Quotation List</li>
				</ol>

		</div>
		<div class="section-body contain-lg">
                   
		           

			
			<div class="row">
				<?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
                                                   </div>
		            <?php }?>
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View</a></li>-->
								
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>Vender Id</th>
									<th>Vender Name</th>
									<th>Quotation No</th>
									<th class="sort-numeric">Grand Total</th>
									<th class="sort-alpha">Expected Delivery</th>
									<th>Attachment</th>
									<th class="sort-alpha">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($getdetails)){ ?>
									<?php foreach($getdetails as $row){
											$qtid=$row->qtid;
										    
										 ?>
										 <!--<tr><td colspan="7" style="color:red;text-align: left;">Quotation No-<?php echo $qtid; ?></td></tr>-->
										 <?php $query=mysqli_query($con,"select * from quotation where qtid='".trim($qtid)."' order by id desc"); ?>
										 <?php $i=1; while($row=mysqli_fetch_array($query)){ 
										 	 $curreny=$row['currencytyp'];
										 	?> 
										
								<tr>
									
									<td><?php echo $i; ?></td>
									<td><?php echo $vid=$row['venid']; ?></td>
									<td><?php
									     $qrvenname=mysqli_query($con,"select * from venderslist where vender_id='".trim($vid)."'"); 
										$rowvname=mysqli_fetch_array($qrvenname);
										echo $vename=$rowvname['vcompany'];
										
										?></td>
									<td><?php echo $pid=$row['poid'] ; ?></td>
									<td><?php if($curreny=="dollar"){ echo "&#36;";}else{ echo "&#x20b9;"; } ?><?php echo $row['total'];  ?></td>
									<td><?php echo $row['disdate']; ?></td>
									<td><a href="<?php echo base_url(); ?>venders/quotationfile/<?php echo $row['file']; ?>" target="_blank"><?php echo $file1=$row['file']; ?></a></td>
									<td><form action="<?php echo base_url(); ?>Purchase_controller/getfinalquotation" method="post"><input type="hidden" name="pid" value="<?php echo $pid; ?>"/><input type="hidden" name="vid" value="<?php echo $vid ;?>"/><button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-eye" aria-hidden="true"></button></i></form></td>
									
								</tr>
								<?php  $i++ ; } }  } ?>
							</tbody>
        
							
    </table>
				</div>
				</form>	
         <div class="tab-pane" id="second1">
	</div>
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							<div class="tab-pane" id="third1"><p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p><p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p></div>
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
 