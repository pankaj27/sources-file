<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />
 
	<!--jQuery-->

<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	
<?php $con=mysqli_connect("localhost","root","","erp_manager"); ?>			
	<style>
		table,tr{
			border-bottom:1px solid #0aa89e;
			text-align: right;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:right;
			height:44px;
		}
		tr{
			text-align: center;
		}
		
		#exmple3 td{
			width:150px;
		}
		#exmple4 td{
			width:250px;
		}
		#exmple5 td{
			width:300px;
		}
		#exam td{
			width:400px;
		}
		#example8 td{
			width:40px;
		}
		
	</style>			

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
			
	<section>

		<!-- BEGIN INBOX -->
		<div class="section-body">
			<div class="row">
                 
				<!-- BEGIN INBOX NAV -->
				<form action="<?php echo base_url(); ?>Purchase_controller/finalorder" method="post" enctype="multipart/form-data">
				<div class="col-md-12">
				<div class="card card-bordered style-primary">
						<div class="card-head">
							<header><i class="fa fa-fw fa-tag"></i>Final Purchase Order</header>
						</div>
					
					<div class="card-body style-default-bright">
					
					 <input type="hidden" name="vid" value="<?php echo $vid; ?>"/>
					 <input type="hidden"  name="poid" value="<?php echo $poid; ?>"/>
					<div class="row">
						
						<?php //print_r($getquot); ?>
                         
						<div class="col-md-12">
							<table id="example" cellspacing="0" width="100%">
        						<thead>
            							<tr style="text-align:right;">
            								<th>S.no</th>
            								<th>P.Id</th>
											<th>P. Name</th>
											<th>M.Name</th>
											<th>M.ID</th>
											<th>Qty</th>
                							<th>Rate </th>
                							<th>Amount</th>
                							<th>Final Rate</th>
                							<th>Final Price</th>
											
            							</tr>
        						</thead>
        									 <?php
											 	 if(isset($getquot)&& !empty($getquot)) 
												 {
												 	  $i=1;
												 	foreach($getquot as $row5)
													{
														$parts=$row5->parts;
														if(empty($parts)){
															 $partsexplode="";
															
														}else{
															 $partsexplode=explode(",",$parts);
														}
														
														//echo $countmode=count($partsexplode);
														 $model=$row5->model;
														
														if(empty($model)){
															echo  $modelexplode="";
															
														}else{
															 $modelexplode=explode(",",$model);
															 //print_r($modelexplode);
														}
														
													   // $countmode=count($modelexplode);
														$tax=$row5->tax;
														$taxexplode=explode(",",$tax);
														$total=$row5->total;
														$fstpmnt=$row5->fstpmnt;
														$sndpmnt=$row5->ndpmnt;
														$thrdpmnt=$row5->thrdpmnt;
														$procdate=$row5->procdate;
														$disdate=$row5->disdate;
														$curreny=$row5->currencytyp;
														$file=$row5->file;
														$nttot=0;
														
													} }
												 ?>
												 <tbody>
											  <?php  
											  	if(!empty($partsexplode)){  ?>
											  		<?php  foreach($partsexplode as $roparts){ ?>
											  			<?php $ropartsexplode=explode(";",$roparts); ?>
											  			<?php 
											  				$partsid=$ropartsexplode[0]; 
															$modelname=$ropartsexplode[1];
															$prtsqty=$ropartsexplode[2];
															$prtserte=$ropartsexplode[3];
															$prtsamnt=$ropartsexplode[4];
											  			
											  			
											  			
											  			
											  			?>
											  	<tr>
												<td><?php echo $i; ?></td>	
												<td><?php echo $partsid; ?><input type="hidden" name="partsid_<?php echo $i; ?>" value="<?php echo $partsid; ?>"/></td>
											   	<td><?php $queryprtnme=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($partsid)."'");
															$rowmateri=mysqli_fetch_array($queryprtnme);
															echo $partsnme=$rowmateri['materialname'];
												
												 ?></td>
											   	<td><?php echo $modelname; ?><input type="hidden" name="modelname_<?php echo $i; ?>" value="<?php echo $modelname; ?>" /></td>
											   	<td>
											   		<?php $queryprtnme=mysqli_query($con,"select * from productmaster where productname='".trim($modelname)."'");
															$rowmateri=mysqli_fetch_array($queryprtnme);
															echo $partsnme=$rowmateri['productid'];
												
												 ?>
											   		
											   		
											   		
											   	</td>
											   	<td style="width: 50px;"><?php echo $prtsqty; ?><input type="hidden" name="qty_<?php echo $i; ?>" id="qty_<?php echo $i; ?>" value="<?php echo $prtsqty; ?>"/></td>
											   	<td><?php echo $prtserte;  ?><input type="hidden" name="partsrte_<?php echo $i; ?>" value="<?php echo $prtserte; ?>"/></td>
											   	<td style="text-align: center;"><?php echo $prtsamnt;$nttot=floatval($nttot)+ floatval($prtsamnt); ?></td>
											   	<td><input type="text" class="decimal-2-places" style="text-align: right;" value="<?php echo $prtserte ;  ?>"  name="finalrte_<?php echo $i; ?>" id="finalrte_<?php echo $i; ?>" onkeyup="getfinaltotal(this.id);"/></td>
											   	<td><input type="text" style="text-align: right;border: none;" value="<?php echo $prtsamnt ;  ?>" name="finalprice_<?php echo $i; ?>" id="finalprice_<?php echo $i; ?>" readonly/></td>
												</tr>	
													
													
												<?php $i++; }} ?>
												<?php 
													if(!empty($modelexplode)){ $modelname1="";$tb=1;?>
														
														<?php $modelexplode=array_filter($modelexplode); ?>
														<?php  foreach($modelexplode as $rowmodel){ ?>
															<?php $modimplode=explode(";",$rowmodel); ?>
															<?php 
																$modelname=$modimplode[0];
																$modelqty=$modimplode[1];
																$prtsid=$modimplode[2];
																//##################################
																$getpartsnamemodelwise=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($prtsid)."'");
																$rowmodelwise=mysqli_fetch_array($getpartsnamemodelwise);
																$partsnam=$rowmodelwise['materialname'];
																$prtsunit=$rowmodelwise['unit'];
																	
																
																//#######################################
																$prtsspe=$modimplode[3];
																$query_spec=mysqli_query($con,"select * from spareparts_specification where id='".trim($prtsspe)."'");
																$rowspe=mysqli_fetch_array($query_spec);
																$spetitl=$rowspe['specification'];
																
																$prtsqty=$modimplode[4];
																$prtsrte=$modimplode[5];
																$prtsamnt=$modimplode[6];
															   
															
															 ?>
												<?php  if($modelname!=$modelname1){ $k=1; $tb++;?>
												<tr><td colspan="10" style="background-color:#0aa89e;color:white;text-align: left; ">Spare Parts For <?php echo $modelname."-Qty($modelqty)"; ?></td></tr>
												<tr><td></td>
													<td>Sl.No.</td>
													<td>PartsID</td>
													<td>Partsname</td>
													<td>Specificaion</td>
													<td>Qty</td>
													<td>Rate</td>
													<td>Amount</td>
													<td>Final Rate</td>
													<td>Final Price</td>
													
												</tr>
												<?php } ?>
												<tr>
												<td></td>
												<td><?php echo $k; ?></td>	
												<td><?php echo $prtsid; ?><input type="hidden" name="prtsid1_<?php echo $i; ?>" value="<?php echo $prtsid; ?>"/></td>
											   	<td><?php echo $partsnam; ?><input type="hidden" name="modelqty_<?php echo $i; ?>" value="<?php echo $modelqty; ?>"/></td>
											   	<td><?php echo $spetitl; ?><input type="hidden" name="modelname_<?php echo $i; ?>" value="<?php echo $modelname;  ?>" /><input type="hidden" name="speci_<?php echo $i; ?>" value="<?php echo $prtsspe;  ?>"/></td>
											   	
											   	<td style="width: 50px;"><?php echo "$prtsunit X $modelqty=$prtsqty" ; ?><input type="hidden" id="qty_<?php echo $i; ?>" name="qty_<?php echo $i; ?>"  value="<?php echo $prtsqty;  ?>"/></td>
											   	<td><?php echo $prtsrte ; ?><input type="hidden" name="partsrte_<?php echo $i; ?>" value="<?php echo $prtsrte; ?>"/></td>
											   	<td style="text-align: center;"><?php echo $modelamnt=$prtsamnt;$nttot=floatval($nttot)+ floatval($modelamnt); ?></td>
											   	<td><input type="text" class="decimal-2-places" value="<?php echo $prtsrte; ?>" name="finalrte_<?php echo $i; ?>" id="finalrte_<?php echo $i; ?>" onkeyup="getfinaltotal(this.id);" style="text-align: right;"/></td>
											   	<td><input type="text" value="<?php echo $prtsamnt; ?>" name="finalprice_<?php echo $i; ?>" id="finalprice_<?php echo $i; ?>"  style="text-align: right;border: none;" readonly/></td>
												
												</tr>
												<?php   $modelname1=$modelname;$k++; $i++;} ?>
												
												
												
											<?php   }	 ?>
        								  	<tr>
        								  		<td colspan="7">Net Total</td>
        								  		<td style="text-align: center;border: none;"><?php if($curreny=="dollar"){ echo "&#36;";}else{ echo "&#x20b9;"; } ?><?php echo $nttot;  ?></td>
        								  		<td></td>
        								  		<td><input type="text" value="<?php  echo floatval($nttot);  ?>" name="nettotal" id="netfinal" readonly style="text-align: right;border:none;"/>
        								  			<input type="hidden" name="totalrow" value="<?php echo $i; ?>" readonly style="text-align: right;border:none;"/>
        								  			<input type="hidden" name="modelrow1" value="<?php if(isset($tb) && !empty($tb)){ echo $tb; }else{echo $tb=1; } ; ?>" readonly style="text-align: right;border:none;" id="modelrow1"/>
        								  		</td>
        								  	</tr>	
        								  <?php //for($k=1;$k<4;$k++){ ?>
        								  	<?php if(!empty($tax)){ $n=1;$taxex=explode(",",$tax); ?>
        								  		<?php foreach($taxex as $row6){ $taxexplode=explode(";",$row6);
        								  		
													$txtxt=$taxexplode[0];
												    $txtrte=$taxexplode[1];
													$txtamnt=$taxexplode[2];
												
												
												 ?>
        							
        									<tr>
        								  		<td colspan="3">Tax <?php echo $n; ?>(%)</td>
        								  		<td colspan="3" style="width: 100px;"><input type="text" name="taxtext_<?php echo $n; ?>" id="<?php   ?>" value="<?php echo $txtxt; ?>" style="border: none;"/></td>
        								  		<td ><input type="text" name="taxrte_<?php echo $n; ?>" class="decimal-2-places" id="taxrte_<?php echo $n; ?>" style="width: 100px;text-align: center;border: none;" value="<?php echo $txtrte;  ?>" onblur="getpercentage(this.id)"/></td>
        								  		<td><input type="text" name="nettotal" readonly value="<?php echo $txtamnt; ?>" style="text-align: center;border: none;"/></td>
        								  		<td><input type="text" name="nettotal" readonly/></td>
        								  		<td><input type="text" value="<?php echo $txtamnt;  ?>" name="taxfinal_<?php echo $n; ?>" id="taxfinal_<?php echo $n; ?>" style="text-align: right;border: none;" readonly/>
        								  			
        								  		</td>
        								  	</tr>
            							   <?php  $n++ ; } } //} ?>   
            							   <input type="hidden" name="taxxfinal" id="taxrow" value="<?php if(isset($n)){echo $n;  } ?>"/> 
            							   <input type="hidden" name="currency"  id="currency" value="<?php if(isset($curreny)){ echo $curreny; } ?>" />
        						 </tbody>
								 
   					 	</table>
						<br>
						
						<hr class="ruler-xxx">
						
						
   					 	
						</div><!--end .col -->
						<!-- END EMAIL CONTENT -->

					</div><!--end .row -->
					
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<div class="col-md-12">
								 <div class="col-md-6"><h4>1st Payment:</h4></div><div class="col-md-3"><input type="text" name="fstpmnt" value="<?php echo $fstpmnt;  ?>" class="decimal-2-places" id="st_1"/></div>
						     </div>
							<div class="col-md-12">
								 <div class="col-md-6">	<h4>2nd Payment:</h4></div><div class="col-md-3"><input type="text" name="sndpmnt" class="decimal-2-places" value="<?php echo $sndpmnt;  ?>" id="st_2" /></div>
							</div>
						   <div class="col-md-12">
								 <div class="col-md-6"><h4> 3rd Payment:</h4></div><div class="col-md-3"><input type="text" class="decimal-2-places" name="thrdpmnt" value="<?php echo $thrdpmnt;  ?>" id="st_3"  /></div>
						  </div>
						 
						  <div class="col-md-12">
								 	<div class="col-md-6"><h4>Processing Date:</h4></div><div class="col-md-3"><input type="text" class="decimal-2-places"  id="datepicker" name="pdate" value="<?php echo $procdate;  ?>" readonly/></div>
						  </div>
						<div class="col-md-12">
								 	<div class="col-md-6"><h4>Dispatchdate:</h4></div><div class="col-md-3"><input type="text" id="datepicker2" class="decimal-2-places" name="disdate" value="<?php echo $disdate;  ?>" readonly/></div>
						</div>
						<div class="col-md-12">
								 	<div class="col-md-6"><h4>Download Attachment:</h4></div><div class="col-md-3"><a href="<?php echo base_url(); ?>venders/quotationfile/<?php echo $file; ?>" target="_blank"><?php echo $file; ?></a></div>
						</div>
						</div>
						<div class="col-md-6">
							
							 <div class="col-md-12">
								<div class="col-md-4"><b>Grand Total:</b></div>
								<div class="col-md-3"><input type="text" id="gtotal"  value="<?php if($curreny=="dollar"){ echo "&#36;";}else{ echo "&#x20b9;"; } ?><?php echo $total;  ?> " readonly name="grandtot" style="text-align: right;font-weight: bold;color:red;border: none;"></div>
								<div class="col-md-2"></div>
								<div class="col-md-3"><input type="text" id="finalgtotal"  value="<?php echo $total; ?> " readonly name="grandtottal" style="text-align: right;font-weight: bolder;" ></div>
								
							</div>
							<div class="col-md-12">
								<div class="col-md-4">
									<!-----#######################################  shortcut key  ###############-->
									<div class="modal fade" id="myModal"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
														    <div class="modal-dialog modal-lg">
														      <div class="modal-content">
														        <div class="modal-header">
														          <button type="button" class="close" data-dismiss="modal">&times;</button>
														          <h4 class="modal-title">Payment Split For Purchase Order No:<?php echo $poid; ?> and Grand total:<?php echo $total; ?> </h4>
														        </div>
														        <div class="modal-body">
														          <div class="row">
														          	<div class="col-md-12">
														          		<div class="col-md-6">
														          			<div class="row">
														          				<div class="col-md-12">
														          					<input type="hidden" id="gtot" value="<?php echo $total; ?>" />
														          				<div class="col-md-4"><h4>Cheque Payment:</h4></div><div class="col-md-8"><input type="text" class="form-control" id="cheque" placeholder="Enter cheque Amount Details" onkeyup="getrestamount();" name="cheque">
														          			</div></div></div>
														          			<div class="form-group">
														      				 	<label for="email">1st Payment:</label>
														      					<input type="text" class="form-control" name="cheque1" id="cheque_1" placeholder="Enter 1st payment" onkeyup="getrestamountindividual(this.id)">
																			</div>
																			<div class="form-group">
																				      <label for="pwd">2nd Payment</label>
																				      <input type="text" class="form-control" name="cheque2" id="cheque_2" placeholder="Enter 2nd payment" onkeyup="getrestamountindividual(this.id)">
																		    </div>
																		    <div class="form-group">
																				      <label for="pwd">3rd Payment</label>
																				      <input type="text" class="form-control" name="cheque3" id="cheque_3" placeholder="Enter 3rd payment" onkeyup="getrestamountindividual(this.id)">
																		    </div>
																		    <div class="form-group">
																				      <label for="pwd">4th Payment</label>
																				      <input type="text" class="form-control" name="cheque4" id="cheque_4" placeholder="Enter 4th payment" onkeyup="getrestamountindividual(this.id)">
																		    </div>
																			<div class="form-group">
																				      <label for="pwd">Rest Payment</label>
																				      <input type="text" class="form-control" id="cheque_5" style="text-align: center;border: none;font-weight: bolder;color:green;">
																		    </div>
																			
																				    
														          			</div>
														          			<div class="col-md-6" style="border-left: 1px solid #c2c2c2;padding: 2px;">
														          			<div class="row" style="padding: 2px;">
														          				<div class="col-md-12">
														          				<div class="col-md-3"><h4>Cash Payment:</h4></div><div class="col-md-9"><input type="text" class="form-control" id="cash" placeholder="Enter cash Amount Details" onkeyup="getrestcheqe();" name="cash">
														          			</div></div></div>
														          			<div class="form-group">
														      					<label for="email">1st Payment</label>
														      					<input type="text" class="form-control" name="cash1" id="cash_1" placeholder="Enter 1st payment" onkeyup="getrestcash(this.id);">
																			</div>
																		    <div class="form-group">
														      					<label for="email">2nd Payment</label>
														      					<input type="text" class="form-control" name="cash2" id="cash_2" placeholder="Enter 2nd payment" onkeyup="getrestcash(this.id);">
																			</div>
																			<div class="form-group">
														      					<label for="email">3rd Payment</label>
														      					<input type="text" class="form-control" name="cash3" id="cash_3" placeholder="Enter 3rd payment" onkeyup="getrestcash(this.id);">
																			</div>
																			<div class="form-group">
														      					<label for="email">4th Payment</label>
														      					<input type="text" class="form-control" name="cash4" id="cash_4" placeholder="Enter 4th payment" onkeyup="getrestcash(this.id);">
																			</div>
																			<div class="form-group">
														      					<label for="email">Rest Amount</label>
														      					<input type="text" class="form-control" id="cash_5">
																			</div>
																																						
																			
														          			
														          		</div>
														          	</div>
														          </div>
														        </div>
														        <div class="modal-footer">
														          <button type="submit" name="save_date1" value="2" class="btn btn-primary" data-success="modal">Submit</button>
														        </div>
														      </div>
														    </div>
														  </div>
																							
																							
																							
																							
																							
																							
																							
									
									<!--##############################  end   #######################-->
									
									
									
									
									
									
								</div>
								<div class="col-md-3"></div>
								<div class="col-md-2"></div>
								<div class="col-md-3"><br><b>
									<button type="submit" id="submit1" value="1" class="btn ink-reaction btn-lg btn-primary" name="save_date1">Submit</button></b></div>
								
							</div>	
							<div class="col-md-12">
								<div id="resttotal" style="color:red;text-align: left;font-weight: bolder;font-size: 6;"></div>
							</div>	
						</div>
						</div>
						</div>
						</div>
					</div>
					
					
					
					
				</div><!--end .col -->

			
		<!-- END INBOX -->
  </form>
		<!-- BEGIN SECTION ACTION -->
		<!--end .section-action -->
		<!-- END SECTION ACTION -->

	</section>

		</div><!--end #content-->		
		<!-- END CONTENT -->
          
		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>login_assets/jquerymodal/js/jquery.modal.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 
<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>-->


<script>
	$(window).load(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
 
 //$("#submit1").hide();
 $(".decimal-2-places").numeric({ decimalPlaces: 2 });
 //$("#submit1").css('display','none');
});
$( function() {
    $( "#datepicker,#datepicker2" ).datepicker({
      showOn: "button",
      buttonImage: "image/calendar.gif",
      buttonImageOnly: true,
      buttonText: "Select date"
    }
    );
  } );
</script>

<script>
function isNumberKey(evt)
       {
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if (charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57))
             return false;

          return true;
       }
	function getfinaltotal(id)
	{
		//alert('hello');
		
		//alert('hello');
		var idsplit=id.split("_");
		//alert(idsplit);
		var qty=$("#qty_"+idsplit[1]).val();
		var rte=$("#finalrte_"+idsplit[1]).val();
		var mdlr=parseInt($("#modelrow1").val());
		//alert(rte);
		var total=parseFloat(rte)* parseInt(qty);
		var rowCount = $('#example tr').length;
		alert(rowCount);
		var txr=$("#taxrow").val();
		alert(txr);
		//alert(rowCount);
		mdlr=((parseInt(mdlr)-1)*2)+5;
		alert(mdlr);
		var nettot=0;
		if(rte=="")
		{
			tot=0;
			var tot=tot.toFixed(2);
		}else
		{
			var total=parseFloat(rte) * parseInt(qty);
			var tot=total.toFixed(2);
		}
		
		nettot=parseFloat(nettot)+parseFloat(tot);
		$("#finalprice_"+idsplit[1]).val(tot);
		nettot=nettot.toFixed(2);
		
		//$("#total").val(nettot);
		//nettot=0;
		var gtot1=0;
		for(var m=1;m<=(mdlr-rowCount) ; m++)
		{
			var gtot=$("#finalprice_"+m).val();
			//alert(gtot);
			if(gtot==""){
				gtot=0;
			}
			//console.log(gtot);
			//console.log("#amountid_"+m);
			gtot1=parseFloat(gtot1) + parseFloat(gtot);
			//console.log(gtot1);
			
		}
		gtot1=gtot1.toFixed(2);
	     alert(gtot1);
		$("#netfinal").val(gtot1);
		var txttoal=0;
		alert(txr);
		for(var c=1;c<parseInt(txr);c++){
			//var finalt=$("#finalgtotal").val(); 
			var ctx=$("#taxrte_"+c).val();
			//alert(ctx);alert(gtot1);
			if(ctx=="")
			{
				ctx=0;
			}
			//txttoal=parseFloat(txttoal)+parseFloat(ctx);
			var k=(parseFloat(gtot1)) * parseFloat(ctx)/100;
			k=k.toFixed(2);
			//alert(k);
			$("#taxfinal_"+c).val(k);
			txttoal=parseFloat(txttoal)+parseFloat(k);
			gtot1=parseFloat(gtot1)+parseFloat(k);
			alert(gtot1);
			
			
		}
		
		//gtot1=parseFloat(gtot1)+parseFloat(txttoal);
		gtot1=gtot1.toFixed(2);
		//alert(gtot1);
		
		$("#finalgtotal").val(gtot1);
	 
	}
	function getpercentage(id)
	{
		var idsplit=id.split("_");
		//alert('hello');
		//var idno=idsplit[1];
		//if()
		var total=$("#netfinal").val();
		//alert(total);
		var txttoal=0;
		var txr=$("#taxrow").val();
		for(var c=1;c<4;c++){
			//var finalt=$("#finalgtotal").val(); 
			var ctx=$("#taxrte_"+c).val();
			alert(ctx);
			if(ctx=="")
			{
				ctx=0;
			}
			//txttoal=parseFloat(txttoal)+parseFloat(ctx);
			var k=(parseFloat(total)) * parseFloat(ctx)/100;
			k=k.toFixed(2);
			//alert(k);
			$("#taxfinal_"+c).val(k);
			txttoal=parseFloat(txttoal)+parseFloat(k);
			
			var gtot1=parseFloat(total)+parseFloat(k);
			total=gtot1;
			//alert(gtot1);
		
		}
		//alert(txttoal);
		gtot1=gtot1.toFixed(2);
		
		$("#finalgtotal").val(gtot1);
			}
			
			function getrestamount(id)
			{
				var idsplit=id.split("_");
				var id=idsplit[1];
				var gtoto=$("#finalgtotal").val();
				var cur=$("#currency").val();
				var getamount=$("#st_"+idsplit[1]).val();
				//alert(getamount);
				
				var  tot=0;
				for(var g=1;g<4;g++)
				{
					var pv=$("#st_"+g).val();
					if(pv=="")
					{
						pv=0;
					}
					//alert(g);
					tot=parseFloat(tot)+parseFloat(pv);
					//alert(tot);
				}
				var rest=parseFloat(gtoto)-parseFloat(tot);
				//alert(tot);
				
				rest=rest.toFixed(2);
				if(rest<0)
				{
					alert('Please enter right number');
					 $("#resttotal").html("<h5>Please put right value</h5>");
					 $("#submit1").hide();
					 if(id==1){
					 	$("#st_2").prop('readonly',true);
					 	$("#st_3").prop('readonly',true);
					 }
				}else{
				
				 if(cur=="inr"){
				 $("#resttotal").html("<h5>&#x20b9;"+rest+"</h5>");
				 
				 }else{
				 
				 	 $("#resttotal").html("<h5>&#36;"+rest+"</h5>");
				 }
				}
				//alert(tot);
				if(tot==gtoto)
				{
					$("#submit1").show();
				}else
				{
					$("#submit1").hide();
				}
				
			}
			function getrestamount()
			{
				var gtot=parseFloat($("#gtot").val());
				var chequ=parseFloat($("#cheque").val());
				var cash=gtot-chequ;
				var cash=cash.toFixed(2);
				//alert(cash);
				$("#cash").val(cash);
				$("#cash").attr('readonly','readonly');
				
				
			}
			function getrestcheqe()
			{
				var gtot=parseFloat($("#gtot").val());
				var cash=parseFloat($("#cash").val());
				var cheque=gtot-cash;
				var cheque=cheque.toFixed(2);
				//alert(cash);
				$("#cheque").val(cheque);
				$("#cheque").attr('readonly','readonly');
			}
			function getrestamountindividual(id)
			{
				var idsplit=id.split("_");
				//var cheqs=$("#cheque_"+idsplit[1]).val();
				var chqamnt=parseFloat($("#cheque").val());
				var chrt=0;
				for(var d1=1;d1<5;d1++)
				{
					var cheqs=parseFloat($("#cheque_"+d1).val());
					//alert(cheqs);
					if(isNaN(cheqs))
					{
						//alert('hdr');
						
						cheqs=0;
					}
					//alert(cheqs);
					chrt=parseFloat(chrt)+parseFloat(cheqs);
				}
				//alert(chrt);
				/*for(var f=(idsplit+1);f<5;f++);
				{
					
				}*t=*/
				//alert(chqamnt);
			var rstamny=parseFloat(chqamnt)-parseFloat(chrt);
			if(parseFloat(rstamny)<0)
			{
				alert('please type actual value');
				$("#cheque_5").val(0);
			}else
			{
				$("#cheque_5").val(rstamny);
			}
			
				
			}
			function getrestcash(id)
			{
				var idsplit=id.split("_");
				//var cheqs=$("#cheque_"+idsplit[1]).val();
				var cashamnt=parseFloat($("#cash").val());
				var chrt=0;
				for(var d1=1;d1<5;d1++)
				{
					var cash=parseFloat($("#cash_"+d1).val());
					//alert(cheqs);
					if(isNaN(cash))
					{
						//alert('hdr');
						
						cash=0;
					}
					//alert(cheqs);
					chrt=parseFloat(chrt)+parseFloat(cash);
				}
				
			var rstamny=parseFloat(cashamnt)-parseFloat(chrt);
			rstamny=rstamny.toFixed(2);
			if(parseFloat(rstamny)<0)
			{
				alert('please type actual value');
				$("#cash_5").val(0);
			}else
			{
				$("#cash_5").val(rstamny);
			}
			
			
			}
</script>
<!--<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css">-->
<script src="<?php echo base_url(); ?>assets/js/jquery-2.1.4.min.js"></script>
<!--<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">-->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    
<script src="<?php echo base_url(); ?>assets/js/keyboardShortcut.js"></script>
<script>
        $(document).ready(function(){
            /*
             Quando uma tecla e pressionada
             */
            var av=parseFloat($("#st_1").val());
            if(av=="" || isNaN(av)){
            	av=0;
            }
            var av2=parseFloat($("#st_2").val());
            if(av2=="" || isNaN(av2)){
            	av2=0;
            }
            var av3=parseFloat($("#st_2").val());
            if(av3=="" || isNaN(av3)){
            	av3=0;
            }
            var tot=av+av2+av3;
           // alert(tot);
            var finalgtotal=parseFloat($("#finalgtotal").val());
           // alert(finalgtotal);
            
            $(document).keydown(function( e ){
            	 
                // Alerta
                keyboardShortcut(
                        {
                            selector: e,
                            key: 'a',
                            ctrl: true
                        },function() {
                            alert('This is an alert.')
                            
                        }
                )
                //  Help
                keyboardShortcut(
                        {
                            selector: e,
                            key: 'i',
                            ctrl: true
                        },function() {
                        	//alert('gfrd');
                            $("#myModal").modal()
                            $('#submit1').css('display','none')
                            
		
                        }
                )
                keyboardShortcut(
                        {
                            selector: e,
                            key: 'l',
                            ctrl: true
                        },function() {
                        	//alert('gfrd');
                           // $("#myModal").modal()
                         // alert(av)
                         if(tot==finalgtotal){
                         	$('#submit1').css('display','block')
                         }else
                         {
                         	 alert('please adjust 1st ,2nd,3rd payment with total amount');
                         }
                           
                            
		
                        }
                )
            })

        })
    </script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.numeric.js"></script>