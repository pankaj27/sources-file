<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php $con=mysqli_connect("localhost","root","","erp_manager"); ?>
<?php $i=1; ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<style>
    .invoice-box{
        max-width:900px;
        margin:auto;
        /*padding:30px;*/
        border:1px solid #eee;
        box-shadow:0 0 10px rgba(0, 0, 0, .15);
       /* font-size:16px;*/
        line-height:24px;
        font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color:#555;
    }
    
    .invoice-box table{
        width:100%;
        line-height:inherit;
        text-align:left;
    }
    
    .invoice-box table td{
        padding:5px;
        vertical-align:top;
    }
    
    .invoice-box table tr td:nth-child(2){
        text-align:right;
    }
    
    .invoice-box table tr.top table td{
        padding-bottom:20px;
    }
    
    .invoice-box table tr.top table td.title{
        font-size:45px;
        line-height:45px;
        color:#333;
    }
    
    .invoice-box table tr.information table td{
        padding-bottom:40px;
    }
    
    .invoice-box table tr.heading td{
        background:#9c27b0;
        color:white;
        border-bottom:1px solid #ddd;
        font-weight:bold;
    }
    
    .invoice-box table tr.details td{
        padding-bottom:20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom:1px solid #eee;
    }
    
    .invoice-box table tr.item.last td{
        border-bottom:none;
    }
    
    .invoice-box table tr.total td:nth-child(2){
        border-top:2px solid #eee;
        font-weight:bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td{
            width:100%;
            display:block;
            text-align:center;
        }
        
        .invoice-box table tr.information table td{
            width:100%;
            display:block;
            text-align:center;
        }
    }
    
	table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			font-size: 13px;
			font-weight: normal;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			height:44px;
		}
		tr{
			text-align: center;
		}
	
    </style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">List Of Purchase Order</li>
				</ol>
					
		           

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message2') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		             <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li class="active"><a href="#first1">Search</a></li>
								<li><a href="#second1">View</a></li>
								<!--<li><a href="#third1">Satistics</a></li>-->
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
				<div class="col-md-12">
					<form class="form" action="<?php echo base_url(); ?>Purchase_controller/Search_podeati"  method="POST" >
							<div class="card">
								<div class="card-head style-primary">
									<header>Spare Parts & Product's Billing Details</header>
								</div>
								<div class="card-body floating-label">
					              	<div class="row">
										<div class="col-sm-2">
											<div class="form-group">
								     			<input type="text" class="form-control" name="pono" value="<?php if(isset($pono1)){ echo $pono1 ; } ?>">
												<label for="Username2">Enter PO No</label>
											</div>
											
										</div>
										<div class="col-sm-2">
											<div class="form-group">
								     			<button type="submit" class="btn ink-reaction btn-raised btn-primary active">Search</button>
											</div>
											
										</div>
								
										
										
									</div>
									</form>		
								  </div><!--end .card-body -->
								
								<div class="card-body floating-label" id="alldata" >
									<?php if(isset($podetails) && !empty($podetails)){ ?>
					              	<div class="row">
										<div class="col-sm-12">
											
												<?php foreach($podetails as $row){
													 $venid=$row->venid;
													 $foid=$row->foid;
													 $poid=$row->poid;
													 $parts=$row->parts;
													 $partsexplode=explode(",",$parts);
													 $partsfilt=array_filter($partsexplode);
													 //print_r($partsexplode);
													 $model=$row->model;
												     $modelexplo=explode(",",$model);
												     $modefil=array_filter($modelexplo);
													// print_r($modelexplo);
													//print_r($modefil);
													 $fstpmnt=$row->fpmnt;
													 $sndpmnt=$row->spmnt;
													 $thrdpmnt=$row->thpmnt;
													 $procdte=$row->procdate;
													 $desdte=$row->disdate;
													 $total=$row->total;
													 $tax=$row->tax;
													 $taxexplode=explode(",",$tax);
													 $taxfilte=array_filter($taxexplode);
													// print_r($taxfilte);
													 
													
													
												} ?>
												<div class="row">
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="venid" value="<?php echo $venid; ?>">
																<label for="Username2">Vendors ID</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="pono" value="<?php echo $poid;  ?> ">
																<label for="Username2">PO No</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="fono" value="<?php echo $foid ?>">
																<label for="Username2">FO No</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="processdate" value="<?php echo $procdte;  ?> ">
																<label for="Username2">Processing Date</label>
															</div>
											
														</div>
								
										
										
												</div>
												<div class="row">
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="despatchdate" value="<?php echo $desdte; ?>">
																<label for="Username2">Despatched Date</label>
															</div>
											
														</div>
														</div>
											 <div class="invoice-box">
											 <table id="example" cellpadding="0" width="100%">
											 	
											 	<tr class="heading">
               											 <td>Sl No</td>
                										 <td style="text-align: Left;">Parts ID</td>
                										  <td>Parts Name</td>
                										  <td>Model Name</td>
                										   <td>Model Code</td>
                										    <td>Qty</td>
                										    <td style="text-align: right;">Rate</td>
                										    <td style="text-align: right;" >Total</td>
            									</tr>
                                              
                                              	
                                              	<?php if(!empty($partsfilt) && isset($partsfilt)){   ?>
                                              		<tr>
                                              			<td colspan="8" style="text-align: left;" >Spare partswise </td>
                                              		</tr>
                                              		<?php foreach($partsfilt as $row){ 
                                              			 // echo $row;
														 // echo "<br>";
                                              			?>
                                              			<?php $partex=explode(";",$row) ; //print_r($partex);
														//echo "<br>";
                                              			
                                              			   $partsid=$partex[0];
                                              			   $modelid=$partex[1];
														   $partsqty=$partex[2];
														   $prtsrte=$partex[4];
														   $prtprice=$partex[5];
                                              			
                                              			?>
                                              	
            									<tr class="item">
                										<td><?php echo $i ; ?></td>
                										<td style="text-align: left;"><?php echo $partsid;  ?></td>
                										<?php $querypartname=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($partsid)."'"); ?>
                										<?php $rowpart=mysqli_fetch_array($querypartname);$partname=$rowpart['materialname']; ?>
                										
                										<td><?php  echo $partname; ?></td>
                										<td><?php echo $modelid;  ?></td>
                										<?php $querymodel=mysqli_query($con,"select * from productmaster where productname='".trim($modelid)."'"); ?>
                										<?php $rowmodel=mysqli_fetch_array($querymodel);$modlnmae=$rowmodel['productid']; ?>
                										
                										<td><?php echo $modlnmae ; ?></td>
                										<td><?php echo $partsqty ; ?></td>
                										<td style="text-align: right;"><?php echo  number_format((float)$prtsrte, 2, '.', ''); ?></td>
                										<td style="text-align: right;"><?php echo $prtprice ; ?></td>
            									</tr>
                                              <?php $i++; } } ?>
                                              <?php if(!empty($modefil) && isset($modefil)){
                                              	  //echo $modelexplo;
                                              	  //print_r($modefil);
                                              	  $modlnmae12="abcfed";$tr1=1;
												 ?>
                                              	<?php  foreach($modefil as $rowmod){
                                              		//echo $rowmod;
                                              		//echo "<br>";
                                              		
													 ?>
                                              		<?php 
                                              		    $modelex=explode(";",$rowmod);
                                              		 //   print_r($modelex);
														//echo "<br>";
														$modelid=$modelex[0];
														//$modname=$modelex[1];
														$modqty=$modelex[1];
														$mpartsid=$modelex[2];
														$mpartsqty=$modelex[4];
														$mpartspecif=$modelex[3];
														//$mpqty=$modelex[4];
														$mprate=$modelex[6];
														$mtot=$modelex[7];
														//$modrte=$modelex[3];
														//$modpri=$modelex[4];
													    $querymodel=mysqli_query($con,"select * from productmaster where productname='".trim($modelid)."'"); 
                										 $rowmodel=mysqli_fetch_array($querymodel);$modlnmae=$rowmodel['productid'];
														 $getpartsn=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($mpartsid)."'");
														// echo "select * from materiel_master where material_id='".trim($mpartsid)."'";
														 $getmprtn=mysqli_fetch_array($getpartsn);//print_r($getmprtn);
														 $prtnme=$getmprtn['materialname'];
                										$getspeci=mysqli_query($con,"select * from spareparts_specification where id='".trim($mpartspecif)."'");
														$getspef=mysqli_fetch_array($getspeci);
														if(!empty($getspef))
														{
															$shospe=$getspef['specification'];
														}else
															{
																$shospe="";
															}
														
														
													
													
													if($modlnmae!=$modlnmae12){
													  ?>
													  
													  <tr>
                                              			<td colspan="8" style="text-align: left;" >Modelwise(<?php echo $modelid;  ?>) </td>
                                              		 </tr>
                                              		 <tr>
                                              		 	
                                              		 	
                                              		 			<td>Sl No.</td>
                                              		 			<td>Parts Name</td>
                                              		 			<td>Specification</td>
                                              		 			<td>Modelname</td>
                                              		 			<td>Modelcode</td>
                                              		 			<td style="text-align: right;">Qty</td>
                                              		 			<td style="text-align: right;">Rate</td>
                                              		 			<td style="text-align: right;">Total</td>
                                              		 		
                                              		 	
                                              		 </tr>
                                              		 <?php } ?>
                                              	<tr class="item">
                										<td><?php echo $tr1 ; ?></td>
                										<td><?php echo $prtnme;  ?></td>
                										<td><?php echo $shospe; ?></td>
                										<td><?php echo $modelid;  ?></td>
                										<?php $querymodel=mysqli_query($con,"select * from productmaster where productname='".trim($modelid)."'"); ?>
                										<?php $rowmodel=mysqli_fetch_array($querymodel);$modlnmae=$rowmodel['productid']; ?>
                										
                										<td><?php echo $modlnmae ; ?></td>
                										<td><?php echo $mpartsqty ; ?></td>
                										<td style="text-align: right;"><?php echo  number_format($mprate,2); ?></td>
                										<td style="text-align: right;"><?php echo $mtot ; ?></td>
            									</tr>
            									<!--<tr class="item">
                										<td><?php echo $i ; ?></td>
                										<td style="text-align: left;"></td>
                										<td></td>
                										<td><?php echo $modelid;  ?></td>
                										<?php $querymodel=mysqli_query($con,"select * from productmaster where productname='".trim($modelid)."'"); ?>
                										<?php $rowmodel=mysqli_fetch_array($querymodel);$modlnmae=$rowmodel['productid']; ?>
                										
                										<td><?php echo $modlnmae ; ?></td>
                										<td><?php echo $modrte ; ?></td>
                										<td style="text-align: right;"><?php echo  number_format((float)$modrte, 2, '.', ''); ?></td>
                										<td style="text-align: right;"><?php echo $modpri ; ?></td>
            									</tr>-->
            								<?php $i++;$tr1++; $modlnmae12=$modlnmae;  } } ?>
            								<?php if(!empty($taxfilte) && isset($taxfilte)){ ?>
            									<?php foreach($taxfilte as $rowtax){ 
            										//echo $rowtax;
            										?>
            									<?php 
            										$taxstex=explode(";",$rowtax); 
													$taxttx=$taxstex[0];
													$txrt=$taxstex[1];
													$txpr=$taxstex[2];
            									
            									
            									
            									
            									?>
            									<tr class="item">
                										<td style="text-align: right;" colspan="6"><?php echo $taxttx;  ?></td>
                										<td style="text-align: right;"><?php echo number_format((float)$txrt, 2, '.', '')."%";  ?></td>
                										<td style="text-align: right;"><?php echo $txpr; ?></td>
            									</tr>
            								<?php }} ?>
            									<tr class="total">
                										<td colspan="7"></td>
                
                										<td>
                  											Grand Total: &#x20b9;<?php echo $total ; ?>
                										</td>
            									</tr>
        									</table>
        								</div>
        								
        								
											
										</div>
										
									</div>
									<hr class="ruler-xxl">
									<div class="row">
									<?php  
										$querypmnt=mysqli_query($con,"select * from pi_invoice where pono='".trim($poid)."' and paymentno='1'");
										  $nr=mysqli_num_rows($querypmnt);
										  $rowfstpmnt=mysqli_fetch_array($querypmnt);
										  $invoiceno=$rowfstpmnt['invoiceno'];
										  $paymentyp=$rowfstpmnt['paymentyp'];
										 $pono=$rowfstpmnt['pono'];
										 $amount=$rowfstpmnt['amount'];
										  $bank=$rowfstpmnt['bank'];
										  $cheque=$rowfstpmnt['cheque'];
										  $branch=$rowfstpmnt['branch'];
										  $doe=$rowfstpmnt['doe'];
										  $venid=$rowfstpmnt['venid'];
										 
										  
										  if($nr>0){ ?>
										  	 <div class="col-md-12">
												<div class="panel-group" id="accordion1">
												<div class="card panel">
													<div class="card-head style-primary collapsed" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-1">
														<header>1st Payment Details</header>
															<div class="tools">
																<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
															</div>
													</div>
													<div id="accordion1-1" class="collapse">
														<div class="card-body">
															<div class="row"><div class="col-md-12"><div class="col-md-6">	
															<div class="card-body no-padding">
																	<ul class="list divider-full-bleed">
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Invoice No:-  <?php if(isset($invoiceno)){ echo $invoiceno; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									PO No:-  <?php if(isset($pono)){ echo $pono; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Vendors ID:- <?php if(isset($venid)){ echo $venid ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Bank Name:- <?php if(isset($bank)){ echo $bank ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Cheque No/Transc Id:- <?php if(isset($cheque)){ echo $cheque ;} ?>
																						</div>
																				</a>
																			</li>
								
																	</ul>
															</div>
															</div>
															<div class="col-md-6">	
															<div class="card-body no-padding">
																	<ul class="list divider-full-bleed">
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Payment Type:- <?php if(isset($paymentyp)){ echo $paymentyp; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Amount:- <?php if(isset($amount)){echo $amount; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Date of Entry:- <?php if(isset($doe)){ echo $doe ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Branch Name:- <?php if(isset($branch)){ echo $branch ;} ?>
																						</div>
																				</a>
																			</li>
								
																	</ul>
															</div>
															</div>
															</div>
															</div>
														</div>
													</div>
												</div>
												</div>
											  </div>			 
										  <?php	}else{
											
										?>
									
										
										<div class="col-sm-12">
											<div class="row">
												<p><button type="button" class="btn ink-reaction btn-floating-action btn-lg btn-primary">1</button></p>
													<form action="<?php echo base_url();  ?>Purchase_controller/savepayment" method="post">
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="invoiceno1" value="">
								     							<input type="hidden" name="paymentno1" value="1"/>
								     							<input type="hidden" name="pono" value="<?php echo $poid ?>"/>
								     							<input type="hidden" name="venid" value="<?php echo $venid ; ?>"/>
								     								
																<label for="Username2">Enter Invoice No </label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="amount1" value="<?php echo $fstpmnt;  ?> ">
																<label for="Username2">Amount</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<select id="select2" name="paymenttype1" class="form-control">
								     								<option value="">&nbsp;</option>
																	<option value="cash">Cash</option>
																	<option value="cheque">Cheque</option>
																	<option value="RTGS/NEFT">RTGS/NEFT</option>
																</select>
																<label for="Username2">Payment Type</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="chequeno1" value=" ">
																<label for="Username2">Cheque No/Transaction Id</label>
															</div>
											
														</div>
								
										
										
												</div>
												<div class="row">
														<div class="col-sm-6">
															<div class="form-group">
								     							<input type="text" class="form-control" name="bankname1" value="">
																<label for="Username2">Bank Name</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="branch1" value="">
																<label for="Username2">Branch</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<button type="submit" class="btn ink-reaction btn-raised btn-primary active" name="submit1">Submit</button>
															</div>
											
														</div>
														
								
										
										
												</div>
												</form>
											
										</div>
										
									</div>
									<?php } ?>
									<hr class="ruler-xxl">
									<div class="row">
										<?php  
										$querypmnt=mysqli_query($con,"select * from pi_invoice where pono='".trim($poid)."' and paymentno='2'");
										  $nr=mysqli_num_rows($querypmnt);
										  $rowfstpmnt=mysqli_fetch_array($querypmnt);
										  $invoiceno=$rowfstpmnt['invoiceno'];
										  $paymentyp=$rowfstpmnt['paymentyp'];
										 $pono=$rowfstpmnt['pono'];
										 $amount=$rowfstpmnt['amount'];
										  $bank=$rowfstpmnt['bank'];
										  $cheque=$rowfstpmnt['cheque'];
										  $branch=$rowfstpmnt['branch'];
										  $doe=$rowfstpmnt['doe'];
										  $venid=$rowfstpmnt['venid'];
										 
										  
										  if($nr>0){ ?>
										  	<div class="col-md-12">
												<div class="panel-group" id="accordion1">
												<div class="card panel">
													<div class="card-head style-primary collapsed" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-2">
														<header>2nd Payment Details</header>
															<div class="tools">
																<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
															</div>
													</div>
													<div id="accordion1-2" class="collapse">
														<div class="card-body">
															<div class="row"><div class="col-md-12"><div class="col-md-6">	
															<div class="card-body no-padding">
																	<ul class="list divider-full-bleed">
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Invoice No:-  <?php if(isset($invoiceno)){ echo $invoiceno; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									PO No:-  <?php if(isset($pono)){ echo $pono; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Vendors ID:- <?php if(isset($venid)){ echo $venid ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Bank Name:- <?php if(isset($bank)){ echo $bank ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Cheque No/Transc Id:- <?php if(isset($cheque)){ echo $cheque ;} ?>
																						</div>
																				</a>
																			</li>
								
																	</ul>
															</div>
															</div>
															<div class="col-md-6">	
															<div class="card-body no-padding">
																	<ul class="list divider-full-bleed">
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Payment Type:- <?php if(isset($paymentyp)){ echo $paymentyp; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Amount:- <?php if(isset($amount)){echo $amount; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Date of Entry:- <?php if(isset($doe)){ echo $doe ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Branch Name:- <?php if(isset($branch)){ echo $branch ;} ?>
																						</div>
																				</a>
																			</li>
								
																	</ul>
															</div>
															</div>
															</div>
															</div>
														</div>
													</div>
												</div>
												</div>
											  </div>
											
											
										 <?php  }else{?>
										<div class="col-sm-12">
											<div class="row">
												<p><button type="button" class="btn ink-reaction btn-floating-action btn-lg btn-primary">2</button></p>
												<form action="<?php echo base_url();  ?>Purchase_controller/savepayment" method="post">
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="invoiceno2" value="">
								     							<input type="hidden" name="paymentno2" value="2"/>
								     							<input type="hidden" name="pono" value="<?php echo $poid ?>"/>
								     							<input type="hidden" name="venid" value="<?php echo $venid ; ?>"/>
																<label for="Username2">Enter Invoice No </label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
																<input type="text" class="form-control" name="amount2" value="<?php echo $sndpmnt;  ?> ">
								     													     							
																<label for="Username2">Amount</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<select id="select2" name="paymenttype2" class="form-control">
								     								<option value="">&nbsp;</option>
																	<option value="cash">Cash</option>
																	<option value="cheque">Cheque</option>
																	<option value="RTGS/NEFT">RTGS/NEFT</option>
																</select>
																<label for="Username2">Payment Type</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="chequeno2" value=" ">
																<label for="Username2">Cheque No(if any)</label>
															</div>
											
														</div>
								
										
										
												</div>
												<div class="row">
														<div class="col-sm-6">
															<div class="form-group">
								     							<input type="text" class="form-control" name="bankname2" value="">
																<label for="Username2">Bank Name</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="branch2" value="">
																<label for="Username2">Branch</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<button type="submit" class="btn ink-reaction btn-raised btn-primary active" name="submit2">Submit</button>
															</div>
											
														</div>
														
								
										
										
												</div>
											</form>
										</div>
										<?php }  ?>
									</div>
									<hr class="ruler-xxl">
									<div class="row">
										<?php  
										$querypmnt=mysqli_query($con,"select * from pi_invoice where pono='".trim($poid)."' and paymentno='3'");
										  $nr=mysqli_num_rows($querypmnt);
										  $rowfstpmnt=mysqli_fetch_array($querypmnt);
										  $invoiceno=$rowfstpmnt['invoiceno'];
										  $paymentyp=$rowfstpmnt['paymentyp'];
										 $pono=$rowfstpmnt['pono'];
										 $amount=$rowfstpmnt['amount'];
										  $bank=$rowfstpmnt['bank'];
										  $cheque=$rowfstpmnt['cheque'];
										  $branch=$rowfstpmnt['branch'];
										  $doe=$rowfstpmnt['doe'];
										  $venid=$rowfstpmnt['venid'];
										 
										  
										  if($nr>0){ ?>
										  						
										  			<div class="col-md-12">
												<div class="panel-group" id="accordion1">
												<div class="card panel">
													<div class="card-head style-primary collapsed" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-3">
														<header>3rd Payment Details</header>
															<div class="tools">
																<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
															</div>
													</div>
													<div id="accordion1-3" class="collapse">
														<div class="card-body">
															<div class="row"><div class="col-md-12"><div class="col-md-6">	
															<div class="card-body no-padding">
																	<ul class="list divider-full-bleed">
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Invoice No:-  <?php if(isset($invoiceno)){ echo $invoiceno; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									PO No:-  <?php if(isset($pono)){ echo $pono; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Vendors ID:- <?php if(isset($venid)){ echo $venid ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Bank Name:- <?php if(isset($bank)){ echo $bank ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Cheque No/Transc Id:- <?php if(isset($cheque)){ echo $cheque ;} ?>
																						</div>
																				</a>
																			</li>
								
																	</ul>
															</div>
															</div>
															<div class="col-md-6">	
															<div class="card-body no-padding">
																	<ul class="list divider-full-bleed">
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-star"></i>
																						</div>
																						<div class="tile-text">
																									Payment Type:- <?php if(isset($paymentyp)){ echo $paymentyp; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Amount:- <?php if(isset($amount)){echo $amount; } ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Date of Entry:- <?php if(isset($doe)){ echo $doe ;} ?>
																						</div>
																				</a>
																			</li>
																			<li class="tile">
																				<a class="tile-content ink-reaction">
																						<div class="tile-icon">
																							<i class="fa fa-inbox"></i>
																						</div>
																						<div class="tile-text">
																									Branch Name:- <?php if(isset($branch)){ echo $branch ;} ?>
																						</div>
																				</a>
																			</li>
								
																	</ul>
															</div>
															</div>
															</div>
															</div>
														</div>
													</div>
												</div>
												</div>
											  </div>		
										  				
										  			
										  		
										  	
									   <?php  }else{ ?>
										<div class="col-sm-12">
											<div class="row">
												<p><button type="button" class="btn ink-reaction btn-floating-action btn-lg btn-primary">3</button></p>
												<form action="<?php echo base_url();  ?>Purchase_controller/savepayment" method="post">
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="invoiceno3" value="">
								     							<input type="hidden" name="paymentno3" value="3"/>
								     							<input type="hidden" name="pono" value="<?php echo $poid ?>"/>
								     							<input type="hidden" name="venid" value="<?php echo $venid ; ?>"/>
																<label for="Username2">Enter Invoice No </label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
																<input type="text" class="form-control" name="amount3" value="<?php echo $sndpmnt;  ?> ">
								     													     							
																<label for="Username2">Amount</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<select id="select2" name="paymenttype3" class="form-control">
								     								<option value="">&nbsp;</option>
																	<option value="cash">Cash</option>
																	<option value="cheque">Cheque</option>
																	<option value="RTGS/NEFT">RTGS/NEFT</option>
																</select>
																<label for="Username2">Payment Type</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="chequeno3" value=" ">
																<label for="Username2">Cheque No(if any)</label>
															</div>
											
														</div>
								
										
										
												</div>
												<div class="row">
														<div class="col-sm-6">
															<div class="form-group">
								     							<input type="text" class="form-control" name="bankname3" value="">
																<label for="Username2">Bank Name</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<input type="text" class="form-control" name="branch3" value="">
																<label for="Username2">Branch</label>
															</div>
											
														</div>
														<div class="col-sm-3">
															<div class="form-group">
								     							<button type="submit" class="btn ink-reaction btn-raised btn-primary active" name="submit3">Submit</button>
															</div>
											
														</div>
														
								
										
										
												</div>
											</form>
										</div>
										
										
									</div>
									<?php }?>
									<?php  } ?>
									<!---->
								
									
									
								
								</div>
							
						</div><!--end .card -->
				</div>
							    	
							    	
							    	
				</div>
								
								
				</div>
				
         <div class="tab-pane" id="second1">
         	<div class="col-lg-12">
					<div class="table-responsive">
						<table id="example" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>Sl No</th>
									<th>FO No</th>
									<th>PO No</th>
									<th>vendors ID</th>
									<th class="sort-numeric">Grand Total</th>
									<th class="sort-alpha">Proc. Date</th>
									<th class="sort-alpha">Desp. Date</th>
									<th>Status</th>
									<th class="sort-alpha">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php  ?>
								<?php if(isset($viewpilist)  && !empty($viewpilist)){$i=1; ?>
									<?php foreach($viewpilist as $row){  $couurencytype=$row->currencytyp;	 ?>
									 	
								<tr>
									
									<td><?php echo $i; ?></td>
									<td><?php echo $foid=$row->foid; ?></td>
									<td><form action="<?php echo base_url(); ?>Purchase_controller/Search_podeatils" method="post"><input type="hidden" name="pono" value="<?php echo $poid=$row->poid ; ?>"><button class="btn btn-flat btn-primary ink-reaction" type="submit"> <?php echo $poid=$row->poid ; ?></button></form></td>
									<td><?php echo $venid=$row->venid ; ?></td>
									<td><?php if($couurencytype=="inr"){ echo $ct="&#x20b9;" ; }else{ echo $ct="&#36;"; } ?><?php echo $row->total ; ?></td>
									<td><?php echo $row->procdate;  ?></td>
									<td><?php echo $row->disdate; ?></td>
									<td>
										
											<a href="javascript:toggleDiv(<?php echo $i; ?>);" style="background-color: #ccc; padding: 5px 10px;">Payment Details</a>
										<div id="tog_<?php echo $i ?>" class="togcl">
										<?php echo "Payment No 1:".$ct.$fpmnt=$row->fstpmnt;
										
									      $querypmnt=mysqli_query($con,"select * from pi_invoice where pono='".trim($poid)."' and paymentno='1'");
										  $nr=mysqli_num_rows($querypmnt);
										  if($nr>0){ ?> <em class="text-caption" style="color:green;">Payment Done</em> <?php }else	{ ?> <em class="text-caption" style="color:red;">Pending..</em> <?php 	}?>
										<?php echo "<hr>Payment No 2:".$ct.$sndpmnt=$row->ndpmnt; 
										  $querypmnt=mysqli_query($con,"select * from pi_invoice where pono='".trim($poid)."' and paymentno='2'");
										  $nr=mysqli_num_rows($querypmnt);
										  if($nr>0){ ?> <em class="text-caption" style="color:green;">Payment Done</em> <?php }else	{ ?> <em class="text-caption" style="color:red;">Pending..</em> <?php 	}?>
										<br>
										<?php echo "<hr>Payment No 3:".$ct.$trdpmnt=$row->thrdpmnt; 
										  $querypmnt=mysqli_query($con,"select * from pi_invoice where pono='".trim($poid)."' and paymentno='3'");
										  $nr=mysqli_num_rows($querypmnt);
										  if($nr>0){ ?> <em class="text-caption" style="color:green;">Payment Done</em> <?php }else	{ ?> <em class="text-caption" style="color:red;">Pending..</em> <?php 	}?>
										</div>
									</td>
									<td><!--<a href="<?php echo base_url(); ?>"><i class="fa fa-edit" title="Edit"></i></a>&nbsp;&nbsp;--><a href="<?php echo base_url();?>Purchase_controller/deletepodetails/<?php echo $row->id; ?>" onclick="return confirm('want to delete?')"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a>&nbsp;&nbsp;<!--<a href="<?php echo base_url(); ?>"><i class="fa fa-eye" aria-hidden="true" title="View"></i></a>--></td>
									
								</tr>
								<?php  $i++ ;  }  } ?>
							</tbody>
						</table>
					</div><!--end .table-responsive -->
				</div>
         </div>
		<div class="tab-pane" id="third1">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<article class="margin-bottom-xxl">
						<p>
							Accordions make use of cards.
							A selected card is slightly larger than the folded cards.
						</p>
					</article>
				</div><!--end .col -->
				<div class="col-md-12">
						<div class="panel-group" id="accordion1">
						<div class="card panel">
							<div class="card-head style-primary collapsed" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-1">
								<header>Header</header>
								<div class="tools">
									<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
								</div>
							</div>
							<div id="accordion1-1" class="collapse">
								<div class="card-body">						<p>Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Dicant vituperata consequuntur.</p>
			</div>
							</div>
						</div><!--end .panel -->
						<div class="card panel expanded">
							<div class="card-head" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-2">
								<header>Header</header>
								<div class="tools">
									<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
								</div>
							</div>
							<div id="accordion1-2" class="collapse in">
								<div class="card-body">						<p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p>
			<p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p>
			</div>
							</div>
						</div><!--end .panel -->
						<div class="card panel">
							<div class="card-head collapsed" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-3">
								<header>Header</header>
								<div class="tools">
									<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
								</div>
							</div>
							<div id="accordion1-3" class="collapse">
								<div class="card-body">						<p>Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Dicant vituperata consequuntur.</p>
			</div>
							</div>
						</div><!--end .panel -->
						<div class="card panel">
							<div class="card-head collapsed" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-4">
								<header>Header</header>
								<div class="tools">
									<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
								</div>
							</div>
							<div id="accordion1-4" class="collapse">
								<div class="card-body">						<p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p>
			<p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p>
			</div>
							</div>
						</div><!--end .panel -->
					</div><!--end .panel-group -->
					<em class="text-caption">Accordion</em>
				</div><!--end .col -->
			</div><!--end .row -->
			
		</div>
		</div><!--end .card-body -->
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			
			<hr class="ruler-xxl">

			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->

<script>
$(document).ready(function(){
	
	//alert('hello');
	$(".togcl").hide();
});
	function getallpodetails()
	{
		//alert('hello');
		var pono=$("#pono").val();
		//alert(pono);
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Purchase_controller/getpurchasepaymentdetails",
  			data :{'pono':pono},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				var foid=json.foid;
  				var venid=json.venid;
  				var poid=json.poid;
  				var parts=json.parts;
  				var partssplit=parts.split(",");
  				var partssplitlen=partssplit.length;
  				alert(partssplitlen);
  				var model=json.model;
  				var modesplit=model.split(",");
  				var modellen=modesplit.length;
  				alert(modellen);
  				var fstpmnt=json.fstpmnt;
  				var ndpmnt=json.ndpmnt;
  				var thrdpmnt=json.thrdpmnt;
  				var procdate=json.procdate;
  				var disdate=json.disdate;
  				var tax=json.tax;
  				var taxsplit=tax.split(",");
  				var taxlen=taxsplit.length;
  				alert(taxlen);
  				taxdiv="";
  				for( var b=0;b<taxlen;b++)
  				{
  					var taxst=taxsplit[b];
  					var taxstsplit=taxst.split(";");
  					var taxstring=taxstsplit[0];
  					var taxrte=taxstsplit[1];
  					var taxamnt=taxstsplit[2];
  					taxdiv +="<div><div>"+taxstring+"</div><div>"+taxrte +"</div><div>"+taxamnt +"</div></div>"
  					//alert(taxst);
  				}
  				//alert(taxdiv);
  				$("#foid").val(taxdiv);
  				//alert(foid);
  				  			  
              }  
           });
          
	}
	function toggleDiv(id)
	{
		var id=id;
		$("#tog_"+id).toggle();
		  
	}
</script>
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>


<?php $this->load->view('dashboard/main_menu_left.php'); ?>
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
