<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php include("connection.php"); ?>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
		<section>
			<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">New Spare Parts Entry</li>
				</ol>

			</div>
			<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
						 <div class="alert alert-danger alert-dismissible">
					           <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
					                <?php echo $this->session->flashdata('message'); ?>
						   </div>
		            <?php }?>
		       <div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">New Spareparts Entry</a></li>
																
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								
								<div class="col-md-12">
							    <div class="card">
							    	<form action="<?php echo base_url();  ?>newBrand_controller/getallspareparts" method="post">
									<div class="card-head style-primary">
										<header>Select Model</header>
									</div>
									<div class="card-body floating-label">
										<div class="col-md-8">
											<div class="form-group">
												
												<select class="form-control select2-list" data-placeholder="Select an item" name="mName"  required >
													<?php if(isset($modelname) && !empty($modelname)){ ?>
														<option value="<?php echo $modelname;  ?>" selected><?php echo $modelname;  ?></option>
														<option value="">--select Model---</option>
														<?php   if(isset($model) && !empty($model)){ ?><?php    foreach($model as $row) {   ?><option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option><?php  		} }?> ?>
														
												<?php	}else{ ?>
														
													
													<option value="">--select Model---</option>
													<?php if(isset($model) && !empty($model)){ ?><?php    foreach($model as $row) {   ?><option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option><?php  		} }?>											
												<?php 	} ?>
												</select>
												<!--<input type="text" class="form-control" id="brand" name="brand">-->
												
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<div class="card-actionbar">
													<div class="card-actionbar-row">
														<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
													</div>
												</div>
											</div>
										</div>
					              	</div><!--end .section-body -->
					              	 </form>
					             </div>
					            </div>
					           
	<!--                              all spareparts list                              -->
					            <?php if(isset($alcommonparts) && !empty($alcommonparts)){ $sl=1; ?>
					            <div class="col-md-12">
							    <div class="card">
									<div class="card-head style-primary">
										<header>Sparepats List for <?php  echo $modelname ;  ?></header>
									</div>
									<div class="card-body floating-label">
										<div class="col-md-12">
											 <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
											<form action="<?php echo base_url(); ?>newBrand_controller/saveallprt" method="POST">
											<div class="form-group" style="overflow-y: scroll;">
												<table class="table table-border" id="example1">
													<thead>
														<tr>
															<th>Sl No.</th>
															<th>Model</th>
															<th>Parts name</th>
															
															<th>Parts Code</th>
															<th>Unit</th>
															<th>Weight</th>
															<th>Re-orderlabel</th>
															<th>Specification</th>
															<th>Action</th>
															
														</tr>
													</thead>
													<tbody>
														
															<?php foreach($alcommonparts as $row){ 
																
																$pid=$row->materiel_id;
																$id=$row->id;
																$qry=mysqli_query($con,"select * from materiel_master where id='".trim($id)."'");
																$rw=mysqli_fetch_array($qry);
																$wt=$rw['wt'];
																$reord=$rw['reorderlevel'];
																$chkspef=$qrspe=mysqli_query($con,"select * from spareparts_specification where productid='".trim($id)."'");
																$rwspef=mysqli_fetch_array($chkspef);
																//print_r($rwspef);
															//echo "<br>";
																?>
														<tr>
															<td><?php  echo $sl; ?>
																<input type="hidden" name="prtsmid_<?php echo $sl; ?>" value="<?php echo $row->id; ?>" id="prtsmid_<?php echo $sl; ?>"/>
																<input type="hidden" name="model_<?php echo $sl; ?>"  id="model_<?php echo $sl; ?>" value="<?php echo $modelname; ?>" /></td>
																<td><?php echo $modelname; ?></td>
															<td><?php echo $row->materialname; ?><input type="hidden" name="partsname_<?php echo $sl; ?>"  id="partsname_<?php echo $sl; ?>" value="<?php echo $row->materialname; ?>" /></td>
															
															<td><?php  echo $pid;   ?> <input type="hidden" name="partsid_<?php echo $sl; ?>"  id="partsid_<?php echo $sl; ?>" value="<?php echo $pid; ?>" /></td>
															<td><?php echo $row->unit; ?><input type="hidden" name="unit_<?php echo $sl; ?>"  id="unit_<?php echo $sl; ?>" value="<?php echo $row->unit; ?>" /></td>
															<td><input typ="text" name="weight_<?php echo $sl; ?>" id="weight_<?php echo $sl; ?>" style="width:100px;" value="<?php if(isset($wt) && !empty($wt)){ echo $wt;} ?>"></td>
															<td><input typ="text" name="reorder_<?php echo $sl; ?>" id="reorder_<?php echo $sl; ?>" style="width:50px;" value="<?php if(isset($reord) && !empty($reord)){ echo $reord;} ?>"> </td>
															<td>
																<?php if(empty($rwspef)){ ?>
																<input typ="text" name="specf_<?php echo $sl; ?>_1" id="specf_<?php echo $sl; ?>_1" style="width:100px;">
																<button type="button" id="add_<?php echo $sl; ?>" class="btn btn-flat btn-primary ink-reaction" data-toggle="modal" data-target="#myModal_<?php echo $sl; ?>"><i class="fa fa-plus" aria-hidden="true"></i></button>
																<!--############################    MOdal    ###########################-->
																	<div class="modal fade" id="myModal_<?php echo $sl; ?>" role="dialog">
																	    <div class="modal-dialog modal-md">
																	      <div class="modal-content">
																	        <div class="modal-header">
																	          <button type="button" class="close" data-dismiss="modal">&times;</button>
																	          <h4 class="modal-title">Add Specification For <?php  echo $row->materialname; ?>(<?php echo $modelname; ?>)</h4>
																	        </div>
																	        <div class="modal-body">
																	          <div class="row">
																	          	<?php for($sp=1;$sp<10;$sp++){ ?>
																	          	<div class="col-md-12">
																	          		<div class="col-md-2"><?php echo  ($sp+1);?></div>
																	          		<div class="col-md-10">
																	          			<div class="form-group">
																	          			       <input type="text"  class="form-control" name="specf_<?php echo  $sl; ?>_<?php echo ($sp+1); ?>" id="specf_<?php echo  $sl; ?>_<?php echo ($sp+1); ?>" />
																	          			</div>
																	          		</div>
																	          	</div>
																	          <?php } ?>
																	          </div>
																	        </div>
																	        <div class="modal-footer">
																	          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																	          <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
																	        </div>
																	      </div>
																	    </div>
																	  </div>
																
																
																
																<!-- ################################  End Of Modal  ####################-->
																 <?php }else{  ?>
																 	<button type="button" id="add_<?php echo $sl; ?>" class="btn btn-flat btn-primary ink-reaction" data-toggle="modal" data-target="#myModalspef_<?php echo $sl; ?>"><i class="fa fa-eye" aria-hidden="true"></i> show</button>
																	<!--############################  edit specification modal  MOdal    ###########################-->
																	<div class="modal fade" id="myModalspef_<?php echo $sl; ?>" role="dialog">
																	    <div class="modal-dialog modal-md">
																	      <div class="modal-content">
																	        <div class="modal-header">
																	          <button type="button" class="close" data-dismiss="modal">&times;</button>
																	          <h4 class="modal-title">Add Specification For <?php  echo $row->materialname; ?>(<?php echo $modelname; ?>)</h4>
																	        </div>
																	        <div class="modal-body">
																	          <div class="row">
																	          	<?php $sp1=1;
																				$chkspef=$qrspe=mysqli_query($con,"select * from spareparts_specification where productid='".trim($id)."'");
																				 while($rfd=mysqli_fetch_array($chkspef)){ 
																	          		$spd=$rfd['specification'];
																	          		?>
																	          	<div class="col-md-12">
																	          		<div class="col-md-2"><?php echo  $sp1;?></div>
																	          		<div class="col-md-10">
																	          			<div class="form-group">
																	          			       <input type="text"  class="form-control" name="specf_<?php echo  $sl; ?>_<?php echo ($sp1); ?>" id="specf_<?php echo  $sl; ?>_<?php echo ($sp1); ?>" value="<?php if(isset($spd)){echo $spd; } ?>" />
																	          			</div>
																	          		</div>
																	          	</div>
																	          <?php $sp1++; } ?>
																	          <?php if($sp1<10){ ?>
																	          	<?php for($sp1=$sp1;$sp1<11;$sp1++){ ?>
																				<div class="col-md-12">
																	          		<div class="col-md-2"><?php echo  $sp1;?></div>
																	          		<div class="col-md-10">
																	          			<div class="form-group">
																	          			       <input type="text"  class="form-control" name="specf_<?php echo  $sl; ?>_<?php echo ($sp1); ?>" id="specf_<?php echo  $sl; ?>_<?php echo ($sp1); ?>" value="" />
																	          			</div>
																	          		</div>
																	          	</div>
																				
																				
																	       <?php }    } ?>
																	          </div>
																	        </div>
																	        <div class="modal-footer">
																	          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																	          <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
																	        </div>
																	      </div>
																	    </div>
																	  </div>
																
																
																
																<!-- ################################  End Of specification  Modal  ####################-->
																	
																	
																	
															  <?php	 } ?>
															</td>
															<td><button type="button" id="save_<?php echo $sl; ?>" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-floppy-o" aria-hidden="true"></i></button> &nbsp;<button type="button" id="delete_<?php echo $sl; ?>" class="btn btn-flat btn-primary ink-reaction"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
															
														</tr>
														
												<?php   $sl++; }  ?>
													</tbody>
													<input type="hidden" name="rowcoun" value="<?php echo $sl; ?>">
												</table>
												<div class="form-group">
												<div class="card-actionbar">
													<div class="card-actionbar-row">
														<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
													</div>
												</div>
											</div>
											</form>
											</div>
										</div>
					              	</div><!--end .section-body -->
					             </div>
					            </div>
					            <?php  } ?>
	<!----                end of card                                            -->
					          </div>
					         </div>
					        </div>
					      </div>
					    </div>
	        </section>
		</div><!--end #content-->
		</div>		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function getexceldata(){
		//alert('hello');
      $("#example1").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
</script>
<script src="<?php echo base_url(); ?>assets/js/src/jquery.table2excel.js"></script>
 
