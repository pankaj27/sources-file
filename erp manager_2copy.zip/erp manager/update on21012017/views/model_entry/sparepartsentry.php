<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<div id="base">
<!-- BEGIN OFFCANVAS LEFT -->
<div class="offcanvas">
</div>
	<div id="content">
		<section>
			<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">New Spare Parts Entry</li>
				</ol>

			</div>
			<div class="section-body contain-lg">
               <?php if($this->session->flashdata('message') != ''){ ?>
				   <div class="alert alert-danger alert-dismissible">
				        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
							<?php echo $this->session->flashdata('message'); ?>
				   </div>
		      <?php }?>
		      <div class="row">
		      		<div class="col-md-12">
		      			<div class="card">
		      				<div class="card-head">
								<ul class="nav nav-tabs" data-toggle="tabs">
									<li><a class="active">Create</a></li>
								</ul>
							</div>
							<div class="card-body tab-content">
								<div class="tab-pane active" id="first1">
									<div class="col-md-12">
										<div class="card">
											<div class="card-head style-primary">
												<header>Select Model</header>
											</div>
											<div class="card-body floating-label">
												<form action="<?php echo base_url(); ?>NewBrand_controller/getallspareparts" method="POST">
												<!-------------  Model Select --->
												<div class="col-md-8">
													<div class="form-group">
														<input type="hidden"  value="1" name="divnorow" id="abcd"/>
														<select class="form-control select2-list" data-placeholder="Select an item" name="mName"  required="required" >
															<option value="">---------Select Model---------</option>
																<?php 
																		if(isset($model)){foreach($model as $rowmodel){?><option value="<?php echo $rowmodel->productname; ?>"><?php echo $rowmodel->productname; ?></option><?php 	}} ?>
														</select>
															<!--<input type="text" class="form-control" id="brand" name="brand">-->
														    <!--<label for="mName">Model Name</label>-->
													</div>
												</div>
												<!----  Model Select  Submit   -->
												<div class="col-md-2">
													<div class="form-group">
														<div class="card-actionbar">
															<div class="card-actionbar-row">
																<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
															</div>
														</div>
													</div>
												</div>
												</form>
											</div>
										</div>
<!---#####################################################################################################################-->
<!--                                                          Generate TAble                                                                                   -->
<!--####################################################################################################################-->
										<?php if(isset($getallprt) && !empty($getallprt)){ ?>
										<div class="card">
											<div class="card-head style-primary">
												<header>Spare Parts List for <?php if(isset($modl)){ echo $modl; } ?></header>
											</div>
											<div class="card-body floating-label">
												<form action="<?php echo base_url(); ?>NewBrand_controller/getallspareparts" method="POST">
												<!-------------  Model Select --->
												<div class="col-md-12">
													<table class="table table-bordered">
													    <thead>
													        <tr>
													            <th>Slno </th>
													            <th>Parts Name</th>
													            <th>Parts Code</th>
													            <th>Unit</th>
													            
													            <th>Weight</th>
													            <th>Reordr Level</th>
													            <th>Specf.</th>
													            
													            <th>Action</th>
													        </tr>
													    </thead>
													    <tbody>
													    	<?php echo $sl=1; ?>
													    	<?php foreach($getallprt as $row2){ ?>
													    	<tr>
													    		<td><?php echo $sl; ?></td>
													    		<td><?php echo $row2->partsname; ?><input type="hidden" name="partsname_<?php echo $sl; ?>" value="<?php echo $row2->partsname; ?>"></td>
													    		<td><?php  ?><input type="hidden" name="pcode_<?php echo $sl; ?>" value=""></td>
													    		<td><?php echo $row2->unit; ?><input type="hidden" name="punit_<?php echo $sl; ?>" value=""></td>
													    		<td><input type="text" name="weight_<?php echo $sl; ?>"></td>
													    		<td><input type="text" name="reorder_<?php echo $sl; ?>"></td>
													    		<td><input type="text" name="speci_<?php echo $sl; ?>"></td>
													    		
													    		
													    		<td></td>
													    	</tr>
													       <?php $sl++; } ?>
													    </tbody>
													</table>
												</div>
												<!----  Model Select  Submit   -->
											</div>
										</div>									

								<?php } ?>


<!---#####################################################################################################################-->
<!--                                                          End Of Table                                                            -->
<!--####################################################################################################################-->


									</div>
								</div>
							</div>
		      			</div>
		      		</div>
		      </div>
		      
			</div>
	</section>
	</div><!--end .section-body -->
	
</div><!--end #content-->		
		
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		
<?php  $this->load->view('dashboard/fotter.php'); ?>