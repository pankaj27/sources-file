<?php
	$con=mysqli_connect("localhost","root","","erp_manager");


?>