<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $(document).(function(){
    $("#example").dataTable();
  })
  </script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Edit Model Entry</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li class="active"><a href="#first1">Edit</a></li>
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
									
									<?php if(isset($model) && !empty($model)){
													foreach($model as $row){
														$id=$row->id;
														
														}
													}  
													?>
									
				<form class="form" action="<?php echo base_url(); ?>newBrand_controller/updatNewEnrey"  method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Information</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-12">
										<div class="form-group">
											<!--<select class="form-control select2-list" data-placeholder="Select an item" name="brand">
												<option value=""></option>
												<option value="g5red">G5(Red)</option>
												<option value="g5green">G5(Green)</option>
												<option value="g5blue">G5(Blue)</option>
												   <option value="k9red">K9(Red)</option>
											</select>
											<label>Brand</label>-->
											<input type="hidden"  value="<?php if(isset($id)){ echo $id ;} ?>" name="id"/>
											<input type="text" class="form-control" id="brand" name="brand" value="GK" readonly >
											<label for="brand">Brand Name</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" style="text-transform: uppercase;" class="form-control" id="modelName" name="modelName" required value="<?php echo $row->productname; ?>">
												<label for="modelName">Model Name</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="modelcode" name="modelcode" value="<?php echo $row->productid; ?>" readonly >
												<label for="modelcode">Model Code</label>
											</div>
										</div>
									</div>
									<br><br>
									<div class="card-head style-primary">
										<header>Battery Information</header>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" style="text-transform: uppercase;" class="form-control" id="batteryPower" name="batteryPower" required value="<?php echo $row->batteryPower; ?>">
												<label for="batteryPower">Battery Power</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" style="text-transform: uppercase;" class="form-control" id="batteryModel" name="batteryModel" required value="<?php echo $row->batteryModel; ?>">
												<label for="batteryModel">Battery Model</label>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" style="text-transform: uppercase;" class="form-control" id="clsModel" name="clsModel" value="<?php echo $row->clsModel; ?>">
												<label for="clsModel">Class of Model</label>
											</div>
										</div>
									</div>
									<br><br>
									<!--<div class="card-head style-primary">
										<header>Price Information</header>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="disPric_excld" name="disPric_excld" value="<?php //echo $row->disPric_excld; ?>">
												<label for="disPric_excld">Distributer Price (Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="disPric_incld" name="disPric_incld" value="<?php// echo $row->disPric_incld; ?>">
												<label for="disPric_incld">Distributer Price (Including Battery):</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="dis2subPric_excld" name="dis2subPric_excld" value="<?php //echo $row->dis2subPric_excld; ?>">
												<label for="dis2subPric_excld">Distributer to sub-distributer Price (Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="dis2subPric_incld" name="dis2subPric_incld" value="<?php// echo $row->dis2subPric_incld; ?>">
												<label for="dis2subPric_incld">Distributer to sub-distributer Price (Including Battery):</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="sub2dis_excld" name="sub2dis_excld" value="<?php// echo $row->sub2dis_excld; ?>">
												<label for="sub2dis_excld">Sub-Distributer To Retailer Price(Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="sub2dis_incld" name="sub2dis_incld" value="<?php //echo $row->sub2dis_incld; ?>">
												<label for="sub2dis_incld">Sub-Distributer To Retailer Price(Including Battery):</label>
											</div>
										</div>
									</div>
									<br><br>-->
									<div class="card-head style-primary">
										<header>Tax Information</header>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input  type="text" class="form-control" id="vat" name="vat" value="<?php echo $row->vat; ?>">
												<label for="vat">Vat % :</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="Sales" name="Sales" value="<?php echo $row->Sales; ?>">
													<label for="Sales">Sales % :</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="Road" name="Road" value="<?php echo $row->excise; ?>">
												<label for="Road">Excise Tax:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="cst" name="cst" value="<?php echo $row->cst; ?>">
													<label for="cst">CST</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="ntext" class="form-control" id="custom" name="custom" value="<?php echo $row->custom; ?>">
												<label for="custom">Custom Duty</label>
											</div>
										</div>
									</div><br><br>
									<div class="card-head style-primary">
										<header>Others Information</header>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" style="text-transform: uppercase;" class="form-control" id="servpaid" name="servpaid" value="<?php echo $row->servpaid; ?>">
												<label for="servpaid">Service Paid:</label>
											</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" style="text-transform: uppercase;" class="form-control" id="servday" name="servday" value="<?php echo $row->servday; ?>">
													<label for="servday">Service Days/Km :</label>
												</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" style="text-transform: uppercase;" class="form-control" id="motorPower" name="motorPower" value="<?php echo $row->motorPower; ?>">
													<label for="motorPower">Motor Power:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<input type="text" style="text-transform: uppercase;" class="form-control" id="seatcap" name="seatcap" value="<?php echo $row->seatcap; ?>" required >
												<label for="seatcap">Seat. Capacity:</label>
											</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="number" style="text-transform: uppercase;" class="form-control" id="grossvhc" name="grossvhc" value="<?php echo $row->grossvhc; ?>">
													<label for="grossvhc">Gross Vhc. Wt (kg):</label>
												</div>
										</div>
										<div class="col-md-4">
												<div class="form-group">
													<input type="text" style="text-transform: uppercase;" class="form-control" id="bodyType" name="bodyType" value="<?php echo $row->bodyType; ?>">
													<label for="bodyType">Types of Body:</label>
												</div>
										</div>
									</div>
									<div class="row">
										<!--<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="fuelUsed" name="fuelUsed" value="<?php //echo $row->fuelUsed; ?>">
												<label for="fuelUsed">Fuel used:</label>
											</div>
										</div>-->
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="mfgYear" name="mfgYear" value="<?php echo $row->mfgYear; ?>" readonly >
													<label for="mfgYear">Mfg. Year :</label>
												</div>
										</div>
										<!--<div class="col-md-4">
												<div class="form-group">
													<input type="text" class="form-control" id="unLoadwt" name="unLoadwt" value="<?php //echo $row->unLoadwt; ?>">
													<label for="unLoadwt">Unloaden Weight:</label>
												</div>
										</div>-->
									</div>
									<!--<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="octrail" name="octrail" value="<?php// echo $row->octrail; ?>">
												<label for="octrail">Octrai No :</label>
											</div>
										</div>
									</div>-->	
									
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="ace-icon fa fa-check"></i> Update</button>&nbsp;&nbsp;&nbsp;
											<a href="<?php echo base_url();?>newBrand_controller/modelEntry"><button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="ace-icon fa fa-times"></i> Cancel</button></a>
								</div>
							</div>
								
							</div><!--end .card-body -->
							
						</div><!--end .card -->
						    	</div>
							    	<!--<div class="col-md-6">
							    		<div class="card">
							<div class="card-head style-primary">
								<header>Contact Information</header>
							</div>
							<div class="card-body floating-label">
					              <div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactname1">
											<label for="Firstname2">Contact Name1</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="email" class="form-control" id="Lastname2" name="contactemail1">
											<label for="Lastname2">Contact Email1</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactphno1">
											<label for="Firstname2">Contact Phno1</label>
										</div>
									</div>
									
								</div>
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactname2">
											<label for="Firstname2">Contact Name2</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="email" class="form-control" id="Lastname2" name="contactemail2" >
											<label for="Lastname2">Contact Email2</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactphno2"> 
											<label for="Firstname2">Contact Phno2</label>
										</div>
									</div>
									
								</div>
								
								
							</div><!--end .card-body -->
							
						<!--</div>
							    	<!--</div>-->
							    	<div class="col-md-12">
							    		<div class="card">
							<!--<div class="card-head style-primary">
								<header>Bank  & Company Information</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bank1">
											<label for="Firstname2">Bank Name</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankac1">
											<label for="Lastname2">Bank A/c NO.</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankifsc1">
											<label for="Firstname2">IFSC Code</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankswift1">
											<label for="Lastname2">Swift Code</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankbr1">
											<label for="Firstname2">Branch Name</label>
										</div>
									</div>
									
								</div>
								 
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bank2">
											<label for="Firstname2">Bank Name</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankac2">
											<label for="Lastname2">Bank A/c NO.</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankifsc2">
											<label for="Firstname2">IFSC Code</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankswift2">
											<label for="Lastname2">Swift Code</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankbr1">
											<label for="Firstname2">Branch Name</label>
										</div>
									</div>
									
								</div>
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											
											<label for="Firstname2"><b>Company Information:</b></label>
										</div>
									</div>
									
								</div>
								
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="cstno">
											<label for="Firstname2">CST No:</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="vatno">
											<label for="Lastname2">VAT No</label>
										</div>
									</div>
								</div>
								 
								
					              
							</div><!--end .card-body -->
							
						</div>
							    	</div>
							    	<div class="col-md-12">
							    		<div class="card">
							<!--<div class="card-head style-primary">
								<header>Suppiler Product Information</header>
							</div>
							<div class="card-body floating-label">
								 <div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											<div class="col-md-12">
											<?php $k=1;   for($i=1;$i<10;$i++){ ?>
											  <?php if($k<10){ ?>
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" name="material[]" value="materiel_<?php echo $i;  ?>"><span></span>Material<?php echo $i; ?>
												</label>
											</div>
											
											
											<?php $k++; } } ?>
											</div>
										     </div>
										
										
									</div>
								</div>
								<hr class="ruler-xxl">
								<div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											<div class="col-md-12">
											<?php $k=1;   for($i=1;$i<10;$i++){ ?>
											  <?php if($k<10){ ?>
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" name="product[];" value="product_<?php echo $i; ?>"><span></span>Product<?php echo $i; ?>
												</label>
											</div>
											
											
											<?php $k++; } } ?>
											</div>
										     </div>
										
										
									</div>
								</div>
					              
							</div><!--end .card-body -->
							<!--<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>-->
						</div>
							    	</div>
							</div>
				</div>
				</form>	
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
						
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			

			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
