<?php  include("smtpmail2/smtpmail/confirmmail.php");$con=mysqli_connect("localhost","root","","erp_manager")?>
<?php //print_r($alldetails) ;echo  $alldetails['invoiceno']; ?>
<?php //foreach($alldetails as $row){
	   $invoiceno=$alldetails['invoiceno'];
	  $venid=$alldetails['venid'];
	  $pono=$alldetails['pono'];
	  $paymentyp=$alldetails['paymentyp'];
	  $paymentno=$alldetails['paymentno'];
	  $amount=$alldetails['amount'];
	  $bank=$alldetails['bank'];
      $cheque=$alldetails['cheque'];
	  $branch=$alldetails['branch'];
	   
	
	
	
 ?>
 
<?php 
  if($paymentno==1){ $ptitle="1st Payment" ; }
  if($paymentno==2){ $ptitle="2nd Payment" ; }
  if($paymentno==3){ $ptitle="3rd Payment" ; }
   $queryven=mysqli_query($con,"select * from venderslist where vender_id='".trim($venid)."'");
   $rowven=mysqli_fetch_array($queryven);
   $venmail=$rowven['vemail'];
   $email=$venmail;

//exit;
 ?>
 
<?php //$poid=$poid;//$vendmail=$vendmail; ?>
<?php //$vendmail1=explode(",",$vendmail) ; ?>
<?php //foreach($vid as $row) {?>
	
	<?php //$vd=$row; ?>
	<?php// $query=mysqli_query($con,"select * from venderslist where vender_id='".trim($vd)."'"); $row=mysqli_fetch_array($query);$vendid=$row['vender_id']; $name=$row['vname'];$email=$row['vemail']; ?>
<?php  $subject="Payment Confirmation for  PO NO-". $pono." & ". $ptitle ; ?>
<?php
 $msg= 'Dear, sir <br> we have processed your payment .All the details are as follows.................<br>';
 $msg .='<b>Invoice No    :</b> '.$invoiceno.'<br>';
 $msg .='<b>PurchaseOde No:</b> '.$pono.'<br>';
 $msg .='<b>Payment No    :</b> '.$ptitle.'<br>';
 $msg .='<b>Payment Type  : </b>'.strtoupper($paymentyp).'<br>';
 $msg .='<b>Amount        : </b>'.$amount.'<br>';
 $msg .='<b>Cheq/Trans ID : </b>'.strtoupper($cheque).'<br>';
 $msg .='<b>Bank Name     : </b>'.strtoupper($bank).'<br>';
 $msg .='<b>Branch        :</b> '.strtoupper($branch).'<br>';
 //$msg .='--------------------------------------------<br>';
 $msg .='Thanks and Regards,<br> G K Rikshaw Pvt Ltd.<br>';
 $msg .='---------------------------------------------------------------------------------------------------------<br>';
 $msg .='This is system generated e-mail .Do not reply it .<br>';
 $msg .='--------------------------------------------------------------------------------------------------------<br>';
 
 
 $name="G K Rikshaw Ltd";

 ?>
<?php echo $mail_user = send_mail1("$subject","$email","$msg","$name"); ?>

<?php// } ?>