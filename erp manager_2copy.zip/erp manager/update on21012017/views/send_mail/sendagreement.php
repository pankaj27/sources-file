<?php  include("smtpmail2/smtpmail/senddistmail.php");
//include("connection.php");
$con=mysqli_connect("localhost","root","","erp_manager");
//$con=mysqli_connect("localhost","senatedt_erp_man","pkp@9800743629","senatedt_erp_manager");
//$email=$email;
//$pass=$pasword;
$clientid=$clientid;
$qr=mysqli_query($con,"select * from clientmaster where ucase(clientid)='".trim(strtoupper($clientid))."'");
$rqr=mysqli_fetch_array($qr);
$username=$rqr['email'];
$password=$rqr['pass'];
?>
<?php //$poid=$poid;//$vendmail=$vendmail;  ?>
<?php $path="http://localhost/gkdistributer/" ; ?>
<?php //$vendmail1=explode(",",$vendmail) ; ?>
<?php ?>
	
	
	<?php //$query=mysqli_query($con,"select * from venderslist where vender_id='".trim($vd)."'"); $row=mysqli_fetch_array($query);$vendid=$row['vender_id']; $name=$row['vname'];$email=$row['vemail']; ?>
<?php  $subject="E-Agreement Copy & On Login Detais";  ?>
<?php $msg= '

<!doctype html>
 <html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="initial-scale=1.0" />
  <meta name="format-detection" content="telephone=no" />
  <title></title>
 
 </head>
 <body>
  <center><h3>Thank You for Register with us</h3></center>
  <br>
  Your Login Credential Details are as Follows:-
  <br>
 username:'.$username.'
 <br>
 password:'.$password.'
 <br>
 <center>
 <h4><a href="'.$path.'">Click here for Login</a></h4>
 </center>
 </body>
</html>
 '; ?>

 
<?php $name="Gk Rickshaw Pvt Ltd"; ?>
<?php echo $mail_user = send_mail1("$subject","$username","$msg","$name"); ?>

<?php ?>