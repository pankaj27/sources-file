<?php  include("smtpmail2/smtpmail/finalmail1.php");$con=mysqli_connect("localhost","root","","erp_manager")?>

<?php $email=$venmail; ?>

<?php $subject="Final Purchase order " ;  $name1="Gk Rickshaw" ;
 $msg="Dear , Sir <br> We have send you the final purchase order details .<br>Please fined the attachment as follows.............."; ?>
<?php echo $mail_user = send_mail2("$subject","$email","$msg","$name1"); ?>

<?php //} ?>