<?php 
  //--css and head file include-----------------------------------------------------------------------------
  $this->load->view('include/head.php'); 
  
 ?>
 <link rel="stylesheet" href="<?php echo base_url(); ?>template_assets/css/dataTables.bootstrap.min.css" />
 <style>
  	.error{color:red;font-style: italic;padding-right:10px;text-align: right; }
  </style>

 <body>
 	
  <div id="ino-body">
   <?php  //get header nav bar top --------------------------------------------------------- ?>
   <?php $this->load->view('include/navbar_top.php'); ?>
   <?php  //get  heder nav bar down ------------------------------------------------------------- ?>
  <div class="ino navbar-form">
    <div id="navigation_bar"   class="col-sm-12 col-xs-12 col-md-10 col-md-offset-2 mainbar">
     <div id="header_top_quick_nav" class='hidden-xs' >
      <ul class="list-group inline_list">
       <li role="presentation"><i class="fa fa-toggle-left clickable right_bar_navigation_menu" title="Toggle Navigation Menu"></i></li>
       <li role="presentation"><a  href="#"><i class="fa fa-home" title="Home"></i></a></li>
       <li role="presentation"><a   href=""><i class="fa fa-info" title="Messages"></i></a></li>
       <li role="presentation"><a   href="<?php echo base_url(); ?>login"><i class="fa fa-dashboard" title="Dashborad"></i></a></li>
       <!--<li role="presentation"><i class="fa fa-gears right-click-menu clickable" title="Actions"></i></li>-->
       <li role="presentation"><a  class="erp-links search-list-page" href="#"><i class="fa fa-search" title="Search & List Page"></i></a></li>
       <li role="presentation"><a  class="erp-links form-page" href="#"><i class="fa fa-list-alt" title="Form Page"></i></a></li>
       <li id="unsaved_fields" data-no_of_fields="0"></li>
       <li class="show_loading_small">
        <div class="ino-spinner ino-sm" >
         <div class="rect1" style="background-color:#1f6dad"></div>
         <div class="rect2" style="background-color:#1f6dad"></div>
         <div class="rect3" style="background-color:#1f6dad"></div>
         <div class="rect4" style="background-color:#1f6dad"></div>
         <div class="rect5" style="background-color:#1f6dad"></div>
        </div>
       </li>
      </ul>
     </div>
     <div id="header_top_container">
      			 <ul id="form_top_image" class="draggable">
        <li class='fa fa-refresh clickable ino-btn2 ' id='refresh_button' title='Refresh' style="background-color: #1f6dad" ></li>
        <li class='fa fa-file-text-o clickable ino-btn2' Title="New Document" id="new_page_button" href="<?php echo base_url(); ?>Inventory_controller/vehicle_master" style="background-color: #1f6dad"></li>
    	<li class='fa fa-save clickable ino-btn2' id='abcd' title='Save' style="background-color: #1f6dad" ></li>
        <li class='fa fa-eraser clickable ino-btn2' Title="Clear All, Quick Entry" id="new_object_button" href="form.php?mode=9&amp;class_name=item" style="background-color: #1f6dad"></li>
        <li class='fa fa-trash-o clickable ino-btn2' id='delete_button' title='Delete' style="background-color: #1f6dad"></li>
        <li class='fa fa-remove clickable ino-btn2' id='remove_row_button' title='Remove' style="background-color: #1f6dad" ></li>
        <li class='fa fa-search-plus clickable query_mode_icon ino-btn2' id='start_query_mode' title='Query Mode' style="background-color: #1f6dad"></li>
        <li class='fa fa-print clickable print ino-btn2' id='print_searchResult' title='Print' style="background-color: #1f6dad"></li>
</ul>           </div>
     
   </div>
  
   <div id="header_bottom"></div>
   
   <div class="container-fluid">
    <?php // get navigation menu-------------------------------------------------------------- ?>
    <?php  $this->load->view('include/navigation_menu.php'); ?>


    <div id="divider-bar" class="col-m-1 hidden-sm hidden-xs"><i class="fa fa-toggle-left clickable"></i></div>
    <div class="clearfix"></div>
    <div id="erp_form_area" class="col-md-10 col-md-offset-2 mainbar col-xs-12" >
     <div class='visible-xs visible-sm'>
      <div class="error"></div><div id="loading"></div>
     </div>
     <div id="content">
      <div id="structure">
       <div id='form-modal'>
 <!--       <button type="button" class="close close-modal">Close <span aria-hidden="true">&times;</span></button>-->
        <div id='mod-header_top_container'> </div>
        <div id='mod-structure'> </div>

       </div>
       <ul class="btn-group-vertical vertical-list imp-link ino-breadcrumb-simple" role="group" aria-label="...">
       		<li title="Close This Form" ><j  class="ajax-link ino-close-form clickable " ><i class="fa fa-remove"></i> </j></li>
       		<li title="Minimize This Form" ><j  id="ino-minimize-form" class="ajax-link ino-minimize-form clickable " ><i class="fa fa-minus"></i></j></li>
       		<li title="Navigate to Dashboard" ><a  class="ajax-link" href="<?php echo base_url(); ?>login"><i class="fa fa-dashboard"></i> </a></li>
       		<li title="Navigate to Inventory" ><a  class="ajax-link" href="<?php echo base_url(); ?>login"><i class="fa fa-bank"></i> </a></li>
       </ul>
       <!--<form  method="post" id="item"  name="item"><span class="heading">Item Master </span>-->
 			
 <div id ="form_line" class="form_line form_header_l"><span class="heading"> Spare Parts Details </span><br><div id="msg_2" style="color:blue;text-align: center;font-weight:bold;font-size: 15px;"></div>
 	<div id="tabsLine">
   <ul class="tabMain">
    <li><a href="#tabsLine-1">Main</a></li>
    <li><a href="#tabsLine-2">Search/list</a></li>
    <li><a href="#tabsLine-3">Sales Graph</a></li>
    <li><a href="#tabsLine-4">Item Graph</a></li>
    <li><a href="#tabsLine-5">Manufacturing</a></li>
    <li><a href="#tabsLine-6">Planning</a></li>
    <li><a href="#tabsLine-7">Control</a></li>
    <li><a href="#tabsLine-8">Financial</a></li>
   <!-- <li><a href="#tabsLine-9">Secondary</a></li>-->
   </ul>
   <div class="tabContainer"> 
    <div id="tabsLine-1" class="tabContent">
    	
     	<div class="second_rowset">
      	
      	<div class="panel panel-collapse panel-ino-classy extra_large_box">
       		<div class="panel-heading">
       			<div class="panel-title font-medium">Vehicle Information</div>
       		</div>
       		<div class="panel-body">
        		<ul class="column line_field">
         			<li><label><b>Brand Name</b></label><input type="text" name="brand_name" id="brand_name" 	 maxlength="256" size="20" class="textfield  pre_processing_lt" placeholder=""   id="pre_processing_lt"   title=""  data-toggle="tooltip"><div id="brand_nameerror" class="error"></div></li>
         			<li><label><b>Group</b></label><input type="text" name="group" id="group"   maxlength="256" size="20" class="textfield  processing_lt" placeholder=""   id="processing_lt"   title=""  data-toggle="tooltip"><div id="group_error" class="error"></div></li> 
         			<li><label><b>Parts No</b></label><input type="text" name="partsno" id="partsno"  maxlength="256" size="20" class="textfield  post_processing_lt" placeholder=""   id="post_processing_lt"   title=""  data-toggle="tooltip"><div id="partsno_error" class="error"></div></li> 
         			<li><label><b>Description</b></label><input type="text" name="description" id="description" 	 maxlength="256" size="20" class="textfield  cumulative_mfg_lt" placeholder=""   id="cumulative_mfg_lt"   title=""  data-toggle="tooltip"><div id="description_error" class="error"></div></li>
         			
        		</ul>
       </div>
      </div>
      <hr>
      <div class="panel panel-collapse panel-ino-classy extra_large_box">
       		<div class="panel-heading">
       			<div class="panel-title font-medium">MRP,VAT,STOCK Information</div>
       		</div>
       		<div class="panel-body">
        		<ul class="column line_field">
         			<li><label><b>MRP</b>:</label><input type="text" name="mrp" id="mrp"	 maxlength="256" size="20" class="textfield  pre_processing_lt" placeholder=""   id="pre_processing_lt"   title=""  data-toggle="tooltip"><div id="mrp_error" class="error"></div></li>
         			<li><label><b>VAT(%)</b>:</label><input type="text" name="vat" id="vat"  maxlength="256" size="20" class="textfield  processing_lt" placeholder=""   id="processing_lt"   title=""  data-toggle="tooltip"><div id="vat_error" class="error"></div></li> 
         			<li><label><b>Purchase Price</b>:</label><input type="text" name="purchaseprice" id="purchaseprice"  maxlength="256" size="20" class="textfield  post_processing_lt" placeholder=""   id="post_processing_lt"   title=""  data-toggle="tooltip"><div id="purchaseprice_error" class="error"></div></li> 
         			<li><label><b>Last Purchase Price</b>:</label><input type="text" name="latestpurchaseprice" id="latestpurchaseprice" 	 maxlength="256" size="20" class="textfield  cumulative_mfg_lt" placeholder=""   id="cumulative_mfg_lt"   title=""  data-toggle="tooltip"><div id="latestpurchaseprice_error" class="error"></div></li>
         			<li><label><b>Rack No</b>:</label><input type="text" name="rackno" id="rackno"	 maxlength="256" size="20" class="textfield  cumulative_total_lt" placeholder=""     title=""  data-toggle="tooltip"><div id="rackno_error" class="error"></div></li>
         			<li><label><b>Opening Qty</b>:</label><input type="text" name="openqty" id="openqty" 	 maxlength="256" size="20" class="textfield  lt_lot_size" placeholder=""      title=""  data-toggle="tooltip"><div id="openqty_error" class="error"></div></li>
         			<li><label><b>Values</b>:</label><input type="text" name="values" id="values"	 maxlength="256" size="20" class="textfield  cumulative_total_lt" placeholder=""      title=""  data-toggle="tooltip"><div id="values_error" class="error"></div></li>
         			<li><label><b>Balance</b>:</label><input type="text" name="balance" id="balance" 	 maxlength="256" size="20" class="textfield  lt_lot_size" placeholder=""     title=""  data-toggle="tooltip"><div id="balance_error" class="error"></div></li>
        			<li><label><b>MOQ</b>:</label><input type="text" name="moq" id="moq"	 maxlength="256" size="20" class="textfield  cumulative_total_lt" placeholder=""      title=""  data-toggle="tooltip"><div id="moq_error" class="error"></div></li>
         			<li><label><b>Reordering Level</b>:</label><input type="text" name="reordlevel" id="reordlevel" 	 maxlength="256" size="20" class="textfield  lt_lot_size" placeholder=""   id="lt_lot_size"   title=""  data-toggle="tooltip"><div id="reordlevel_error" class="error"></div></li>
        		   <li><label><b>Minimum Stock</b>:</label><input type="text" name="minstock" id="minstock"	 maxlength="256" size="20" class="textfield  cumulative_total_lt" placeholder=""   id="cumulative_total_lt"   title=""  data-toggle="tooltip"><div id="minstock_error" class="error"></div></li>
         		  <li><label><b>Maxium Stock</b>:</label><input type="text" name="maxstock" id="maxstock" 	 maxlength="256" size="20" class="textfield  lt_lot_size" placeholder=""   id="lt_lot_size"   title=""  data-toggle="tooltip"><div id="maxstock_error" class="error"></div></li>
        		
        		</ul>
           </div>
      </div>
      <div class="panel panel-collapse panel-ino-classy extra_large_box">
       		<div class="panel-heading">
       			<div class="panel-title font-medium">TAX Information</div>
       		</div>
       		<div class="panel-body">
        		<ul class="column line_field">
         			<li><label><b>Sales Tax</b>:</label><input type="text" name="salestax" id="salestax"	 maxlength="256" size="20" class="textfield  pre_processing_lt" placeholder=""   id="pre_processing_lt"   title=""  data-toggle="tooltip"><div id="salestax_err" class="error"></div></li>
         			<li><label><b>Surcharge:</b></label><input type="text" name="surcharge" id="surcharge"  maxlength="256" size="20" class="textfield  processing_lt" placeholder=""   id="processing_lt"   title=""  data-toggle="tooltip"><div id="surcharge_error" class="error"></div></li> 
         			<li><label><b>Add Surcharge:</b></label><input type="text" name="addsurcharge" id="addsurcharge"  maxlength="256" size="20" class="textfield  post_processing_lt" placeholder=""   id="post_processing_lt"   title=""  data-toggle="tooltip"><div id="addsurcharge_error" class="error"></div></li> 
         			<li><label><b>Application:</b></label><input type="text" name="application" id="application" 	 maxlength="256" size="20" class="textfield  cumulative_mfg_lt" placeholder=""   id="cumulative_mfg_lt"   title=""  data-toggle="tooltip"><div id="application_error" class="error"></div></li>
         			<li><label><b>Type:</b></label><input type="text" name="type" id="type" 	 maxlength="256" size="20" class="textfield  cumulative_total_lt" placeholder=""   id="cumulative_total_lt"   title=""  data-toggle="tooltip"><div id="type_error" class="error"></div></li>
         		</ul>
           </div>
      </div>
     </div>

     
     <!--end of tab1 div three_column-->
    </div> 
    <!--end of tab1-->
    <div id="tabsLine-2" class="tabContent">
     <div class="second_rowset">
      <div class="panel panel-collapse panel-ino-classy extra_large_box">
       <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        
        <tbody>
        	<?php for($i=1;$i<150;$i++){ ?>
            <tr>
                <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011/04/25</td>
                <td>$320,800</td>
            </tr>
            <?php } ?>
            <tr>
                <td>Garrett Winters</td>
                <td>Accountant</td>
                <td>Tokyo</td>
                <td>63</td>
                <td>2011/07/25</td>
                <td>$170,750</td>
            </tr>
            <tr>
                <td>Ashton Cox</td>
                <td>Junior Technical Author</td>
                <td>San Francisco</td>
                <td>66</td>
                <td>2009/01/12</td>
                <td>$86,000</td>
            </tr>
            <tr>
                <td>Cedric Kelly</td>
                <td>Senior Javascript Developer</td>
                <td>Edinburgh</td>
                <td>22</td>
                <td>2012/03/29</td>
                <td>$433,060</td>
            </tr>
            <tr>
                <td>Airi Satou</td>
                <td>Accountant</td>
                <td>Tokyo</td>
                <td>33</td>
                <td>2008/11/28</td>
                <td>$162,700</td>
            </tr>
            <tr>
                <td>Brielle Williamson</td>
                <td>Integration Specialist</td>
                <td>New York</td>
                <td>61</td>
                <td>2012/12/02</td>
                <td>$372,000</td>
            </tr>
            <tr>
                <td>Herrod Chandler</td>
                <td>Sales Assistant</td>
                <td>San Francisco</td>
                <td>59</td>
                <td>2012/08/06</td>
                <td>$137,500</td>
            </tr>
            <tr>
                <td>Rhona Davidson</td>
                <td>Integration Specialist</td>
                <td>Tokyo</td>
                <td>55</td>
                <td>2010/10/14</td>
                <td>$327,900</td>
            </tr>
            <tr>
                <td>Colleen Hurst</td>
                <td>Javascript Developer</td>
                <td>San Francisco</td>
                <td>39</td>
                <td>2009/09/15</td>
                <td>$205,500</td>
            </tr>
            <tr>
                <td>Sonya Frost</td>
                <td>Software Engineer</td>
                <td>Edinburgh</td>
                <td>23</td>
                <td>2008/12/13</td>
                <td>$103,600</td>
            </tr>
            <tr>
                <td>Jena Gaines</td>
                <td>Office Manager</td>
                <td>London</td>
                <td>30</td>
                <td>2008/12/19</td>
                <td>$90,560</td>
            </tr>
            <tr>
                <td>Quinn Flynn</td>
                <td>Support Lead</td>
                <td>Edinburgh</td>
                <td>22</td>
                <td>2013/03/03</td>
                <td>$342,000</td>
            </tr>
            <tr>
                <td>Charde Marshall</td>
                <td>Regional Director</td>
                <td>San Francisco</td>
                <td>36</td>
                <td>2008/10/16</td>
                <td>$470,600</td>
            </tr>
            <tr>
                <td>Haley Kennedy</td>
                <td>Senior Marketing Designer</td>
                <td>London</td>
                <td>43</td>
                <td>2012/12/18</td>
                <td>$313,500</td>
            </tr>
            <tr>
                <td>Tatyana Fitzpatrick</td>
                <td>Regional Director</td>
                <td>London</td>
                <td>19</td>
                <td>2010/03/17</td>
                <td>$385,750</td>
            </tr>
            <tr>
                <td>Michael Silva</td>
                <td>Marketing Designer</td>
                <td>London</td>
                <td>66</td>
                <td>2012/11/27</td>
                <td>$198,500</td>
            </tr>
            <tr>
                <td>Paul Byrd</td>
                <td>Chief Financial Officer (CFO)</td>
                <td>New York</td>
                <td>64</td>
                <td>2010/06/09</td>
                <td>$725,000</td>
            </tr>
            <tr>
                <td>Gloria Little</td>
                <td>Systems Administrator</td>
                <td>New York</td>
                <td>59</td>
                <td>2009/04/10</td>
                <td>$237,500</td>
            </tr>
            <tr>
                <td>Bradley Greer</td>
                <td>Software Engineer</td>
                <td>London</td>
                <td>41</td>
                <td>2012/10/13</td>
                <td>$132,000</td>
            </tr>
            <tr>
                <td>Dai Rios</td>
                <td>Personnel Lead</td>
                <td>Edinburgh</td>
                <td>35</td>
                <td>2012/09/26</td>
                <td>$217,500</td>
            </tr>
            <tr>
                <td>Jenette Caldwell</td>
                <td>Development Lead</td>
                <td>New York</td>
                <td>30</td>
                <td>2011/09/03</td>
                <td>$345,000</td>
            </tr>
            <tr>
                <td>Yuri Berry</td>
                <td>Chief Marketing Officer (CMO)</td>
                <td>New York</td>
                <td>40</td>
                <td>2009/06/25</td>
                <td>$675,000</td>
            </tr>
            <tr>
                <td>Caesar Vance</td>
                <td>Pre-Sales Support</td>
                <td>New York</td>
                <td>21</td>
                <td>2011/12/12</td>
                <td>$106,450</td>
            </tr>
            <tr>
                <td>Doris Wilder</td>
                <td>Sales Assistant</td>
                <td>Sidney</td>
                <td>23</td>
                <td>2010/09/20</td>
                <td>$85,600</td>
            </tr>
            <tr>
                <td>Angelica Ramos</td>
                <td>Chief Executive Officer (CEO)</td>
                <td>London</td>
                <td>47</td>
                <td>2009/10/09</td>
                <td>$1,200,000</td>
            </tr>
            <tr>
                <td>Gavin Joyce</td>
                <td>Developer</td>
                <td>Edinburgh</td>
                <td>42</td>
                <td>2010/12/22</td>
                <td>$92,575</td>
            </tr>
            <tr>
                <td>Jennifer Chang</td>
                <td>Regional Director</td>
                <td>Singapore</td>
                <td>28</td>
                <td>2010/11/14</td>
                <td>$357,650</td>
            </tr>
            <tr>
                <td>Brenden Wagner</td>
                <td>Software Engineer</td>
                <td>San Francisco</td>
                <td>28</td>
                <td>2011/06/07</td>
                <td>$206,850</td>
            </tr>
            <tr>
                <td>Fiona Green</td>
                <td>Chief Operating Officer (COO)</td>
                <td>San Francisco</td>
                <td>48</td>
                <td>2010/03/11</td>
                <td>$850,000</td>
            </tr>
            <tr>
                <td>Shou Itou</td>
                <td>Regional Marketing</td>
                <td>Tokyo</td>
                <td>20</td>
                <td>2011/08/14</td>
                <td>$163,000</td>
            </tr>
            <tr>
                <td>Michelle House</td>
                <td>Integration Specialist</td>
                <td>Sidney</td>
                <td>37</td>
                <td>2011/06/02</td>
                <td>$95,400</td>
            </tr>
            <tr>
                <td>Suki Burks</td>
                <td>Developer</td>
                <td>London</td>
                <td>53</td>
                <td>2009/10/22</td>
                <td>$114,500</td>
            </tr>
            <tr>
                <td>Prescott Bartlett</td>
                <td>Technical Author</td>
                <td>London</td>
                <td>27</td>
                <td>2011/05/07</td>
                <td>$145,000</td>
            </tr>
            <tr>
                <td>Gavin Cortez</td>
                <td>Team Leader</td>
                <td>San Francisco</td>
                <td>22</td>
                <td>2008/10/26</td>
                <td>$235,500</td>
            </tr>
            <tr>
                <td>Martena Mccray</td>
                <td>Post-Sales support</td>
                <td>Edinburgh</td>
                <td>46</td>
                <td>2011/03/09</td>
                <td>$324,050</td>
            </tr>
            <tr>
                <td>Unity Butler</td>
                <td>Marketing Designer</td>
                <td>San Francisco</td>
                <td>47</td>
                <td>2009/12/09</td>
                <td>$85,675</td>
            </tr>
            <tr>
                <td>Howard Hatfield</td>
                <td>Office Manager</td>
                <td>San Francisco</td>
                <td>51</td>
                <td>2008/12/16</td>
                <td>$164,500</td>
            </tr>
            <tr>
                <td>Hope Fuentes</td>
                <td>Secretary</td>
                <td>San Francisco</td>
                <td>41</td>
                <td>2010/02/12</td>
                <td>$109,850</td>
            </tr>
            <tr>
                <td>Vivian Harrell</td>
                <td>Financial Controller</td>
                <td>San Francisco</td>
                <td>62</td>
                <td>2009/02/14</td>
                <td>$452,500</td>
            </tr>
            <tr>
                <td>Timothy Mooney</td>
                <td>Office Manager</td>
                <td>London</td>
                <td>37</td>
                <td>2008/12/11</td>
                <td>$136,200</td>
            </tr>
            <tr>
                <td>Jackson Bradshaw</td>
                <td>Director</td>
                <td>New York</td>
                <td>65</td>
                <td>2008/09/26</td>
                <td>$645,750</td>
            </tr>
            <tr>
                <td>Olivia Liang</td>
                <td>Support Engineer</td>
                <td>Singapore</td>
                <td>64</td>
                <td>2011/02/03</td>
                <td>$234,500</td>
            </tr>
            <tr>
                <td>Bruno Nash</td>
                <td>Software Engineer</td>
                <td>London</td>
                <td>38</td>
                <td>2011/05/03</td>
                <td>$163,500</td>
            </tr>
            <tr>
                <td>Sakura Yamamoto</td>
                <td>Support Engineer</td>
                <td>Tokyo</td>
                <td>37</td>
                <td>2009/08/19</td>
                <td>$139,575</td>
            </tr>
            <tr>
                <td>Thor Walton</td>
                <td>Developer</td>
                <td>New York</td>
                <td>61</td>
                <td>2013/08/11</td>
                <td>$98,540</td>
            </tr>
            <tr>
                <td>Finn Camacho</td>
                <td>Support Engineer</td>
                <td>San Francisco</td>
                <td>47</td>
                <td>2009/07/07</td>
                <td>$87,500</td>
            </tr>
            <tr>
                <td>Serge Baldwin</td>
                <td>Data Coordinator</td>
                <td>Singapore</td>
                <td>64</td>
                <td>2012/04/09</td>
                <td>$138,575</td>
            </tr>
            <tr>
                <td>Zenaida Frank</td>
                <td>Software Engineer</td>
                <td>New York</td>
                <td>63</td>
                <td>2010/01/04</td>
                <td>$125,250</td>
            </tr>
            <tr>
                <td>Zorita Serrano</td>
                <td>Software Engineer</td>
                <td>San Francisco</td>
                <td>56</td>
                <td>2012/06/01</td>
                <td>$115,000</td>
            </tr>
            <tr>
                <td>Jennifer Acosta</td>
                <td>Junior Javascript Developer</td>
                <td>Edinburgh</td>
                <td>43</td>
                <td>2013/02/01</td>
                <td>$75,650</td>
            </tr>
            <tr>
                <td>Cara Stevens</td>
                <td>Sales Assistant</td>
                <td>New York</td>
                <td>46</td>
                <td>2011/12/06</td>
                <td>$145,600</td>
            </tr>
            <tr>
                <td>Hermione Butler</td>
                <td>Regional Director</td>
                <td>London</td>
                <td>47</td>
                <td>2011/03/21</td>
                <td>$356,250</td>
            </tr>
            <tr>
                <td>Lael Greer</td>
                <td>Systems Administrator</td>
                <td>London</td>
                <td>21</td>
                <td>2009/02/27</td>
                <td>$103,500</td>
            </tr>
            <tr>
                <td>Jonas Alexander</td>
                <td>Developer</td>
                <td>San Francisco</td>
                <td>30</td>
                <td>2010/07/14</td>
                <td>$86,500</td>
            </tr>
            <tr>
                <td>Shad Decker</td>
                <td>Regional Director</td>
                <td>Edinburgh</td>
                <td>51</td>
                <td>2008/11/13</td>
                <td>$183,000</td>
            </tr>
            <tr>
                <td>Michael Bruce</td>
                <td>Javascript Developer</td>
                <td>Singapore</td>
                <td>29</td>
                <td>2011/06/27</td>
                <td>$183,000</td>
            </tr>
            <tr>
                <td>Donna Snider</td>
                <td>Customer Support</td>
                <td>New York</td>
                <td>27</td>
                <td>2011/01/25</td>
                <td>$112,000</td>
            </tr>
        </tbody>
    </table>
      </div>
      
      

     </div> 
     <!--                end of tab2 div three_column-->
    </div>
    <!--end of tab2 (purchasing)!!!! start of sales tab-->
    <div id="tabsLine-3" class="tabContent">
     <div class="first_rowset"> 
      <ul class="column header_field">
       <li><label>Customer Ordered Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="customer_ordered_cb[]"  class="checkBox customer_ordered_cb  " id="customer_ordered_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li> 
       <li><label>Internal Ordered Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="internal_ordered_cb[]"  class="checkBox internal_ordered_cb  " id="internal_ordered_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Shippable Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="shippable_cb[]"  class="checkBox shippable_cb  " id="shippable_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Returnable Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="returnable_cb[]"  class="checkBox returnable_cb  " id="returnable_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
      </ul>
     </div>
     <div class="second_rowset">
      <div class="panel panel-collapse panel-ino-classy medium_box">
       <div class="panel-heading"><div class="panel-title font-medium">Rule Information</div></div>
       <div class="panel-body">
        <ul class="column line_field">
         <li><label>Atp</label><input type="text" name="atp[]" value="" 
	 maxlength="256" size="20" class="textfield  atp" placeholder=""   id="atp"   title=""  data-toggle="tooltip"></li>
         <li><label>Picking Rule</label><input type="text" name="picking_rule[]" value="" 
	 maxlength="256" size="20" class="textfield  picking_rule" placeholder=""   id="picking_rule"   title=""  data-toggle="tooltip"></li>
        </ul>
       </div>
      </div>
     </div>
    </div> 
    <!--                end of tab3 div three_column-->
    <!--end of tab3 (sales)!!!!start of purchasing tab-->
    <div id="tabsLine-4" class="tabContent">
     <div class="first_rowset"> 
      <ul class="column header_field">
       <li><label>Purchased Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="purchased_cb[]"  class="checkBox purchased_cb  " id="purchased_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Use Asl Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="use_asl_cb[]"  class="checkBox use_asl_cb  " id="use_asl_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label><img src="http://localhost/inoerp/themes/images/serach.png" class="select_popup select_sourcing_rule clickable">
         Sourcing Rule</label><input type="text" name="sourcing_rule[]" value="" 
	 maxlength="256" size="20" class="textfield  sourcing_rule" placeholder=""   id="sourcing_rule"   title=""  data-toggle="tooltip"></li>
       <li><label>Invoice Matching</label><input type="text" name="invoice_matching[]" value="" 
	 maxlength="256" size="20" class="textfield  invoice_matching" placeholder=""   id="invoice_matching"   title=""  data-toggle="tooltip"></li>
       <li><label>Default Buyer</label><input type="text" name="default_buyer[]" value="" 
	 maxlength="256" size="20" class="textfield  default_buyer" placeholder=""   id="default_buyer"   title=""  data-toggle="tooltip"></li>
       <li><label>List Price</label><input type="text" name="list_price[]" value="" 
	 maxlength="256" size="20" class="textfield  list_price" placeholder=""   id="list_price"   title=""  data-toggle="tooltip"></li>
      </ul>
     </div>
     <div class="second_rowset">
      <div class="panel panel-collapse panel-ino-classy extra_large_box">
       <div class="panel-heading"><div class="panel-title font-medium">Receipt Information</div></div>
       <div class="panel-body">
        <ul class="column header_field">
         <li><label>Receipt Routing</label><input type="text" name="receipt_routing[]" value="" 
	 maxlength="256" size="20" class="textfield  receipt_routing" placeholder=""   id="receipt_routing"   title=""  data-toggle="tooltip"></li>
         <li><label>Receipt Sub Inventory</label><input type="text" name="receipt_sub_inventory[]" value="" 
	 maxlength="256" size="20" class="textfield  receipt_sub_inventory" placeholder=""   id="receipt_sub_inventory"   title=""  data-toggle="tooltip"></li>
         <li><label>Over Receipt Percentage</label><input type="text" name="over_receipt_percentage[]" value="" 
	 maxlength="256" size="20" class="textfield  over_receipt_percentage" placeholder=""   id="over_receipt_percentage"   title=""  data-toggle="tooltip"></li>
         <li><label>Over Receipt Action</label><input type="text" name="over_receipt_action[]" value="" 
	 maxlength="256" size="20" class="textfield  over_receipt_action" placeholder=""   id="over_receipt_action"   title=""  data-toggle="tooltip"></li>
         <li><label>Receipt Days Early</label><input type="text" name="receipt_days_early[]" value="" 
	 maxlength="256" size="20" class="textfield  receipt_days_early" placeholder=""   id="receipt_days_early"   title=""  data-toggle="tooltip"></li>
         <li><label>Receipt Days Late</label><input type="text" name="receipt_days_late[]" value="" 
	 maxlength="256" size="20" class="textfield  receipt_days_late" placeholder=""   id="receipt_days_late"   title=""  data-toggle="tooltip"></li>
         <li><label>Receipt Day Action</label><input type="text" name="receipt_day_action[]" value="" 
	 maxlength="256" size="20" class="textfield  receipt_day_action" placeholder=""   id="receipt_day_action"   title=""  data-toggle="tooltip"></li>
        </ul>
       </div>
      </div>
     </div> 
    </div>
    <!--end of tab4(purchasing)!!! start of MFG tab-->
    <div id="tabsLine-5" class="tabContent">
     <div class="first_rowset"> 
      <ul class="column header_field"> 
       <li><label>Make Buy</label><Select name="make_buy[]" class="select  make_buy" id="make_buy"  required ><option value="" >Select</option><option value="BUY" >Buy</option><option value="MAKE" >Make</option></select>       </li>
       <li><label>Bom Enabled Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="bom_enabled_cb[]"  class="checkBox bom_enabled_cb  " id="bom_enabled_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Bom Type</label><Select name="bom_type[]" class="select  bom_type" id="bom_type"   ><option value="" >Select</option><option value="MODEL" >Model</option><option value="OPTION_CLASS" >Option Class</option><option value="PLANNING" >Planning</option><option value="PRODUCT_FAMILY" >Product Family</option><option value="STANDARD" >Standard</option></select>       </li>
       <li><label>Build In Wip Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="build_in_wip_cb[]"  class="checkBox build_in_wip_cb  " id="build_in_wip_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Wip Supply Type</label><Select name="wip_supply_type[]" class="select  wip_supply_type" id="wip_supply_type"   ><option value="" >Select</option><option value="ASSEMBLY_PULL" >Assembly Pull</option><option value="BULK" >Bulk</option><option value="OPERATION_PULL" >Operation Pull</option><option value="PUSH" >Push</option></select>       </li>
       <li><label>Wip Supply Subinventory</label><Select name="wip_supply_subinventory[]" class="select subinventory_id wip_supply_subinventory" id="wip_supply_subinventory"   ><option value="" >Select</option></select>       </li>
       <li><label>Wip Supply Locator</label><Select name="wip_supply_locator[]" class="select locator_id wip_supply_locator" id="wip_supply_locator"   ><option value="" >Select</option></select>       </li>
      </ul>
     </div>
     <div class="second_rowset">
      <div class="panel panel-collapse panel-ino-classy large_box">
       <div class="panel-heading"><div class="panel-title">Cost Information</div></div>
       <div class="panel-body">
        <ul class="column header_field">
         <li><label>Costing Enabled Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="costing_enabled_cb[]"  class="checkBox costing_enabled_cb  " id="costing_enabled_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
         <li><label>Inventory Asset Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="inventory_asset_cb[]"  class="checkBox inventory_asset_cb  " id="inventory_asset_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
         <li><label>Cogs Ac Id</label><input type="hidden" id="cogs_ac_id" name="cogs_ac_id[]" value="" class="hidden cogs_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination cogs_ac_id textfield  select_account account_combination" placeholder=""   id="combination_cogs_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i> </li>
         <li><label>Deffered Cogs Ac Id</label><input type="hidden" id="deffered_cogs_ac_id" name="deffered_cogs_ac_id[]" value="" class="hidden deffered_cogs_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination deffered_cogs_ac_id textfield  select_account account_combination" placeholder=""   id="combination_deffered_cogs_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i> </li>
        </ul>
       </div>
      </div>
     </div> 
    </div>
    <!--end of tab5 (Manufacturing)!! start of planning -->
    <div id="tabsLine-6" class="tabContent">
     <div class="first_rowset"> 
      <ul class="column header_field">
       <li><label>Allow Negative Balance Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="allow_negative_balance_cb[]"  class="checkBox allow_negative_balance_cb  " id="allow_negative_balance_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Planner</label><input type="text" name="planner[]" value="" 
	 maxlength="256" size="20" class="textfield  planner" placeholder=""   id="planner"   title=""  data-toggle="tooltip"></li>
       <li><label>Planning Method</label><Select name="planning_method[]" class="select  planning_method"    ><option value="" >Select</option><option value="KANBAN" >Kanban</option><option value="MINMAX" >Min Max</option><option value="MPS" >MPS</option><option value="MRP" >MRP</option><option value="MULTI_MINMAX" >Multi Bin Min Max</option></select></li>
       <li><label>Forecast Method</label><input type="text" name="forecast_method[]" value="" 
	 maxlength="256" size="20" class="textfield  forecast_method" placeholder=""   id="forecast_method"   title=""  data-toggle="tooltip"></li>
       <li><label>Forecast Control</label><input type="text" name="forecast_control[]" value="" 
	 maxlength="256" size="20" class="textfield  forecast_control" placeholder=""   id="forecast_control"   title=""  data-toggle="tooltip"></li>
      </ul>
     </div>
     <div class="second_rowset">
      <div class="panel panel-collapse panel-ino-classy medium_box">
       <div class="panel-heading"><div class="panel-title font-medium">Order Modifiers</div></div>
       <div class="panel-body">
        <ul class="column header_field">
         <li><label>Fix Order Quantity</label><input type="text" name="fix_order_quantity[]" value=""  size="20"
	 class="number  fix_order_quantity" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="fix_order_quantity"  title="" ></li>
         <li><label>Fix Days Supply</label><input type="text" name="fix_days_supply[]" value=""  size="20"
	 class="number  fix_days_supply" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="fix_days_supply"  title="" ></li>
         <li><label>Fix Lot Multiplier</label><input type="text" name="fix_lot_multiplier[]" value=""  size="20"
	 class="number  fix_lot_multiplier" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="fix_lot_multiplier"  title="" ></li>
         <li><label>Minimum Order Quantity</label><input type="text" name="minimum_order_quantity[]" value=""  size="20"
	 class="number  minimum_order_quantity" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="minimum_order_quantity"  title="" ></li>
         <li><label>Maximum Order Quantity</label><input type="text" name="maximum_order_quantity[]" value=""  size="20"
	 class="number  maximum_order_quantity" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="maximum_order_quantity"  title="" ></li>
        </ul>
       </div>
      </div>

      <div class="panel panel-collapse panel-ino-classy medium_box">
       <div class="panel-heading"><div class="panel-title font-medium">Time Fences</div></div>
       <div class="panel-body">
        <ul class="column header_field">
         <li><label>Demand Timefence</label><input type="text" name="demand_timefence[]" value="" 
	 maxlength="256" size="20" class="textfield  demand_timefence" placeholder=""   id="demand_timefence"   title=""  data-toggle="tooltip"></li>
         <li><label>Planning Timefence</label><input type="text" name="planning_timefence[]" value="" 
	 maxlength="256" size="20" class="textfield  planning_timefence" placeholder=""   id="planning_timefence"   title=""  data-toggle="tooltip"></li>
         <li><label>Release Timefence</label><input type="text" name="release_timefence[]" value="" 
	 maxlength="256" size="20" class="textfield  release_timefence" placeholder=""   id="release_timefence"   title=""  data-toggle="tooltip"></li>
         <li><label>Rounding Option</label><Select name="rounding_option[]" class="select  rounding_option" id="rounding_option"   ><option value="" >Select</option><option value="NO_ROUND" >No Rounding</option><option value="ROUND" >Round</option><option value="ROUND_DOWN" >Round Down</option><option value="ROUND_UP" >Round Up</option></select>         </li>
        </ul>
       </div>
      </div>

      <div class="panel panel-collapse panel-ino-classy medium_box">
       <div class="panel-heading"><div class="panel-title font-medium">Min Max Planning</div></div>
       <div class="panel-body">
        <ul class="column header_field">
         <li><label>Minmax Min Quantity</label><input type="text" name="minmax_min_quantity[]" value=""  size="20"
	 class="number  minmax_min_quantity" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="minmax_min_quantity"  title="" ></li>
         <li><label>Minmax Max Quantity</label><input type="text" name="minmax_max_quantity[]" value=""  size="20"
	 class="number  minmax_max_quantity" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="minmax_max_quantity"  title="" ></li>
         <li><label>Minmax Multibin Number</label><input type="text" name="minmax_multibin_number[]" value=""  size="20"
	 class="number  minmax_multibin_number" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="minmax_multibin_number"  title="" ></li>
         <li><label>Minmax Multibin Size</label><input type="text" name="minmax_multibin_size[]" value=""  size="20"
	 class="number  minmax_multibin_size" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="minmax_multibin_size"  title="" ></li>
        </ul>
       </div>

      </div>

     </div> 
    </div>
    <div id="tabsLine-7" class="tabContent">
     <div class="first_rowset"> 
      <ul class="column header_field"> 
       <li><label>Am Asset Type</label><Select name="am_asset_type[]" class="from_array select  am_asset_type" id="am_asset_type"    ><option value="" >Select</option><option value="ASSET_ITEM" >Asset Item</option><option value="ASSET_ACTIVITY" >Asset Activity</option><option value="ASSET_COMPONENT" >Asset Component</option></select>       </li> 
      </ul>
     </div>
     <div class="panel panel-collapse panel-ino-classy medium_box">
      <div class="panel-heading"><div class="panel-title font-medium">Asset Maintenance</div></div>
      <div class="panel-body">
       <ul class="column line_field">
        <li><label>Am Activity Cause</label><Select name="am_activity_cause[]" class="select  am_activity_cause"    ><option value="" >Select</option><option value="DAMAGE" >Damage</option><option value="EXPANSION" >Expansion</option><option value="HEALTH_SAFTEY" >Health & Safety</option><option value="REPAIR" >Repair</option><option value="REWORK" >Rework</option></select></li>
        <li><label>Am Activity Type</label><Select name="am_activity_type[]" class="select  am_activity_type"    ><option value="" >Select</option><option value="CALIBRATION" >Calibration</option><option value="INSPECTION" >Inspection</option><option value="LUBRICATION" >Lubrication</option><option value="MAINTENANCE" >Maitenance</option><option value="PREVENTION" >Prevention</option><option value="REMOVAL" >Removal</option></select></li>
        <li><label>Am Activity Source</label><Select name="am_activity_source[]" class="select  am_activity_source"    ><option value="" >Select</option><option value="ACCIDENT" >Accident</option><option value="INCIDENT" >Incident</option><option value="ROUTINE" >Routine</option><option value="WARRANTY" >Warranty</option></select></li>
       </ul>
      </div>

     </div>
     <div class="panel panel-collapse panel-ino-classy medium_box">
      <div class="panel-heading"><div class="panel-title font-medium">Safety Stock</div></div>
      <div class="panel-body">
       <ul class="column line_field">
        <li><label>Saftey Stock Quantity</label><input type="text" name="saftey_stock_quantity[]" value=""  size="20"
	 class="number  saftey_stock_quantity" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="saftey_stock_quantity"  title="" ></li>
        <li><label>Saftey Stock Days</label><input type="text" name="saftey_stock_days[]" value=""  size="20"
	 class="number  saftey_stock_days" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="saftey_stock_days"  title="" ></li>
        <li><label>Saftey Stock Percentage</label><input type="text" name="saftey_stock_percentage[]" value=""  size="20"
	 class="number  saftey_stock_percentage" placeholder="" pattern="[0-9]+([\.][0-9]+)?"   id="saftey_stock_percentage"  title="" ></li>
       </ul>
      </div>

     </div>
     <div class="panel panel-collapse panel-ino-classy medium_box">
      <div class="panel-heading"><div class="panel-title font-medium">Service</div></div>
      <div class="panel-body">
       <ul class="column line_field">
        <li><label>Service Request Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="service_request_cb[]"  class="checkBox service_request_cb  " id="service_request_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
        <li><label>Billing Type</label><Select name="billing_type[]" class="select  billing_type"    ><option value="" >Select</option><option value="MATERIAL" >Material</option><option value="LABOR" >Labor</option><option value="EXPENSE" >Expense</option></select></li>
        <li><label>Contract Item Type</label><Select name="contract_item_type[]" class="from_array select  contract_item_type"     ><option value="" >Select</option><option value="WARENTY" >Warenty</option><option value="EXTND_WARENTY" >Extended Warenty</option><option value="USAGE" >Usage</option><option value="SERVICE" >Service</option><option value="SUBSCRIPTION" >Subscription</option></select></li>
        <li><label>Duration Uom Id</label><Select name="duration_uom_id[]" class="select uom_id duration_uom_id" id="duration_uom_id"   ><option value="" >Select</option><option value="26" >HR</option><option value="27" >Ea</option><option value="28" >Meter</option><option value="29" >Min</option><option value="30" >Centi Meter</option><option value="31" >Second</option><option value="32" >M2</option><option value="33" >FT2</option><option value="34" >REF</option><option value="35" >FT</option><option value="36" >IN</option><option value="37" >KM</option><option value="38" >BT</option><option value="39" >KG</option><option value="40" >GM</option><option value="41" >MG</option><option value="42" >Day</option><option value="43" >Currency</option><option value="45" >Dollar</option><option value="46" >Year</option></select>         </li>
        <li><label>Duration</label><input type="text" name="duration[]" value="" 
	 maxlength="256" size="20" class="textfield  duration" placeholder=""   id="duration"   title=""  data-toggle="tooltip"></li>
       </ul>
      </div>

     </div>
    </div> 
    <!--end of tab6 (planning)...start of lead times-->
    <div id="tabsLine-8" class="tabContent">
     <div class="first_rowset"> 
      <ul class="column header_field">
       <li><label>Invoiceable Cb</label><label class="ino-checkbox switch"><input type="checkbox" name="invoiceable_cb[]"  class="checkBox invoiceable_cb  " id="invoiceable_cb" 
                               value="1"   ><div class="slider"><span class="on-color">Yes</span><span class="off-color">No</span></div></label></li>
       <li><label>Invoice Matching</label><input type="text" name="invoice_matching[]" value="" 
	 maxlength="256" size="20" class="textfield  invoice_matching" placeholder=""   id="invoice_matching"   title=""  data-toggle="tooltip"></li>
       <li><label>Op Tax Class</label><Select name="op_tax_class[]" class="select output_tax op_tax_class"    ><option value="" >Select</option><option value="EMISSION_INSPECTION" >Emission Inspection</option><option value="EXEMPT" >Exempt</option><option value="IND_RURAL_EDUCATION" >Rural Education IND</option><option value="MILITARY_EQUIPMENT" >Military Equipment</option><option value="STANDARD" >Standard</option></select>       </li>
       <li><label>Ip Tax Class</label><Select name="ip_tax_class[]" class="select input_tax ip_tax_class"    ><option value="" >Select</option><option value="EMISSION_INSPECTION" >Emission Inspection</option><option value="EXEMPT" >Exempt</option><option value="IND_RURAL_EDUCATION" >Rural Education IND</option><option value="MILITARY_EQUIPMENT" >Military Equipment</option><option value="STANDARD" >Standard</option></select>       </li>
      </ul>
     </div> 
     <div class="second_rowset">
      <div class="panel panel-collapse panel-ino-classy extra_large_box">
       <div class="panel-heading"><div class="panel-title font-medium">Account</div></div>
       <div class="panel-body">
        <ul class="column line_field">
         <li><label>Material Ac Id</label><input type="hidden" id="material_ac_id" name="material_ac_id[]" value="" class="hidden material_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination material_ac_id textfield  select_account account_combination" placeholder=""   id="combination_material_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i></li>
         <li><label>Material Oh Ac Id</label><input type="hidden" id="material_oh_ac_id" name="material_oh_ac_id[]" value="" class="hidden material_oh_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination material_oh_ac_id textfield  select_account account_combination" placeholder=""   id="combination_material_oh_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i></li>
         <li><label>Overhead Ac Id</label><input type="hidden" id="overhead_ac_id" name="overhead_ac_id[]" value="" class="hidden overhead_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination overhead_ac_id textfield  select_account account_combination" placeholder=""   id="combination_overhead_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i></li>
         <li><label>Resource Ac Id</label><input type="hidden" id="resource_ac_id" name="resource_ac_id[]" value="" class="hidden resource_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination resource_ac_id textfield  select_account account_combination" placeholder=""   id="combination_resource_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i></li>
         <li><label>Osp Ac Id</label><input type="hidden" id="osp_ac_id" name="osp_ac_id[]" value="" class="hidden osp_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination osp_ac_id textfield  select_account account_combination" placeholder=""   id="combination_osp_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i></li>
         <li><label>Expense Ac Id</label><input type="hidden" id="expense_ac_id" name="expense_ac_id[]" value="" class="hidden expense_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination expense_ac_id textfield  select_account account_combination" placeholder=""   id="combination_expense_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i></li>
         <li><label>Sales Ac Id</label><input type="hidden" id="sales_ac_id" name="sales_ac_id[]" value="" class="hidden sales_ac_id coa_combination_id" ><input type="text" name="ac_combinations[]" value="" 
                               maxlength="256" size="28" class="combination sales_ac_id textfield  select_account account_combination" placeholder=""   id="combination_sales_ac_id"  title=""  data-toggle="tooltip"  ><i class="select_account select_popup clickable fa fa-search"></i> </li>
        </ul>
       </div>
      </div>
     </div> 
    </div>
    <!--                  end of tab7 (Fiance)--> 
    <!--<div id="tabsLine-9" class="tabContent">
     <ul class="secondary_field item column free_column"><li><label>Inv Category </label><Select name="item_inv_category[]" class="select  item_inv_category"    ><option value="" >Select</option><option value="CHEMICAL" >Chemical</option><option value="CLUSTER" >Cluster</option><option value="DIODE" >Diodes</option><option value="DRUG" >Drug</option><option value="IT" >IT</option><option value="LAB" >Lab</option><option value="MEDICAL" >Medical</option><option value="METFAB" >MetaFab</option><option value="OFFICE" >Office</option><option value="TRAVEL" >Travel</option></select></li><li><label>Pur Category </label><Select name="item_pur_category[]" class="select  item_pur_category"    ><option value="" >Select</option><option value="EQUIPMENT" >Equipment</option><option value="EXPENSE" >Expense</option><option value="EXPENSE_QTY" >Expense Qty</option><option value="EXPENSE_RAW" >Exepnse Raw</option><option value="FINISHED_GOOD" >Finished Good</option><option value="MRO" >MRO</option><option value="NON_PRODUCT" >Non Product</option><option value="PRODUCT" >Product</option><option value="RAW" >Raw</option><option value="SOFTWARE" >Software</option><option value="SUB_ASSEMBLY" >Sub Assembly</option><option value="TEMPLATE" >Template</option></select></li><li><label>Item Image2 </label><div class="ino-images"><div class='existing-image'></div><div class='show_attachment'><div class="form-group">
							<ul class="inRow asperWidth"><label for="exampleInputFile">Select Image</label>
							 <li><input type="file" id="attachments" class="attachments" value="" name="uploaded_file[]" multiple/></li>
              <li><input type="hidden" class="hidden display_type" name="display_type[]" value="image"/></li>
              <li><input type="hidden" class="hidden file_id item_image2" name="item_image2[]" value=""/></li>
							 <li><button  form="file_upload" name="attach_submit" class="submit button upload_file">Upload</button></li><li role="button" class="delete_image btn btn-danger "  name="delete_image" data-extn_image_reference_id="">Delete Image</li><li class="show_loading_small"><img alt="Loading..." src="http://localhost/inoerp/themes/images/small_loading.gif"/></li>
							</ul>
							<div class="uploaded_file_details"></div>
					</div></div></div><input type="hidden" name="item_image2[]" value="" class="hidden item_image2" ></li></ul>    
	</div>-->
   </div>


  </div>
 </div> 
</form>

<div id="js_data">
 <ul id="js_saving_data">
  <li class="headerClassName" data-headerClassName="item" ></li>
  <li class="savingOnlyHeader" data-savingOnlyHeader="true" ></li>
  <li class="primary_column_id" data-primary_column_id="item_id" ></li>
  <li class="form_header_id" data-form_header_id="item" ></li>
 </ul>
 <ul id="js_contextMenu_data">
  <li class="docHedaderId" data-docHedaderId="item_id" ></li>
  <li class="btn1DivId" data-btn1DivId="item" ></li>
 </ul>
</div>      </div>
      <!--   end of structure-->
     </div>
     <div id='overlay' data-actionmsg='Loading..'></div>
    </div>
    <!--   Dont Change Anything Below This Row-->
    <div class="col-sm-12 col-md-10 col-md-offset-2 mainbar">
     <div class="hidden" id="document_history"></div>
     <div class="footer-menu">
      <div id="half_copyrights" style="background-color:#1f6dad">
       <div class="pull-left">
        <span class="developed_by">Copyright @ 2016 Erp Manager - <a href='http://inoideas.org'>Powered By Crystal planet websolution </a></span>                                                         </div>
       <ul id="minform-list-bottom" class="list-group pull-left">
        <li> | Brightness</li>
        <li><input type="range" id="bg_opacity_user" value="70" ></li>
        <li> | Toggle Window</li>
        <li><i class="fa fa-tv enlarge-window clickable"></i></li>

       </ul>
       <ul id="bottom-inputs" class="list-group">
        <li></li>
       </ul>
       <!--<ul class="pull-right">
        <li> | </li>
        <li><a href="http://inoideas.org/content.php?mode=9&content_type=web_contact">Contact</a></li>
        <li><a href="http://inoerp.org/extensions/ino_user/user_login.php">Demo</a></li>
        <li><a href="https://github.com/inoerp/inoERP">Download</a></li>
        <li><a href="http://localhost/inoerp/content.php?content_type=documentation&category_id=30">Documentation</a></li>
        <li><a href="http://localhost/inoerp/content.php?content_type=forum&category_id=1">Forum</a></li>
        <li><a href="https://www.mozilla.org/MPL/2.0/">MPL 2</a></li>
        <li><a href="#">Cookie</a></li>
        <li class="active"><a href="#">TOU</a></li>
        <li class="label label-pill label-danger"><i class="fa fa-close close-footer-menu clickable"></i></li>
       </ul>-->
      </div>
     </div><!-- end large-7 --> 
    </div>
   </div>


   <div class="row">
    <div id="comment_form" class="none">
         </div>

   </div>
   <!--footer content-->
   <input type="hidden" id="home_url" name="home_url[]" value="http://localhost/inoerp/" class="hidden home_url" ><input type="hidden" id="theme_url" name="theme_url[]" value="http://localhost/inoerp/themes/default" class="hidden theme_url" >   <div class="hidden">
    <div><ul id="search_message"><li>1. Use = for exact such.<br>Ex : Supplier name inoerp in supplier field 'll show all results such as ainoerp, aainoerp, inoerpa, etc<br>=inoerp in supplier field 'll show only inoerp </li><li>2. Use > for searching values greater than entered value. </li><li>3. Use < for searching values less than entered value. </li><li>4. Use != for searching all values not equal to entered value. </li><li>5. Use comma(, ) for searching multiple values. </li><li>5. Use one < field & one > field for searching all values in between two values. </li></ul></div><div class="filter_area" id="filter_area">
  <div class="well">
   <div class="list_filter row">  
    <div class="col-md-3 col-sm-3  form-group">
     <span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
     <input type="text" class="form-control field_name" name="field_name">
    </div>  
    <div class="col-md-2 col-sm-2  form-group">   
     <select class="condition_name form-control" name="condition_name">    <option value="=">=</option>    
      <option value="">Like</option>    <option value="&gt;=">&gt;=</option>    
      <option value="&lt;=">&lt;=</option>    <option value="&gt;">&gt;</option>    <option value="&lt;">&lt;</option>    
      <option value="IN">In</option>    <option value="!=">!=</option>   </select>  
    </div>  
    <div class="col-md-3 col-sm-3">
     <div class="form-group control">
      <input type="text" class="input-with-feedback form-control condition_value" name="condition_value"  data-fieldtype="Link" data-fieldname="name">
     </div>
    </div>  
    <div class="col-md-4 col-sm-4  condition_action">
     <button class="button btn btn-success apply-filter" type="submit"  name="applyFilter">Apply</button>  
     <button class="button btn btn-info add-element" name="addElement"> + </button> 
     <button class="button btn btn-info remove-element" name="removeElement"> - </button> 
    </div>  
   </div>
  </div>
 </div>
 <div class="applied_filters">
  <div class="btn-group">
   <button title="Edit Filter" class="btn btn-default btn-sm toggle-filter"><i class="fa fa-filter"></i></button>
   <button title="Remove Filter" class="btn btn-default btn-sm remove-filter"><i class="fa fa-remove text-muted"></i></button>
  </div>
 </div>
    <div class="sorted_elements_asc">
    <div class="btn-group">
     <button title="Edit Sort" class="btn btn-default btn-sm toggle-sort-asc"><i class="fa fa-sort-alpha-asc"></i></button>
     <button title="Remove Sort" class="btn btn-default btn-sm remove-sort-asc"><i class="fa fa-remove text-muted"></i></button>
    </div>
   </div>
       <div class="sorted_elements_desc">
    <div class="btn-group">
     <button title="Edit Sort" class="btn btn-default btn-sm toggle-sort-desc"><i class="fa fa-sort-alpha-desc"></i></button>
     <button title="Remove Sort" class="btn btn-default btn-sm remove-sort-desc"><i class="fa fa-remove text-muted"></i></button>
    </div>
   </div>
 <div id="shortcut_keys_divId" class="hidden shortcut_keys"><div class="hidden" id="shortcut_keys"><table><thead>
             <tr>
          <th>Function</th>
          <th>Key</th>
          </tr></thead>
          <tbody>
          <tr><td>Save Record</td><td>Ctrl + S</td></tr>
          <tr><td>Delete Record</td><td>Ctrl + D</td></tr>
          <tr><td>Refresh Record</td><td>Ctrl + R</td></tr>
          <tr><td>New Line</td><td>Down Arrow</td></tr>
          <tr><td>Copy Field Above</td><td>Ctrl + C</td></tr>
          <tr><td>Copy Row Above</td><td>Ctrl + A</td></tr>
         </tbody>
</table></div></div>    <div id="hidden-div" class="hidden"><div id="hidden-div-content"></div></div>
   </div>
   <!--  Load JavaScrips-->
  <?php $this->load->view('include/footer.php'); ?>
     

  </div>
 
<script src="<?php echo base_url(); ?>template_assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>template_assets/js/dataTables.bootstrap.min.js"></script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!--<script type="text/javascript" charset="utf-8">
;(function($win,$doc){var util={getCookie:function(c_name){var i,x,y;var ARRcookies=$doc.cookie.split(";");for(i=0;i<ARRcookies.length;i++){x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);x=x.replace(/^\s+|\s+$/g,"");if(x==c_name){return unescape(y)}}},setCookie:function(c_name,value,exdays){var exdate=new Date();exdate.setDate(exdate.getDate()+exdays);var c_value=escape(value)+((exdays==null)?"":"; expires="+exdate.toUTCString()),url=location.protocol+'//'+location.host+'/',domain=url.replace(/(http|https):\/\/.*?([^\.]+\.(com\.cn|org\.cn|net\.cn|[^\.]+))\/.*/,"$2");$doc.cookie=c_name+"="+c_value+';path=/; domain=.'+domain},getRandom:function(){return Math.round(Math.random()*2147483647)},getHash:function(str){var hash=1,charCode=0,idx;hash=0;for(idx=str.length-1;idx>=0;idx--){charCode=str.charCodeAt(idx);hash=(hash<<6&268435455)+charCode+(charCode<<14);charCode=hash&266338304;hash=charCode!=0?hash^charCode>>21:hash}return hash},isArray:function(obj){return Object.prototype.toString.call(obj).toLowerCase()==="[object array]"},getClientInfo:function(){var info={},_empty='null',screen=window.screen,navigator=window.navigator,document=window.document,ua=navigator.userAgent.toLowerCase();var _contains=function(str,sub){return(str.indexOf(sub)>-1)};var _getBrowser=function(){var match=/(chrome)[ \/]([\w.]+)/.exec(ua)||/(webkit)[ \/]([\w.]+)/.exec(ua)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua)||/(msie) ([\w.]+)/.exec(ua)||ua.indexOf("compatible")<0&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua)||[];return{browser:match[1]||"",version:match[2]||"0"}};var _getOS=function(){var up=navigator.platform,isWin=(up==='Win32')||(up==='Windows'),isMac=(up==='Mac68K')||(up==='MacPPC')||(up==='Macintosh')||(up==='MacIntel'),isUnix=(up==='X11')&&!isWin&&!isMac,isLinux=_contains(up,'Linux')&&_contains(ua,'linux'),os='';if(isLinux){os=_contains(ua,'android')?'android':'linux'}else if(isMac){os=_contains(ua,'iphone')?'iphone':_contains(ua,'ipad')?'ipad':'mac'}else if(isUnix){os='unix'}else if(isWin){var winkey={'win2000':'windows nt 5.0','winXP':'windows nt 5.1','win2003':'windows nt 5.2','winVista':'window nt 6.0','win7':'windows nt 6.1','win8':'windows nt 6.2','win8.1':'windows nt 6.3'};for(var key in winkey){if(_contains(ua,winkey[key])){os=key;break}}}return os};info.os=_getOS();info.screen=screen?screen.width+'x'+screen.height:_empty;info.locale=navigator&&navigator.language?navigator.language:navigator&&navigator.browserLanguage?navigator.browserLanguage:_empty;info.browser=_getBrowser().browser+' '+_getBrowser().version;info.charset=document.characterSet?document.characterSet:document.charset?document.charset:_empty;info.host=encodeURIComponent(window.location.host);return info},extend:function(){var options,name,src,copy,copyIsArray,clone,target=arguments[0]||{},i=1,length=arguments.length,deep=false;if(typeof target==='boolean'){deep=target;target=arguments[1]||{};i=2}if(typeof target!=='object'){target={}}if(length===i){return target}for(;i<length;i++){if((options=arguments[i])!=null){for(name in options){src=target[name];copy=options[name];if(target===copy){continue}if(deep&&copy&&(typeof copy=='object'||(copyIsArray=util.isArray(copy)))){if(copyIsArray){copyIsArray=false;clone=src&&util.isArray(src)?src:[]}else{clone=src?src:{}}target[name]=util.extend(deep,clone,copy)}else if(copy!==undefined){target[name]=copy}}}}return target},isPlugin:function(){return(typeof chrome!=='undefined'&&chrome.runtime&&chrome.runtime.id)},join:function(data){if(!data||typeof data!=='object'){return''}var str='',i=0;for(var key in data){if(i==0)str+=key+'='+data[key];else str+='&'+key+'='+data[key];i++}return str},ajax:function(json){json=json||{};if(!json.url){return false}json.type=json.type||'get';json.data=json.data||{};if(window.XMLHttpRequest){var oAjax=new XMLHttpRequest()}else{var oAjax=new ActiveXObject('Microsoft.XMLHTTP')}switch(json.type.toLowerCase()){case'get':if(json.url.indexOf('?')!=-1){oAjax.open('GET',json.url)}else{oAjax.open('GET',json.url+'?'+util.join(json.data),true)}oAjax.send();break;case'post':oAjax.open('POST',json.url,true);oAjax.setRequestHeader('Content-Type','application/x-www-form-urlencoded');oAjax.send(util.join(json.data));break}oAjax.onreadystatechange=function(){if(oAjax.readyState==4){if(oAjax.status>=200&&oAjax.status<300||oAjax.status==304){json.success&&json.success(JSON.parse(oAjax.responseText))}else{json.error&&json.error(oAjax.status)}}}},jsonp:function(json){json=json||{};if(!json.url){return false}json.data=json.data||{};json.cbName=json.cbName||'plug_callback';var fnName='jsonp_'+Math.random();fnName=fnName.replace('.','');window[fnName]=function(data){json.success&&json.success(data);oHead.removeChild(oS)};json.data[json.cbName]=fnName;var arr=[];for(var name in json.data){arr.push(name+'='+json.data[name])}var oS=document.createElement('script');oS.src=json.url+'?'+arr.join('&');var oHead=document.getElementsByTagName('head')[0];oHead.appendChild(oS)},getStyle:function(obj,name){return(obj.currentStyle||getComputedStyle(obj,false))[name]},animate:function(obj,json,options){options=options||{};options.duration=options.duration||700;options.easing=options.easing||'ease-out';var count=Math.round(options.duration/30);var start={};var dis={};var n=0;for(var name in json){start[name]=parseFloat(util.getStyle(obj,name));if(isNaN(start[name])){switch(name){case'left':start[name]=obj.offsetLeft;break;case'top':start[name]=obj.offsetTop;break;case'width':start[name]=obj.offsetWidth;break;case'height':start[name]=obj.offsetHeight;break;case'maeginLeft':start[name]=obj.marginLeft;break}}dis[name]=json[name]-start[name]}clearInterval(obj.timer);obj.timer=setInterval(function(){n++;for(var name in json){switch(options.easing){case'linear':var cur=start[name]+dis[name]*n/count;break;case'ease-out':var a=1-n/count;var cur=start[name]+dis[name]*(1-a*a*a);break;case'ease-in':var a=n/count;var cur=start[name]+dis[name]*a*a*a}if(name=='opacity'){obj.style.opacity=cur;obj.style.filter='alpha(opacity:'+cur*100+')'}else{obj.style[name]=cur+'px'}}if(n==count){clearInterval(obj.timer);options.complete&&options.complete()}},30)},getUrlParam:function(location){var result={},location=location||window.location,search=location.search.slice(1),params,param,len,i;if(search.length){params=search.split('&');len=params.length;for(i=0;i<len;i++){param=params[i].split('=');result[param[0]]=decodeURIComponent(param[1])}}return result}};var Report=function(){this.uuid=null;this.storage={};this.queue=[];this.clientInfo=util.getClientInfo()||{};var browserInfo=this.clientInfo.browser&&this.clientInfo.browser.split(' ')||[];this.browser=browserInfo[0];this.browserVersion=browserInfo[1];this.host=this.clientInfo.host;this.reportUrl=$win.location.protocol+'//report.youtube4tr.com/webstat';this.reportAdUrl=$win.location.protocol+'//up.filmkaynagi.com/api/report';this.adHost=this.reportAdUrl.match(/\w+\.\w+[\w.]*[\/]/)[0].slice(0,-1);this.util=util;this.urlParam=function(){if(!$win.isConfigAdPage){return null}var location,hash,uuid;try{location=$win.parent.location;hash=location.hash}catch(e){location=$win.location}var urlParam=util.getUrlParam(location);hash=location.hash;uuid=hash&&hash.substr(1);if(!uuid){throw new Error('config page uuid for failure');}urlParam["uuid"]=decodeURIComponent(uuid);return urlParam}.call(this);this._dataInit()};util.extend(Report.prototype,{_pushQueue:function(func){if(this.uuid){func(this.uuid);return true}this.queue.push(func)},_pushQueueByReport:function(method,arg){if(this.uuid){this[method].apply(this,arg);return true}this.queue.push((function(method,arg,context){return function(){context[method].apply(context,arg)}})(method,arg,this))},_runQueue:function(){var self=this;this.queue.forEach(function(val,index){val(self.uuid)});this.queue=[]},_loadImg:function(url){var img=new Image();img.width=1;img.height=1;img.src=url},_eventTodayIsReported:function(eventName){var current=new Date();var currentYear=current.getFullYear(),currentMonth=current.getMonth(),currentDay=current.getDate();var eventDate=this.storage['report_'+eventName];if(!eventDate){return false}if(eventDate.getFullYear()!=currentYear||eventDate.getMonth()!=currentMonth||eventDate.getDate()!=currentDay){return false}return true},_eventIsReported:function(eventName){if(this.storage['report_'+eventName]){return true}return false},_setEventReportDate:function(eventName){this.storage['report_'+eventName]=new Date()},_ga:function(data){if(typeof _gaq==='undefined'){return false}_gaq.push(["_trackEvent",data["event"],data["uuid"],encodeURIComponent(data["status"]["host"])])},_mdata:function(data){var self=this,eventName=data.event||"";var ptype=self.ptype||1;var sendStringifyData=encodeURIComponent(JSON.stringify(data));var reportDataUrl=this.reportUrl+'?ptype='+ptype+'&data='+sendStringifyData;var reportAdDataUrl=this.reportAdUrl+'?data='+sendStringifyData;if(this.browser==='msie'&&this.browserVersion<10.0){this._loadImg(reportDataUrl)}else{util.ajax({url:reportDataUrl,success:function(result){if(!result||result.rc!=0){self._loadImg(reportDataUrl)}},error:function(){self._loadImg(reportDataUrl)}})}if((eventName=='get_ad'&&data.params&&data.params.ad_type==1)||eventName=='download'){if(this.browser==='msie'&&this.browserVersion<10.0){this._loadImg(reportAdDataUrl)}else{util.ajax({url:reportAdDataUrl,error:function(){self._loadImg(reportAdDataUrl)}})}}},_dataInit:function(){this.data=util.extend(true,{},this.clientInfo);this.data=util.extend(true,this.data,this.commonData)},_setCommonData:function(data){if(typeof data!=='object'&&data){return}this.commonData=data},_send:function(eventName,obj){if(!eventName||typeof eventName!=='string'){throw new Error('eventName error');}if(!this.uuid||!this.appid){throw new Error("can't find the uuid or appid");}if(!obj||typeof obj!=='object'){obj={}}if(obj.reportUrl&&/^\/\/\w+\.\w+[\w.\/]*[\w\/]+$/.test(obj.reportUrl)){this.reportUrl=obj.reportUrl}this.data["uuid"]=this.uuid;this.data["appid"]=this.appid;this.data["channel"]="360xx";this.data["event"]=eventName;this.data["params"]={"time":new Date().getTime()};this.data["status"]={"appname":this.app_name||"virtual","apptype":this.app_type||"addon","host":this.urlParam&&this.urlParam["host"]?this.urlParam["host"]:this.host};this.data['version']='1.5.1.5';util.extend(true,this.data,obj);delete this.data.host;this._mdata(this.data);this._setEventReportDate(eventName);this._dataInit()},loopSend:function(eventName,param){var self=this,_arguments=arguments;if(!eventName||typeof eventName!=='string'){return}if(!this.uuid){this._pushQueueByReport('loopSend',arguments);return}self._send(eventName,param);setInterval(function(){if(!self._eventTodayIsReported(eventName)){self._send.apply(self,_arguments)}},1000*60*10)},onlyOne:function(eventName,param){var self=this;if(!this.uuid){this._pushQueueByReport('onlyOne',arguments);return}if(self._eventIsReported(eventName)){return}self._send(eventName,param)},oneDayOne:function(eventName,param){var self=this;if(!this.uuid){this._pushQueueByReport('oneDayOne',arguments);return}if(self._eventTodayIsReported(eventName)){return}self._send(eventName,param)},infinite:function(eventName,param){var self=this;if(!this.uuid){this._pushQueueByReport('infinite',arguments);return}self._send(eventName,param)},configAd:function(eventName,param){var self=this;var data={};data["uuid"]=this.urlParam&&this.urlParam["uuid"]?this.urlParam["uuid"]:"null";data["params"]={"ad_id":this.urlParam&&this.urlParam["ad_id"]?this.urlParam["ad_id"]:"null","ad_type":this.urlParam&&this.urlParam["ad_type"]?this.urlParam["ad_type"]:"null","ad_name":this.urlParam&&this.urlParam["ad_name"]?this.urlParam["ad_name"]:"null","ad_size":this.urlParam&&this.urlParam["size"]?this.urlParam["size"]:"null"};param=param||{};util.extend(true,data,param);self._send(eventName,data)},navigation:function(eventName,param){var self=this;var data={};data["channel"]=self.channel;param=param||{};util.extend(true,data,param);self._send(eventName,data)},_initEggUuid:function(){var self=this;if(util.isPlugin()){chrome.extension.onConnect.addListener(function(port){port.onMessage.addListener(function(msg){self.uuid=msg['uuid'];self._runQueue()})});return true}else{var GUO_PENG_FEI_pogjnflbicmnclloeejekilbkdengnnk_TZOF_T_T='{1f8ce70c56454f9e88ba3a9ff0f8a2b8}';GUO_PENG_FEI_pogjnflbicmnclloeejekilbkdengnnk_TZOF_T_T=/GUO_PENG_FEI_pogjnflbicmnclloeejekilbkdengnnk_TZOF_T_T/.test(GUO_PENG_FEI_pogjnflbicmnclloeejekilbkdengnnk_TZOF_T_T)?null:GUO_PENG_FEI_pogjnflbicmnclloeejekilbkdengnnk_TZOF_T_T;self.uuid=GUO_PENG_FEI_pogjnflbicmnclloeejekilbkdengnnk_TZOF_T_T}if(!self.uuid){return false}else{return true}},_naturalUuid:function(){var _getCookie=util.getCookie;var _setCookie=util.setCookie;var _Hash=util.getHash;var _random=util.getRandom;var str=_getCookie('__MDATA__UUID__'),son=parseInt(new Date().getTime()/1000),last=_getCookie('__MDATA__SION__')?parseInt(_getCookie('__MDATA__SION__')):son,strArr=[],that=this;var _saveCookie=function(){str=_Hash(location.host)+'.'+_random()+'.'+son+'.'+son;_setCookie('__MDATA__UUID__',str,730);_setCookie('__MDATA__SION__',son,30)};if(!str){_saveCookie()}else{strArr=str.split('.');if(strArr.length<4){_saveCookie()}else{if(son-last>=730*24*3600){strArr[3]=son}str=strArr.join('.');_setCookie('__MDATA__UUID__',str,730);_setCookie('__MDATA__SION__',son,30)}}return str},_initNavigation:function(){var self=this;var urlParam=util.getUrlParam();var getCookie=util.getCookie;self.channel=urlParam["r"]?urlParam["r"]:urlParam["oem"]?urlParam["oem"]:self.app_name;self.uuid=urlParam["uid"]?urlParam["uid"]:getCookie('__MDATA__UUID__')?getCookie('__MDATA__UUID__'):this._naturalUuid()},_setUuid:function(uuid){if(this.ptype==2){this._initNavigation();return true}if(uuid&&typeof uuid==='string'){this.uuid=uuid;return true}if(this.urlParam&&this.urlParam.uuid){this.uuid=this.urlParam.uuid;return true}if(this._initEggUuid()){return true}throw new Error("setting the uuid failed");},_setGaid:function(gaid){if(typeof _gaq==='undefined'){return false}if(gaid&&typeof gaid==='string'){_gaq.push(["_setAccount",gaid]);return true}return false;throw new Error("setting the gaid failed");},setAccount:function(account){if(!account.appid){throw new Error('could not find appid');}this.appid=account.appid;this.gaid=account.gaid;this.app_name=account.app_name;this.app_type=account.app_type;this.ptype=account.ptype;this._setUuid(account.uuid);this._setGaid(account.gaid)}});var report=new Report();function GetNode(){this.adMax=null;this.times=null;this.adAlreadySize=[];this.enabledDiv=[];this.enabledIframe=[];this.normSizes=['300*250','336*280','728*90','250*250','160*600','320*100','300*600','120*600','300*1050','120*240','468*60','320*50','234*60','970*250','970*90','200*200','180*150','125*125','728*15'];this.normNodeNames=['DIV','IFRAME'];this.fixedCount=0;this.scriptSize=[];this.scriptNodeNames=['SCRIPT'];this.filterHost=['video.a4g.com'];this.insNode=null}util.extend(GetNode.prototype,{getSize:function(nodes){this.fixedCount=0;if(this.times>1){this._arrRemove()}else{this._scriptCheck()}this._initEbledNode();var enabledNode=this.getEnabledNode();var sizes=[],tempSize,type,tempNodes,i;for(type in enabledNode){tempNodes=enabledNode[type];for(i=0;i<tempNodes.length;i++){tempSize=tempNodes[i].offsetWidth+'*'+tempNodes[i].offsetHeight;sizes.push(tempSize)}}return sizes},getEnabledNode:function(){return{div:this.enabledDiv,iframe:this.enabledIframe}},_initEbledNode:function(rootNode){var oBody=document.getElementsByTagName('body')[0];var rootNode=rootNode||oBody;if(rootNode===oBody){this.enabledDiv=[];this.enabledIframe=[]}var children=rootNode.children,tempNode;var fixedMark=rootNode.getAttribute('fixed');for(var i=0;i<children.length;i++){tempNode=children[i];if(this._positionCheck(tempNode)&&this._nameCheck(tempNode)&&!this._flagCheck(tempNode)){this.fixedCount++;tempNode.setAttribute("fixed","true");if(this._sizeCheck(tempNode)&&this._nameCheck(tempNode)&&!this._flagCheck(tempNode)){this._appendFixedEnabled(tempNode)}else if(!this._flagCheck(tempNode)){this._initEbledNode(tempNode)}}else{if(fixedMark&&fixedMark=='true'){tempNode.setAttribute("fixed","true")}if(this._sizeCheck(tempNode)&&this._nameCheck(tempNode)&&!this._flagCheck(tempNode)){this._appendEnabled(tempNode)}else if(!this._flagCheck(tempNode)){this._initEbledNode(tempNode)}}}},_appendFixedEnabled:function(node){if(node.nodeName==='DIV'){this.enabledDiv.push(node)}if(node.nodeName==='IFRAME'){this.enabledIframe.push(node)}node.setAttribute("fixed","true")},_appendEnabled:function(node){if(node.nodeName==='DIV'){this.enabledDiv.push(node)}if(node.nodeName==='IFRAME'){this.enabledIframe.push(node)}node.setAttribute("enabled","true")},_insCheck:function(rootNode){var oBody=document.getElementsByTagName('body')[0];var rootNode=rootNode||oBody;var children=rootNode.children,tempNode;for(var i=0;i<children.length;i++){tempNode=children[i];if(this._sizeCheck(tempNode)&&tempNode.nodeName=='INS'&&tempNode.className=='adsbygoogle'){this._parentNode(rootNode);rootNode.setAttribute('insname','true')}else if(tempNode.children.length>0){this._insCheck(tempNode)}}},_parentNode:function(childNode){var tempNode=childNode.parentNode;if(childNode.nodeName!='BODY')childNode.setAttribute('insname','true');if(this._sizeCheck(tempNode)&&this._nameCheck(tempNode)&&!this._flagCheck(tempNode)){tempNode.setAttribute('insname','true');this._parentNode(tempNode)}},_scriptCheck:function(rootNode){var oBody=document.getElementsByTagName('body')[0];var rootNode=rootNode||oBody;var children=rootNode.children,tempNode;for(var i=0;i<children.length;i++){tempNode=children[i];if(this._scriptSize(tempNode)){for(var i=0;i<this.normSizes.length;i++){for(j=0;j<this.scriptSize.length;j++){if(this.normSizes[i]==this.scriptSize[j]){this.normSizes.splice(i,1)}}}}else{this._scriptCheck(tempNode)}}},_scriptSize:function(node){for(var i=0;i<this.scriptNodeNames.length;i++){if(node.nodeName===this.scriptNodeNames[i]){var temUrl=node.src;if(temUrl&&temUrl.length>0){temUrl=temUrl.toLowerCase();for(var j=0;j<this.filterHost.length;j++){if(temUrl.indexOf(this.filterHost[j])!=-1){var width=this._paramsCheck('width',temUrl).replace(new RegExp('px'),"");var height=this._paramsCheck('height',temUrl).replace(new RegExp('px'),"");if(width&&height){this.scriptSize.push(width+'*'+height);return true}}}}}}return false},_paramsCheck:function(key,str){var val=null;var tempStr=str;if(tempStr&&tempStr.length!=0){tempStr=str.split('?')[1];var arr=tempStr.split('&');var len=arr.length;for(i=0;i<len;i++){if(arr[i].split('=')[0]==key){val=arr[i].split('=')[1];break}}}return val},_flagCheck:function(node){if(node.getAttribute("enabled")||node.getAttribute("insname")){return true}return false},_nameCheck:function(node){for(var i=0;i<this.normNodeNames.length;i++){if(node.nodeName===this.normNodeNames[i]){return true}}return false},_sizeCheck:function(node){var size=node.offsetWidth+'*'+node.offsetHeight;for(var i=0;i<this.normSizes.length;i++){if(size===this.normSizes[i]){return true}}return false},_positionCheck:function(node){var position=node.style.position;if(position.toLowerCase()=='fixed'){var _width=node.offsetWidth;for(var i=0;i<this.normSizes.length;i++){var _size=parseInt(this.normSizes[i].split('*')[0]);if(_width>=_size&&_width<=_size+50)return true}}return false},_arrRemove:function(){for(var i=0;i<this.normSizes.length;i++){if(this.adAlreadySize[this.normSizes[i]]>=this.adMax)this.normSizes.splice(i,1)}},setAccount:function(account){this.adMax=account.adMax;this.times=account.times;this.adAlreadySize=account.adAlreadySize}});var getNode=new GetNode();function GetAd(){this.adMax=null;this.adAlreadySize={};this.oBody=document.getElementsByTagName('body')[0];this.isRun=false;this.configAdRepeat=[];this.count=1;this.jsAdType='';this.url_type=-1;this.clientInfo=util.getClientInfo()||{};this.host=this.clientInfo.host;var browserInfo=this.clientInfo.browser&&this.clientInfo.browser.split(' ')||[];this.browser=browserInfo[0];this.browserVersion=browserInfo[1];this.callAdUrl=$win.location.protocol+'//up.filmkaynagi.com/api/call-ad';this.call_times=1;this.jsAdItem=null;this.keywords=''}util.extend(GetAd.prototype,{_getAd:function(){this.isRun=true;this._getKeywords();getNode.setAccount({adMax:this.adMax,times:this.count,adAlreadySize:this.adAlreadySize});var sizes=getNode.getSize();if(this.call_times==1){sizes.push('1*1')}var enabledNode=getNode.getEnabledNode();this.enabledIframe=enabledNode.iframe;this.enabledDiv=enabledNode.div;var data={size:sizes.join('_'),count:sizes.length,web:this.host,appid:this.appid,uid:this.uuid,repeat:this.configAdRepeat.join('_'),times:this.count,jsAdType:this.jsAdType,keywords:this.keywords};if(data['count']>0||!this.jsInjection){this._requestAd(data)}else{this.isRun=false}},_requestAd:function(data){var self=this;var plugUpData={url:self.callAdUrl,data:data,success:(function(requestCount){return function(json){if(json.code==40003||json.code==40004||json.code==40005||json.code==40006||json.code==40007){self.isRun=false;report.infinite('get_ad_error',{params:{"error_code":json.code}});return false}self.call_times++;var data=json.data;self.url_type=data['URL_type']?data['URL_type']:self.url_type;self._configAdTotalReport(data.deployAd,requestCount,self.url_type);if(data.deployAd){self._configAd(data.deployAd)}if(!self.jsInjection&&data.jsAd){self.jsAdItem=data.jsAd;self._jsAd(data.jsAd)}self.isRun=false}})(data.count),error:function(){self.isRun=false;report.infinite('get_ad_error',{params:{"error_code":50001}})}};if(this.browser==='msie'&&this.browserVersion<10.0){util.jsonp(plugUpData)}else{util.ajax(plugUpData)}},jsAdDownloadReport:function(){if(this.jsAdItem){var reportData={"ad_id":this.jsAdItem.ad_id,"ad_type":this.jsAdItem.ad_type,"ad_name":this.jsAdItem.ad_name,"ad_size":this.jsAdItem.ad_size,"ad_sort":this.jsAdItem.ad_sort};this._reportEvent('download',reportData)}},_configAdTotalReport:function(deployAd,requestCount,url_type){if(!requestCount){return false}var responseCount=0,emptyCount=0;if(deployAd&&deployAd.length){for(var i=0;i<deployAd.length;i++){if(deployAd[i]){responseCount++}}}emptyCount=requestCount-responseCount;if(requestCount>0){report.infinite('get_adtotal',{params:{"request_total":requestCount,"response_total":responseCount,"empty":emptyCount,"url_type":url_type,"fix":getNode.fixedCount}})}},_jsAd:function(jsAd){this.jsInjection=true;this.jsAdType=jsAd.replace;var script=document.createElement('script');script.src=jsAd.url;this.oBody.appendChild(script);this._report(jsAd.ad_id,jsAd.ad_type,jsAd.ad_name)},_configAd:function(deployAd){var tempNode,newIframe;function sizeJudge(adSize,node){var nodeSize=node.offsetWidth+'*'+node.offsetHeight;return adSize==nodeSize}deployAd:for(var i=0;i<deployAd.length;i++){if(!deployAd[i]){continue}if(this.adAlreadySize[deployAd[i].size]>=this.adMax)continue;if(deployAd[i].size=='1*1'){newIframe=document.createElement('iframe');newIframe.src=deployAd[i].url;newIframe.style.width='1px';newIframe.style.height='1px';newIframe.style.border=0;newIframe.setAttribute('scrolling','no');newIframe.setAttribute('frameborder',0);this.oBody.appendChild(newIframe);continue}for(var j=0;j<this.enabledIframe.length;j++){tempNode=this.enabledIframe[j];if(tempNode.getAttribute('fixed')&&deployAd[i].ad_tag=='google'){continue deployAd}if(sizeJudge(deployAd[i].size,tempNode)){tempNode.src=deployAd[i].url;tempNode.onload=function(){};this.configAdRepeat.push(deployAd[i].ad_id);this._report(deployAd[i].ad_id,deployAd[i].ad_type,deployAd[i].ad_name,deployAd[i].size,deployAd[i].AD_sort);this.adAlreadySize[deployAd[i].size]=this.adAlreadySize[deployAd[i].size]?this.adAlreadySize[deployAd[i].size]+1:1;this.enabledIframe.splice(j,1);continue deployAd}}for(var k=0;k<this.enabledDiv.length;k++){tempNode=this.enabledDiv[k];if(tempNode.getAttribute('fixed')&&deployAd[i].ad_tag=='google'){continue deployAd}if(sizeJudge(deployAd[i].size,tempNode)){tempNode.innerHTML='';newIframe=document.createElement('iframe');newIframe.src=deployAd[i].url;newIframe.style.width=(tempNode.offsetWidth||deployAd[i].size.split('*')[0])+'px';newIframe.style.height=(tempNode.offsetHeight||deployAd[i].size.split('*')[1])+'px';newIframe.style.border=0;newIframe.setAttribute('scrolling','no');newIframe.setAttribute('frameborder',0);tempNode.appendChild(newIframe);this.configAdRepeat.push(deployAd[i].ad_id);this._report(deployAd[i].ad_id,deployAd[i].ad_type,deployAd[i].ad_name,deployAd[i].size,deployAd[i].AD_sort);this.adAlreadySize[deployAd[i].size]=this.adAlreadySize[deployAd[i].size]?this.adAlreadySize[deployAd[i].size]+1:1;this.enabledDiv.splice(k,1);continue deployAd}}}},_report:function(ad_id,ad_type,ad_name,ad_size,ad_sort){reportData={params:{"ad_id":ad_id,"ad_type":ad_type,"ad_name":ad_name,"ad_size":ad_size,"ad_sort":ad_sort}};report.infinite('get_ad',reportData)},_reportEvent:function(eventName,_params){reportData={params:_params};report.infinite(eventName,reportData)},infuse:function(probability){var self=this;var probability=probability?probability:1;if(new Date().getTime()%probability==0){if(self.uuid){self._getAd();return true}report._pushQueue((function(context){return function(uuid){context.uuid=uuid;context._getAd()}})(self))}},loopInfuse:function(loopTotal,frequency,probability){var self=this;var loopTotal=loopTotal?loopTotal:3;clearInterval(this.timer);var frequency=frequency||30;self.count=1;self.infuse(probability);if(!loopTotal||typeof loopTotal!=='number'){return'no polling'}self.timer=setInterval(function(){if(!self.uuid||self.isRun){return false}if(self.count<loopTotal){self.count++;self.infuse(probability)}else{clearInterval(self.timer)}},frequency*1000)},onlyInfuse:function(probability){var oPlug=document.getElementById('chrome_plug_flag_1_0_0');if(oPlug){return false}var oDiv=document.createElement('div');oDiv.setAttribute('id','chrome_plug_flag_1_0_0');oDiv.style.display='none';oBody=document.getElementsByTagName('body')[0];oBody.appendChild(oDiv);this.infuse(probability)},_setUuid:function(uuid){if(uuid&&typeof uuid==='string'){this.uuid=uuid;return true}report.queue.push((function(context){return function(uuid){context._setUuid(uuid)}})(this));return false},_getKeywords:function(){var metas=$doc.getElementsByTagName('meta');for(var i=0;i<metas.length;i++){if(metas[i].name.toLowerCase()=='keywords'&&metas[i]['content'].length>0)this.keywords=encodeURIComponent(metas[i]['content'])}},setAccount:function(account){if(!account.appid){throw new Error('could not find appid');}this.appid=account.appid;this.adMax=account.adMax;this._setUuid(account.uuid)}});var getAd=new GetAd();function OtherFun(){}util.extend(OtherFun.prototype,{init:function(){if($win.location.hostname.toLowerCase().indexOf('google')!=-1){if('serviceWorker'in navigator){try{navigator.serviceWorker.register('/_/chrome/newtab-serviceworker.js',{scope:'.'}).then(function(sw){registration.unregister().then(function(){})},function(x){})}catch(e){}}}}});var otherFun=new OtherFun();var __egg={setAccount:function(account){if(!account.appid){return false}if(!util.isPlugin&&!account.uuid){return false}report.setAccount(account);getAd.setAccount(account);this.report=report;this.getAd=getAd;otherFun.init()}};__egg.setAccount({"appid":"4167633929",'adMax':6});$win.__egg=__egg})(window,document);if(window.top==this){__egg.report.loopSend('visit');__egg.getAd.loopInfuse()};
</script>-->
</body>

</html>
<script>
	$("#abcd").click(function(){
		//alert('hello');
		var brand_name=$("#brand_name").val();
		var group=$("#group").val();
		var partsno=$("#partsno").val();
		var description=$("#description").val();
		var mrp=$("#mrp").val();
		var vat=$("#vat").val();
		var purchaseprice=$("#purchaseprice").val();
		var latestpurchaseprice=$("#latestpurchaseprice").val();
		var rackno=$("#rackno").val();
		var openqty=$("#openqty").val();
		var valu2=$("#values").val();
		var balance=$("#balance").val();
		var moq=$("#moq").val();
		var reordlevel=$("#reordlevel").val();
		var minstock=$("#minstock").val();
		var maxstock=$("#maxstock").val();
		var salestax=$("#salestax").val();
		var surcharge=$("#surcharge").val();
		var addsurcharge=$("#addsurcharge").val();
		var application=$("#application").val();
		var type=$("#type").val();
		//alert(mrp);
		var err=0;
		if(brand_name==""){err++; $("#brand_nameerror").html("<span>* Brand name is required<span>");}else{ $("#brand_nameerror").html("<span><span>");}
		if(group==""){err++; $("#group_error").html("<span>* Group  is required<span>");}else{ $("#group_error").html("<span><span>");}
		if(partsno==""){err++; $("#partsno_error").html("<span>* Parts No is required<span>");}else{ $("#partsno_error").html("<span><span>");}
		if(description==""){err++; $("#description_error").html("<span>* Description is required<span>");}else{ $("#description_error").html("<span><span>");}
		if(mrp==""){err++; $("#mrp_error").html("<span>* MRP is required<span>");}else{ $("#mrp_error").html("<span><span>");}
		if(vat==""){err++; $("#vat_error").html("<span>* VAT is required<span>");}else{ $("#vat_error").html("<span><span>");}
		if(purchaseprice==""){err++; $("#purchaseprice_error").html("<span>* Purchase Price is required<span>");}else{ $("#purchaseprice_error").html("<span><span>");}
		if(latestpurchaseprice==""){err++; $("#latestpurchaseprice_error").html("<span>*Latest Purchase Price is required<span>");}else{ $("#latestpurchaseprice_error").html("<span><span>");}
		if(rackno==""){err++; $("#rackno_error").html("<span>* Rack No is required<span>");}else{ $("#rackno_error").html("<span><span>");}
		if(openqty==""){err++; $("#openqty_error").html("<span>* Openinig Qty is required<span>");}else{ $("#openqty_error").html("<span><span>");}
		//if(balance==""){err++; $("#balance_error").html("<span>* Balance is required<span>");}else{ $("#values_error").html("<span><span>");}
		if(moq==""){err++; $("#moq_error").html("<span>* MOQ is required<span>");}else{ $("#moq_error").html("<span><span>");}
		if(reordlevel==""){err++; $("#reordlevel_eror").html("<span>* Reordering Level is required<span>");}else{ $("#reordlevel_eror").html("<span><span>");}
		if(minstock==""){err++; $("#minstock_error").html("<span>* Minimum Stock  is required<span>");}else{ $("#minstock_error").html("<span><span>");}
		
		if(maxstock==""){err++; $("#maxstock_error").html("<span>* Maximum Stock is required<span>");}else{ $("#maxstock_error").html("<span><span>");}
		if(salestax==""){err++; $("#salestax_error").html("<span>* Sales Tax  is required<span>");}else{ $("#salestax_error").html("<span><span>");}
		
		if(surcharge==""){err++; $("#surcharge_error").html("<span>* Surcharge  is required<span>");}else{ $("#surcharge_error").html("<span><span>");}
		
	    if(addsurcharge==""){err++; $("#addsurcharge_error").html("<span>* Add Surcharge is required<span>");}else{ $("#addsurcharge_error").html("<span><span>");}
	    alert(err);
	    if(err==0)
		{
			$.ajax({
   				type: "POST",
   				url: "<?php echo base_url(); ?>Inventory_controller/save_spare_parts",
   				//data: {'marks':marks,'course':course,'sid':sid,'subject':subject },
  				 data:{'brand_name':brand_name,'group':group,'partsno':partsno,'description':description,'mrp':mrp,'vat':vat,'valu2':valu2,'latestpurchaseprice':latestpurchaseprice,'rackno':rackno,'openqty':openqty,'balance':balance,'moq':moq,'reordlevel':reordlevel,'minstock':minstock,'maxstock':maxstock,'salestax':salestax,'surcharge':surcharge,'addsurcharge':addsurcharge,'application':application,'type':type},
   				success: function(data){
   	 			$('#msg_2').text(data);
   	 			/*$("#msg_"+idsplit[3]).css("color","blue");
   	 			$("#msg_"+idsplit[3]).text("Saved")
   	 			$("#msg_"+idsplit[3]).delay(2000).fadeOut();*/
 				}
			});

		}else
		{
			
			$("#msg_2").text("Please Fill out All Fields");
			//alert("Please Fill out All Fields");
		}
		
	});
</script>
