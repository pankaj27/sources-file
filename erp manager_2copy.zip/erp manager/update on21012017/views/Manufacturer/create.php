
<?php //include('conection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
  
<!--<script src="//code.jquery.com/jquery-1.12.3.js"></script>-->
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    $( "#datepicker" ).datepicker({dateFormat:'dd-mm-yy'});
    
  } );
  </script>


<style>
	#verticalLine {
    border-left: 1px solid black;
   }
    .print-clean{
    	border: none;
       background: transparent;
    }
    #partstble,#partstble2{
    	width:100%;
    }
    #optr{
    	width:100%;
    }
    #partstble tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #partstble2 tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #optr tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    .datatr{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    .datatr1{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    #partstble3{
    	width:100%;
    }
     #partstble3 tr {
     	line-height:15px;
    	border-top: 1px solid #0aa89e;
     }
    .table12{
    	width:100%;
    	
    }
    .table12 tr{
    	height:6px;
    	border-bottom: 1px solid black;
    }
    .table12 td{
    	padding:0px;
    	margin:0px;
    	
    }
    .thred,.trhide{
    	display: none;
    }
    .wrapper {
  margin: 50px auto;
  width: 280px;
  height: 370px;
  background: white;
  border-radius: 10px;
  -webkit-box-shadow: 0px 0px 8px rgba(0,0,0,0.3);
  -moz-box-shadow:    0px 0px 8px rgba(0,0,0,0.3);
  box-shadow:         0px 0px 8px rgba(0,0,0,0.3);
  position: relative;
  z-index: 90;
}

.ribbon-wrapper-green {
  width:100px;
  height: 88px;
  overflow: hidden;
  position: absolute;
  top: -3px;
  right: -3px;
}

.ribbon-green {
  font: bold 15px Sans-Serif;
  color: #000;
  text-align: center;
  text-shadow: rgba(255,255,255,0.5) 0px 1px 0px;
  -webkit-transform: rotate(360deg);
  -moz-transform:    rotate(360deg);
  -ms-transform:     rotate(360deg);
  -o-transform:      rotate(360deg);
  position: relative;
  padding: 7px 0;
  left: -5px;
  top: 15px;
  width: 120px;
  background-color: #BFDC7A;
  background-image: -webkit-gradient(linear, left top, left bottom, from(#BFDC7A), to(#8EBF45)); 
  background-image: -webkit-linear-gradient(top, #BFDC7A, #8EBF45); 
  background-image:    -moz-linear-gradient(top, #BFDC7A, #8EBF45); 
  background-image:     -ms-linear-gradient(top, #BFDC7A, #8EBF45); 
  background-image:      -o-linear-gradient(top, #BFDC7A, #8EBF45); 
  color: #000;
  -webkit-box-shadow: 0px 0px 3px rgba(0,0,0,0.3);
  -moz-box-shadow:    0px 0px 3px rgba(0,0,0,0.3);
  box-shadow:         0px 0px 3px rgba(0,0,0,0.3);
}

.ribbon-green:before, .ribbon-green:after {
  content: "";
  border-top:   3px solid #6e8900;   
  border-left:  3px solid transparent;
  border-right: 3px solid transparent;
  position:absolute;
  bottom: -3px;
}

.ribbon-green:before {
  left: 0;
}
.ribbon-green:after {
  right: 0;
}

</style>
	<!-- BEGIN BASE-->

</div>
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
			
	<!-- BEGIN BLANK SECTION -->
	<section>
		<div class="ribbon-wrapper-green"><div class="ribbon-green"><a href="<?php echo base_url(); ?>">Show Stock</a></div></div>
		<div class="section-header">
				<ol class="breadcrumb">
									<li><a href="<?php echo base_url(); ?>">home</a></li>
												<li class="active"><?php if(isset($title)){ echo $title ; } ?></li>
						</ol>

		</div><!--end .section-header -->
		<div class="section-body">
			<div class="row">
				<div class="col-md-12">
					
					<div class="card card-bordered style-primary">
						<div class="card-head">
							
							<header><i class="fa fa-fw fa-tag"></i>Create Model Details</header>
						</div><!--end .card-head -->
						<div class="card-body style-default-bright">
							<div class="row">
								
								<form action="<?php echo base_url();  ?>Manufactarer_Controller/getchasis" method="post">
								<div class="col-md-12">
								<div class="col-md-2">
									<div class="form-group">
								     <input type="date" class="form-control" id="datepicker" name="datename"   placeholder="SELECT DATE">
									<!--<label for="Username2">Enter PO NO</label>-->
								    </div>
								</div>
								<div class="col-md-1">
									
								</div>
								
								<div class="col-md-2">
									<div class="form-group">
								     <!--<input type="text" class="form-control" id="Username2" name="orderid" value="" required="required" placeholder="SELECT MODEL">-->
								     <select class="form-control" name="model">
								     	<option value="">--select Model--</option>
								     	
								     	<?php if(isset($modellist) && !empty($modellist)){ ?>
								     		<?php  foreach($modellist as $row){ ?>
								     		<option value="<?php echo $row->productname; ?>"><?php echo $row->productname; ?></option>
								     		
								     		<?php  } } ?>
								     </select>
									<!--<label for="Username2">Enter PO NO</label>-->
									</div>
								</div>
								<div class="col-md-1">
									
								</div>
								<div class="col-md-2">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="color" value="" required="required" placeholder="COLOR">
									<!--<label for="Username2">Enter PO NO</label>-->
									</div>
								</div>
								<div class="col-md-1">
									
								</div>
								<div class="col-md-2">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="qty" value="" required="required" placeholder="QTY">
									<!--<label for="Username2">Enter PO NO</label>-->
									</div>
								</div>
								<div class="col-md-1">
									
								</div>
								</div>
								</div>
								<div class="row">
								<div class="col-md-2">
									<div class="form-group">
								     <button type="submit" class="btn btn-flat btn-primary ink-reaction">SUBMIT</button>
									<!--<label for="Username2">Enter PO NO</label>-->
								</div>
								</div>
								
							<!--end .col -->
							</form>
						</div>
						
						<div class="row">
						    <div class="col-md-12" style="border-bottom: 1px solid blue;padding: 2px;">
						    	<div class="col-md-6"></div>
						    	<div class="col-md-6">
						    		<div class="col-md-2"></div>
						    		<div class="col-md-2">
						    			<form action="<?php echo base_url(); ?>Manufactarer_Controller/printWriteForm" method="POST" target="_blank">
						    				<input type="hidden" name="date" value="<?php if(isset($dte)){echo $dte; } ?>" />
						    				<input type="hidden" name="chasisno" value="<?php if(isset($chasisdetails)) { echo $chasisdetails;} ?>"/>
						    				<input type="hidden" name="mnthcode" value="<?php if(isset($mnthcode)){ echo $mnthcode ; } ?>" />
						    				<input type="hidden" name="yrcode" value="<?php if(isset($yrcode)){ echo $yrcode ; } ?>" />
						    				<input type="hidden" name="qty" value="<?php if(isset($qty)){echo $qty ; } ?>" />
						    				<input type="hidden" name="model" value="<?php if(isset($model)){echo $model ; } ?>" />
						    				<button type="submit">Print Form</button>
						    			</form>
						    		</div>
						    		<div class="col-md-2">
						    	          <form action="<?php echo base_url(); ?>" method="POST" target="_blank"><button>Print</button></form>
						    	    </div>
						    	 </div>
						    </div>
						    <div class="col-md-12">
							<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="95%" style="text-align: center;">
								<thead>
									<tr>
										<th style="text-align: center;">SL NO.</th>
										<th style="text-align: center;">MODEL</th>
										<th style="text-align: center;">CHASIS NO</th>
										<th style="text-align: center;">MOTOR NO</th>
										<th style="text-align: center;">CONTROLLER NO</th>
										<th style="text-align: center;">BATTERY1 </th>
										<th style="text-align: center;">BATTERY2 </th>
										<th style="text-align: center;">BATTERY3 </th>
										<th style="text-align: center;">BATTERY4 </th>
										<!--<th style="text-align: center;">COLOUR</th>-->
										<th style="text-align: center;">DOE</th>
										<th style="text-align: center;">ACTION</th>
									</tr>
								</thead>
								<tbody>
									<?php if(isset($chasisdetails) && !empty($chasisdetails)){
								$chasisd=$chasisdetails;
								$lastfid=intval(substr($chasisd,-4));
								$lastid1=intval($lastfid)+1;
							    for($chs=0;$chs<intval($qty);$chs++)
								{
									 $chasisnonew="M6REP3085".$mnthcode.$yrcode."B".str_pad($lastid1,4 ,'0',STR_PAD_LEFT);
								?>
									<tr>
										<td><?php echo $chs+1; ?></td>
										<td><?php echo $model; ?></td>
										<td><?php echo $chasisnonew;  ?></td>
										<td><input type="text" size="8" ></td>
										<td><input type="text" size="8"></td>
										<td><input type="text" size="8" ></td>
										<td><input type="text"  size="8"></td>
										<td><input type="text" size="8" ></td>
										<td><input type="text" size="8"></td>
										
										<!--<th><?php if(isset($color)){ echo $color ; } ?><input type="hidden" value="<?php if(isset($color)){ echo $color ; } ?>" ></th>-->
										<th><?php echo date('d-m-Y'); ?><input type="hidden" value="<?php echo date('d-m-Y'); ?>"  readonly></th>
										<th><button type="button" id="save_<?php echo $chs+1; ?>" class="btn btn-flat btn-primary ink-reaction" onclick="savechasisdetails(this.id)"><i class="fa fa-save"></i></button>&nbsp;&nbsp;
											<button type="button" id="delete_<?php echo $chs+1; ?>" class="btn btn-flat btn-primary ink-reaction" onclick="saveeditorder(this.id)"><i class="fa fa-trash"></i></button></th>
										
									</tr>
									<?php  
								 
									$lastid1++;
								}
										
									
								
							} ?>
									
									
								</tbody>
							</table>
								
							</div>	
							
							
						</div>
							
						</div> 
							<!--end .col -->
						</div>
					
							
							
							
							
													
									
						</div><!--end .card-body -->
					</div><!--end .card -->
					
				</div><!--end .col -->
			</div>
		</div><!--end .section-body -->
	</section>
	<!-- BEGIN BLANK SECTION -->

		</div><!--end #content-->		
		<!-- END CONTENT -->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>

 

  
<!-- END CONTENT -->
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  
$( function() {
    
    $("#example").dataTable();
  } );
  </script>
