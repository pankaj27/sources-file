
<?php include('conection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">


<style>
	#verticalLine {
    border-left: 1px solid black;
   }
    .print-clean{
    	border: none;
       background: transparent;
    }
    #partstble,#partstble2{
    	width:100%;
    }
    #optr{
    	width:100%;
    }
    #partstble tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #partstble2 tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #optr tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    .datatr{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    .datatr1{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    #partstble3{
    	width:100%;
    }
     #partstble3 tr {
     	line-height:15px;
    	border-top: 1px solid #0aa89e;
     }
    .table12{
    	width:100%;
    	
    }
    .table12 tr{
    	height:6px;
    	border-bottom: 1px solid black;
    }
    .table12 td{
    	padding:0px;
    	margin:0px;
    	
    }
    .thred,.trhide{
    	display: none;
    }

</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			
			
	   </div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
	<!-- BEGIN BLANK SECTION -->
	<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li><a href="<?php echo base_url(); ?>">home</a></li>
												<li class="active"><?php if(isset($title)){ echo $title ; } ?></li>
						</ol>

		</div><!--end .section-header -->
		<div class="section-body">
			<div class="row">
				<div class="col-md-12">
					
					<div class="card card-bordered style-primary">
						<div class="card-head">
							
							<header><i class="fa fa-fw fa-tag"></i>All Stock List</header>
						</div><!--end .card-head -->
						<div class="card-body style-default-bright">
								<div class="row">
									<div class="col-md-12">
										<form action="<?php echo base_url(); ?>stockManage_controller/getstocklist" method="POST" class="form">
											
											<!--<div class="col-md-3">
													<div class="form-group">
														<select id="select1" name="godown" class="form-control" >
															  
															 
																<?php  if(isset($downstock) && !empty($downstock)){ ?>
																	<option value="">&nbsp;</option>
																	<?php foreach($downstock as $row){ ?>
																		 <option value="<?php echo $row->id;  ?>"><?php echo $row->gdname; ?></option> 
																		
																	
																<?php } } ?>
															</select>
															<label for="select1">Select Godown</label>
												    </div>
											</div>-->
											<div class="col-md-3">
													<div class="form-group">
															<select id="modelnmae" name="model" class="form-control"  onchange="getspareparts()">
																
															
																<?php if(isset($model)&& !empty($model)){ ?>
																	<option value="">&nbsp;</option>
																	<?php foreach($model as $row2) {  ?>
																	<option value="<?php  echo $row2->productname; ?>"><?php echo $row2->productname; ?></option>
																<?php } }  ?>
															</select>
															<label for="select1">Select Model</label>
													</div>
											</div>
											<div class="col-md-3">
													<div class="form-group">
															<select id="spareparts" name="parts" class="form-control" onchange="getspecification()">
																<option value="">&nbsp;</option>
															</select>
															<label for="select1">Select SpareParts</label>
													</div>
											</div>
											<div class="col-md-3">
													<div class="form-group">
															<select id="Specification" name="specf" class="form-control">
																<option value="">&nbsp;</option>
															</select>
															<label for="select1">Select SpareParts</label>
													</div>
											</div>
										    <div class="col-md-3">
													<div class="form-group">
													     <button type="submit" class="btn btn-flat btn-primary ink-reaction">GO</button>
														
													</div>
											</div>
										
										</form>
									</div>
											
								</div>
								<?php if(isset($stock) && !empty($stock)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Manufactarar Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example1" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <!--<th>GODOWN</th>-->
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($stock as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!--------------------------------  get allmodel wise data-------------------------------->
								<?php if(isset($modeldata) && !empty($modeldata)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Model Wise Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata2()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example2" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($modeldata as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!-------------------------  model and worshop both wise---------------------->
								<?php if(isset($modelwrehsedata) && !empty($modelwrehsedata)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Model and Warehouse Wise Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata3()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example3" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($modelwrehsedata as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!--------------------- wthout warehose by parts --------------------->
									
								<?php if(isset($prtsnowrsehse) && !empty($prtsnowrsehse)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Model and Spareparts Wise Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata4()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example4" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($prtsnowrsehse as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!--------------------- get parts list by warehouse-------->
								<?php if(isset($prtsyswrsehse) && !empty($prtsyswrsehse)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Model and Spareparts Wise Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata5()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example5" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($prtsyswrsehse as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!--------------------- get parts list by specification -------->
								<?php if(isset($getspef1) && !empty($getspef1)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Model and Spareparts Wise Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata6()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example6" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($getspef1 as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!--------------------- get parts list by specification -------->
								<?php if(isset($getspef2) && !empty($getspef2)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "Model and Spareparts Wise Stock" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata7()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example7" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($getspef2 as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								<!--------------------- GET All Data                  -------->
								<?php if(isset($getalldata) && !empty($getalldata)){ ?>
									<div class="row">

											<div class="col-md-12">
											<div class="card card-underline">
												<div class="card-head">
													<header><?php echo "All Stock List" ; ?></header>
													<div class="tools">
														<div class="btn-group">
															<div class="btn-group">
															  <!--<a href="#" class="btn btn-icon-toggle dropdown-toggle" data-toggle="dropdown"><i class="md md-colorize"></i></a>-->
															 
															  <button type="submit" class="btn btn-flat btn-primary ink-reaction" onclick="getexceldata7()"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp;Export</button>
														   </div>
														
															
														</div>
								
													</div>
												</div>
												<div class="card-body tab-content">
													<div class="tab-pane active" id="first1">
															<table id="example7" class="table  table-bordered table-hover" cellspacing="0" width="100%">
																<thead>
														            <tr>
														            	<th>SL NO.</th>
														            	<th>PARTS ID</th>
														                <th>PARTS NAME</th>
														                <th>SPECIFICATION</th>
														                <th>MODEL</th>
														                <th>GODOWN</th>
														                <th>UNIT</th>
														                
																		
														            </tr>
														        </thead>
							        
							        							<tbody>
		
																			<?php  $i=1; ?>
																			<?php foreach($getalldata as $row){
																				
																				$partsid=$row->partsid;
																				$querygetprtsname=mysqli_query($con,"select * from materiel_master where id='".trim($partsid)."'");
																				$prtsarray=mysqli_fetch_array($querygetprtsname);
																				$prtsname=$prtsarray['materialname'];
																				$prtsid=$prtsarray['materiel_id'];
																				$mnme=$row->mnme;
																				$spefcid=$row->spefcid;
																				$querygetspecfe=mysqli_query($con,"select * from spareparts_specification where id='".trim($spefcid)."'");
																				$specarray=mysqli_fetch_array($querygetspecfe);
																				$spenme=$specarray['specification'];
																				
																				$gdownid=$row->gdownid;
																				$querygetgodown=mysqli_query($con,"select * from godown where id='".trim($gdownid)."'");
																				$godownrray=mysqli_fetch_array($querygetgodown);
																				$gdown=$godownrray['gdowncode'];
																				
																				$qty=$row->qty;
																				
																				 ?>
																            <tr>
																               <td><?php echo $i; ?></td>
																               <td><?php echo $prtsid; ?></td>
																               <td><?php echo $prtsname; ?></td>
																               <td><?php echo $spenme; ?></td>
																               <td><?php echo $mnme; ?></td>
																               <td><?php echo $gdown; ?></td>
																               <td><?php echo $qty; ?></td>
																                
																            </tr>
																             
																            
																            <?php $i++; }  ?>
														        </tbody>
													    	</table>
													    	
															</div>
														</div>
											</div><!--end .card -->
											
										</div><!--end .col -->
										<!-- END LAYOUT RIGHT ALIGNED -->

									</div><!--end .row -->	
								<?php } ?>
								
								
								<!--end .col -->
								</div>
					
							
							
							
							
													
									
						</div><!--end .card-body -->
					</div><!--end .card -->
					
				</div><!--end .col -->
			</div>
		</div><!--end .section-body -->
	</section>
	<!-- BEGIN BLANK SECTION -->

		</div><!--end #content-->		
		<!-- END CONTENT -->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
  $(function(){
    $("#example,#example1,#example2,#example3,#example4,#example5,#example6,#example7").dataTable();
   // alert('hello');
  })
  </script>
<script>
function getspareparts()
	{
		var mname=$("#modelnmae").val();
		//alert(mname);
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getallspareparts",
  			data :{'mname':mname},
  			success : function(data){
  				 				 
  				alert(data);
  				$("#spareparts").html(data);
  			  
              }  
           });
	}
	function getspecification()
	{
		var spareparts=$("#spareparts").val();
		//alert(spareparts);
		
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getspecification",
  			data :{'spareparts':spareparts},
  			success : function(data){
  				 				 
  				alert(data);
  				$("#Specification").html(data);
  			  
              }  
           });
	
		
	}
	function getexceldata(){
		//alert('hello');
      $("#example1").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function getexceldata2(){
		//alert('hello');
      $("#example12").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function getexceldata3(){
		//alert('hello');
      $("#example3").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function getexceldata4(){
		//alert('hello');
      $("#example4").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function getexceldata5(){
		//alert('hello');
      $("#example5").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function getexceldata6(){
		//alert('hello');
      $("#example6").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  function getexceldata7(){
		//alert('hello');
      $("#example7").table2excel({
    name: "Excel Document Name",
	filename: "stockdetails",
	fileext: ".xls",
	exclude_img: true,
	exclude_links: true,
	exclude_inputs: true
  }); 
  }
  
</script>
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
 <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>-->
<script src="<?php echo base_url(); ?>assets/js/src/jquery.table2excel.js"></script>
 