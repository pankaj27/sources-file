<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class colourManage_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('colourManage_model');
	}
	public function addColour()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		$this->load->view("colour_manage/addColour/addColour");
	}
	public function saveColour()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		$ccode=$this->input->post('rgb');
		$hexcolor=$this->input->post("rgb1");
		$cname=$this->input->post('colourName');
		$data_array=array(
			"rgb_code"=>$ccode,
			"color_name"=>$cname,
			"code_hex"=>$hexcolor
		);
		$this->colourManage_model->insertColour($data_array);
		redirect('colourManage_controller/viewcolour','refresh');
	}
	public function viewcolour()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		$data['ccod']=$this->colourManage_model->fetchcolour();
		
		$this->load->view('colour_manage/addColour/viewColour',$data);
	}
	public function updateColour($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		//$id=$this->input->post('id');
		$ccode=$this->input->post('rgb');
		$hexcolor=$this->input->post("rgb1");
		
		$data_array=array(
			"rgb_code"=>$ccode,
			"code_hex"=>$hexcolor
		);
		$this->colourManage_model->updateColour($data_array,$id);
		
	}
	public function deleteColour($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$this->colourManage_model->deleteColour($id1);
		redirect('colourManage_controller/viewcolour','refresh');
	}
}