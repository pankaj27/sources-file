<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class stockManage_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('stockManage_model');
	}
	public function boxwiseentry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Admin Dashboard";
		$this->load->view("stockmanage/boxwiseentry",data);
		
	}
	public function stockentrybox()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Stock Entry";
		//$data['getpurchase']=$this->stockManage_model->getallpurchase();
		$this->load->view('stockmanage/stockentrybox',$data);
	}
	public function getpurchaselist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Stock Entry";
		$pono=$this->input->post('pono');
		$data['pono']=$pono;
		$data['getpurchaselist']=$this->stockManage_model->getallpurchaselist($pono);
		//print_r($data['getpurchaselist']);
		$deatgetspa=$data['getpurchaselist'];
		$modlar=array();
		foreach($deatgetspa as $rowpurcsdet)
		{
			$model=$rowpurcsdet->modelcode;
			$parts=$rowpurcsdet->spareparts;
		}
		$modelsin=explode(",",$model);
		$count_model=count($modelsin);
		for($mk=0;$mk<$count_model;$mk++)
		{
			$modelarr=$modelsin[$mk];
			$modelim=explode(";",$modelarr);
			$mnam=$modelim[1];
			$mqty=$modelim[2];
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			//array_push($modlar,$mnam);
		}
		$modlarimplode=implode(",",$modlar);
		//echo $modlarimplode;
		//$modlarimplode=explode(",",$modlarimplode);
		//echo $modlarimplode=count($modlarimplode);
		$data['modelnamedropdwn']=$modlarimplode;
		
	   //print_r($data['modelnamedropdwn']);echo 1;
		//$data['getpurchase']=$this->stockManage_model->getallpurchase();
		$this->load->view('stockmanage/stockentrybox',$data);
	}
	public function getallspare_parts_sort_by_modelname()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$modelname=$this->input->post('modelname');
		$getspareparts=$this->stockManage_model->getallspareparts($modelname);
		$i=1;
		if(!empty($getspareparts)){
		foreach($getspareparts as $rowparts)
		{
			echo '<li style="border-bottom:1px solid #c2c2c2;background-color:#4caf50;color:white;padding:5px;">';
				echo '<a id="parts_'.$rowparts->id.'_'.$i.'" href="javascript:putpartsqtybyparts('.$i.','.$rowparts->id.')" style="display:block;text-decoration:none; color:white;font-weight:bolder;>
				  <div class="tile-content">
						
						<div class="tile-text">'.$rowparts->materialname.'</div>
					</div>
				</a>
		  </li>';
		}
		}else
			{
				echo "";
			}
	}
	public function getdetails_stocklist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$prtsid=$this->input->post('prtsmid');
		$pono=$this->input->post('pono');
		$mtqy=$this->input->post("mtqy");
		//echo json_encode($resultarray);
		$mty=explode(",",$mtqy);
		//echo json_encode($mty);
		array_pop($mty);
		//$mty=implode(";",)
		//$mqtr=$mty[1];
		//$mtnme=$mty[0];
		$mtyimplode=implode(",",$mty);
		$mtyimplodeex=explode(";",$mtyimplode);
		//echo json_encode($mtyimplodeex);exit;
		$mqtr=$mtyimplodeex[1];
		$mtnme=$mtyimplodeex[0];
		$getpartsdetails=$this->stockManage_model->getpartsdetailsbyprtsid($prtsid);
		foreach($getpartsdetails as $rowprtsdetails)
		{
			$prtsname=$rowprtsdetails->materialname;
			$prtsid=$rowprtsdetails->materiel_id;
			$prtmid=$rowprtsdetails->id;
			$unit=$rowprtsdetails->unit;
			$mnbe=$rowprtsdetails->mName;
		}
		$totqtr=intval($mqtr)*intval($unit);
		//$totqtr="oo";
		//$getpqty=$this->stockManage_model->getpqtybypono($pono,$prtsid);
	 
		//foreach()
		$resultarray=array("partsname"=>"$prtsname","partsid"=>"$prtsid","partmid"=>"$prtmid","unit"=>"$unit","mty"=>"$mtyimplode","rstqty"=>"$totqtr","modelnameprts"=>"$mnbe");
		echo json_encode($resultarray);
		
	}
	public function stockentrycopy()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$user=$this->session->userdata('user_name');
		$totrow=$this->input->post('totrow');
		$pono=$this->input->post('pono');
		$godown=$this->input->post('godown');
		$boxname=$this->input->post('boxname');
		$boxqty=$this->input->post('nobox');
		echo $entrp=$this->input->post("entrytp");
		$totrowexplode=explode(",",$totrow);
		print_r($totrowexplode);
	   echo  $totrwcount=count($totrowexplode);
		$temp_stock=array();
		if($entrp=="box"){
		for($j=0;$j<$totrwcount;$j++)
		{
			echo $rowid=$totrowexplode[$j];
			$prtsid=$rowid;
			$prtsqty=$this->input->post("tablerow_$prtsid");
			echo $unit=$this->input->post("unit2_$prtsid");
			//if(!empty($prtsid) && !empty($prtsqty))
			//{
				
				$stokstring=$prtsid.";".$prtsqty.";".$unit;
				array_push($temp_stock,$stokstring);
			//
			///
			
			//echo $rowid;
		}
		array_pop($temp_stock);
		$temp_stockemplode=implode(",",$temp_stock);
		$data_array=array(
			"pono"=>$pono,
			"warehouse"=>$godown,
			"boxname"=>$boxname,
			"totalbox"=>$boxqty,
			"stock"=>$temp_stockemplode,
			"doe"=>date('Y-m-d h:i:s'),
			"credtd"=>$user
		
		);
		}
		if($entrp=="indi")
		{
			for($j=0;$j<$totrwcount;$j++)
		{
			echo $rowid=$totrowexplode[$j];
			$prtsid=$rowid;
			$prtsqty=$this->input->post("tablerow_$prtsid");
			echo $unit=$this->input->post("unit2_$prtsid");
			echo $pkg=$this->input->post("pkg2_$prtsid");
			//if(!empty($prtsid) && !empty($prtsqty))
			//{
				
				$stokstring=$prtsid.";".$prtsqty.";".$unit.";".$pkg;
				array_push($temp_stock,$stokstring);
			//
			///
			
			//echo $rowid;
		}
		array_pop($temp_stock);
		$temp_stockemplode=implode(",",$temp_stock);
		$data_array=array(
			"pono"=>$pono,
			"warehouse"=>$godown,
			"stockindi"=>$temp_stockemplode,
			"doe"=>date('Y-m-d h:i:s'),
			"credtd"=>$user
		
		);
		}
		$this->stockManage_model->savetempdatabystockorder($data_array);
		$data['title']="Stock Entry";
		//$pono=$this->input->post('pono');
		$data['pono']=$pono;
		$data['getpurchaselist']=$this->stockManage_model->getallpurchaselist($pono);
		//print_r($data['getpurchaselist']);
		$deatgetspa=$data['getpurchaselist'];
		$modlar=array();
		foreach($deatgetspa as $rowpurcsdet)
		{
			$model=$rowpurcsdet->modelcode;
			$parts=$rowpurcsdet->spareparts;
		}
		$modelsin=explode(",",$model);
		$count_model=count($modelsin);
		for($mk=0;$mk<$count_model;$mk++)
		{
			$modelarr=$modelsin[$mk];
			$modelim=explode(";",$modelarr);
			$mnam=$modelim[1];
			$mqty=$modelim[2];
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			//array_push($modlar,$mnam);
		}
		//$data['modelname']=$modlar;
		$modlarimplode=implode(",",$modlar);
		$data['modelnamedropdwn']=$modlarimplode;
		///print_r($data['modelnamedropdwn']);echo 2;
		//$data['getpurchase']=$this->stockManage_model->getallpurchase();
		$data['temp_data']=$this->stockManage_model->getalldatatemptable($pono);
		$this->load->view('stockmanage/stockentrybox',$data);
		
		//print_r($temp_stock);
	}
	public function stocktempsavedata()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		 $pono=$this->input->post("pono");//
		$data['getalltemdataprts']=$this->stockManage_model->getalldata($pono);
		$this->load->view('stockmanage/viewstockentrylist',$data);
		//print_r($gettemdata);
		//exit;
	
	}
	public function viewallstockentry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		// $pono=$this->input->post("pono");//
		$data['getalltemdataprtsall']=$this->stockManage_model->getalldatastock();
		$this->load->view('stockmanage/viewstockentrylist',$data);
		
	}
	public function print_pdfstock($pono)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		// $pono=$this->input->post("pono");//
		//$data['getalltemdataprtsall']=$this->stockManage_model->getalldatastock();o
		 $data['pono']=$pono;
		$this->load->view('stockmanage/getpdfviewstock',$data);
		
	}
	public function checkingstock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Checking stockEntry";
		$this->load->view('stockmanage/checkingstock',$data);
	}
	public function checkstocked()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Checking stockEntry";
		$pono=$this->input->post("pono");
		$data['pono']=$pono;
		$data['temp_data']=$this->stockManage_model->getalldata($pono);
		$data['getpurchaselist']=$this->stockManage_model->getallpurchaselist($pono);
		//print_r($data['getpurchaselist']);
		$deatgetspa=$data['getpurchaselist'];
		$modlar=array();
		foreach($deatgetspa as $rowpurcsdet)
		{
			$model=$rowpurcsdet->modelcode;
			$parts=$rowpurcsdet->spareparts;
		}
		$modelsin=explode(",",$model);
		$count_model=count($modelsin);
		for($mk=0;$mk<$count_model;$mk++)
		{
			$modelarr=$modelsin[$mk];
			$modelim=explode(";",$modelarr);
			$mnam=$modelim[1];
			$mqty=$modelim[2];
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			//array_push($modlar,$mnam);
		}
		 $modlarimplode=implode(",",$modlar);
		$data['modelname2']=$modlarimplode;
		//print_r($data['modelname2']);
		$this->load->view('stockmanage/checkingstock',$data);
	}
	public function purchaseorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Purchase";
		$this->load->view("stockmanage/purchaseorder",$data);
	}
}