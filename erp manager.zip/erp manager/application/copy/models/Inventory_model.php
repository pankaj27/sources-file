<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Inventory_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function checkdata($bname,$modelname,$modelname)
	{
		$query=$this->db->query("select * from item_master_vhc_div where brandName='".trim($bname)."' and  modelName='".trim($modelname)."' and  modelCode='".trim($modelname)."'");
		return $query->result();
	}
	public function savevehicle_itemmaster($data_array)
	{
		$res=$this->db->insert('item_master_vhc_div',$data_array);
		if($res==TRUE)
		{
			return 1;
		}else{
			return 0;
		}
	}
	public function checkdata_spareparts($brand_name,$partsno)
	{
		$query=$this->db->query("select * from spareparts where brand_name='".trim($brand_name)."' and  partsno='".trim($partsno)."'");
		return $query->result();
	}
	public function savespareparts_master($data_array)
	{
		$res=$this->db->insert('spareparts',$data_array);
		if($res==TRUE)
		{
			return 1;
		}else{
			return 0;
		}
	}
	
	
	
	
}
