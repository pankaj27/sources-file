<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notify_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getall_quatation_status()
	{
		$query=$this->db->query("select * from quotation where status='0'");
		return $query->result();
	}
	public function getvenname($venname)
	{
		$query=$this->db->query("select * from venderslist where vender_id='".trim($venname)."'");
		$resul=$query->result();
		foreach($resul as $row)
		{
			$benmae=$row->vcompany;
		   
		}
		return $benmae;
	}
	public function savenotify($data_array)
	{
		$this->db->insert('notification',$data_array);
	}
	public function getqtexist($venname,$qtid)
	{
		$query=$this->db->query("select * from notification where uniid='".trim($qtid)."' and title like'%".trim($venname)."%'");
		return $query->result();
	}
	public function getallnotice()
	{
		//$query=$this->db->query();
	}
}