<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class stockManage_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function poDetail()
	{
		$query=$this->db->query("select * from finalorder order by id desc");
		return $query->result();
	}
	public function gettallpodetails($pono)
	{
		
		$query=$this->db->query("select * from finalorder where poid='".trim($pono)."'");
		return $query->result();
	}
	public function getallfinalpono()
	{
		$query=$this->db->query("select * from finalorder order by id desc");
		return $query->result();
	}
	public function gettdetails()
	{
		$query=$this->db->query("select * from materiel_master");
		return $query->result();
	}
	public function addStock($data_array,$mnam)
	{
		$this->db->where('mName', $mnam);
		$this->db->update('materiel_master', $data_array);
	}
	public function getallpurchaselist($pono)
	{
		$query=$this->db->query("select * from purchaseorder where poid='".trim($pono)."'");
		return $query->result();
	}
	public function getallspareparts($modelname)
	{
		$query=$this->db->query("select * from materiel_master where mName='".trim($modelname)."'");
		return $query->result();
	}
	public function getpartsdetailsbyprtsid($prtsid)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($prtsid)."'");
		return $query->result();
	}
	public function savetempdatabystockorder($data_array)
	{
		$this->db->insert('temp_table',$data_array);
	}
	public function getalldatatemptable($pono)
	{
		$query=$this->db->query("select * from temp_table where pono='".trim($pono)."'");
		return $query->result();
	}
	public function getpqtybypono($pono,$prtsid)
	{
		$query=$this->db->query("select * from purchaseorder where poid='".trim($pono)."'");
		$result=$query->result();
		
	}
	public function getalldata($pono)
	{
		$query=$this->db->query("select * from temp_table where pono='".trim($pono)."'");
		return $query->result();
	}
	public function getalldatastock()
	{
		$query=$this->db->query("select * from temp_table");
		return $query->result();
	}
	

	
}