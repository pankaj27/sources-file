<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class colourManage_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function insertColour($data_array)
	{
		$this->db->insert('color_code',$data_array);
	}
	public function fetchcolour()
	{
		$query=$this->db->query("select * from color_code");
	   return $query->result();
	}
	public function deleteColour($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('color_code');
	}
	public function updateColour($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('color_code', $data_array);
	}
}