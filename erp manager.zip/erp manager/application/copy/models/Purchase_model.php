<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Purchase_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_material()
	{
		$query=$this->db->query("select materiel_id, qnty,reorderlevel,qnty-reorderlevel as diff,materiel_id,materialname,id from materiel_master order by diff asc ");
		return $query->result();
	}
	public function get_alldetails($id)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($id)."' ");
		return $query->result();
	}
	public function getall_vendors()
	{
		$query=$this->db->query("select * from venderslist");
		return $query->result();
	}
	public function getvenders_dtails($venid)
	{
		$query=$this->db->query("select * from venderslist,purchaseqatation where 	purchaseqatation.venderid=venderslist.vender_id and venderslist.vender_id='".trim($venid)."' order by purchasedate limit 1");
		return $query->result();
	}
	public function getpurchaseorder()
	{
		$query=$this->db->query("select max(id) as id from purchaseorder");
		return $query->result();
	}
	public function get_poductname($itemid)
	{
		$query=$this->db->query("select materialname  from materiel_master where materiel_id='".trim($itemid)."'");
		return $query->result();
	}
	public function getvenderemail($vid)
	{
		$query=$this->db->query("select * from venderslist where vender_id='".trim($vid)."'");
		return $query->result();
	}
	public function savepurcsaeorder($dataarray)
	{
		$this->db->insert('purchaseorder',$dataarray);
	}
	public function getallproduct()
	{
		$query=$this->db->query("select * from productmaster where status=0");
		return $query->result();
	}
	public function getalldt($pid)
	{
		$query=$this->db->query("select * from product_specification where productid='".trim($pid)."'");
		return $query->result();
	}
	public function getvenders_dtails_excepttransaction($venid)
	{
		$query=$this->db->query("select * from venderslist where venderslist.vender_id='".trim($venid)."'");
		return $query->result();
	}
	public function getall_colorcode()
	{
		$query=$this->db->query("select * from color_code");
		return $query->result();
	}
	public function get_modelname($modelcode)
	{
		$query=$this->db->query("select * from productmaster where productname='".trim($modelcode)."'");
		return $query->result();
	}
	public function getspectxt($sptxt)
	{
		$query=$this->db->query("select * from spareparts_specification where id='".trim($sptxt)."'");
		return $query->result();
	}
	public function get_colorrgbcode($colorcode)
	{
		$query=$this->db->query("select * from color_code where id='".trim($colorcode)."'");
		return $query->result();
	}
	public function getalldetails($vid,$poid)
	{
		$query=$this->db->query("select * from quotation where venid='".trim($vid)."' and poid='".trim($poid)."'");
		return $query->result();
	}
	public function savefinalorder($dataarray)
	{
		$row=$this->db->insert("finalorder",$dataarray);
		if($row==TRUE)
		{
			return  1;
		}else{
			return 0;
		}
	}
	public function getspecificationdetails($poid)
	{
		$query=$this->db->query("select * from purchaseorder where poid='".trim($poid)."'");
		return $query->result();
	}
	public function getvendet($vid)
	{
		$query=$this->db->query("select * from venderslist where vender_id='".trim($vid)."'");
		return $query->result();
	}
	public function getquotationlist()
	{
		$query=$this->db->query("select distinct(qtid) as qtid from quotation order by id desc");
		return $query->result();
	}
	public function getrefno($poid)
	{
		$query=$this->db->query("select * from purchaseorder where poid='".trim($poid)."'");
		$res=$query->result();
		foreach($res as $ro)
		{
			$refno=$ro->refno;
		}
		return $refno;
	}
	public function getallfinalpono()
	{
		$query=$this->db->query("select * from finalorder order by id desc");
		return $query->result();
	}
	public function gettallpodetails($pono)
	{
		$query=$this->db->query("select * from finalorder where poid='".trim($pono)."'");
		return $query->result();
	}
	public function savepayment($dataarray)
	{
		$res=$this->db->insert('pi_invoice',$dataarray);
		if($res==TRUE)
		{
			return 1;
		}else{
			return 0;
		}
	}
	public function getparts_sort_by_modelname($modelname)
	{
		$query=$this->db->query("select materiel_id,qnty,reorderlevel,qnty-reorderlevel as diff,materiel_id,materialname,id from materiel_master where mName='".trim($modelname)."' order by diff asc ");
		return $query->result();
	}
	public function deleteposdetaild($posid)
	{
		$query=$this->db->query("delete from finalorder where id='".trim($posid)."'");
		if($query==TRUE)
		{
			return 1;
		}else
		{
				return 0;
		}
	}
	public function getall_quatation_status()
	{
		$query=$this->db->query("select * from quotation where status='0'");
		return $query->result();
	}
	public function getspecifbypartsid($partsid)
	{
		$query=$this->db->query("select * from spareparts_specification where parts_id='".trim($partsid)."'");
		return $query->result();
	}
	public function getspecification($specid)
	{
		$query=$this->db->query("select * from spareparts_specification where id='".trim($specid)."' ");
		return $query->result();
	}
	public function getvendorrss($vid)
	{
		$query=$this->db->query("select * from venderslist where id='".trim($vid)."'");
		return $query->result();
	}
}