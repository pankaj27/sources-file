<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class newBrand_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getModelCode()
	{
		$query=$this->db->query("select max(id) as id from productmaster");
		return $query->result();
	}
	public function save_stock($data_array)
	{
		$this->db->insert('productmaster',$data_array);
	}
	public function fetchmodel()
	{
	   $query=$this->db->query("select * from productmaster order by id desc");
	   return $query->result();
	}
	public function fetchModelEntry($id1)
	{
		$query=$this->db->query("select * from productmaster where id=".trim($id1)."");
	   return $query->result();
	}
	public function updatNewEnrey($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('productmaster', $data_array);
	}
	public function deleteModelEntry($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('productmaster');
	}
	
	                    //////................................................../////
	
	public function getabc()
	{
		$query=$this->db->query("select max(id) as id from materiel_master");
		
	$s= $query->result();
	foreach($s as $row){
		$id=$row->id;
	}
	$query1=$this->db->query("select * from materiel_master where id='".trim($id)."'");
	return $query1->result();
	
	}
	public function getPartsCode()
	{
		$query=$this->db->query("select max(id) as id from materiel_master");
		return $query->result();
	
	}
	public function saveSpareParts($data_array)
	{
		$this->db->insert('materiel_master',$data_array);
	}
	public function savespecification($data_array2)
	{
		$this->db->insert('spareparts_specification',$data_array2);
	}
	public function fetchSpareParts()
	{
		$query=$this->db->query("select * from materiel_master");
	   return $query->result();
	}
	public function editSpareParts($id1)
	{
		$query=$this->db->query("select * from materiel_master where id=".trim($id1)."");
		
	   return $query->result();
	}
	public function fetchSpecific($id1)
	{
		$query=$this->db->query("select * from spareparts_specification where productid=".trim($id1)."");
	   return $query->result();
	}
	public function updatespecification ($data_array,$partsCode)
	{
		$this->db->where('parts_id',$partsCode);
		$this->db->update('spareparts_specification', $data_array);
	}
	
	public function updateSpareParts($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('materiel_master', $data_array);
	}
	public function deleteSpareParts($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('materiel_master');
	}
	public function deletespec($speid)
	{
		$query=$this->db->query("delete from spareparts_specification where id=".trim($speid)."");
		if($query==true)
		{
			return 1;
		}
		else{
			return 0;
		}
		//echo "delete from spareparts_specification where id='".trim($speid)."'";
		
		//return $res;
	}
	public function fetchallmodel()
	{
		$query=$this->db->query("select distinct(productname) as productname from productmaster");
		return $query->result();
	}
	public function checkmodelexist($mopdel)
	{
		$query=$this->db->query("select * from productmaster where productname ='".trim($mopdel)."'");
		return $query->result();
	}
}