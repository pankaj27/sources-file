<!DOCTYPE html>
<html>
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="ERP,PHP ERP,Open Source ERP ">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title> User Dashboard  - Erp- Manager!</title>
  <link rel="shortcut icon" type="image/x-icon" href="files/favicon.ico">
  <link href="<?php echo base_url(); ?>template_assets/themes/default/public.css" media="all" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>template_assets/themes/default/menu.css" media="all" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>template_assets/themes/default/jquery.css" media="all" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>template_assets/tparty/bootstrap/css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>template_assets/tparty/bootstrap/css/style.css" rel="stylesheet" >
 <!-- <link href="fontawasome.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">-->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
  <link href='https://fonts.googleapis.com/css?family=PT+Sans:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Lato:400,300,400italic,300italic,700,700italic,900' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Exo:400,300,600,500,400italic,700italic,800,900' rel='stylesheet' type='text/css'>
      <link href="<?php echo base_url(); ?>template_assets/extensions/ino_user/dashboard/dashboard.css" media="all" rel="stylesheet" type="text/css" />
</head>