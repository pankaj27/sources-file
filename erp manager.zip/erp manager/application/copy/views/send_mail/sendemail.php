<?php  include("smtpmail2/smtpmail/mail.php");$con=mysqli_connect("localhost","root","","erp_manager")?>
<?php $poid=$poid;//$vendmail=$vendmail; ?>
<?php //$vendmail1=explode(",",$vendmail) ; ?>
<?php foreach($vid as $row) {?>
	
	<?php $vd=$row; ?>
	<?php $query=mysqli_query($con,"select * from venderslist where vender_id='".trim($vd)."'"); $row=mysqli_fetch_array($query);$vendid=$row['vender_id']; $name=$row['vname'];$email=$row['vemail']; ?>
<?php  $subject="Quotation Requested For Folllowing Products,Spare Parts..."  ?>
<?php $msg= '
<html>
<head>
  <title>GK Rikshow</title>
</head>
<body>
  <p>Quatation  Requested For The Following Products ,Spare Parts</p>
  <a href="http://localhost/erp_manager/venders/form.php?venid='.$vendid."_".$poid.'" target="_blank">Click Here </a>

</body>
</html>
'; ?>
<?php echo $mail_user = send_mail1("$subject","$email","$msg","$name"); ?>

<?php } ?>