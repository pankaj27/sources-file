<?php 
//$con=mysqli_connect('localhost','root','','');
?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#addCF").click(function(){
    	//alert("hello");
		var no=$(".norow").length;
		no=no+1;
		//alert(no);
        $("#customFields").append('<div class="norow" id="res_'+no+'"><div class="col-md-1"><div class="form-group"><h4>'+no+'.</h4></div></div><div class="col-md-9"><div class="form-group"><input type="text" class="form-control" id="sp_'+no+'" name="sp_'+no+'"><input type="hidden" name="speid_'+no+'"  id="speid_'+no+'"><label for="cst"></label></div></div><div class="col-md-2"><div class="form-group"><a href="javascript:deletediv('+no+')" id="remCF_'+no+'" ><i class="fa fa-minus-square-o" style="font-size:36px;"></i></a></div></div></div>');
	   $("#abcd").val(no);
	   /* $("#remCF").on('click',function(){
			 
            $(this).parent().parent().remove();
        });*/
		
    });
	
});
</script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">Edit Spare Parts</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">Edit</a></li>
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
							    	<div class="col-md-12">
									
									<?php if(isset($parts) && !empty($parts)){
													foreach($parts as $row){
														$id=$row->id;
														
														}
													}  
													?>
									
				<form class="form" action="<?php echo base_url(); ?>newBrand_controller/updateSpareParts"  method="post" >
						<div class="card">
							<div class="card-head style-primary">
								<header>Information</header>
							</div>
							<div class="card-body floating-label">
									<div class="col-md-12">
										<div class="form-group">
										<input type="hidden"  value="<?php if(isset($id)){ echo $id ;} ?>" name="id"/>
										<select class="form-control select2-list" data-placeholder="Select an item" name="mName">
												<option value="<?php echo $row->mName; ?>"><?php echo $row->mName; ?></option>
												<option value="G5(Red)">G5(Red)</option>
												<option value="G5(Green)">G5(Green)</option>
												<option value="G5(Blue)">G5(Blue)</option>
												<option value="K9(Red)">K9(Red)</option>
											</select>
											<!--<input type="text" class="form-control" id="brand" name="brand">-->
											<label for="mName">Model Name</label>
										</div>
									</div>
					             <div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<input type="text" class="form-control" id="partsName" name="partsName" value="<?php echo $row->materialname; ?>">
											<label for="partsName">Parts Name</label>
										</div>
									</div>
									<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="partsCode" name="partsCode" value="<?php echo $row->materiel_id; ?>">
												<label for="partsCode">Parts Code</label>
											</div>
									</div>
									<div class="col-md-4">
											<div class="form-group">
												<input type="text" class="form-control" id="description" name="description" value="<?php echo $row->description; ?>">
												<label for="description">Description</label>
											</div>
									</div>
								</div>
								<br><br>
								<div class="card-head style-primary">
										<header>Price Information</header>
								</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="disPric_excld" name="disPric_excld" value="<?php echo $row->disPric_excld; ?>">
												<label for="disPric_excld">Distributer Price (Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="disPric_incld" name="disPric_incld" value="<?php echo $row->disPric_incld; ?>">
												<label for="disPric_incld">Distributer Price (Including Battery):</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="dis2subPric_excld" name="dis2subPric_excld" value="<?php echo $row->dis2subPric_excld; ?>">
												<label for="dis2subPric_excld">Distributer to sub-distributer Price (Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="dis2subPric_incld" name="dis2subPric_incld" value="<?php echo $row->dis2subPric_incld; ?>">
												<label for="dis2subPric_incld">Distributer to sub-distributer Price (Including Battery):</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="sub2dis_excld" name="sub2dis_excld" value="<?php echo $row->sub2dis_excld; ?>">
												<label for="sub2dis_excld">Sub-Distributer To Retailer Price(Excluding Battery):</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="sub2dis_incld" name="sub2dis_incld" value="<?php echo $row->sub2dis_incld; ?>">
												<label for="sub2dis_incld">Sub-Distributer To Retailer Price(Including Battery):</label>
											</div>
										</div>
									</div>
									<br><br>
									<div class="card-head style-primary">
										<header> tax Information</header>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="vat" name="vat" value="<?php echo $row->vat; ?>">
												<label for="vat">Vat % :</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="Sales" name="Sales" value="<?php echo $row->Sales; ?>">
													<label for="Sales">Sales % :</label>
												</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="Road" name="Road" value="<?php echo $row->Road; ?>">
												<label for="Road">Road Tax:</label>
											</div>
										</div>
										<div class="col-md-6">
												<div class="form-group">
													<input type="text" class="form-control" id="cst" name="cst" value="<?php echo $row->cst; ?>">
													<label for="cst">CST</label>
												</div>
										</div>
									</div>
									<br><br>
								<div class="card-head style-primary">
									<header> Specification</header>
								</div>
								<div class="row">
								<?php  if(isset($specific)){  $i=1; ?>
								<?php foreach($specific as $row1){ ?>
								<?php
								if($i==1)
								{
								?>	
								
								 <div id="customFields" >
									 <div class="norow">
										<div class="col-md-1">
											<div class="form-group">
												<h4><?php echo $i; ?></h4>
											</div>
										</div>
										<div class="col-md-9">
											<div class="form-group">
												<input type="text" class="form-control" id="sp_<?php echo $i; ?>" name="sp_<?php echo $i; ?>"  value="<?php echo $row1->specification; ?>">
												<input type="hidden" name="speid_<?php echo $i; ?>" value="<?php echo $row1->id; ?>" id="speid_<?php echo $i; ?>">
												<label for="cst"></label>
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<a href="javascript:void(0);" id="addCF"><i class="fa fa-plus-square-o" style="font-size:36px;"></i></a>		
											</div>
										</div>
									</div>
								</div>
								<?php $i++; }
								else { ?>  
									
								
								<div class="norow" id="res_<?php echo $i; ?>">
									<div class="col-md-1">
										<div class="form-group">
											<h4><?php echo $i; ?></h4>
											</div></div>
											<div class="col-md-9">
												<div class="form-group">
													<input type="text" class="form-control" id="sp_<?php echo $i; ?>" name="sp_<?php echo $i; ?>" value="<?php echo $row1->specification; ?>">
													<input type="hidden" name="speid_<?php echo $i; ?>" value="<?php echo $row1->id; ?>" id="speid_<?php echo $i; ?>">
													<label for="cst"></label>
													</div>
													</div>
													<div class="col-md-2">
														<div class="form-group">
															
																<button type="button" onclick="deletediv(this.id);" class="btn ink-reaction btn-floating-action btn-primary" id="remCF_<?php echo $i; ?>"><i class="fa fa-minus"></i>
																
																
																</button>
																</div></div></div>
								
								
								
								
								<?php $i++; }
								
								
								
								
								
								
								
								 } } ?>
								</div>

								<br><br>
								<input type="hidden" value="<?php echo $i; ?>" name="asdf" id="abcd">
								<div class="card-head style-primary">
									<header>Others Information</header>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<input type="text" class="form-control" id="reOrdering" name="reOrdering" value="<?php echo $row->reorderlevel; ?>">
											<label for="reOrdering">ReOrdering Level</label>
										</div>
									</div>
									<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" id="minStk" name="minStk" value="<?php echo $row->minStk; ?>">
												<label for="minStk">Maximum Stock</label>
											</div>
									</div>
								</div>
								
							<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction"><i class="ace-icon fa fa-check"></i> Update</button>&nbsp;&nbsp;&nbsp;
											<a href="<?php echo base_url();?>newBrand_controller/sparePartsEntry"><button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="ace-icon fa fa-times"></i> Cancel</button></a>
								</div>
							</div>
								
						</div><!--end .card-body -->
							
						</div><!--end .card -->
						</div>
						<!--<div class="col-md-6">
							    		<div class="card">
							<div class="card-head style-primary">
								<header>Contact Information</header>
							</div>
							<div class="card-body floating-label">
					              <div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactname1">
											<label for="Firstname2">Contact Name1</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="email" class="form-control" id="Lastname2" name="contactemail1">
											<label for="Lastname2">Contact Email1</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactphno1">
											<label for="Firstname2">Contact Phno1</label>
										</div>
									</div>
									
								</div>
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactname2">
											<label for="Firstname2">Contact Name2</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="email" class="form-control" id="Lastname2" name="contactemail2" >
											<label for="Lastname2">Contact Email2</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="contactphno2"> 
											<label for="Firstname2">Contact Phno2</label>
										</div>
									</div>
									
								</div>
								
								
							</div><!--end .card-body -->
							
						<!--</div>
							    	<!--</div>-->
							    	<div class="col-md-12">
							    		<div class="card">
							<!--<div class="card-head style-primary">
								<header>Bank  & Company Information</header>
							</div>
							<div class="card-body floating-label">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bank1">
											<label for="Firstname2">Bank Name</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankac1">
											<label for="Lastname2">Bank A/c NO.</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankifsc1">
											<label for="Firstname2">IFSC Code</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankswift1">
											<label for="Lastname2">Swift Code</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankbr1">
											<label for="Firstname2">Branch Name</label>
										</div>
									</div>
									
								</div>
								 
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bank2">
											<label for="Firstname2">Bank Name</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankac2">
											<label for="Lastname2">Bank A/c NO.</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankifsc2">
											<label for="Firstname2">IFSC Code</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="bankswift2">
											<label for="Lastname2">Swift Code</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="bankbr1">
											<label for="Firstname2">Branch Name</label>
										</div>
									</div>
									
								</div>
								<hr class="ruler-xxl">
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											
											<label for="Firstname2"><b>Company Information:</b></label>
										</div>
									</div>
									
								</div>
								
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Firstname2" name="cstno">
											<label for="Firstname2">CST No:</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<input type="text" class="form-control" id="Lastname2" name="vatno">
											<label for="Lastname2">VAT No</label>
										</div>
									</div>
								</div>
								 
								
					              
							</div><!--end .card-body -->
							
						</div>
							    	</div>
							    	<div class="col-md-12">
							    		<div class="card">
							<!--<div class="card-head style-primary">
								<header>Suppiler Product Information</header>
							</div>
							<div class="card-body floating-label">
								 <div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											<div class="col-md-12">
											<?php $k=1;   for($i=1;$i<10;$i++){ ?>
											  <?php if($k<10){ ?>
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" name="material[]" value="materiel_<?php echo $i;  ?>"><span></span>Material<?php echo $i; ?>
												</label>
											</div>
											
											
											<?php $k++; } } ?>
											</div>
										     </div>
										
										
									</div>
								</div>
								<hr class="ruler-xxl">
								<div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											<div class="col-md-12">
											<?php $k=1;   for($i=1;$i<10;$i++){ ?>
											  <?php if($k<10){ ?>
											<div class="checkbox checkbox-inline checkbox-styled">
												<label>
													<input type="checkbox" name="product[];" value="product_<?php echo $i; ?>"><span></span>Product<?php echo $i; ?>
												</label>
											</div>
											
											
											<?php $k++; } } ?>
											</div>
										     </div>
										
										
									</div>
								</div>
					              
							</div><!--end .card-body -->
							<!--<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
								</div>
							</div>-->
							</div>
							</div>
							</div>
				</div>
				</form>	
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->

						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function deletediv(id)
		{
			alert('hello');
			var idsplit=id.split("_");
			alert(idsplit);
			var speid=$("#speid_"+idsplit[1]).val();alert(speid);
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>newBrand_controller/delspac",
  			data :{'speid':speid},
  			success : function(data){  				
  				  alert(data);		
              }  
           });
			$("#res_"+idsplit[1]).remove();		
			
			
		}
</script>

