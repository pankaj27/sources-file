<?php
include("connection.php");
//include("fpdf/fpdf.php");
require('fpdf/fpdf.php');
$pono=$pono;
$querypono=mysqli_query($con,"select * from purchaseorder where id='".trim($pono)."'");
$getrow=mysqli_fetch_array($querypono);
 $poid=$getrow['poid'];
$queryven=mysqli_query($con,"select venderslist.vender_id as vid,venderslist.vcompany as vcom,venderslist.add1 as vadd,venderslist.vphno as vphn from venderslist,finalorder where finalorder.venid=venderslist.vender_id and  finalorder.poid='".trim($poid)."'");
$rowven=mysqli_fetch_array($queryven);
$vid=$rowven['vid'];
$vcom=$rowven['vcom'];
$add1=$rowven['vadd'];
$vphn=$rowven['vphn'];

//print_r($rowven);
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(190,10,"$vcom",0,0,'C');
$pdf->SetFont('Arial','',10);
$pdf->ln(5);
$pdf->cell(190,10,"$add1",0,0,'C');
$pdf->ln(5);
$pdf->cell(190,10,"Contact No-$vphn",0,0,'C');
$pdf->ln(8);
$pdf->SetFont('Arial','',12);
$pdf->cell(190,5,"PACKING LIST",0,0,'C');
$pdf->ln(10);
$pdf->SetFont('Arial','',10);
$pdf->setFillColor(0,102,0);
$pdf->setTextColor(255,255,255);
$pdf->cell(15,7,"Slno",1,0,'C',TRUE);
$pdf->cell(35,7,"Box No",1,0,'C',TRUE);
$pdf->cell(60,7,"Name",1,0,'C',TRUE);
$pdf->cell(20,7,"Qty",1,0,'C',TRUE);
$pdf->cell(15,7,"Unit",1,0,'C',TRUE);
$pdf->cell(25,7,"Packg",1,0,'C',TRUE);
$pdf->cell(15,7,"",1,1,'C',TRUE);
$pdf->setTextColor(0,0,0);
$querytem=mysqli_query($con,"select * from temp_table where pono='".trim($poid)."'");
$i=1;
while($rowtemp=mysqli_fetch_array($querytem))
{
	$pono=$rowtemp['pono'];
	$warehouse=$rowtemp['warehouse'];
																			//$boxno=$row->
	$boxname=$rowtemp['boxname'];
	$totalbox=$rowtemp['totalbox'];
	$stock=$rowtemp['stock'];
	
	$stockindi=$rowtemp['stockindi'];
	$stockindimplode=explode(",",$stockindi);
	$stockindicount=count($stockindimplode);
	$bxty=$rowtemp['totalbox'];
	$stockimplode=explode(",",$stock);
	$stockimplodecount=count($stockimplode);
																			
	if(isset($boxname) && !empty($boxname))
	{
		$pdf->setFillColor(0,25,51);
		$pdf->setTextColor(255,255,255);
		
		$pdf->cell(15,7,"$i",1,0,'C',TRUE);
		$pdf->cell(35,7,"$boxname",1,0,'C',TRUE);
		$pdf->cell(60,7,"",1,0,'C',TRUE);
		$pdf->cell(20,7,"",1,0,'C',TRUE);
		$pdf->cell(15,7,"",1,0,'C',TRUE);
		$pdf->cell(25,7,"$totalbox",1,0,'C',TRUE);
		$pdf->cell(15,7,"",1,1,'C',TRUE);
		$pdf->setTextColor(0,0,0);
		$bx1=1;
		$i++;
		for($g=0;$g<$stockimplodecount;$g++){
			 
																			
			$stock=$stockimplode[$g];
			 $stocvex=explode(";",$stock);
			$prtsid=$stocvex[0];
			//$prtsqty=intval($stocvex[1])*intval($totalbox);
			$prtsqty=intval($stocvex[1]);
			$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
			$getrow=mysqli_fetch_array($querygetprtsname);
			$prtsnme=$getrow['materialname'];
			$mname=$getrow['mName'];
			$unit=$stocvex[2];
			$getunit=mysqli_query($con,"select * from unit_tbl where id='".trim($unit)."'");
			$rowgetnme=mysqli_fetch_array($getunit);
			$unitnme=$rowgetnme['unitname'];
			//$pkg=$stocvex[3];
			$pdf->Cell(15,7,' ','LTR',0,'L',0);
			//$pdf->cell(15,7,"",0,0,'C');
			$pdf->cell(35,7,"",0,0,'C');
			$pdf->cell(60,7,"$prtsnme($mname)",1,0,'C');
			$pdf->cell(20,7,"$prtsqty",1,0,'C');
			$pdf->cell(15,7,"$unitnme",1,0,'C');
			//$pdf->cell(25,7,"",1,0,'C');
			$pdf->Cell(25,7,' ','LR',0,'L',0);
			$pdf->cell(15,7,"",1,1,'C');
			$bx1++;
		
		}																 
																			
		
	}else{
				
				for($g=0;$g<$stockindicount;$g++){; 
																			
				$stock=$stockindimplode[$g];
				$stocvex=explode(";",$stock);
				$prtsid=$stocvex[0];
				//$prtsqty=intval($stocvex[1])*intval($totalbox);
				$prtsqty=intval($stocvex[1]);
				$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
				$getrow=mysqli_fetch_array($querygetprtsname);
				$prtsnme=$getrow['materialname'];
			    $mname=$getrow['mName'];
				$unit=$stocvex[2];
				$getunit=mysqli_query($con,"select * from unit_tbl where id='".trim($unit)."'");
				$rowgetnme=mysqli_fetch_array($getunit);
				$unitnme=$rowgetnme['unitname'];
				$pkg=$stocvex[3];															
			
		
				$pdf->cell(15,7,"$i",1,0,'C');
				$pdf->cell(35,7,"",1,0,'C');
				$pdf->cell(60,7,"$prtsnme($mname)",1,0,'C');
				$pdf->cell(20,7,"$prtsqty",1,0,'C');
				$pdf->cell(15,7,"$unitnme",1,0,'C');
				$pdf->cell(25,7,"$pkg",1,0,'C');
				$pdf->cell(15,7,"",1,1,'C');
			$i++;		
		}
	}		
	

		
	
}
$pdf->cell(130,7,"Total",1,0,'C');
$pdf->cell(15,7,"",1,0,'C');
$pdf->cell(25,7,"",1,0,'C');
$pdf->cell(15,7,"",1,1,'C');
				


$pdf->Output();



?>