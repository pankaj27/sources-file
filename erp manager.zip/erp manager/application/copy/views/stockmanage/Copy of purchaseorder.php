
<?php include('conection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	

<style>
	#verticalLine {
    border-left: 1px solid black;
   }
    .print-clean{
    	border: none;
       background: transparent;
    }
    #partstble,#partstble2{
    	width:100%;
    }
    #optr{
    	width:100%;
    }
    #partstble tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #partstble2 tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #optr tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    .datatr{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    .datatr1{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    #partstble3{
    	width:100%;
    }
     #partstble3 tr {
     	line-height:15px;
    	border-top: 1px solid #0aa89e;
     }
    .table12{
    	width:100%;
    	
    }
    .table12 tr{
    	height:6px;
    	border-bottom: 1px solid black;
    }
    .table12 td{
    	padding:0px;
    	margin:0px;
    	
    }
    .thred,.trhide{
    	display: none;
    }

</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
	<!-- BEGIN BLANK SECTION -->
	<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li><a href="<?php echo base_url(); ?>">home</a></li>
												<li class="active"><?php if(isset($title)){ echo $title ; } ?></li>
						</ol>

		</div><!--end .section-header -->
		<div class="section-body">
			<div class="row">
				<div class="col-md-12">
					
					<div class="card card-bordered style-primary">
						<div class="card-head">
							
							<header><i class="fa fa-fw fa-tag"></i>Purchase Order from Stock</header>
						</div><!--end .card-head -->
						<div class="card-body style-default-bright">
							<div class="row">
								<form action="<?php echo base_url();  ?>stockManage_controller/getpurchaselist" method="post">
								<div class="col-md-3">
									<div class="form-group">
								     	<input type="text" class="form-control" id="Username2" name="pono" value="<?php if(isset($pono)){ echo $pono; } ?>" required="required" placeholder="Enter Product name">
										<!--<label for="Username2">Enter PO NO</label>-->
								    </div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
								     	<input type="text" class="form-control" id="Username2" name="pono" value="" required="required" placeholder="Enter Qty">
										<!--<label for="Username2">Enter PO NO</label>-->
								    </div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
								     <button type="submit" class="btn btn-flat btn-primary ink-reaction">Go</button>
									<!--<label for="Username2">Enter PO NO</label>-->
								</div>
								</div>
								
							<!--end .col -->
							</form>
						</div>
							<div class="row">
								<div class="col-md-6">
								</div>
								<div class="col-md-6">
								</div><!--end .card -->
					        </div> 
							<!--end .col -->
						</div>
					
							
							
							
							
													
									
						</div><!--end .card-body -->
					</div><!--end .card -->
					
				</div><!--end .col -->
			</div>
		</div><!--end .section-body -->
	</section>
	<!-- BEGIN BLANK SECTION -->

		</div><!--end #content-->		
		<!-- END CONTENT -->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
$(document).ready(function(){
	
	//alert('hello');
	$(".trhide,.thred").hide();
	$("#boxhd").hide();
	$("#nohead_box").hide();
});
	function getallspareparts()
	{ 
		var getallpartsqtybtmodel="";
		var mqty="";
		var mqty1=$("#mqty1").val();
		//alert(mqty1);
		if(mqty1=="")
		{
			var mqty2=$("#mqty1").val();
		}else
		{
			var mqty2=mqty;
		}
		var modelname1=$("#modelnameget").val();
		var idsplit=modelname1.split(";");
		var modelname=idsplit[0];
		
			mqty1 =modelname1+',';
		
		
		//alert(mqty1);
		$("#mqty1").val(mqty1);
		if(modelname=="")
		{
			alert('please select model name');
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getallspare_parts_sort_by_modelname",
  			data :{'modelname':modelname},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#getallspareparts").html(data);
  			  
              }  
           });
		}else
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getallspare_parts_sort_by_modelname",
  			data :{'modelname':modelname},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#getallspareparts").html(data);
  				 $('.inputr').append("<input type='hidden' id='tablerow_"+prtsmid+"' name='tablerow_"+prtsmid+"' value=''/>");
  			     $('.inputr').append("<input type='hidden' id='unit2_"+prtsmid+"' name='unit2_"+prtsmid+"' value=''/>");
              }  
           });
		}
		
	}
	function putpartsqtybyparts(id,partsid)
	{
		//alert('hello');
		//var idsplit=id.split("_");
		var a=id;
		var prtsmid=partsid;
		var boximndi=$("#boximndi").val();
		var pono=$("#pono").val();
		var totrow=$("#totrow").val();
		
		if(totrow=="")
		{
			var textw="";
		}else
		{
			var textw=totrow;
		}
		var mtqy=$("#mqty1").val();
		
		var rowCount = $('#partstble tr').length;
		var tr=rowCount-1;
		var tr2=tr+1;
		//alert(rowCount);
		if(boximndi=="indi"){
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getdetails_stocklist",
  			data :{'prtsmid':prtsmid,'pono':pono,'mtqy':mtqy},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				
  				var prtsname=json.partsname;
  				var partsid=json.partsid;
  				var unit=json.unit;
  				var prtsmid=json.partmid;
  				var mtyq=json.mty;
  				var modelnameprts=json.modelnameprts;
  				var idsplit=mtyq.split(";");
  				var mnme=idsplit[0];
  				var qty2=idsplit[1];
  				textw +=prtsmid +"," ;
  				var rstqty=json.rstqty;
  				//alert(matid);
  				//var matname=json.matname;
  				//$("#matid").val(matid);
  				$("#totrow").val(textw);
  				$('#partstble tr:last').after('<tr class="qtro" id="getid_'+tr2+'"><td>'+tr2+'</td><td>'+prtsname+'('+modelnameprts+')</td><td>'+rstqty+'</td><td><input type="text" size="5" onkeyup="getalltotqty(this.id)" name="prtsinputqty_'+prtsmid+'" id="prtsinputqty_'+prtsmid+'" /></td><td><select required id="unit_'+prtsmid+'" onchange="getunit(this.id)"><option value="" >select</option><option value="1">Set</option><option value="2">Pcs</option><option value="3">Pair</option></select></td><td><input type="text" name="pkg_'+prtsmid+'" id="pkg_'+prtsmid+'"  size="5" onkeyup="gettotalpkg(this.id)" /></td><td><button type="button" id="close_'+tr2+'" onclick="delete_row(this.id,'+tr2+')" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='tablerow_"+prtsmid+"' name='tablerow_"+prtsmid+"' value=''/>");
  			    $('.inputr').append("<input type='hidden' id='unit2_"+prtsmid+"' name='unit2_"+prtsmid+"' value=''/>");
  			    $('.inputr').append("<input type='hidden' id='pkg2_"+prtsmid+"' name='pkg2_"+prtsmid+"' value=''/>");
  			    //$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			   //  $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' />");
              }  
           });
           
          }
          if(boximndi=="box"){
          	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getdetails_stocklist",
  			data :{'prtsmid':prtsmid,'pono':pono,'mtqy':mtqy},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				
  				var prtsname=json.partsname;
  				var partsid=json.partsid;
  				var unit=json.unit;
  				var prtsmid=json.partmid;
  				var mtyq=json.mty;
  				var modelnameprts=json.modelnameprts;
  				var idsplit=mtyq.split(";");
  				var mnme=idsplit[0];
  				var qty2=idsplit[1];
  				textw +=prtsmid +"," ;
  				var rstqty=json.rstqty;
  				//alert(matid);
  				//var matname=json.matname;
  				//$("#matid").val(matid);
  				$("#totrow").val(textw);
  				$('#partstble tr:last').after('<tr class="qtro" id="getid_'+tr2+'"><td>'+tr2+'</td><td>'+prtsname+'('+modelnameprts+')</td><td>'+rstqty+'</td><td><input type="text" size="5" onkeyup="getalltotqty(this.id)" name="prtsinputqty_'+prtsmid+'" id="prtsinputqty_'+prtsmid+'" /></td><td><select required id="unit_'+prtsmid+'" onchange="getunit(this.id)"><option value="">select</option><option value="1">Set</option><option value="2">Pcs</option><option value="3">Pair</option></select></td><td><input type="text" class="print-clean" size="15" readeonly name="prtstotalqty_'+prtsmid+'" id="prtstotalqty_'+prtsmid+'"/></td><td><button type="button" id="close_'+tr2+'" onclick="delete_row(this.id,'+tr2+')" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='tablerow_"+prtsmid+"' name='tablerow_"+prtsmid+"' value=''/>");
  			    $('.inputr').append("<input type='hidden' id='unit2_"+prtsmid+"' name='unit2_"+prtsmid+"' value=''/>");
  			    
  			    
  			    //$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			   //  $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' />");
              }  
           });
           
          }
          if(boximndi=="")
          {
          	alert('please select entry type boxwise/individual');
          	$("#boximndi").focus();
          	
          }
		/**/
		
	}
	function getalltotqty(id)
	{
		var idsplit=id.split("_");
		var qtyval=$("#prtsinputqty_"+idsplit[1]).val();
		var unit=$("#unit_"+idsplit[1]).val();
		//alert(unit);
		//alert(qtyval);
		$("#prtstotalqty_"+idsplit[1]).val(qtyval);
		$("#tablerow_"+idsplit[1]).val(qtyval);
		$("#unit2_"+idsplit[1]).val(unit);
		//alert($("#unit2_"+idsplit[1]).val());
	}
	function gettotal()
	{
		var rowCount = $('#partstble tr').length;
		var tr=rowCount-1;
		var tr2=tr+1;
		var txtrw=$("#totrow").val();
		var idsiplit=txtrw.split(",");
		var nohead_box=parseInt($("#nohead_box").val());
		var a=idsiplit.length;
		a=a-1;
		if(nohead_box=="")
		{
			
			nohead_box=1;
		}
			for(var d=0;d<a;d++)
			{
				var in1=parseInt($("#prtsinputqty_"+idsiplit[d]).val());
				//alert(in1);
				//alert(nohead_box);
				var box1=nohead_box*in1;
				//alert(nohead_box);
				$("#prtstotalqty_"+idsiplit[d]).val(box1);
			}
		
		//alert(a);
		
	}
	function delete_row(id,tr)
	{
		var idsplit=id.split("_");
		var idval=idsplit[1];
		//alert(tr);
		var result=confirm("Want to delete?");
		
		
		if(result==true)
		{
			//alert(this);
			//$(this).closest('tr').remove();
			$("#qty_"+idsplit[1]).css("background-color","#7dd8d2");
	
			$("#qty_"+idsplit[1]).fadeOut(400, function(){
				$("#qty_"+idsplit[1]).remove();
				//$("#tablerow_"+tr).remove();
			});
		}
		
	}
	function delete_rowqty(id)
	{
		var idsplit=id.split("_");
		var result=confirm("Want to delete?");
		
		
		if(result==true)
		{
			//alert(this);
			//$(this).closest('tr').remove();
			$("#getid_"+idsplit[1]).css("background-color","#7dd8d2");
	
			$("#getid_"+idsplit[1]).fadeOut(400, function(){
				$("#getid_"+idsplit[1]).remove();
				$("#tablerow_"+tr).remove();
			});
		}
		
	}
	function opentable(id)
	{
		var idsplit=id.split("_");
		//alert('hello');
		
		$("#opntr_"+idsplit[1]).toggle();
	}
	function opentablethrid(id)
	{
		var idsplit=id.split("_");
		$("#tqtry_"+idsplit[1]).toggle();
	}
	function getboxnametr()
	{
		var boximndi=$("#boximndi").val();
		if(boximndi==""|| boximndi=="indi")
		{
			$("#boxhd").hide();
			$("#nohead_box").hide();
		}else
		{
			$("#boxhd").show();
			$("#nohead_box").show();
		}
	}
	function gettotalpkg(id)
	{
		var idsplit=id.split("_");
		var pkg=$("#pkg_"+idsplit[1]).val();
		alert(pkg);
		$("#pkg2_"+idsplit[1]).val(pkg);
	}
	function getunit(id)
	{
		var idsplit=id.split("_");
		var unit=$("#unit_"+idsplit[1]).val();
		//alert(unit);
		$("#unit2_"+idsplit[1]).val(unit);
	}
</script>