
<?php include('conection.php'); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	

<style>
	#verticalLine {
    border-left: 1px solid black;
   }
    .print-clean{
    	border: none;
       background: transparent;
    }
    #partstble,#partstble2{
    	width:100%;
    }
    #optr{
    	width:100%;
    }
    #partstble tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #partstble2 tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    #optr tr td{
    	line-height:10px;
    	border-top: 1px solid #0aa89e;
    }
    .datatr{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    .datatr1{
    	width:80%;
    	border:1px solid #0aa89e;
    	  
    }
    #partstble3{
    	width:100%;
    }
     #partstble3 tr {
     	line-height:15px;
    	border-top: 1px solid #0aa89e;
     }
    .table12{
    	width:100%;
    	
    }
    .table12 tr{
    	height:6px;
    	border-bottom: 1px solid black;
    }
    .table12 td{
    	padding:0px;
    	margin:0px;
    	
    }
    .thred,.trhide{
    	display: none;
    }

</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			
	<!-- BEGIN BLANK SECTION -->
	<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li><a href="<?php echo base_url(); ?>">home</a></li>
												<li class="active"><?php if(isset($title)){ echo $title ; } ?></li>
						</ol>

		</div><!--end .section-header -->
		<div class="section-body">
			<div class="row">
				<div class="col-md-12">
					
					<div class="card card-bordered style-primary">
						<div class="card-head">
							
							<header><i class="fa fa-fw fa-tag"></i>BOX/Head wise Stock Entry</header>
						</div><!--end .card-head -->
						<div class="card-body style-default-bright">
							<div class="row">
								<form action="<?php echo base_url();  ?>stockManage_controller/getpurchaselist" method="post">
								<div class="col-md-3">
									<div class="form-group">
								     <input type="text" class="form-control" id="Username2" name="pono" value="<?php if(isset($pono)){ echo $pono; } ?>" required="required" placeholder="Enter PO NO">
									<!--<label for="Username2">Enter PO NO</label>-->
								</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
								     <button type="submit" class="btn btn-flat btn-primary ink-reaction">SUBMIT</button>
									<!--<label for="Username2">Enter PO NO</label>-->
								</div>
								</div>
								
							<!--end .col -->
							</form>
						</div>
							<?php if(isset($getpurchaselist) && !empty($getpurchaselist)){ ?>
								<?php  foreach($getpurchaselist as $rowpurchase){ ?>
								     <?php $models=$rowpurchase->modelcode; ?>
								     <?php $spareprts=$rowpurchase->spareparts; ?>
									
									
								<?php } ?>
							<div class="row">
								<div class="col-md-6">
					
									<div class="card card-bordered style-gray-light">
										<div class="card-head">
							
												<header>Purchaseorder List by PO NO</header>
										</div><!--end .card-head -->
										<div class="card-body style-default-bright">
												<div class="row">
													<div class="col-md-12" >
																<div class="card-body no-padding height-12 scroll" id="getallpartsqtybtmodel" style="overflow-y: scroll;">
																			<table class="table12">
																				
																					<tr>
																					   <th>Sl No.</th>
																					   <th>Details</th>
																					   <th>Model Name</th>
																						<th>Model ID</th>
																						<th>Parts Name</th>
																					    <th>Parts ID</th>
																					    <th>Qty</th>
																					    </tr>
																					    <?php if(isset($models) && !empty($models)){$rt=1;
																								
																								$modelexplode=explode(",",$models);
																								$codelcount=count($modelexplode);
																								for($dw=0;$dw<$codelcount;$dw++)
																								{
																									$modelindividual=$modelexplode[$dw];
																									$modelindiexplo=explode(";",$modelindividual);
																									$modelid=$modelindiexplo[0];
																									$modelnam=$modelindiexplo[1];
																									$modelqty=$modelindiexplo[2];
																									$modelspe=$modelindiexplo[3];
																								?>	
																									 <tr>
																									 <td><?php  echo $rt; ?></td>
																									 <td><button type="button" id="open_<?php echo $rt; ?>" onclick="opentablethrid(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-angle-double-down" aria-hidden="true"></i></button></td>
																									 <td><?php echo $modelnam; ?></td>
																									 <td><?php echo $modelid;  ?></td>
																									 <td></td>
																									 <td></td>
																									 <td><?php echo $modelqty; ?></td>
																									 
																					 				</tr>
																					 				<tr class="thred" id="tqtry_<?php echo $rt;  ?>">
																					 					<td colspan="7">
																					 						<center>
																					 						<table class="datatr1">
																					 							<tr style="background-color:#0aa89e;color:white;font-weight:normal;line-height: 12px;font-size: 10px;padding: 1px;text-align:center;">
																					 								<td>Sl No.</td>
																					 								<td>Parts Id</td>
																					 								<td>Parts Name</td>
																					 								<td>Specification</td>
																					 								<td>Unit</td>
																					 								<td>Qty</td>
																					 							</tr>
																					 							<?php 
																					 							$modelspeexpl=explode("||",$modelspe);
																												array_pop($modelspeexpl);
																												 $modelspecount=count($modelspeexpl);
																												for($gt=0;$gt<$modelspecount;$gt++)
																												{
																													$prtsdtls=$modelspeexpl[$gt];
																													$prtsexplode=explode("_",$prtsdtls);
																													$prtsid=$prtsexplode[0];
																													$queryprts=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($prtsid)."'");
																													$rowprts=mysqli_fetch_array($queryprts);
																													$prtsname=$rowprts['materialname'];
																													$prtsunit=$rowprts['unit'];
																													$prtsqtyr=$rowprts['qnty'];
																													$prtspec=$prtsexplode[1];
																													$queryspec=mysqli_query($con,"select * from spareparts_specification where id='".trim($prtspec)."'");
																													$rowspec=mysqli_fetch_array($queryspec);
																													$specname=$rowspec['specification'];
																													$totprtsqty=intval($prtsunit)*intval($modelqty); ?>
																												
																					 							<tr style="font-weight:normal;height:12px;font-size:10px;padding: 1px;text-align:center;">
																					 								<td><?php echo $gt+1; ?></td>
																					 								<td><?php echo $prtsid; ?></td>
																					 								<td><?php echo $prtsname."($prtsqtyr)"; ?></td>
																					 								<td><?php echo $specname; ?></td>
																					 								<td><?php echo $prtsunit; ?></td>
																					 								<td><?php echo $totprtsqty; ?></td>
																					 							</tr>
																					 							<?php }  ?>
																					 							</center>
																					 						</table>
																					 						
																					 					</td>
																					 				</tr>
																							<?php 		
																							$rt++;	}
																					    	
																							
																							
																					    } ?>
																					 </tr>
																					 <?php if(isset($spareprts) && !empty($spareprts)){
																					 				
																					 			$spareprtsexplode=explode(",",$spareprts);
																					 		   $spareprtscount=count($spareprtsexplode);
																							   for($gr=0;$gr<$spareprtscount;$gr++)
																							   {
																							   		$prtsex=$spareprtsexplode[$gr];
																									$prtsexexplode=explode(";",$prtsex);
																									$prtsid2=$prtsexexplode[0];
																									$modelname=$prtsexexplode[1];
																									$prtwqtw=$prtsexexplode[2];
																									$queryprts2=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($prtsid2)."'");
																									$rowprts2=mysqli_fetch_array($queryprts2);
																									$prtsname2=$rowprts2['materialname'];
																									$prtsunit2=$rowprts2['unit'];
																									 $modelnamprts=$rowprts2['mName'];
																									$prtsqtyr2=$rowprts2['qnty'];
																									$qwty=intval($prtsunit2)*intval($prtwqtw);
																													
																							 
																					 	 ?>
																					 <tr>
																					 	<td><?php  echo $rt; ?></td>
																						<td><button type="button" id="open_<?php echo $rt; ?>" onclick="opentablethrid(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-angle-double-down" aria-hidden="true"></i></button></td>
																						<td><?php echo $modelnamprts; ?></td>
																						<td></td>
																						<td><?php echo $prtsname2."($prtsunit2 x $prtwqtw)" ?></td>
																						<td><?php echo $prtsid2;  ?></td>
																						
																						<td><?php echo $qwty; ?></td>
																					 </tr>
																				  <?php $rt++; } } ?>
																			</table>
																	</div><!--end .card-body -->
																
														</div><!--end .col -->
																				
																			
																			
												</div>	
			
										</div><!--end .card-body -->
									</div><!--end .card -->
					
								</div>
								<div class="col-md-6">
					
									<div class="card card-bordered style-gray-light">
										<div class="card-head">
							
												<header>Stock Entry Section</header>
										</div><!--end .card-head -->
										<div class="card-body style-default-bright">
													<div class="row">
														<div class="col-md-9">
															<button type="button" class="btn btn-flat btn-primary ink-reaction" data-toggle="modal" data-target=".bd-example-modal-lg" >New Stock</button>
															<button style="float:right;" type="button" class="btn btn-flat btn-primary ink-reaction" data-toggle="modal" data-target=".bd-example-modal-lg_damage" >Damage Entry</button>
														</div>
														   <!------------------- open head popup --->
															<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
															  <div class="modal-dialog modal-lg">
															    <div class="modal-content">
															    	
															      <div class="modal-header">
															        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
															          <span aria-hidden="true">&times;</span>
															        </button>
															        <h4 class="modal-title" id="myModalLabel"><?php if(isset($pono)){ echo "Purchase Order No-<i>".$pono."</i>" ; }?></h4>
															      </div>
															      <div class="modal-body">
															       <div class="row">
																			<form action="<?php echo base_url(); ?>stockManage_controller/stockentrycopy" method="post">
																			<div class="col-md-12">
																				<div class="col-md-3">
																							<select class="form-control" id="boximndi" onchange="getboxnametr()" name="entrytp">
																									<option value="">--select--</option>
																									<option value="box">Box/Head</option>
																									<option value="indi">Individual</option>
																								<select>	
																					</div>
																				
																					<div class="col-md-3">
																						<div class="form-group floating-label">
																							<?php if(isset($modelnamedropdwn) && !empty($modelnamedropdwn)){   $modelnamedropdwn1=explode(",",$modelnamedropdwn);   $counmodel=count($modelnamedropdwn1); ?>
																							
																								<select class="form-control" name="modelname" required="required" id="modelnameget" onchange="getallspareparts()">
																									<option value="">--select model--</option>
																									
																										 <?php for($g=0;$g<$counmodel;$g++){ ?>
																										 	  <?php $mld1=$modelnamedropdwn1[$g]; ?>
																										 	    <?php $modlnme=explode(";",$mld1);$modlnme1=$modlnme[0];$modlqty=$modlnme[1]; ?>
																													
																												<option value="<?php echo $mld1;  ?>"><?php echo $modlnme1;  ?></option>	
																												
																											
																										
																								<?php 	} } ?>
																									
																									
																								</select>
																								<input type="hidden" id="mqty1" >
																								</div>
																					 </div>
																					  <div class="col-md-3">
																								<select name="godown" required="required" class="form-control">
																									<option value="">--select warehouse--</option>
																									<option value="GK_GDWN/1">Warehouse 1</option>
																									<option value="GK_GDWN/2">Warehouse 2</option>
																								</select>
																					</div>
																					
																				   <div class="col-md-3">
																								
																								<input type="text" class="form-control" name="boxname" placeholder="Enter box/head name " id="boxhd">
																								<input type="hidden" name="pono" id="pono" value="<?php if(isset($pono)){ echo $pono; }  ?>" />
																								<input type="hidden" name="totrow" id="totrow"/>
																								<div class="inputr"></div>
																				  </div>
																						
																					
																				</div><!--end .card -->
																				
																			</div><!--end .col -->
																		
																		<hr>
																		<div class="row">
																			<div class="col-md-12">
																				<div class="col-md-3">
																						<div class="card ">
																							<div class="card-head card-head-xs style-primary">
																								<header>Spare parts list</header>
																								
																							</div><!--end .card-head -->
																							<div class="card-body no-padding height-9 scroll" style="overflow-y: scroll;">
																								<ul  id="getallspareparts" style="list-style:none; padding: 0px;">
																									
																									
																								 </ul>
																							</div><!--end .card-body -->
																						</div><!--end .card -->
																				</div><!--end .col -->
																				<div class="col-md-9" id="verticalLine">
																						<div>
																							<div class="card-head card-head-xs style-primary">
																								<header>Stocked List</header>
																								
																							</div><!--end .card-head -->
																							<div class="card-body no-padding height-9 scroll" id="getallpartsqtybtmodel" style="overflow-y: scroll;">
																								 <table class="table1" id="partstble">
																								      <tbody>
																								      <tr>
																								      	<th>Sl No.</th>
																								        <th>Parts Name</th>
																								        <th>Rest Qty</th>
																								         <th>Qty</th>
																								         <th>Unit</th>
																								         <th>Pkg</th>
																								         <th>Action</th>
																								      </tr>
																								   </tbody>
																								  </table>
																							</div><!--end .card-body -->
																						</div>
																				</div><!--end .col -->
																				
																			</div>
																			
																		</div>
																		<hr>
																		<div class="row">
																			<div class="col-md-6">
																				
																			</div>
																			
																			<div class="col-md-6">
																				<input type="text" class="form-control" name="nobox" placeholder="Enter no of box/head" value="" id="nohead_box" onkeyup="gettotal()">
																			</div>
																		</div>
																		
															      </div>
															      <div class="modal-footer">
															        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
															        <button type="submit" class="btn btn-primary"> Savechanges</button>
															      </div>
															     </form>
															    </div>
															  </div>
															</div>
<!------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////////////////////////////   Damage Entry    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
															<div class="modal fade bd-example-modal-lg_damage" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
															  <div class="modal-dialog modal-lg">
															    <div class="modal-content">
															    	
															      <div class="modal-header">
															        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
															          <span aria-hidden="true">&times;</span>
															        </button>
															        <h4 class="modal-title" id="myModalLabel"><?php if(isset($pono)){ echo "Purchase Order No-<i>".$pono."</i>" ; }?></h4>
															      </div>
															      <div class="modal-body">
															       <div class="row">
																			<form action="<?php echo base_url(); ?>stockManage_controller/stockentrycopy" method="post">
																			<div class="col-md-12">
																				<div class="col-md-3">
																							<select class="form-control" id="boximndi" onchange="getboxnametr()" name="entrytp">
																									<option value="">--select--</option>
																									<option value="box">Box/Head</option>
																									<option value="indi">Individual</option>
																								<select>	
																					</div>
																				
																					<div class="col-md-3">
																						<div class="form-group floating-label">
																							<?php if(isset($modelnamedropdwn) && !empty($modelnamedropdwn)){   $modelnamedropdwn1=explode(",",$modelnamedropdwn);   $counmodel=count($modelnamedropdwn1); ?>
																							
																								<select class="form-control" name="modelname" required="required" id="modelnameget" onchange="getallspareparts()">
																									<option value="">--select model--</option>
																									
																										 <?php for($g=0;$g<$counmodel;$g++){ ?>
																										 	  <?php $mld1=$modelnamedropdwn1[$g]; ?>
																										 	    <?php $modlnme=explode(";",$mld1);$modlnme1=$modlnme[0];$modlqty=$modlnme[1]; ?>
																													
																												<option value="<?php echo $mld1;  ?>"><?php echo $modlnme1;  ?></option>	
																												
																											
																										
																								<?php 	} } ?>
																									
																									
																								</select>
																								<input type="hidden" id="mqty1" >
																								</div>
																					 </div>
																					  <div class="col-md-3">
																								<select name="godown" required="required" class="form-control">
																									<option value="">--select warehouse--</option>
																									<option value="GK_GDWN/1">Warehouse 1</option>
																									<option value="GK_GDWN/2">Warehouse 2</option>
																								</select>
																					</div>
																					
																				   <div class="col-md-3">
																								
																								<input type="text" class="form-control" name="boxname" placeholder="Enter box/head name " id="boxhd">
																								<input type="hidden" name="pono" id="pono" value="<?php if(isset($pono)){ echo $pono; }  ?>" />
																								<input type="hidden" name="totrow" id="totrow"/>
																								<div class="inputr"></div>
																				  </div>
																						
																					
																				</div><!--end .card -->
																				
																			</div><!--end .col -->
																		
																		<hr>
																		<div class="row">
																			<div class="col-md-12">
																				<div class="col-md-3">
																						<div class="card ">
																							<div class="card-head card-head-xs style-primary">
																								<header>Spare parts list</header>
																								
																							</div><!--end .card-head -->
																							<div class="card-body no-padding height-9 scroll" style="overflow-y: scroll;">
																								<ul  id="getallspareparts" style="list-style:none; padding: 0px;">
																									
																									
																								 </ul>
																							</div><!--end .card-body -->
																						</div><!--end .card -->
																				</div><!--end .col -->
																				<div class="col-md-9" id="verticalLine">
																						<div>
																							<div class="card-head card-head-xs style-primary">
																								<header>Stocked List</header>
																								
																							</div><!--end .card-head -->
																							<div class="card-body no-padding height-9 scroll" id="getallpartsqtybtmodel" style="overflow-y: scroll;">
																								 <table class="table1" id="partstble">
																								      <tbody>
																								      <tr>
																								      	<th>Sl No.</th>
																								        <th>Parts Name</th>
																								        <th>Rest Qty</th>
																								         <th>Qty</th>
																								         <th>Unit</th>
																								         <th>Pkg</th>
																								         <th>Action</th>
																								      </tr>
																								   </tbody>
																								  </table>
																							</div><!--end .card-body -->
																						</div>
																				</div><!--end .col -->
																				
																			</div>
																			
																		</div>
																		<hr>
																		<div class="row">
																			<div class="col-md-6">
																				
																			</div>
																			
																			<div class="col-md-6">
																				<input type="text" class="form-control" name="nobox" placeholder="Enter no of box/head" value="" id="nohead_box" onkeyup="gettotal()">
																			</div>
																		</div>
																		
															      </div>
															      <div class="modal-footer">
															        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
															        <button type="submit" class="btn btn-primary"> Savechanges</button>
															      </div>
															     </form>
															    </div>
															  </div>
															</div>














<!------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////////////////////////////  End Damage Entry   /////////////////////////////////////////////////////////////////////////////////////////////////////////////
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->

                                                         
													</div>
													<hr>
													<form action="<?php echo base_url(); ?>stockManage_controller/stocktempsavedata" method="post">
													<div class="row">
														
														<div class="col-md-12">
															<?php if(isset($temp_data) && !empty($temp_data)){ $h=1; ?>
															<table class="table1" id="partstble2">
																	<tbody>
																		<tr>
																			<th>Sl No.</th>
																			<th>Details</th>
																			<th>PO No</th>
																			<th>No</th>
																			<th>Name</th>
																			<th>Qty</th>
																			<th>Unit</th>
																			<th>Packge</th>
																			<th>Action</th>
																		</tr>
																		
																		<?php foreach($temp_data as $row) {
																			
																			$pono=$row->pono;
																			$warehouse=$row->warehouse;
																			//$boxno=$row->
																			$boxname=$row->boxname;
																			$totalbox=$row->totalbox;
																			$stock=$row->stock;
																			$bxty=$row->totalbox;
																			$stockindi=$row->stockindi;
																			$stockimplode=explode(",",$stock);
																			$stockimplodeindi=explode(",",$stockindi);
																			$stockimplodeindicount=count($stockimplodeindi);
																			$stockimplodecount=count($stockimplode);
																			?>
																			<?php if(isset($boxname) && !empty($boxname))
																			{ ?>
																				<tr id="qty_<?php echo $h; ?>">
																			<td><?php echo $h; ?></td>
																			<td><button type="button" id="open_<?php echo $h; ?>" onclick="opentable(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-angle-double-down" aria-hidden="true"></i></button></td>
																			<td><?php echo $pono; ?><inpu type="hidden" name="pono_<?php echo $h; ?>"/></td>
																			<td><?php echo $boxname ?><inpu type="hidden" name="boxno_<?php echo $h; ?>"/></td>
																			<td></td>
																			<td></td>
																			<td></td>
																			<td><?php echo $bxty; ?><input type="hidden" name="bxty_<?php echo $h; ?>"</td>
																			<td><button type="button" id="close_<?php echo $h; ?>" onclick="delete_rowqty(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td>
																	</tr>
																	<tr id="opntr_<?php echo $h; ?>" class="trhide">
																		<td colspan="9">
																			<center>
																			<table class="datatr">
																				<tr style="background-color:#0aa89e;color:white;font-weight:normal;line-height: 12px;font-size: 10px;padding: 1px;text-align:center;">
																					<td>Slno.</td>
																					<td>No</td>
																					<td>Name</td>
																					<td>Model</td>
																					<td>Qty</td>
																					<td>Unit</td>
																					
																					<td>Action</td>
																					
																				</tr>
																				<?php  $u=1;
																			 for($g=0;$g<$stockimplodecount;$g++){; 
																			
																			$stock=$stockimplode[$g];
																			$stocvex=explode(";",$stock);
																			$prtsid=$stocvex[0];
																			//$prtsqty=intval($stocvex[1])*intval($totalbox);
																			$prtsqty=intval($stocvex[1]);
																			$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																			$getrow=mysqli_fetch_array($querygetprtsname);
																			$prtsnme=$getrow['materialname'];
																			$mname=$getrow['mName'];
																			$unit=$stocvex[2];
																			$getunit=mysqli_query($con,"select * from unit_tbl where id='".trim($unit)."'");
																			$rowgetnme=mysqli_fetch_array($getunit);
																			$unitnme=$rowgetnme['unitname'];
																			 
																			 ?>
																				<tr style="font-weight:normal;height:12px;font-size:10px;padding: 1px;text-align:center;">
																					<td><?php echo $u; ?></td>
																					<td></td>
																					<td><?php echo $prtsnme ?></td>
																					<td><?php echo $mname; ?></td>
																					<td><?php echo $prtsqty; ?></td>
																					<td><?php echo $unitnme; ?></td>
																					
																					<td><button type="button" id="close_<?php echo $h; ?>" onclick="delete_rowqty(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td>
																				</tr>
																		<?php $u++; } ?>
																				
																			</table>
																			</center>
																		</td>
																	</tr>
																				
																			<?php  }else{ ?>
																				
																				<?php  $u=1;
																			 for($g=0;$g<$stockimplodeindicount;$g++){; 
																			
																			$stock=$stockimplodeindi[$g];
																			$stocvex=explode(";",$stock);
																			$prtsid=$stocvex[0];
																			$prtsqty=intval($stocvex[1]);
																			$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																			$getrow=mysqli_fetch_array($querygetprtsname);
																			$prtsnme=$getrow['materialname'];
																			$mname=$getrow['mName'];
																			$unit=$stocvex[2];
																			$getunit=mysqli_query($con,"select * from unit_tbl where id='".trim($unit)."'");
																			$rowgetnme=mysqli_fetch_array($getunit);
																			$unitnme=$rowgetnme['unitname'];
																			$pkg=$stocvex[3];
																			 
																			 ?>
																				<tr style="font-weight:normal;height:12px;">
																					<td><?php echo $h; ?></td>
																					<td></td>
																					<td></td>
																					<td></td>
																					<td><?php echo $prtsnme."($mname)" ?></td>
																					
																					<td><?php echo $prtsqty; ?></td>
																					<td><?php echo $unitnme;  ?></td>
																					<td><?php echo $pkg;  ?></td>
																					<td><button type="button" id="close_<?php echo $h; ?>" onclick="delete_rowqty(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td>
																				</tr>
																		<?php $u++;$h++; } ?>
																			
																				
																				
																				
																				
																				
																		<?php 	} ?>
																			
																			
																			
																			
																	<?php $h++;	 } ?>
																																				
																		
																			<?php /* $u=1;
																			 for($g=0;$g<$stockimplodecount;$g++){; 
																			
																			$stock=$stockimplode[$g];
																			$stocvex=explode(";",$stock);
																			$prtsid=$stocvex[0];
																			$prtsqty=intval($stocvex[1])*intval($totalbox);
																			$querygetprtsname=mysqli_query($con,"select * from  materiel_master where id='".trim($prtsid)."'");
																			$getrow=mysqli_fetch_array($querygetprtsname);
																			$prtsnme=$getrow['materialname'];
																			 
																			*/ ?>
																	<!--<tr id="qty_<?php echo $u; ?>">
																			<td><?php echo $u; ?></td>
																			<td><?php echo $prtsnme ?></td>
																			<td></td>
																			<td><?php echo $prtsqty; ?></td>
																			<td><button type="button" id="close_<?php echo $u; ?>" onclick="delete_rowqty(this.id)" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td>
																	</tr>-->
																		<?php //$u++; } ?>
																	</tbody>
															</table>
															
															<input type="hidden" name="tablerow1" value="<?php echo $h; ?>"/>
															<input type="hidden" name="pono" value="<?php echo $pono; ?>"/>
															
														</div>
													</div>
													<div class="row">
														<div class="card-actionbar">
															<div class="card-actionbar-row">
																<button type="submit" class="btn btn-flat btn-primary ink-reaction">Submit</button>
															</div>
														</div>
														
													</div>	
														
														
													</div>
												
										</div><!--end .card-body -->
									</div><!--end .card -->
					                 </form>
					                 <?php } ?>
								</div> 
							<!--end .col -->
						</div>
					<?php } ?>
							
							
							
							
													
									
						</div><!--end .card-body -->
					</div><!--end .card -->
					
				</div><!--end .col -->
			</div>
		</div><!--end .section-body -->
	</section>
	<!-- BEGIN BLANK SECTION -->

		</div><!--end #content-->		
		<!-- END CONTENT -->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
$(document).ready(function(){
	
	//alert('hello');
	$(".trhide,.thred").hide();
	$("#boxhd").hide();
	$("#nohead_box").hide();
});
	function getallspareparts()
	{ 
		var getallpartsqtybtmodel="";
		var mqty="";
		var mqty1=$("#mqty1").val();
		//alert(mqty1);
		if(mqty1=="")
		{
			var mqty2=$("#mqty1").val();
		}else
		{
			var mqty2=mqty;
		}
		var modelname1=$("#modelnameget").val();
		var idsplit=modelname1.split(";");
		var modelname=idsplit[0];
		
			mqty1 =modelname1+',';
		
		
		//alert(mqty1);
		$("#mqty1").val(mqty1);
		if(modelname=="")
		{
			alert('please select model name');
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getallspare_parts_sort_by_modelname",
  			data :{'modelname':modelname},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#getallspareparts").html(data);
  			  
              }  
           });
		}else
		{
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getallspare_parts_sort_by_modelname",
  			data :{'modelname':modelname},
  			success : function(data){
  				 				 
  				//alert(data);
  				$("#getallspareparts").html(data);
  				 $('.inputr').append("<input type='hidden' id='tablerow_"+prtsmid+"' name='tablerow_"+prtsmid+"' value=''/>");
  			     $('.inputr').append("<input type='hidden' id='unit2_"+prtsmid+"' name='unit2_"+prtsmid+"' value=''/>");
              }  
           });
		}
		
	}
	function putpartsqtybyparts(id,partsid)
	{
		//alert('hello');
		//var idsplit=id.split("_");
		var a=id;
		var prtsmid=partsid;
		var boximndi=$("#boximndi").val();
		var pono=$("#pono").val();
		var totrow=$("#totrow").val();
		
		if(totrow=="")
		{
			var textw="";
		}else
		{
			var textw=totrow;
		}
		var mtqy=$("#mqty1").val();
		
		var rowCount = $('#partstble tr').length;
		var tr=rowCount-1;
		var tr2=tr+1;
		//alert(rowCount);
		if(boximndi=="indi"){
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getdetails_stocklist",
  			data :{'prtsmid':prtsmid,'pono':pono,'mtqy':mtqy},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				
  				var prtsname=json.partsname;
  				var partsid=json.partsid;
  				var unit=json.unit;
  				var prtsmid=json.partmid;
  				var mtyq=json.mty;
  				var modelnameprts=json.modelnameprts;
  				var idsplit=mtyq.split(";");
  				var mnme=idsplit[0];
  				var qty2=idsplit[1];
  				textw +=prtsmid +"," ;
  				var rstqty=json.rstqty;
  				//alert(matid);
  				//var matname=json.matname;
  				//$("#matid").val(matid);
  				$("#totrow").val(textw);
  				$('#partstble tr:last').after('<tr class="qtro" id="getid_'+tr2+'"><td>'+tr2+'</td><td>'+prtsname+'('+modelnameprts+')</td><td>'+rstqty+'</td><td><input type="text" size="5" onkeyup="getalltotqty(this.id)" name="prtsinputqty_'+prtsmid+'" id="prtsinputqty_'+prtsmid+'" /></td><td><select required id="unit_'+prtsmid+'" onchange="getunit(this.id)"><option value="" >select</option><option value="1">Set</option><option value="2">Pcs</option><option value="3">Pair</option></select></td><td><input type="text" name="pkg_'+prtsmid+'" id="pkg_'+prtsmid+'"  size="5" onkeyup="gettotalpkg(this.id)" /></td><td><button type="button" id="close_'+tr2+'" onclick="delete_row(this.id,'+tr2+')" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='tablerow_"+prtsmid+"' name='tablerow_"+prtsmid+"' value=''/>");
  			    $('.inputr').append("<input type='hidden' id='unit2_"+prtsmid+"' name='unit2_"+prtsmid+"' value=''/>");
  			    $('.inputr').append("<input type='hidden' id='pkg2_"+prtsmid+"' name='pkg2_"+prtsmid+"' value=''/>");
  			    //$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			   //  $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' />");
              }  
           });
           
          }
          if(boximndi=="box"){
          	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>stockManage_controller/getdetails_stocklist",
  			data :{'prtsmid':prtsmid,'pono':pono,'mtqy':mtqy},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				
  				var prtsname=json.partsname;
  				var partsid=json.partsid;
  				var unit=json.unit;
  				var prtsmid=json.partmid;
  				var mtyq=json.mty;
  				var modelnameprts=json.modelnameprts;
  				var idsplit=mtyq.split(";");
  				var mnme=idsplit[0];
  				var qty2=idsplit[1];
  				textw +=prtsmid +"," ;
  				var rstqty=json.rstqty;
  				//alert(matid);
  				//var matname=json.matname;
  				//$("#matid").val(matid);
  				$("#totrow").val(textw);
  				$('#partstble tr:last').after('<tr class="qtro" id="getid_'+tr2+'"><td>'+tr2+'</td><td>'+prtsname+'('+modelnameprts+')</td><td>'+rstqty+'</td><td><input type="text" size="5" onkeyup="getalltotqty(this.id)" name="prtsinputqty_'+prtsmid+'" id="prtsinputqty_'+prtsmid+'" /></td><td><select required id="unit_'+prtsmid+'" onchange="getunit(this.id)"><option value="">select</option><option value="1">Set</option><option value="2">Pcs</option><option value="3">Pair</option></select></td><td><input type="text" class="print-clean" size="15" readeonly name="prtstotalqty_'+prtsmid+'" id="prtstotalqty_'+prtsmid+'"/></td><td><button type="button" id="close_'+tr2+'" onclick="delete_row(this.id,'+tr2+')" class="btn ink-reaction btn-icon-toggle btn-primary"><i class="fa fa-close"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='tablerow_"+prtsmid+"' name='tablerow_"+prtsmid+"' value=''/>");
  			    $('.inputr').append("<input type='hidden' id='unit2_"+prtsmid+"' name='unit2_"+prtsmid+"' value=''/>");
  			    
  			    
  			    //$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			   //  $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' />");
              }  
           });
           
          }
          if(boximndi=="")
          {
          	alert('please select entry type boxwise/individual');
          	$("#boximndi").focus();
          	
          }
		/**/
		
	}
	function getalltotqty(id)
	{
		var idsplit=id.split("_");
		var qtyval=$("#prtsinputqty_"+idsplit[1]).val();
		var unit=$("#unit_"+idsplit[1]).val();
		//alert(unit);
		//alert(qtyval);
		$("#prtstotalqty_"+idsplit[1]).val(qtyval);
		$("#tablerow_"+idsplit[1]).val(qtyval);
		$("#unit2_"+idsplit[1]).val(unit);
		//alert($("#unit2_"+idsplit[1]).val());
	}
	function gettotal()
	{
		var rowCount = $('#partstble tr').length;
		var tr=rowCount-1;
		var tr2=tr+1;
		var txtrw=$("#totrow").val();
		var idsiplit=txtrw.split(",");
		var nohead_box=parseInt($("#nohead_box").val());
		var a=idsiplit.length;
		a=a-1;
		if(nohead_box=="")
		{
			
			nohead_box=1;
		}
			for(var d=0;d<a;d++)
			{
				var in1=parseInt($("#prtsinputqty_"+idsiplit[d]).val());
				//alert(in1);
				//alert(nohead_box);
				var box1=nohead_box*in1;
				//alert(nohead_box);
				$("#prtstotalqty_"+idsiplit[d]).val(box1);
			}
		
		//alert(a);
		
	}
	function delete_row(id,tr)
	{
		var idsplit=id.split("_");
		var idval=idsplit[1];
		//alert(tr);
		var result=confirm("Want to delete?");
		
		
		if(result==true)
		{
			//alert(this);
			//$(this).closest('tr').remove();
			$("#qty_"+idsplit[1]).css("background-color","#7dd8d2");
	
			$("#qty_"+idsplit[1]).fadeOut(400, function(){
				$("#qty_"+idsplit[1]).remove();
				//$("#tablerow_"+tr).remove();
			});
		}
		
	}
	function delete_rowqty(id)
	{
		var idsplit=id.split("_");
		var result=confirm("Want to delete?");
		
		
		if(result==true)
		{
			//alert(this);
			//$(this).closest('tr').remove();
			$("#getid_"+idsplit[1]).css("background-color","#7dd8d2");
	
			$("#getid_"+idsplit[1]).fadeOut(400, function(){
				$("#getid_"+idsplit[1]).remove();
				$("#tablerow_"+tr).remove();
			});
		}
		
	}
	function opentable(id)
	{
		var idsplit=id.split("_");
		//alert('hello');
		
		$("#opntr_"+idsplit[1]).toggle();
	}
	function opentablethrid(id)
	{
		var idsplit=id.split("_");
		$("#tqtry_"+idsplit[1]).toggle();
	}
	function getboxnametr()
	{
		var boximndi=$("#boximndi").val();
		if(boximndi==""|| boximndi=="indi")
		{
			$("#boxhd").hide();
			$("#nohead_box").hide();
		}else
		{
			$("#boxhd").show();
			$("#nohead_box").show();
		}
	}
	function gettotalpkg(id)
	{
		var idsplit=id.split("_");
		var pkg=$("#pkg_"+idsplit[1]).val();
		alert(pkg);
		$("#pkg2_"+idsplit[1]).val(pkg);
	}
	function getunit(id)
	{
		var idsplit=id.split("_");
		var unit=$("#unit_"+idsplit[1]).val();
		//alert(unit);
		$("#unit2_"+idsplit[1]).val(unit);
	}
</script>