<?php include("connection.php"); ?>
<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<script src="<?php echo base_url(); ?>jscolor.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#addCF").click(function(){
		var no=$(".norow").length;
		no=no+1;
		//alert(no);
        $("#customFields").append('<div class="norow" id="res_'+no+'"><div class="col-md-1"><div class="form-group"><h4>'+no+'.</h4></div></div><div class="col-md-9"><div class="form-group"><input type="text" class="form-control" id="sp_'+no+'" name="sp_'+no+'"><label for="cst"></label></div></div><div class="col-md-2"><div class="form-group"><a href="javascript:deletediv('+no+')" id="remCF_'+no+'" ><i class="fa fa-minus-square-o" style="font-size:36px;"></i></a></div></div></div>');
	   $("#abcd").val(no);
	   /* $("#remCF").on('click',function(){
			 
            $(this).parent().parent().remove();
        });*/
		
    });
	
});
 function deletediv(id)
		{
			//alert('hello');
			var idsplit=id;
			//alert(idsplit);
			$("#res_"+idsplit).remove();
			
		}
</script>
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
					<li class="active">View All Stock Entry Details <h6><i>Last Updated on <?php echo date('Y-m-d h:i:s A'); ?></i></h6></li>
				</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View</a></li>-->
								<!--<li><a href="#third1">Statistic</a></li>-->
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
                <th>PO NO</th>
                <th>INVOICE NO</th>
                <th>DOE</th>
                <th>VENDORS NAME</th>
                <th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($getalltemdataprts) && !empty($getalltemdataprts)){ $pono1=""; $i=1; ?>
			<?php foreach($getalltemdataprts as $row){  $pono=$row->pono; ?>
				<?php if($pono!=$pono1){  
				  $pono=$row->pono;
				  $querypono=mysqli_query($con,"select * from purchaseorder where poid='".trim($pono)."' ");
						$getrow=mysqli_fetch_array($querypono);
						$ponoid=$getrow['id'];
            			
				 ?>
				<?php  //if($pono!=$pono1){ ?>
            <tr>
               <td><?php echo $i; ?></td>
               <td><?php echo $pono=$row->pono; ?></td>
               <td>12DCSE</td>
               <td>23-10-2016</td>
               <td>G k Rickshaw</td>
               <td><a href="<?php echo base_url();  ?>stockManage_controller/print_pdfstock/<?php echo $ponoid; ?>" target="_blank"><i class="fa fa-print" aria-hidden="true"></i></a></td>
            </tr>
            <?php $i++;  $pono1=$pono; } } } ?>
            <?php if(isset($getalltemdataprtsall) && !empty($getalltemdataprtsall)){ $pono1=""; $i=1 ; ?>
            	<?php foreach($getalltemdataprtsall as $row){
            		
					$pono=$row->pono;
					  ?>
            		<?php if($pono!=$pono1){ 
            			$querypono=mysqli_query($con,"select * from purchaseorder where poid='".trim($pono)."' ");
						$getrow=mysqli_fetch_array($querypono);
						$ponoid=$getrow['id'];
            			
            			?>
              		<tr>
               <td><?php echo $i; ?></td>
               <td><?php echo $pono=$row->pono; ?></td>
               <td>12DCSE</td>
               <td>23-10-2016</td>
               <td>G k Rickshaw</td>
               <td><a href="<?php echo base_url();  ?>stockManage_controller/print_pdfstock/<?php echo $ponoid ;?>" target="_blank"><i class="fa fa-print" aria-hidden="true"></i></a></td>
            </tr>
            
            <?php $i++;} $pono1=$pono; } } ?>
        </tbody>
    </table>
				</div>
				</form>	
         <div class="tab-pane" id="second1">
	</div>
	<!--<div class="tab-pane" id="forth1"><table id="example" class="mdl-data-table" cellspacing="0" width="100%">
		<tr>
			<td> This is History block.
			</td>
		</tr>
    </table></div>-->
							<div class="tab-pane" id="third1"><p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p><p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p></div>
						</div><!--end .card-body -->
						</div>
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			


			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

		<!-- BEGIN MENUBAR-->
<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

	<!-- BEGIN JAVASCRIPT -->

<!-- END CONTENT -->
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
 