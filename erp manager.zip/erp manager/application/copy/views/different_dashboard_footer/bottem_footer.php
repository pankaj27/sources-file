<div class="footer-menu">
      <div id="half_copyrights" style="background-color:#216ca5">
       <div class="pull-left">
        <span class="developed_by">Copyright @ <?php  echo date('Y')."-".(date('Y')+1); ?> ERP Manager - <a href='#'>Powered By CPS initiative </a></span>                                                         </div>
       <ul id="minform-list-bottom" class="list-group pull-left">
        <li> | Brightness</li>
        <li><input type="range" id="bg_opacity_user" value="70" ></li>
        <li> | Toggle Window</li>
        <li><i class="fa fa-tv enlarge-window clickable"></i></li>

       </ul>
       <ul id="bottom-inputs" class="list-group">
        <li></li>
       </ul>
       <!--<ul class="pull-right">
        <li> | </li>
        <li><a href="http://inoideas.org/content.php?mode=9&content_type=web_contact">Contact</a></li>
        <li><a href="http://inoerp.org/extensions/ino_user/user_login.php">Demo</a></li>
        <li><a href="https://github.com/inoerp/inoERP">Download</a></li>
        <li><a href="http://localhost/inoerp/content.php?content_type=documentation&category_id=30">Documentation</a></li>
        <li><a href="http://localhost/inoerp/content.php?content_type=forum&category_id=1">Forum</a></li>
        <li><a href="https://www.mozilla.org/MPL/2.0/">MPL 2</a></li>
        <li><a href="#">Cookie</a></li>
        <li class="active"><a href="#">TOU</a></li>
        <li class="label label-pill label-danger"><i class="fa fa-close close-footer-menu clickable"></i></li>
       </ul>-->
      </div>
     </div>