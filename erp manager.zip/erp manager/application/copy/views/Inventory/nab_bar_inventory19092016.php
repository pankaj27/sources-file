<div class="ino navbar-form">
    <div id="navigation_bar"   class="col-sm-12 col-xs-12 col-md-10 col-md-offset-2 mainbar">
     <div id="header_top_quick_nav" class='hidden-xs' >
      <ul class="list-group inline_list">
       <li role="presentation"><i class="fa fa-toggle-left clickable right_bar_navigation_menu" title="Toggle Navigation Menu"></i></li>
       <li role="presentation"><a  href="#"><i class="fa fa-home" title="Home"></i></a></li>
       <li role="presentation"><a   href=""><i class="fa fa-info" title="Messages"></i></a></li>
       <li role="presentation"><a   href="<?php echo base_url(); ?>login"><i class="fa fa-dashboard" title="Dashborad"></i></a></li>
       <!--<li role="presentation"><i class="fa fa-gears right-click-menu clickable" title="Actions"></i></li>-->
       <li role="presentation"><a  class="erp-links search-list-page" href="#"><i class="fa fa-search" title="Search & List Page"></i></a></li>
       <li role="presentation"><a  class="erp-links form-page" href="#"><i class="fa fa-list-alt" title="Form Page"></i></a></li>
       <li id="unsaved_fields" data-no_of_fields="0"></li>
       <li class="show_loading_small">
        <div class="ino-spinner ino-sm" >
         <div class="rect1" style="background-color:#1f6dad"></div>
         <div class="rect2" style="background-color:#1f6dad"></div>
         <div class="rect3" style="background-color:#1f6dad"></div>
         <div class="rect4" style="background-color:#1f6dad"></div>
         <div class="rect5" style="background-color:#1f6dad"></div>
        </div>
       </li>
      </ul>
     </div>
     <div id="header_top_container">
      			 <ul id="form_top_image" class="draggable">
        <li class='fa fa-refresh clickable ino-btn2 ' id='refresh_button' title='Refresh' style="background-color: #1f6dad" ></li>
        <li class='fa fa-file-text-o clickable ino-btn2' Title="New Document" id="new_page_button" href="<?php echo base_url(); ?>Inventory_controller/vehicle_master" style="background-color: #1f6dad"></li>
    		<li class='fa fa-save clickable ino-btn2' id='save' title='Save' style="background-color: #1f6dad" ></li>
        <li class='fa fa-eraser clickable ino-btn2' Title="Clear All, Quick Entry" id="new_object_button" href="form.php?mode=9&amp;class_name=item" style="background-color: #1f6dad"></li>
        <li class='fa fa-trash-o clickable ino-btn2' id='delete_button' title='Delete' style="background-color: #1f6dad"></li>
        <li class='fa fa-remove clickable ino-btn2' id='remove_row_button' title='Remove' style="background-color: #1f6dad" ></li>
        <li class='fa fa-search-plus clickable query_mode_icon ino-btn2' id='start_query_mode' title='Query Mode' style="background-color: #1f6dad"></li>
        <li class='fa fa-print clickable print ino-btn2' id='print_searchResult' title='Print' style="background-color: #1f6dad"></li>
</ul>           </div>
     
   </div>