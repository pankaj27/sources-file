<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">

<!--<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="Description" content="tiny ColorPicker is a small (10.0KB, 4.5KB gZip) but very advanced jQuery color picker and color conversion / calculation tool that supports the following color spaces: rgb, hsv, hsl, hex,  but also  alpha, WCAG 2.0 readability standards (based on opacity levels of all layers), contrast, color similarity, grayscale, 2-layer or 3-layer overlap mix, etc..." />
    <meta name="author" content="Peter Dematté" />
    <meta http-equiv="language" content="en" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php //echo base_url(); ?>tinycolour/development/favicon.ico">
	<link rel="icon" type="image/x-icon" href="<?php //echo base_url(); ?>tinycolour/development/favicon.ico">

	<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>tinycolour/index.css">
	<link id="colorPickerMod" rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>tinycolour/mod.css">
	<script src="http://code.jquery.com/jquery-2.2.3.min.js"></script>
	 <!--<script type="text/javascript" src="<?php //echo base_url(); ?>/tinycolour/jqColorPicker.min.js"></script>-->
	<!--<script type="text/javascript" src="<?php //echo base_url(); ?>tinycolour/colors.js"></script>
	<script type="text/javascript" src="<?php //echo base_url(); ?>tinycolour/jqColorPicker.js"></script>
	<script type="text/javascript" src="<?php //echo base_url(); ?>tinycolour/index.js"></script>-->


<script src="<?php echo base_url(); ?>jscolor.js"></script>


<style>
    .invoice-box{
        max-width:900px;
        margin:auto;
        /*padding:30px;*/
        border:1px solid #eee;
        box-shadow:0 0 10px rgba(0, 0, 0, .15);
       /* font-size:16px;*/
        line-height:24px;
        font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color:#555;
    }
    
    .invoice-box table{
        width:100%;
        line-height:inherit;
        text-align:center;
    }
	.modal-title{
		text-align:center;
	}
	.form-group{
		text-align:left;
	}
    
    .invoice-box table td{
        padding:5px;
        vertical-align:top;
    }
    
    .invoice-box table tr td:nth-child(2){
        text-align:right;
    }
    
    .invoice-box table tr.top table td{
        padding-bottom:20px;
    }
    
    .invoice-box table tr.top table td.title{
        font-size:45px;
        line-height:45px;
        color:#333;
    }
    
    .invoice-box table tr.information table td{
        padding-bottom:40px;
    }
    
    .invoice-box table tr.heading td{
        background:#0aa89e;
        color:white;
        border-bottom:1px solid #ddd;
        font-weight:bold;
    }
    
    .invoice-box table tr.details td{
        padding-bottom:20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom:1px solid #eee;
    }
    
    .invoice-box table tr.item.last td{
        border-bottom:none;
    }
    
    .invoice-box table tr.total td:nth-child(2){
        border-top:2px solid #eee;
        font-weight:bold;
    }
	table thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width: 100%;
			height:44px;
		}
		tr{
			text-align: center;
		}
		
		#exmple3 td{
			width:150px;
		}
		#exmple4 td{
			width:250px;
		}
		#exmple5 td{
			width:300px;
		}
		#exam td{
			width:400px;
		}
		#example8 td{
			width:40px;
		}
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td{
            width:100%;
            display:block;
            text-align:center;
        }
        
        .invoice-box table tr.information table td{
            width:100%;
            display:block;
            text-align:center;
        }
    }
    </style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">New Colour Entry</li>
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			<!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li class="active"><a href="#first1">Add Colour Code</a></li>
								
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<div class="col-md-12">
									<div class="col-md-12">
									<?php if(isset($colour) && !empty($colour)){
													foreach($colour as $row){
														$id=$row->id;
														
														}
													}  
													?>
					<form class="form" action="<?php echo base_url(); ?>colourManage_controller/updateColour"  method="POST" >

								<div class="card-head style-primary">
									<header> Add Colour Code   </header>
								</div>
								
					              	<div class="row">
									<input type="hidden"  value="<?php if(isset($id)){ echo $id ;} ?>" name="id"/>
										<div>
											<h3><b>Choose Your Colour Code  :</h3></b>
										</div>
											<div class="col-md-3">	
												<input type="text" class="form-control" placeholder="Enter Your Colour name" name="colourName" id="colourName" value="<?php echo $row->color_name; ?>">
											</div>
										<div class="col-md-3">
										
											<input class="jscolor {onFineChange:'update(this)'}" name="ccode" id="colour1" style="text-align:center;width:85px;background-color: <?php echo $row->code_hex; ?>;color:white;font-weight:bold;" value="<?php echo $row->code_hex; ?>" \><input type="hidden" name="rgb" id="colour2" value="<?php echo $row->rgb_code; ?>"><input type="hidden" name="rgb1" id="colour3" value="<?php echo $row->code_hex; ?>"> <!--<span id="rgb"></span>-->
										</div>
										<div class="col-md-3">
											<button type="submit" class="btn btn-flat btn-primary ink-reaction">Update</button>&nbsp;&nbsp;&nbsp;
											<a href="<?php echo base_url();?>colourManage_controller/viewcolour"><button type="button" class="btn btn-flat btn-primary ink-reaction"><i class="ace-icon fa fa-times"></i> Cancel</button></a>
										</div>
									</div>
									<!--<div id="content-wrapper">
										<h1>Tiny jQuery colorPicker</h1>
										<p>This is a demo that describes tinyColorPicker custumization 'Skinned dev-tools like with RGB sliders' in a more understandable way.</p>
										<a name="demo" id="demo" class="a-inline"></a>
										<h2>Skinned dev-tools like, with RGB sliders</h2>
										<div class="input-toggles wrapper">
											<input class="color" value="#B6BD79" />
											<input class="color no-alpha" value="rgb(162, 63, 3)" />
											<input class="color no-sliders" value="hsl(32, 95%, 23%)" />
										</div>
										<div class="div-toggles wrapper">
											<div class="trigger" value="#556B2F"></div>
											<div class="trigger" value="rgb(100, 86, 70)"></div>
											<div class="trigger" value="hsla(167, 29%, 68%, 0.8)"></div>
										</div>
									</div>-->
									

									<!--<input class="jscolor {onFineChange:'update(this)'}" value="ffcc00">-->
									

								<div style="position:absolute; left:280px; top:10px;display:none">
										toHEXString = <span id="hex-str"></span><br />
										toRGBString = <span id="rgb-str"></span><br />
										R, G, B = <span id="rgb"></span><br />
										H, S, V = <span id="hsv"></span>
									</div>
											
								  <!--end .card-body -->	
							<!--end .section-body -->
					</form>
	</section>

<script>
function update(picker) {
    document.getElementById('hex-str').innerHTML = picker.toHEXString();
    document.getElementById('rgb-str').innerHTML = picker.toRGBString();

    document.getElementById('rgb').innerHTML =
        Math.round(picker.rgb[0])+','+
        Math.round(picker.rgb[1])+','+
        Math.round(picker.rgb[2]);
		
		 document.getElementById('colour2').value =
        Math.round(picker.rgb[0])+','+
        Math.round(picker.rgb[1])+','+
        Math.round(picker.rgb[2]);
		var colorc=Math.round(picker.rgb[0])+','+Math.round(picker.rgb[1])+','+Math.round(picker.rgb[2]);
		//alert(colorc);
       $("#colour2").val(colorc);
	   $("#colour3").val(picker.toHEXString())
    document.getElementById('hsv').innerHTML =
        Math.round(picker.hsv[0]) + '&deg;, ' +
        Math.round(picker.hsv[1]) + '%, ' +
        Math.round(picker.hsv[2]) + '%';
}
</script>
	
		</div><!--end #content-->	
		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->

<?php  $this->load->view('dashboard/fotter.php'); ?>
<script>
	function getallpodetails()
	{
		alert('hello');
		var pono=$("#pono").val();
		//alert(pono);
		$.ajax({			
 			type :"POST",
  			url : "<?php //echo base_url();  ?>Purchase_controller/getpurchasepaymentdetails",
  			data :{'pono':pono},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				var foid=json.foid;
  				var venid=json.venid;
  				var poid=json.poid;
  				var parts=json.parts;
  				var partssplit=parts.split(",");
  				var partssplitlen=partssplit.length;
  				alert(partssplitlen);
  				var model=json.model;
  				var modesplit=model.split(",");
  				var modellen=modesplit.length;
  				alert(modellen);
  				var fstpmnt=json.fstpmnt;
  				var ndpmnt=json.ndpmnt;
  				var thrdpmnt=json.thrdpmnt;
  				var procdate=json.procdate;
  				var disdate=json.disdate;
  				var tax=json.tax;
  				var taxsplit=tax.split(",");
  				var taxlen=taxsplit.length;
  				alert(taxlen);
  				taxdiv="";
  				for( var b=0;b<taxlen;b++)
  				{
  					var taxst=taxsplit[b];
  					var taxstsplit=taxst.split(";");
  					var taxstring=taxstsplit[0];
  					var taxrte=taxstsplit[1];
  					var taxamnt=taxstsplit[2];
  					taxdiv +="<div><div>"+taxstring+"</div><div>"+taxrte +"</div><div>"+taxamnt +"</div></div>"
  					//alert(taxst);
  				}
  				//alert(taxdiv);
  				$("#foid").val(taxdiv);
  				//alert(foid);
  				  			  
              }  
           });
          
	}
</script>

