<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

<script src="<?php echo base_url(); ?>jscolor.js"></script>
<style>
	table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			font-size: 13px;
			font-weight: normal;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			height:44px;
		}
		tr{
			text-align: center;
		}

</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">View All Colour</li>
									
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message2') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		             <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li class="active"><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View/Search</a></li>
								<li><a href="#third1">Satistics</a></li>-->
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<table id="example" cellspacing="0" width="100%">
        <thead>
            <tr>
            	<th>Sl No.</th>
                <th>Colour Name</th>
                <th>Colour Code</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
			<?php if(isset($ccod)){ $i=1;  ?>
        	<?php foreach($ccod as $row){ ?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $row->color_name; ?></td>
				<td><input type="text" style="text-align:center;width:85px;background-color: <?php echo $row->code_hex; ?>;color:white;font-weight:bold;" value="<?php echo $row->code_hex; ?>" readonly \><input type="hidden" name="rgb" id="colour2"><input type="hidden" name="rgb1" id="colour3"> </td>
				<td>
					<a href="<?php echo base_url(); ?>colourManage_controller/editColour/<?php echo $row->id; ?>" class="tooltip-success">
					<button type="button" class="btn btn-flat btn-primary ink-reaction"> Edit</button></a>
					&nbsp;&nbsp;									
					<a href="<?php echo base_url(); ?>colourManage_controller/deleteColour/<?php echo $row->id; ?>" class="tooltip-success">
					<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-flat btn-primary ink-reaction"> <i class="fa fa-close">Delete</i></button></a>
				</td>
				<input type="hidden" name="id" value="<?php echo $i; ?>">
			</tr>
			<?php $i++; }} ?>
		</tbody>
    </table>
									<div style="position:absolute; left:280px; top:10px;display:none">
										toHEXString = <span id="hex-str"></span><br />
										toRGBString = <span id="rgb-str"></span><br />
										R, G, B = <span id="rgb"></span><br />
										H, S, V = <span id="hsv"></span>
									</div>
								
						  </div>

					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->

			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

<script>
function update(picker) {
    document.getElementById('hex-str').innerHTML = picker.toHEXString();
    document.getElementById('rgb-str').innerHTML = picker.toRGBString();

    document.getElementById('rgb').innerHTML =
        Math.round(picker.rgb[0])+','+
        Math.round(picker.rgb[1])+','+
        Math.round(picker.rgb[2]);
		
		 document.getElementById('colour2').value =
        Math.round(picker.rgb[0])+','+
        Math.round(picker.rgb[1])+','+
        Math.round(picker.rgb[2]);
		var colorc=Math.round(picker.rgb[0])+','+Math.round(picker.rgb[1])+','+Math.round(picker.rgb[2]);
		//alert(colorc);
       $("#colour2").val(colorc);
	   $("#colour3").val(picker.toHEXString())
    document.getElementById('hsv').innerHTML =
        Math.round(picker.hsv[0]) + '&deg;, ' +
        Math.round(picker.hsv[1]) + '%, ' +
        Math.round(picker.hsv[2]) + '%';
}
</script>



<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>login_assets/jquerymodal/js/jquery.modal.js"></script>
<!--<script src="<?php //echo base_url(); ?>assets/notify/jquery-1.7.2.min.js"></script>-->

<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>


<?php $this->load->view('dashboard/main_menu_left.php'); ?>
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>	
<?php $this->load->view('dashboard/fotter.php'); ?>	

<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

  
