<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />
	<!--jQuery-->

<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>	
<?php $con=mysqli_connect("localhost","root","","erp_manager"); ?>			
	<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			height:44px;
		}
		tr{
			text-align: center;
		}
		
		#exmple3 td{
			width:150px;
		}
		#exmple4 td{
			width:250px;
		}
		#exmple5 td{
			width:300px;
		}
		#exam td{
			width:400px;
		}
		#example8 td{
			width:40px;
		}
		
	</style>			

	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
			<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">&nbsp;&nbsp;&nbsp;Final Purchase Order</li>
						</ol>

		</div>
			
	<section class="has-actions style-default-bright">

		<!-- BEGIN INBOX -->
		<div class="section-body">
			<div class="row">

				<!-- BEGIN INBOX NAV -->
				<form action="<?php echo base_url(); ?>Purchase_controller/finalorder" method="post" enctype="multipart/form-data">
				<div class="col-sm-8 col-md-9 col-lg-10">
					 <input type="hidden" name="vid" value="<?php echo $vid; ?>"/>
					 <input type="hidden"  name="poid" value="<?php echo $poid; ?>"/>
					<div class="row">
						<?php //print_r($getquot); ?>

						<div class="col-md-12 col-lg-12">
							<table id="example" cellspacing="0" width="100%">
        						<thead>
            							<tr>
            								<th>Sl No.</th>
            								<th>Product Id</th>
											<th>Product Name</th>
											<th>Model Name</th>
											<th>Model ID</th>
											<th>Quantity</th>
                							<th>Rate </th>
                							<th>Amount</th>
                							<th>Final Rate</th>
                							<th>Final Price</th>
											
            							</tr>
        						</thead>
        									 <?php
											 	 if(isset($getquot)&& !empty($getquot)) 
												 {
												 	  $i=1;
												 	foreach($getquot as $row5)
													{
														$parts=$row5->parts;
														if(empty($parts)){
															 $partsexplode="";
															
														}else{
															 $partsexplode=explode(",",$parts);
														}
														
														//echo $countmode=count($partsexplode);
														 $model=$row5->model;
														
														if(empty($model)){
															 $modelexplode="";
															
														}else{
															 $modelexplode=explode(",",$model);
														}
														
													   // $countmode=count($modelexplode);
														$tax=$row5->tax;
														$taxexplode=explode(",",$tax);
														$total=$row5->total;
														$fstpmnt=$row5->fstpmnt;
														$sndpmnt=$row5->ndpmnt;
														$thrdpmnt=$row5->thrdpmnt;
														$procdate=$row5->procdate;
														$disdate=$row5->disdate;
														$curreny=$row5->currencytyp;
														$file=$row5->file;
														$nttot=0;
														
													} }
												 ?>
												 <tbody>
											  <?php  
											  	if(!empty($partsexplode)){  ?>
											  		<?php  foreach($partsexplode as $roparts){ ?>
											  			<?php $ropartsexplode=explode(";",$roparts); ?>
											  			<?php 
											  				$partsid=$ropartsexplode[0]; 
															$modelname=$ropartsexplode[1];
															$prtsqty=$ropartsexplode[2];
															$prtserte=$ropartsexplode[3];
															$prtsamnt=$ropartsexplode[4];
											  			
											  			
											  			
											  			
											  			?>
											  	<tr>
												<td><?php echo $i; ?></td>	
												<td><?php echo $partsid; ?><input type="hidden" name="partsid_<?php echo $i; ?>" value="<?php echo $partsid; ?>"/></td>
											   	<td><?php $queryprtnme=mysqli_query($con,"select * from materiel_master where materiel_id='".trim($partsid)."'");
															$rowmateri=mysqli_fetch_array($queryprtnme);
															echo $partsnme=$rowmateri['materialname'];
												
												 ?></td>
											   	<td><?php echo $modelname; ?><input type="hidden" name="modelname_<?php echo $i; ?>" value="<?php echo $modelname; ?>" /></td>
											   	<td>
											   		<?php $queryprtnme=mysqli_query($con,"select * from productmaster where productname='".trim($modelname)."'");
															$rowmateri=mysqli_fetch_array($queryprtnme);
															echo $partsnme=$rowmateri['productid'];
												
												 ?>
											   		
											   		
											   		
											   	</td>
											   	<td style="width: 50px;"><?php echo $prtsqty; ?><input type="hidden" name="qty_<?php echo $i; ?>" id="qty_<?php echo $i; ?>" value="<?php echo $prtsqty; ?>"/></td>
											   	<td><?php echo $prtserte;  ?><input type="hidden" name="partsrte_<?php echo $i; ?>" value="<?php echo $prtserte; ?>"/></td>
											   	<td style="text-align: right;"><?php echo $prtsamnt;$nttot=floatval($nttot)+ floatval($prtsamnt); ?></td>
											   	<td><input type="text" class="decimal-2-places" style="text-align: right;" value="<?php echo $prtserte ;  ?>"  name="finalrte_<?php echo $i; ?>" id="finalrte_<?php echo $i; ?>" onkeyup="getfinaltotal(this.id);"/></td>
											   	<td><input type="text" style="text-align: right;" value="<?php echo $prtsamnt ;  ?>" name="finalprice_<?php echo $i; ?>" id="finalprice_<?php echo $i; ?>" readonly/></td>
												</tr>	
													
													
												<?php $i++; }} ?>
												<?php 
													if(!empty($modelexplode)){ ?>
														
														<?php $modelexplode=array_filter($modelexplode); ?>
														<?php  foreach($modelexplode as $rowmodel){ ?>
															<?php $modimplode=explode(";",$rowmodel); ?>
															<?php 
																$modelid=$modimplode[0];
																$modelnme=$modimplode[1];
																$modelqty=$modimplode[2];
																$modelrte=$modimplode[3];
																$modelamnt=$modimplode[4];
															   
															
															 ?>
												<tr>
												<td><?php echo $i; ?></td>	
												<td><?php  ?></td>
											   	<td><?php  ?></td>
											   	<td><?php echo $modelnme; ?><input type="hidden" name="modelname_<?php echo $i; ?>" value="<?php echo $modelnme; ?>" /></td>
											   	<td><?php echo $modelid; ?></td>
											   	<td style="width: 50px;"><?php echo $modelqty ; ?><input type="hidden" id="qty_<?php echo $i; ?>" name="qty_<?php echo $i; ?>"  value="<?php echo $modelqty; ?>"/></td>
											   	<td><?php echo $modelrte ; ?><input type="hidden" name="partsrte_<?php echo $i; ?>" value="<?php echo $modelrte; ?>"/></td>
											   	<td style="text-align: right;"><?php echo $modelamnt;$nttot=floatval($nttot)+ floatval($modelamnt); ?></td>
											   	<td><input type="text" class="decimal-2-places" value="<?php echo $modelrte; ?>" name="finalrte_<?php echo $i; ?>" id="finalrte_<?php echo $i; ?>" onkeyup="getfinaltotal(this.id);" style="text-align: right;"/></td>
											   	<td><input type="text" value="<?php echo $modelamnt; ?>" name="finalprice_<?php echo $i; ?>" id="finalprice_<?php echo $i; ?>"  style="text-align: right;" readonly/></td>
												
												</tr>
												<?php $i++; } ?>
												
												
												
											<?php   }	 ?>
        								  	<tr>
        								  		<td colspan="7">Net Total</td>
        								  		<td style="text-align: right;"><?php if($curreny=="dollar"){ echo "&#36;";}else{ echo "&#x20b9;"; } ?><?php echo $nttot;  ?></td>
        								  		<td></td>
        								  		<td><input type="text" value="<?php  echo $nttot;  ?>" name="nettotal" id="netfinal" readonly style="text-align: right;"/>
        								  			<input type="hidden" name="totalrow" value="<?php echo $i; ?>" readonly style="text-align: right;"/>
        								  		</td>
        								  	</tr>	
        								  <?php //for($k=1;$k<4;$k++){ ?>
        								  	<?php if(!empty($tax)){ $n=1;$taxex=explode(",",$tax); ?>
        								  		<?php foreach($taxex as $row6){ $taxexplode=explode(";",$row6);
        								  		
													$txtxt=$taxexplode[0];
												    $txtrte=$taxexplode[1];
													$txtamnt=$taxexplode[2];
												
												
												 ?>
        							
        									<tr>
        								  		<td colspan="3">Tax <?php echo $n; ?>(%)</td>
        								  		<td colspan="3" style="width: 100px;"><input type="text" name="taxtext_<?php echo $n; ?>" id="<?php   ?>" value="<?php echo $txtxt; ?>"/></td>
        								  		<td ><input type="text" name="taxrte_<?php echo $n; ?>" class="decimal-2-places" id="taxrte_<?php echo $n; ?>" style="width: 100px;text-align: right;" value="<?php echo $txtrte;  ?>" onblur="getpercentage(this.id)"/></td>
        								  		<td><input type="text" name="nettotal" readonly value="<?php echo $txtamnt; ?>" style="text-align: right;"/></td>
        								  		<td><input type="text" name="nettotal" readonly/></td>
        								  		<td><input type="text" value="<?php echo $txtamnt;  ?>" name="taxfinal_<?php echo $n; ?>" id="taxfinal_<?php echo $n; ?>" style="text-align: right;" readonly/>
        								  			
        								  		</td>
        								  	</tr>
            							   <?php  $n++ ; } } //} ?>   
            							   <input type="hidden" name="taxxfinal" id="taxrow" value="<?php if(isset($n)){echo $n;  } ?>"/> 
            							   <input type="hidden" name="currency"  id="currency" value="<?php if(isset($curreny)){ echo $curreny; } ?>" />
        						 </tbody>
								 
   					 	</table>
						<br>
						
						<hr class="ruler-xxx">
						
						
   					 	
						</div><!--end .col -->
						<!-- END EMAIL CONTENT -->

					</div><!--end .row -->
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<div class="col-md-12">
								 
								 	<div class="col-md-6"><h4>1st Payment:</h4></div><div class="col-md-3"><input type="text" name="fstpmnt" value="<?php echo $fstpmnt;  ?>" class="decimal-2-places" id="st_1" onkeyup="getrestamount(this.id);"/></div>
						     </div>
							<div class="col-md-12">
								 <div class="col-md-6">	<h4>2nd Payment:</h4></div><div class="col-md-3"><input type="text" name="sndpmnt" class="decimal-2-places" value="<?php echo $sndpmnt;  ?>" id="st_2" onkeyup="getrestamount(this.id);"/></div>
							</div>
						   <div class="col-md-12">
								 <div class="col-md-6"><h4> 3rd Payment:</h4></div><div class="col-md-3"><input type="text" class="decimal-2-places" name="thrdpmnt" value="<?php echo $thrdpmnt;  ?>" id="st_3" onkeyup="getrestamount(this.id);" /></div>
						  </div>
						  <div class="col-md-12">
								 	<div class="col-md-6"><h4>Processing Date:</h4></div><div class="col-md-3"><input type="text" class="decimal-2-places" id="datepicker" name="pdate" value="<?php echo $procdate;  ?>"/></div>
						  </div>
						<div class="col-md-12">
								 	<div class="col-md-6"><h4>Dispatchdate:</h4></div><div class="col-md-3"><input type="text" id="datepicker2" class="decimal-2-places" name="disdate" value="<?php echo $disdate;  ?>"/></div>
						</div>
						<div class="col-md-12">
								 	<div class="col-md-6"><h4>Download Attachment:</h4></div><div class="col-md-3"><a href="<?php echo base_url(); ?>venders/quotationfile/<?php echo $file; ?>" target="_blank"><?php echo $file; ?></a></div>
						</div>
						</div>
						<div class="col-md-6">
							
							 <div class="col-md-12">
								<div class="col-md-4"><b>Grand Total:</b></div>
								<div class="col-md-3"><input type="text" id="gtotal"  value="<?php if($curreny=="dollar"){ echo "&#36;";}else{ echo "&#x20b9;"; } ?><?php echo $total;  ?> " readonly name="grandtot" style="text-align: right;font-weight: bold;color:red;"></div>
								<div class="col-md-2"></div>
								<div class="col-md-3"><input type="text" id="finalgtotal"  value="<?php echo $total; ?> " readonly name="grandtottal" style="text-align: right;"></div>
								
							</div>
							<div class="col-md-12">
								<div class="col-md-4"></div>
								<div class="col-md-3"></div>
								<div class="col-md-2"></div>
								<div class="col-md-3"><br><b><button type="submit" id="submit1" class="btn ink-reaction btn-lg btn-primary" name="save_date">Submit</button></b></div>
								
							</div>	
							<div class="col-md-12">
								<div id="resttotal" style="color:red;text-align: left;font-weight: bolder;font-size: 6;"></div>
							</div>	
						</div>
						</div>
					</div>
					
					
					
					
				</div><!--end .col -->

			<div class="row">
				<div class="col-sm-8 col-md-9 col-lg-10">
					
				</div>
			</div>
		</div><!--end .section-body -->
		<!-- END INBOX -->
  </form>
		<!-- BEGIN SECTION ACTION -->
		<!--end .section-action -->
		<!-- END SECTION ACTION -->

	</section>

		</div><!--end #content-->		
		<!-- END CONTENT -->
          
		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>

		<!-- BEGIN OFFCANVAS RIGHT -->
		<div class="offcanvas">
			


<!-- BEGIN OFFCANVAS SEARCH -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>login_assets/jquerymodal/js/jquery.modal.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.numeric.js"></script>
<script>
	$(window).load(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
 
 $("#submit1").hide();
 $(".decimal-2-places").numeric({ decimalPlaces: 2 });
});
</script>

<script>
	function getfinaltotal(id)
	{
		//alert('hello');
		
		//alert('hello');
		var idsplit=id.split("_");
		var qty=$("#qty_"+idsplit[1]).val();
		var rte=$("#finalrte_"+idsplit[1]).val();
		//alert(rte);
		var total=parseFloat(rte)* parseInt(qty);
		var rowCount = $('#example tr').length;
		var txr=$("#taxrow").val;
		//alert(rowCount);
		var nettot=0;
		if(rte=="")
		{
			tot=0;
			var tot=tot.toFixed(2);
		}else
		{
			var total=parseFloat(rte) * parseInt(qty);
			var tot=total.toFixed(2);
		}
		
		nettot=parseFloat(nettot)+parseFloat(tot);
		$("#finalprice_"+idsplit[1]).val(tot);
		nettot=nettot.toFixed(2);
		
		//$("#total").val(nettot);
		//nettot=0;
		var gtot1=0;
		for(var m=1;m<=(rowCount-5) ; m++)
		{
			var gtot=$("#finalprice_"+m).val();
			//alert(gtot);
			if(gtot==""){
				gtot=0;
			}
			//console.log(gtot);
			//console.log("#amountid_"+m);
			gtot1=parseFloat(gtot1) + parseFloat(gtot);
			//console.log(gtot1);
			
		}
		gtot1=gtot1.toFixed(2);
		//alert(gtot1);
		$("#netfinal").val(gtot1);
		var txttoal=0;
		for(var c=1;c<4;c++){
			//var finalt=$("#finalgtotal").val(); 
			var ctx=$("#taxrte_"+c).val();
			//alert(ctx);alert(gtot1);
			if(ctx=="")
			{
				ctx=0;
			}
			//txttoal=parseFloat(txttoal)+parseFloat(ctx);
			var k=(parseFloat(gtot1)) * parseFloat(ctx)/100;
			k=k.toFixed(2);
			//alert(k);
			$("#taxfinal_"+c).val(k);
			txttoal=parseFloat(txttoal)+parseFloat(k);
			gtot1=parseFloat(gtot1)+parseFloat(k);
			//alert(gtot1);
			
			
		}
		
		//gtot1=parseFloat(gtot1)+parseFloat(txttoal);
		gtot1=gtot1.toFixed(2);
		
		$("#finalgtotal").val(gtot1);
	 
	}
	function getpercentage(id)
	{
		var idsplit=id.split("_");
		//alert('hello');
		//var idno=idsplit[1];
		//if()
		var total=$("#netfinal").val();
		//alert(total);
		var txttoal=0;
		var txr=$("#taxrow").val();
		for(var c=1;c<4;c++){
			//var finalt=$("#finalgtotal").val(); 
			var ctx=$("#taxrte_"+c).val();
			alert(ctx);
			if(ctx=="")
			{
				ctx=0;
			}
			//txttoal=parseFloat(txttoal)+parseFloat(ctx);
			var k=(parseFloat(total)) * parseFloat(ctx)/100;
			k=k.toFixed(2);
			//alert(k);
			$("#taxfinal_"+c).val(k);
			txttoal=parseFloat(txttoal)+parseFloat(k);
			
			var gtot1=parseFloat(total)+parseFloat(k);
			total=gtot1;
			//alert(gtot1);
		
		}
		//alert(txttoal);
		gtot1=gtot1.toFixed(2);
		
		$("#finalgtotal").val(gtot1);
			}
			
			function getrestamount(id)
			{
				var idsplit=id.split("_");
				var id=idsplit[1];
				var gtoto=$("#finalgtotal").val();
				var cur=$("#currency").val();
				var getamount=$("#st_"+idsplit[1]).val();
				//alert(getamount);
				
				var  tot=0;
				for(var g=1;g<4;g++)
				{
					var pv=$("#st_"+g).val();
					if(pv=="")
					{
						pv=0;
					}
					//alert(g);
					tot=parseFloat(tot)+parseFloat(pv);
					//alert(tot);
				}
				var rest=parseFloat(gtoto)-parseFloat(tot);
				//alert(tot);
				
				rest=rest.toFixed(2);
				if(rest<0)
				{
					alert('Please enter right number');
					 $("#resttotal").html("<h5>Please put right value</h5>");
					 $("#submit1").hide();
					 if(id==1){
					 	$("#st_2").prop('readonly',true);
					 	$("#st_3").prop('readonly',true);
					 }
				}else{
				
				 if(cur=="inr"){
				 $("#resttotal").html("<h5>&#x20b9;"+rest+"</h5>");
				 
				 }else{
				 
				 	 $("#resttotal").html("<h5>&#36;"+rest+"</h5>");
				 }
				}
				//alert(tot);
				if(tot==gtoto)
				{
					$("#submit1").show();
				}else
				{
					$("#submit1").hide();
				}
				
			}
</script>