<?php include('conection.php'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/notify/buttons.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/notify/animate.css"/>
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>login_assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />

<?php $this->load->view('dashboard/header.php'); ?>
<?php $this->load->view('dashboard/top_nav_menu.php');  ?>
<?php 
    if(isset($getvendorsdetails) && !empty($getvendorsdetails))
	{
		foreach($getvendorsdetails as $rowvendors)
		{
			$id=$rowvendors->id;
			$vname=$rowvendors->vname;
			$vcompany=$rowvendors->vcompany;
			$vemail=$rowvendors->vemail; 
			$vphno=$rowvendors->vphno;
			$add1=$rowvendors->add1;
			$cst=$rowvendors->cst;
			$vat=$rowvendors->vat;
			$add4=$rowvendors->add4;
			$pin=$rowvendors->pin;
			$country=$rowvendors->country;
			 if(isset($countries)){ 
			foreach($countries as $row){
				$slno=$row->id;
				
				if($slno==intval($country))
				{
					$cid=$row->id;
					$country=$row->name;
					break;
				}
			
			}
			 }	
			$contactname1=$rowvendors->contactname1;
			$contactemail1=$rowvendors->contactemail1;
			$contactphno1=$rowvendors->contactphno1;
			$contactname2=$rowvendors->contactname2;
			$contactemail2=$rowvendors->contactemail2;
			$contactphno2=$rowvendors->contactphno2;
			$material1=$rowvendors->material;
			$material1explode=explode(",",$material1);
			$products1=$rowvendors->products;
			$products1explode=explode(",",$products1);
			$bankname1=$rowvendors->bankname1;
			$bankacc1=$rowvendors->bankacc1;
			$bankifsc1=$rowvendors->bankifsc1;
			$bankswift1=$rowvendors->bankswift1;
			$branch1=$rowvendors->branch1;
			$bankname2=$rowvendors->bankname2;
			$bankacc2=$rowvendors->bankacc2;
			$bankifsc2=$rowvendors->bankifsc2;
			$bankswift2=$rowvendors->bankswift2;
			$branch2=$rowvendors->branch2;
			
			
			//$contactname2=$row->contactname2;
			
			
			
		}
	}

  ?>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<style>
	table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
			font-size: 13px;
			font-weight: normal;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			height:44px;
		}
		tr{
			text-align: center;
		}
		#exmple3 td{
			width:150px;
		}
		#exmple4 td{
			width:250px;
		}
		#exmple5 td{
			width:300px;
		}
		#exam td{
			width:400px;
		}
		#example8 td{
			width:40px;
		}
		#exmple10 td{
			width:500px;
		}
</style>
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
			 		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->

		<!-- BEGIN CONTENT-->
		<div id="content">
				<section>
		<div class="section-header">
				<ol class="breadcrumb">
									<li class="active">view All Vendors</li>
									
						</ol>

		</div>
		<div class="section-body contain-lg">
                   <?php if($this->session->flashdata('message2') != ''){ ?>
										             <div class="alert alert-danger alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		             <?php if($this->session->flashdata('message') != ''){ ?>
										             <div class="alert alert-success alert-dismissible">
											               <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
											       <?php echo $this->session->flashdata('message'); ?>
										          </div>
		            <?php }?>
		           

			
			<div class="row">
			</div><!--end .row -->
			<!-- END LAYOUT - ALIGNMENT -->

			<div class="row">

				<!-- BEGIN LAYOUT LEFT ALIGNED -->
				<div class="col-md-12">
					<div class="card">
						<div class="card-head">
							<ul class="nav nav-tabs" data-toggle="tabs">
								<li class="active"><a href="#first1">View</a></li>
								<!--<li><a href="#second1">View/Search</a></li>
								<li><a href="#third1">Satistics</a></li>-->
							</ul>
						</div><!--end .card-head -->
						<div class="card-body tab-content">
							<div class="tab-pane active" id="first1">
								<table id="example" cellspacing="0" width="100%">
        <thead>
            <tr>
            	<th>Sl No.</th>
                <th>Ven.ID</th>
                <th>Name</th>
                <th>Address</th>
                <th>Contact Person</th>
                <th>Bank Info.</th>
                <th>Company Info.</th>
                <th>Parts/Products Supplied</th>
                <th>Action</th>
            </tr>
        </thead>
        
        <tbody>
        	<?php if(isset($allvendors)){ $i=1;  ?>
        	<?php foreach($allvendors as $row){ ?>
        		
        		<?php 
        			$venid=$row->vender_id;
					$vname=$row->vname;
					$vcom=$row->vcompany;
					$vemail=$row->vemail;
					$vphno=$row->vphno;
        		
					$add1=$row->add1;
					$cst=$row->cst;
					$vat=$row->vat;
					$pin=$row->pin;
					$country=$row->country;
					foreach($countries as $row1){
							$slno=$row1->id;
				
							if($slno==intval($country))
								{
										$cid=$row1->id;
										$country=$row1->name;
										break;
								}
			
					}
					$contactname1=$row->contactname1;
					$contactemail1=$row->contactemail1;
					$contactphno1=$row->contactphno1;
					$contactname2=$row->contactname2;
					
					$contactemail2=$row->contactemail2;
					$contactphno2=$row->contactphno2;
					$material=$row->material;
					$product=$row->products;
					$bank1=$row->bankname1;
					$bankacc1=$row->bankacc1;
					$bankifsc1=$row->bankifsc1;
					$bankswift1=$row->bankswift1;
					$brnch1=$row->branch1;
					$bank2=$row->bankname2;
					$bankacc2=$row->bankacc2;
					$bankifsc2=$row->bankifsc2;
					$bankswift2=$row->bankswift2;
					$brnch2=$row->branch2;
					
					      		
        		
        		
        		 ?>
        		
            <tr>
               <td><?php echo $i ?></td>
                <td><?php echo $venid; ?></td>
                <td><a href="#" data-toggle="modal" data-target="#myModal_<?php echo $i; ?>" > <?php echo $vcom; ?>
                	<!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>-->
                	</a>

<!-- Modal -->
<div class="modal fade" id="myModal_<?php echo $i; ?>" role="dialog"><div class="modal-dialog modal-lg"><div class="modal-content">
	<div class="modal-header">
	  <button type="button" class="close" data-dismiss="modal">&times;</button>
	  <h4 class="modal-title"></h4>
	       <h3><b><?php echo $vcom; ?></b></h3>
	      
	  </div>
	  <div class="modal-body">
	  	
	  	<table id="exmple3">
	  		<thead>
	  			<tr>
	  				<th colspan="7">Company Information</th>
	  			</tr>
	  		</thead>
	  		<tbody>
	  			<tr>
	  				<td><b>ID<b></td>
	  					<td><b>Name</b></td>
	  					<td><b>Address</b></td>
	  					<td><b>Phno</b></td>
	  					<td><b>Country</b></td>
	  					<td><b>CST</b></td>
	  					<td><b>VAT</b></td>
	  			</tr>
	  			<tr>
	  				<td><?php echo $venid; ?></td>
	  				<td><?php echo $vname; ?></td>
	  				<td><?php echo $add1.", Pin-".$pin; ?></td>
	  				<td><?php echo $vphno; ?></td>
	  				<td><?php echo $country; ?></td>
	  				<td><?php echo $cst; ?></td>
	  				<td><?php echo $vat; ?></td>
	  		   </tr>
	  	  </tbody>
	  	  </table>
	  	  <hr>
	  	  <table id="exmple4">
	  	  	<thead><tr><th colspan="7">Contact Information</th></tr></thead>
	  	  	<tbody><tr><td><b>Sl No<b></td><td><b>Name</b></td><td><b>Email </b></td><td><b>Phno</b></td></tr>
	  	  		<tr><td><b>1.<b></td>
	  	  			<td><?php if(isset($contactname1)){ echo $contactname1 ;} ?></td>
	  	  			<td><?php if(isset($contactemail1)){ echo $contactemail1 ;} ?></td>
	  	  			<td><?php if(isset($contactphno1)){ echo $contactphno1 ;} ?></td>
	  	  		</tr>
	  	  		<tr>
	  	  			<td><b>2.<b></td>
	  	  			<td><?php if(isset($contactname2)){ echo $contactname2 ;} ?></td>
	  	  			<td><?php if(isset($contactemail2)){ echo $contactemail2 ;} ?></td>
	  	  			<td><?php if(isset($contactphno2)){ echo $contactphno2 ;} ?></td>
	  	  		</tr>
	  	  </tbody>
	  	  				
	  	  </table>
	  	  <hr>
	  	  <table id="exmple3">
	  	  	<thead><tr><th colspan="7">Bank Information</th></tr></thead>
	  	  	<tbody>
	  	  		<tr>
	  	  			<td><b>Sl No<b></td>
	  	  			<td><b>Bank Name</b></td>
	  	  			<td><b>Bank Account No </b></td>
	  	  			<td><b>Branch Name</b></td>
	  	  			<td><b>IFSC CODE</b></td>
	  	  			<td><b>SWIFT CODE</b></td>
	  	  		</tr>
	  	  		<tr>
	  	  			<td><b>1<b></td>
	  	  			<td>
	  	  				<?php if(isset($bank1)){ echo $bank1;} ?>
	  	  			</td>
	  	  			<td> <?php if(isset($bankacc1)){ echo $bankacc1;} ?></td>
	  	  			<td> <?php if(isset($bankswift1)){ echo $bankswift1;} ?></td>
	  	  			<td> <?php if(isset($bankifsc1)){ echo $bankifsc1;} ?></td>
	  	  			<td> <?php if(isset($bankswift1)){ echo $bankswift1;} ?></td>
	  	  		</tr>
	  	  		<tr>
	  	  			<td><b>2<b></td>
	  	  			<td>
	  	  				<?php if(isset($bank2)){ echo $bank2;} ?>
	  	  			</td>
	  	  			<td> <?php if(isset($bankacc2)){ echo $bankacc2;} ?></td>
	  	  			<td> <?php if(isset($bankswift2)){ echo $bankswift2;} ?></td>
	  	  			<td> <?php if(isset($bankifsc2)){ echo $bankifsc2;} ?></td>
	  	  			<td> <?php if(isset($bankswift2)){ echo $bankswift2;} ?></td>
	  	  		</tr>
	  	  	</tbody>
	  	  </table>
	  	  <hr>
	  	  <table id="exmple10">
	  	  	<thead><tr><th colspan="2">Supplied Products/Spareparts</th></tr></thead>
	  	  	<tbody>
	  	  		<tr>
	  	  			<td><b>Spare Parts<b></td>
	  	  			<td><b>Products</b></td>
	  	  			
	  	  		</tr>
	  	  		<tr>
	  	  			<td><?php if(isset($material)){ echo $material ;} ?></td>
	  	  			<td><?php if(isset($product)){ echo $product ;} ?></td>
	  	  			
	  	  		</tr>
	  	  		
	  	  	</tbody>
	  	  </table>
	  	  			
	  	  	<hr>
	  	  	
	  	  				</div>
	  	  				<div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div>
                	
                	
                	
                </td>
                <td><?php echo $add1; ?></td>
                <td><?php if(!empty($contactname1)) { echo $contactname1.",<br>" ; }if(!empty($contactname2)) { echo $contactname2 ; }  ?></td>
                <td><?php if(!empty($bank1)) { echo $bank1.",<br>" ; }if(!empty($bank2)) { echo $bank2 ; }  ?></td>
                <td><?php echo "CST-".$cst."<br>"."VAT-".$vat; ?></td>
                <td><?php if(!empty($product)){ echo "Products-".$product; } ?></td>
                <td>
                	<a href="<?php echo base_url();?>Venders_controller/editvendorsdetails/<?php echo $row->id;  ?>" class="tooltip-success">
							 <!--<button type="button" class="btn btn-sm btn-success"><i class="ace-icon fa fa-check">-->
							 <button type="button" class="btn btn-flat btn-primary ink-reaction"></i> Edit</button></a>
					&nbsp;&nbsp;									
					<a href="<?php echo base_url(); ?>Venders_controller/deleteVemdors/<?php echo $row->id; ?>" class="tooltip-success">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-info"><i class="ace-icon fa fa-times bigger-125">-->
					<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-flat btn-primary ink-reaction"></i>Delete</button></a>
					
                	
                	
                </td>
            </tr>
            <!-- <div class="modal fade" id="myModal" role="dialog"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title"></h4><h5><i>Vendor,s Id:-</i></h5></div><div class="modal-body"><table id="exmple3"><thead><tr><th colspan="7">Company Information</th></tr></thead><tbody><tr><td><b>ID<b></td><td><b>Name</b></td><td><b>Address</b></td><td></b>Phno</b></td><td><b>Country</b></td><td></b>CST</b></td><td><b>VAT</b></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table><hr><table id="exmple4"><thead><tr><th colspan="7">Contact Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Name</b></td><td><b>Email </b></td><td><b>Phno</b></td></tr><tr><td><b>1.<b></td><td></td><td></td><td></td></tr><tr><td><b>2.<b></td><td></td><td></td><td></td></tr></tbody></table><hr><table id="exmple3"><thead><tr><th colspan="7">Bank Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Bank Name</b></td><td><b>Bank Account No </b></td><td><b>Branch Name</b></td><td><b>IFSC CODE</b></td><td><b>SWIFT CODE</b></td></tr><tr><td><b>1<b></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td><b>2<b></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table><hr><table id="exmple3"><thead><tr><th colspan="7">Last Transaction Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Quatation No</b></td><td><b>PI No. </b></td><td></b>Date</b></td><td></b>Dr.</b></td><td></b>Cr.</b></td><td></b>Balance</b></td></tr><tr><td><b>1<b></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody><table></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div> -->
            <!-- <button type="button" data-toggle="modal" data-target="#myModal" class="btn ink-reaction btn-xs btn-info">View Details</button></div></div></div></div><div class="modal fade" id="myModal" role="dialog"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">'+vcompany+'</h4><h5><i>Vendor,s Id:-'+vender_id +'</i></h5></div><div class="modal-body"><table id="exmple3"><thead><tr><th colspan="7">Company Information</th></tr></thead><tbody><tr><td><b>ID<b></td><td><b>Name</b></td><td><b>Address</b></td><td></b>Phno</b></td><td><b>Country</b></td><td></b>CST</b></td><td><b>VAT</b></td></tr><tr><td>'+vender_id+'</td><td>'+vcompany+'</td><td>'+add1+'</td><td>'+vphone+'</td><td>'+country+'</td><td>'+cst+'</td><td>'+vat+'</td></tr></tbody></table><hr><table id="exmple4"><thead><tr><th colspan="7">Contact Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Name</b></td><td><b>Email </b></td><td><b>Phno</b></td></tr><tr><td><b>1.<b></td><td>'+contact1+'</td><td>'+contactemail1+'</td><td>'+contactphno1+'</td></tr><tr><td><b>2.<b></td><td>'+contactname2+'</td><td>'+contactemail2+'</td><td>'+contactphno2+'</td></tr></tbody></table><hr><table id="exmple3"><thead><tr><th colspan="7">Bank Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Bank Name</b></td><td><b>Bank Account No </b></td><td><b>Branch Name</b></td><td><b>IFSC CODE</b></td><td><b>SWIFT CODE</b></td></tr><tr><td><b>1<b></td><td>'+bankname1+'</td><td>'+bankacc1+'</td><td>'+branch1+'</td><td>'+bankifsc1+'</td><td>'+bankswift1+'</td></tr><tr><td><b>2<b></td><td>'+bankname2+'</td><td>'+bankacc2+'</td><td>'+branch2+'</td><td>'+bankifsc2+'</td><td>'+bankswift2+'</td></tr></tbody></table><hr><table id="exmple3"><thead><tr><th colspan="7">Last Transaction Information</th></tr></thead><tbody><tr><td><b>Sl No<b></td><td><b>Quatation No</b></td><td><b>PI No. </b></td><td></b>Date</b></td><td></b>Dr.</b></td><td></b>Cr.</b></td><td></b>Balance</b></td></tr><tr><td><b>1<b></td><td>'+qatationno+'</td><td>'+purchaseorderno+'</td><td>'+purchasedate+'</td><td>'+venderlastrans+'</td><td></td><td>'+venderlastrans+'</td></tr></tbody><table></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div><div>-->
            <?php  $i++; } } ?>
        </tbody>
    </table>
								
						  </div>
					
         <div class="tab-pane" id="second1">
         	</div>
							<div class="tab-pane" id="third1"><p>Duo semper accumsan ea, quidam convenire cum cu, oportere maiestatis incorrupte est eu. Soluta audiam timeam ius te, idque gubergren forensibus ad mel, persius urbanitas usu id. Civibus nostrum fabellas mea te, ne pri lucilius iudicabit. Ut cibo semper vituperatoribus vix, cum in error elitr. Vix molestiae intellegat omittantur an, nam cu modo ullum scriptorem.</p><p>Quod option numquam vel in, et fuisset delicatissimi duo, qui ut animal noluisse erroribus. Ea eum veniam audire. Per at postea mediocritatem, vim numquam aliquid eu, in nam sale gubergren. Dicant vituperata consequuntur at sea, mazim commodo</p></div>
						</div><!--end .card-body -->
					</div><!--end .card -->
					<!--<em class="text-caption">Left aligned tabs</em>-->
				</div><!--end .col -->
				
			</div><!--end .row -->
			
			
			
			<hr class="ruler-xxl">

			
		</div><!--end .section-body -->
	</section>
		</div><!--end #content-->		
		<!-- END CONTENT -->

		<!-- BEGIN MENUBAR-->
		<?php $this->load->view('dashboard/main_menu_left.php'); ?>
		<!-- END MENUBAR -->
<?php $this->load->view('dashboard/off_canvas_right.php'); ?>		

	<!-- BEGIN JAVASCRIPT -->
<?php  $this->load->view('dashboard/fotter.php'); ?>

<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>login_assets/jquerymodal/js/jquery.modal.js"></script>
<!--<script src="<?php echo base_url(); ?>assets/notify/jquery-1.7.2.min.js"></script>-->

  
