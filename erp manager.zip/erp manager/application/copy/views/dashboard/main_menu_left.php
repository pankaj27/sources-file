
		<!-- BEGIN MENUBAR-->
		<div id="menubar" class="menubar-inverse ">
			<div class="menubar-fixed-panel">
				<div>
					<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
						<i class="fa fa-bars"></i>
					</a>
				</div>
				<div class="expanded">
					<a href="<?php echo base_url(); ?>">
						<span class="text-lg text-bold text-primary "><?php echo $sd=$this->session->userdata('user_name');  ?></span>
					</a>
				</div>
			</div>
			<div class="menubar-scroll-panel">
				<!-- BEGIN MAIN MENU -->
				



<ul id="main-menu" class="gui-controls">
	<!-- BEGIN DASHBOARD -->
	<li>
		<a href="<?php echo base_url(); ?>">
			<div class="gui-icon"><i class="fa fa-home"></i></div>
			<span class="title"><?php $sd=$this->session->userdata('user_name'); ?></span>
		</a>
	</li><!--end /menu-li -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-truck"></i></div>
			<span class="title">Material/Products Master</span>
		</a>
		<!--start submenu -->
		<ul>
			
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/modelEntry" class="active"><span class="title">Model entry</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/viewmodel" class="active"><span class="title">View all model</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/sparePartsEntry" ><span class="title">Spare Parts Entry</span></a></li>
			<li><a id="createVenders" href="<?php echo base_url(); ?>newBrand_controller/viewspareparts" ><span class="title">View all parts</span></a></li>
			

		</ul><!--end /submenu -->
	</li>
	
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-truck"></i></div>
			<span class="title">Vendors Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a id="createVenders" href="<?php echo base_url(); ?>Venders_controller/createVenders"  ><span class="title">Create New</span></a></li>
			<li id="viewVenders"><a href="<?php echo base_url(); ?>Venders_controller/viewvendors" ><span class="title">View vendors list</span></a></li>

		</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-file-text-o"></i></div>
			<span class="title">Purchase Master</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>Purchase_controller/createNew" id="purchaseorder" ><span class="title">Purchase Order</span></a></li>

			<li><a href="<?php echo base_url(); ?>Purchase_controller/viewquotation" ><span class="title">view Quotation List</span></a></li>
			<li><a href="<?php echo base_url(); ?>Purchase_controller/viewpilist" ><span class="title">PO List</span></a></li>
    	</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-file-text-o"></i></div>
			<span class="title">Stock Management</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/createNew" id="purchaseorder" ><span class="title">Stock Entry(PO No)</span></a></li>

			<li><a href="<?php echo base_url(); ?>stockManage_controller/stockentrybox" ><span class="title">Stock Entry(Box)</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/viewallstockentry" ><span class="title">View Stock Entry</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/checkingstock" ><span class="title">checking Stock</span></a></li>
			<li><a href="<?php echo base_url(); ?>stockManage_controller/purchaseorder" ><span class="title">Purchase</span></a></li>
    	</ul>
	</li><!--end /menu-li -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-file-text-o"></i></div>
			<span class="title">Colour Management</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="<?php echo base_url(); ?>colourManage_controller/addColour"><span class="title">Add Colour Code</span></a></li>
			<li><a href="<?php echo base_url(); ?>colourManage_controller/viewcolour" ><span class="title">View</span></a></li>
    	</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	<!-- END UI -->
	
	<!-- BEGIN TABLES -->
	
	
	<!-- BEGIN FORMS -->
	
	<!-- BEGIN PAGES -->
	
	<!-- BEGIN CHARTS -->
	
	<!-- END CHARTS -->
	
	<!-- BEGIN LEVELS -->
	<li class="gui-folder">
		<a>
			<div class="gui-icon"><i class="fa fa-folder-open fa-fw"></i></div>
			<span class="title">Demo</span>
		</a>
		<!--start submenu -->
		<ul>
			<li><a href="#"><span class="title">Item 1</span></a></li>
			<li><a href="#"><span class="title">Item 1</span></a></li>
			<li class="gui-folder">
				<a href="javascript:void(0);">
					<span class="title">Open level 2</span>
				</a>
				<!--start submenu -->
				<ul>
					<li><a href="#"><span class="title">Item 2</span></a></li>
					<li class="gui-folder">
						<a href="javascript:void(0);">
							<span class="title">Open level 3</span>
						</a>
						<!--start submenu -->
						<ul>
							<li><a href="#"><span class="title">Item 3</span></a></li>
							<li><a href="#"><span class="title">Item 3</span></a></li>
							<li class="gui-folder">
								<a href="javascript:void(0);">
									<span class="title">Open level 4</span>
								</a>
								<!--start submenu -->
								<ul>
									<li><a href="#"><span class="title">Item 4</span></a></li>
									<li class="gui-folder">
										<a href="javascript:void(0);">
											<span class="title">Open level 5</span>
										</a>
										<!--start submenu -->
										<ul>
											<li><a href="#"><span class="title">Item 5</span></a></li>
											<li><a href="#"><span class="title">Item 5</span></a></li>
										</ul><!--end /submenu -->
									</li><!--end /submenu-li -->
								</ul><!--end /submenu -->
							</li><!--end /submenu-li -->
						</ul><!--end /submenu -->
					</li><!--end /submenu-li -->
				</ul><!--end /submenu -->
			</li><!--end /submenu-li -->
		</ul><!--end /submenu -->
	</li><!--end /menu-li -->
	<!-- END LEVELS -->
	
</ul><!--end .main-menu -->
				<!-- END MAIN MENU -->

				
			</div><!--end .menubar-scroll-panel-->
		</div><!--end #menubar-->
		<!-- END MENUBAR -->
