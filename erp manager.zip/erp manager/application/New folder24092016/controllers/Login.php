<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication'));
		$this->load->model('login_model');
	}
	
	public function index()
	{
		
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']='Dashboard';
	$this->load->view('dashboard',$data);
	}
	public function chk_login()
	{
		$this->load->view('loginscreen');
	}
	public function signin()
	{
		 $username=$this->input->post('user_name');
		 $password=$this->input->post('password');

		$data['user_details']=$this->login_model->fetch_user_data($username,$password);
		//print_r($data['user_details']);
		if(!empty($data['user_details']))
		{
		  foreach($data['user_details'] as $ud)
		  {
		   $user_id=$ud->id;
		   $user_name=$ud->user_name;
		   $user=array(
		    "user_id" => $user_id,
			"user_name" => $user_name
		   );
		   $this->session->set_userdata($user);
		  }
		  //exit;
		  $message='Login Successfully.....';
		  $this->session->set_flashdata('message',$message);
		  redirect('login','refresh');
		}
		else
		{
			$message='Invalid Credential..';
		  $this->session->set_flashdata('message',$message);
		  redirect('login/chk_login','refresh');
		}
	}
	public function signout()
	{	
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$this->session->sess_destroy();
		 redirect('login/chk_login/logout','refresh');
	}
	public function change_password()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['password']=$this->login_model->get_pass($this->session->userdata('user_id'));
		$data['title']="Change Password";
		$this->load->view('change_password',$data);
	}
	
	public function update_password()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$password=base64_encode($this->input->post('new_password'));
		$where=array("id" => $this->session->userdata('user_id'));
		$data=array("password" => $password);
		$this->login_model->update_pass($where,$data);
		$message='Password Updated Successfully.';
		$this->session->set_flashdata('message',$message);
		redirect('login/index/','refresh');
	}
	public function chanpassword()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
	}
	
	
	
}
