<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_hr extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->library('fpdf_gen');
		
		$this->load->model('manage_hr_model');
	}
	public function offer_letter()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Manage HR/Create Offer Letter";
		$data['temempid']=$this->manage_hr_model->gettemp_empcode();
		$data['departments']=$this->manage_hr_model->getalldepartments();
		$data['oferleter']=$this->manage_hr_model->getoferleter();
		$this->load->view('hr/createofferletter',$data);
		
	}
	public function save_offerletter()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$data['title']="Manage HR/Create Offer Letter";
		date_default_timezone_set("Asia/kolkata");
		$name=$this->input->post("name");
		$temid=$this->input->post("tempcode");
		$address=$this->input->post("address");
		$email=$this->input->post("email");
		$departments=$this->input->post("departments");
		$desig=$this->input->post("desig");
		$phone=$this->input->post("phone");
		$dob=$this->input->post("dob");
		$gender=$this->input->post("gender");
		$salary=$this->input->post("salary");
		//$salary=$this->input->post("salary");
		$jod=$this->input->post("jod");
		$prob=$this->input->post("probat");
		$board1=$this->input->post("board1");
		$year1=$this->input->post("year1");
		$qual1=$this->input->post("qual1");
		$grad1=$this->input->post("grad1");
		$exp=$this->input->post("exp");
		$adhar=$this->input->post("adhar");
		$pan=$this->input->post('pan');
		$voter=$this->input->post('voter');
		$newDate=date('Y-m-d', strtotime("+30 days"));
		$data_array=array(
			"temp_id"=>$temid,
			"name"=>$name,
			"address"=>$address,
			"email"=>$email,
			"department"=>$departments,
			"desig"=>$desig,
			"phone"=>$phone,
			"dob"=>$dob,
			"gender"=>$gender,
			"salary"=>$salary,
			"prob"=>$prob,
			"jod"=>$jod,
			"board1"=>$board1,
			"year1"=>$year1,
			"qual1"=>$qual1,
			"grade"=>$grad1,
			"ex_p"=>$exp,
			"adhar"=>$adhar,
			"pan"=>$pan,
			"voter"=>$voter,
			"crtd"=>$this->session->userdata('user_name'),
			"doe"=>date('Y-m-d h:i:s A'),
			"doet"=>$newDate
		);
		$this->manage_hr_model->save_offerletter($data_array);
		redirect('manage_hr/offer_letter',$data);
		//$file1=$_FILES['image1']['name'];
			
		
		
	}
  public function edit_offerletter($id)
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['alldet']=$this->manage_hr_model->getdetail_offerletter($id);
	$data['title']="Manage HR/Edit Offer Letter";
	//$data['temempid']=$this->manage_hr_model->gettemp_empcode();
	$data['departments']=$this->manage_hr_model->getalldepartments();
	$data['oferleter']=$this->manage_hr_model->getoferleter();
	$data['desig']=$this->manage_hr_model->getdesignation();
		
	$this->load->view('hr/createofferletter',$data);
  }
  public function update_offerletter()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$data['title']="Manage HR/Create Offer Letter";
		date_default_timezone_set("Asia/kolkata");
		$name=$this->input->post("name");
		$recordid=$this->input->post("recordid");
		//$temid=$this->input->post("tempcode");
		$address=$this->input->post("address");
		$email=$this->input->post("email");
		$departments=$this->input->post("departments");
		$desig=$this->input->post("desig");
		$phone=$this->input->post("phone");
		$dob=$this->input->post("dob");
		$gender=$this->input->post("gender");
		$salary=$this->input->post("salary");
		//$salary=$this->input->post("salary");
		$jod=$this->input->post("jod");
		$prob=$this->input->post("probat");
		$board1=$this->input->post("board1");
		$year1=$this->input->post("year1");
		$qual1=$this->input->post("qual1");
		$grad1=$this->input->post("grad1");
		$exp=$this->input->post("exp");
		$adhar=$this->input->post("adhar");
		$pan=$this->input->post('pan');
		$voter=$this->input->post('voter');
		
		$data_array=array(
			"name"=>$name,
			"address"=>$address,
			"email"=>$email,
			"department"=>$departments,
			"desig"=>$desig,
			"phone"=>$phone,
			"dob"=>$dob,
			"gender"=>$gender,
			"salary"=>$salary,
			"prob"=>$prob,
			"jod"=>$jod,
			"board1"=>$board1,
			"year1"=>$year1,
			"qual1"=>$qual1,
			"grade"=>$grad1,
			"ex_p"=>$exp,
			"adhar"=>$adhar,
			"pan"=>$pan,
			"voter"=>$voter,
			"crtd"=>$this->session->userdata('user_name'),
			
		);
		$this->manage_hr_model->update_offerletter($data_array,$recordid);
		redirect('manage_hr/offer_letter',$data);
  }
 public function delete_offerletter($id)
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$data['title']="Manage HR/Create Offer Letter";
		date_default_timezone_set("Asia/kolkata");
		$recordid=$id;
		$this->manage_hr_model->delete_offerletter($recordid);
	redirect('manage_hr/offer_letter',$data);
 }
 public function pdfview_offerletter($id)
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	//$data['title']="Manage HR/Create Offer Letter";
	$alldet=$this->manage_hr_model->getdetail_offerletter($id);
	foreach($alldet as $row)
					{
						$id=$row->id;
						$name=$row->name;
						$name=$row->name;
						$temempid=$row->temp_id;
						$add=$row->address;
						$phno=$row->phone;
						$email=$row->email;
						$dept=$row->department;
						$desg=$row->desig;
						$dob=$row->dob;
						$jod=$row->jod;
						$gender=$row->gender;
						$prob=$row->prob;
						$board1=$row->board1;
						$year1=$row->year1;
						$qual1=$row->qual1;
						$grade=$row->grade;
						$ex_p=$row->ex_p;
						$doe=$row->doe;
						$newDate=$row->doet;
						
						
						$salary=$row->salary;
						
						
						
					}
					//$dat=explode(" ",$doe);
					$getdesig=$this->manage_hr_model->getdesigname($desg);
					//$newDate=date('Y-m-d', strtotime("+30 days"));
	$this->fpdf->SetFont('Arial','B',16);
	$ttx="    We are pleased to offer you the position of $getdesig for G.K.RICKSHAW PVT LTD at our Head Office  starting on $jod We propose that the terms of employment will be those in the attached draft individual employment agreement";
	$ttx2="   Please note that you are entitled to discuss this offer and to seek advice on the attached proposed agreement with your family, a union, a lawyer, or someone else you trust. If you would like information about your employment rights, see the Ministry of Business, Innovation and Employment's website or phone the Department's free information line on 1234569870";
	$ttx3="  If you disagree with, do not understand or wish to clarify anything in this offer, please contact me to discuss.";
	$ttx4="  If you are happy with the proposed terms and wish to accept this offer of employment, please sign the duplicate copy of this letter and return it to me by $newDate If I have not heard from you by that date, this offer will be automatically withdrawn.";
	$ttx5="  I, $name, confirm that I have read the terms of employment set out in this letter and in the attached individual employment agreement, that I fully understand them and their implications and that I now accept the offer of employment.	";
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		/*$this->fpdf->SetFont('Arial','b',8);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->ln(30);*/
	$this->fpdf->SetFont('Helvetica','B',20);
	$this->fpdf->ln(35);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(190,10,'Appointment Letter',0,0,'C');
	$this->fpdf->SetFont('Arial','b',10);
    $this->fpdf->ln(10);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"DATE:$doe",0,0,'L');
	$this->fpdf->SetFont('Arial','b',12);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"Mr./Mrs. $name",0,0,'L');
	$this->fpdf->ln(10);
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->cell(7);
	$this->fpdf->multiCell(60,5,"Address-$add");
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"Dear $name",'0','1','TRUE');
	$this->fpdf->SetFont('Arial','B',10);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"Offer for the POST of $getdesig",'0','1','TRUE');
	 $this->fpdf->ln(10);
	$this->fpdf->SetFont('Arial','',10);
	//$this->fpdf->SetXY(18,78);
	$this->fpdf->cell(7);
	
	$this->fpdf->multicell(190,5,"$ttx");
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx2");
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx3");
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx4");
	
	
	
	/*
	$this->fpdf->Cell(35,10,'We are pleased to offer you the position of','0','0','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(94,78);
	$this->fpdf->Cell(25,10,"$getdesig and G.K.RICKSHAW PVT LTD",'0','0','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(158,78);
	$this->fpdf->Cell(5,10,'at','0','0','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(163,78);
	$this->fpdf->Cell(10,10,'our Head Office','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,85);
	$this->fpdf->Cell(10,10,'starting on','0','0','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(39,85);
	$this->fpdf->Cell(10,10,"$jod",'0','0','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(64,85);
	$this->fpdf->Cell(156,10,' We propose that the terms of employment will be those in the attached ','0','0','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,92);
	$this->fpdf->Cell(156,10,'draft individual employment agreement.','0','1','TRUE');
	$this->fpdf->SetXY(18,92);
	
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,102);*/
	/*$this->fpdf->Cell(156,10,'Please note that you are entitled to discuss this offer and to seek advice on the attached prop','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,109);
	$this->fpdf->Cell(156,10,'-osed agreement with your family, a union, a lawyer, or someone else you trust.  If you would ','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,116);
	$this->fpdf->Cell(156,10,'like information about your employment rights,  see the Ministry of Business,  Innovation and ','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,123);
	$this->fpdf->Cell(156,10,"Employment's website or phone the Department's free information line on ",'0','1','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(157,123);
	$this->fpdf->Cell(146,10,'1234569870.','0','1','TRUE');*/
	
	/*$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,133);
	$this->fpdf->Cell(146,10,'If you disagree with,  do not understand or wish to clarify anything in this offer, please contact','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,140);
	$this->fpdf->Cell(146,10,'me to discuss.','0','1','TRUE');
	
	$this->fpdf->SetFont('Arial','',10);*/
	$this->fpdf->cell(7);
	$this->fpdf->Multicell(190,5,'I look forward to working with you.');
	$this->fpdf->SetFont('Arial','',12);
	//this->fpdf->SetXY(18,184);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(156,10,'Yours sincerely,','0','','TRUE');
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->SetFont('Arial','b',12);
	//$this->fpdf->SetXY(18,194);
	$this->fpdf->Cell(156,10,"Gautam Basu, H.R",'0','','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	//$this->fpdf->SetXY(18,200);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(156,10,"and Phno-9874719999",'0','','TRUE');
	$this->fpdf->ln(15);
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx5");
	$this->fpdf->ln(10);
	$this->fpdf->cell(7);
	$this->fpdf->SetFont('Arial','b',12);
	$this->fpdf->Cell(96,10,"Signed by:",'0','','TRUE');
	
	$this->fpdf->SetFont('Arial','b',12);
	//$this->fpdf->SetXY(108,265);
	$this->fpdf->Cell(96,10,"Date:",'0','','TRUE');
	
	
	//$text='I am pleased to offer you the position of position and name of business at insert location starting on insert date. I propose that the terms of employment will be those in the attached draft individual employment agreement.';
	//$nb=$this->fpdf->WordWrap($text,120);
	//$this->fpdf->Write(8,"$text");
	//$data_st=array(
	//	"mailsenddt"=>date('Y-m-d'),
	//	"mailsent"=>1
	//);
	
	
	
	
	//$data['post']="ABCDEF";
	//$data['name']=$name;
	//$data['email']=$email;
	
	//$this->manage_hr_model->update_mailsentst($data_st,$id);
	
	//$filename="Fpdfoutput/offerletter.pdf";
	// $this->fpdf->Output("$filename",'F');
   // $d=$this->load->view("send_mail/appointment_mail",$data);
	//if($d==1)	
		
	//$this->fpdf->Output("$filename",'F');
	$this->fpdf->Output();
	
 }
public function send_offer_letter($id)
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	//$data['title']="Manage HR/Create Offer Letter";
	$alldet=$this->manage_hr_model->getdetail_offerletter($id);
	foreach($alldet as $row)
					{
						$id=$row->id;
						$name=$row->name;
						$name=$row->name;
						$temempid=$row->temp_id;
						$add=$row->address;
						$phno=$row->phone;
						$email=$row->email;
						$dept=$row->department;
						$desg=$row->desig;
						$dob=$row->dob;
						$jod=$row->jod;
						$gender=$row->gender;
						$prob=$row->prob;
						$board1=$row->board1;
						$year1=$row->year1;
						$qual1=$row->qual1;
						$grade=$row->grade;
						$ex_p=$row->ex_p;
						$doe=$row->doe;
						$newDate=$row->doet;
						
						
						$salary=$row->salary;
						
						
						
					}
					//$dat=explode(" ",$doe);
					$getdesig=$this->manage_hr_model->getdesigname($desg);
					//$newDate=date('Y-m-d', strtotime("+30 days"));
	$this->fpdf->SetFont('Arial','B',16);
	$ttx="    We are pleased to offer you the position of $getdesig for G.K.RICKSHAW PVT LTD at our Head Office  starting on $jod We propose that the terms of employment will be those in the attached draft individual employment agreement";
	$ttx2="   Please note that you are entitled to discuss this offer and to seek advice on the attached proposed agreement with your family, a union, a lawyer, or someone else you trust. If you would like information about your employment rights, see the Ministry of Business, Innovation and Employment's website or phone the Department's free information line on 1234569870";
	$ttx3="  If you disagree with, do not understand or wish to clarify anything in this offer, please contact me to discuss.";
	$ttx4="  If you are happy with the proposed terms and wish to accept this offer of employment, please sign the duplicate copy of this letter and return it to me by $newDate If I have not heard from you by that date, this offer will be automatically withdrawn.";
	$ttx5="  I, $name, confirm that I have read the terms of employment set out in this letter and in the attached individual employment agreement, that I fully understand them and their implications and that I now accept the offer of employment.	";
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		/*$this->fpdf->SetFont('Arial','b',8);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->ln(30);*/
	$this->fpdf->SetFont('Helvetica','B',20);
	$this->fpdf->ln(35);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(190,10,'Appointment Letter',0,0,'C');
	$this->fpdf->SetFont('Arial','b',10);
    $this->fpdf->ln(10);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"DATE:$doe",0,0,'L');
	$this->fpdf->SetFont('Arial','b',12);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"Mr./Mrs. $name",0,0,'L');
	$this->fpdf->ln(10);
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->cell(7);
	$this->fpdf->multiCell(60,5,"Address-$add");
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"Dear $name",'0','1','TRUE');
	$this->fpdf->SetFont('Arial','B',10);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(142,10,"Offer for the POST of $getdesig",'0','1','TRUE');
	 $this->fpdf->ln(10);
	$this->fpdf->SetFont('Arial','',10);
	//$this->fpdf->SetXY(18,78);
	$this->fpdf->cell(7);
	
	$this->fpdf->multicell(190,5,"$ttx");
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx2");
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx3");
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx4");
	
	
	
	/*
	$this->fpdf->Cell(35,10,'We are pleased to offer you the position of','0','0','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(94,78);
	$this->fpdf->Cell(25,10,"$getdesig and G.K.RICKSHAW PVT LTD",'0','0','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(158,78);
	$this->fpdf->Cell(5,10,'at','0','0','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(163,78);
	$this->fpdf->Cell(10,10,'our Head Office','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,85);
	$this->fpdf->Cell(10,10,'starting on','0','0','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(39,85);
	$this->fpdf->Cell(10,10,"$jod",'0','0','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(64,85);
	$this->fpdf->Cell(156,10,' We propose that the terms of employment will be those in the attached ','0','0','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,92);
	$this->fpdf->Cell(156,10,'draft individual employment agreement.','0','1','TRUE');
	$this->fpdf->SetXY(18,92);
	
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,102);*/
	/*$this->fpdf->Cell(156,10,'Please note that you are entitled to discuss this offer and to seek advice on the attached prop','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,109);
	$this->fpdf->Cell(156,10,'-osed agreement with your family, a union, a lawyer, or someone else you trust.  If you would ','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,116);
	$this->fpdf->Cell(156,10,'like information about your employment rights,  see the Ministry of Business,  Innovation and ','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,123);
	$this->fpdf->Cell(156,10,"Employment's website or phone the Department's free information line on ",'0','1','TRUE');
	$this->fpdf->SetFont('Arial','b',8);
	$this->fpdf->SetXY(157,123);
	$this->fpdf->Cell(146,10,'1234569870.','0','1','TRUE');*/
	
	/*$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,133);
	$this->fpdf->Cell(146,10,'If you disagree with,  do not understand or wish to clarify anything in this offer, please contact','0','1','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->SetXY(18,140);
	$this->fpdf->Cell(146,10,'me to discuss.','0','1','TRUE');
	
	$this->fpdf->SetFont('Arial','',10);*/
	$this->fpdf->cell(7);
	$this->fpdf->Multicell(190,5,'I look forward to working with you.');
	$this->fpdf->SetFont('Arial','',12);
	//this->fpdf->SetXY(18,184);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(156,10,'Yours sincerely,','0','','TRUE');
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->SetFont('Arial','b',12);
	//$this->fpdf->SetXY(18,194);
	$this->fpdf->Cell(156,10,"Gautam Basu, H.R",'0','','TRUE');
	$this->fpdf->SetFont('Arial','',10);
	//$this->fpdf->SetXY(18,200);
	$this->fpdf->ln(5);
	$this->fpdf->cell(7);
	$this->fpdf->Cell(156,10,"and Phno-9874719999",'0','','TRUE');
	$this->fpdf->ln(15);
	$this->fpdf->SetFont('Arial','',10);
	$this->fpdf->cell(7);
	$this->fpdf->multicell(190,5,"$ttx5");
	$this->fpdf->ln(10);
	$this->fpdf->cell(7);
	$this->fpdf->SetFont('Arial','b',12);
	$this->fpdf->Cell(96,10,"Signed by:",'0','','TRUE');
	
	$this->fpdf->SetFont('Arial','b',12);
	//$this->fpdf->SetXY(108,265);
	$this->fpdf->Cell(96,10,"Date:",'0','','TRUE');
	
	
	//$text='I am pleased to offer you the position of position and name of business at insert location starting on insert date. I propose that the terms of employment will be those in the attached draft individual employment agreement.';
	//$nb=$this->fpdf->WordWrap($text,120);
	//$this->fpdf->Write(8,"$text");
	
	
	
	
	$data['post']="ABCDEF";
	$data['name']=$name;
	$data['email']=$email;
	
	
	$filename="Fpdfoutput/offerletter.pdf";
	 $this->fpdf->Output("$filename",'F');
    $this->load->view("send_mail/appointment_mail",$data);
	$data_st=array(
		"mailsenddt"=>date('Y-m-d'),
		"mailsent"=>1
	);
	$this->manage_hr_model->update_mailsentst($data_st,$id);
	redirect('manage_hr/offer_letter',$data);
	//if($d==1)	
		
	//$this->fpdf->Output("$filename",'F');
	//$this->fpdf->Output();
	
 }

//------------------------------------------------------------------------------------//
//                      Set Sales Head                                                //
//------------------------------------------------------------------------------------//
public function set_saleshead()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Employee Head Schedule";
	$data['allemp']=$this->manage_hr_model->getallemplist();
	$data['desig']=$this->manage_hr_model->getalldesig();
	$data['getallsales_ex']=$this->manage_hr_model->getallsalesexcu();
	$this->load->view('hr/setsaleshead',$data);
}
public function get_empname()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$desig=$this->input->post("desig");
	$getallemp=$this->manage_hr_model->getallemp_list($desig);
	if(!empty($getallemp) && isset($getallemp))
	{
		echo '<option value=""></option>';
		foreach($getallemp as $row)
		{
			echo '<option value="'.$row->id.'">'.$row->name.'&nbsp;&nbsp;'.$row->salesmanid.'  </option>';
		}
	}
	else {
		echo '<option value=""></option>';
	}
	
}
public function get_all_salesex()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$empcod=$this->input->post("empcode");
	$getallsale1=$this->manage_hr_model->getall_salesex($empcod);
	$getallsale=$this->manage_hr_model->get_allsalesex($empcod);
   $sl=1;
	if(isset($getallsale1) && !empty($getallsale1))
	{
		
		foreach($getallsale1 as $row)
		{
			$img=$row->image;
			echo '<div class="col-lg-3 col-sm-6">
												<div class="card">
												<div class="card-head card-head-xs style-primary">
													<header>'.strtoupper($row->name).' ('.$row->salesmanid.')</header>
													<div class="tools">
														<a class="btn btn-icon-toggle btn-close"></a>
													</div>
												</div><!--end .card-head -->
												<div class="card-body">
													<center><img src="';
													
													if($img==""){
														
													
													echo  base_url().'uploads/Salesman/'.$img;
													}else{
															
														echo base_url().'assets/img/man-icon.png';
													}
													echo '" width="100" height="100" style="border-radius: 50%;"/></center>
													<br>
													 <table>
													 	<tr>
													 		<td><b>Name:</b></td>
													 		<td>'.strtoupper($row->name).'</td>
													 	</tr>
													 	<tr>
													 		<td><b>Contacts:</b></td>
													 		<td>'.strtoupper($row->phno).'</td>
													 	</tr>
													 	<tr>
													 		<td><b>Area:</b></td>
													 		<td>'.$row->area.'</td>
													 	</tr><tr>
													 		<td><b>Total Leads:</b></td>
													 		<td></td>
													 	</tr>
													 </table>
													  
													<blockquote><small>Joined on '.$row->doe.'</small></blockquote>
													<br>
													<center>
														<label class="checkbox-inline checkbox-styled checkbox-success">
															<input type="checkbox"  checked="" name="execitive_'.$sl.'" value="'.$row->id.'" ><span></span>
															<input type="hidden" name="exn_'.$sl.'" value="'.$row->id.'"/>
														</label>
												    </center>
												</div><!--end .card-body -->
											</div><!--end .card -->
										</div>	';
										$sl++;
		}
	}else
		{
			echo "";
		}
  if(isset($getallsale) && !empty($getallsale))
  {
  	foreach($getallsale as $row)
	{
		$img=$row->image;
		echo '<div class="col-lg-3 col-sm-6">
												<div class="card">
												<div class="card-head card-head-xs style-primary">
													<header>'.strtoupper($row->name).' ('.$row->salesmanid.')</header>
													<div class="tools">
														<a class="btn btn-icon-toggle btn-close"></a>
													</div>
												</div><!--end .card-head -->
												<div class="card-body">
													<center><img src="';
													if($img==""){
														
													
													echo  base_url().'uploads/Salesman/'.$img;
													}else{
															
														echo base_url().'assets/img/man-icon.png';
													}
													echo'" width="100" height="100" style="border-radius: 50%;"/></center>
													<br>
													 <table>
													 	<tr>
													 		<td><b>Name:</b></td>
													 		<td>'.strtoupper($row->name).'</td>
													 	</tr>
													 	<tr>
													 		<td><b>Contacts:</b></td>
													 		<td>'.strtoupper($row->phno).'</td>
													 	</tr>
													 	<tr>
													 		<td><b>Area:</b></td>
													 		<td>'.$row->area.'</td>
													 	</tr><tr>
													 		<td><b>Total Leads:</b></td>
													 		<td></td>
													 	</tr>
													 </table>
													  
													<blockquote><small>Joined on '.$row->doe.'</small></blockquote>
													<br>
													<center>
														<label class="checkbox-inline checkbox-styled checkbox-success">
															<input type="checkbox" name="execitive_'.$sl.'"  value="'.$row->id.'"  ><span></span>
															<input type="hidden" name="exn_'.$sl.'" value="'.$row->id.'"/>
														</label>
												    </center>
												</div><!--end .card-body -->
											</div><!--end .card -->
										</div>	';
										$sl++;
	}
  }else
  	{
  		echo "";
  	}
	echo '<input type="hidden" name="tot_row" value="'.$sl.'" />';
    
}
public function save_emphead()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	
	 $emphd=$this->input->post("empname");
	//$getallsalelist=$this->manage_hr_model->getallsalesexecu($emphd);
	 $tot_tr=intval($this->input->post("tot_row"));
	//print_r($getallsalelist);
	for($tr=1;$tr<intval($tot_tr);$tr++)
	{
		 $execitive=$this->input->post("execitive_".$tr);
		if(isset($execitive) && !empty($execitive))
		{
			$data_arr=array("hod"=>$emphd);
			$this->manage_hr_model->update_sale_hd($data_arr,$execitive);
		}else{
			  $exn=$this->input->post("exn_".$tr);
			$data_arr=array("hod"=>0);
			$this->manage_hr_model->update_sale_hd($data_arr,$exn);
			
		}
         
		
	}
	
	 
	
		
		redirect('Manage_hr/set_saleshead','refresh');
	
	//$nonex
}
	public function generate_payslip()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Payslip Generation";
		$data['getallemp']=$this->manage_hr_model->getall_emplist();
		$data['getallemppayslip']=$this->manage_hr_model->getallpayslip();
		$this->load->view('hr/generate_payslip',$data);
		
		
		
	}
  public function save_payslipdata()
  {
  	 $this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $data['title']="adasd";
	 $monthcode=intval($this->input->post("month"));
	 $yr=intval($this->input->post("year"));
	 $tr=intval($this->input->post("totrow"));
	 for($k=1;$k<intval($tr) ; $k++)
	 {
	 	$empid=$this->input->post("empid_".$k);
		$basic=floatval($this->input->post("basic_".$k));
		$pf=$this->input->post("pf_".$k);
		$esi=$this->input->post("esi_".$k);
		$ptax=$this->input->post("ptax_".$k);
		$ta=$this->input->post("ta_".$k);
		$da=$this->input->post("da_".$k);
		$otralw=$this->input->post("othra_".$k);
		$incentive=$this->input->post("incentive_".$k);
		$wrk=$this->input->post("wrk_".$k);
		$leave=$this->input->post("leave_".$k);
		$holyday=$this->input->post("holyday_".$k);
		$otdeduct=$this->input->post("otdeduct_".$k);
		$nettot=floatval($this->input->post("nettot_".$k));
		if(floatval($basic)>0)
		{
			
			$data_array=array(
				"empid"=>$empid,
				"basicsal"=>$basic,
				"incentive"=>$incentive,
				"pf"=>$pf,
				"esi"=>$esi,
				"ptax"=>$ptax,
				"ta"=>$ta,
				"da"=>$da,
				"otheralwn"=>$otralw,
				"gross"=>$nettot,
				"mnthcode"=>$monthcode,
				"yrcode"=>$yr,
				"otherdeduct"=>$otdeduct,
				"workingdays"=>$wrk,
				"holiday"=>$holyday,
				"tot_leave"=>$leave,
				"crtdby"=>$this->session->userdata('user_name'),
				"doe"=>date('Y-m-d h:i:s A'),
				"dos"=>date('Y-m-d')
			
			
			
			);
			$get_data_existornt=$this->manage_hr_model->getpaysllepdata($empid,$monthcode,$yr);
			if(empty($get_data_existornt))
			{
				 $this->manage_hr_model->save_paysleep_data($data_array);
			}
			
		}
		
		
	 }
  redirect('Manage_hr/generate_payslip','refresh');
	 
	 
		
  }
  public function update_payslip()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $data['title']="adasd";
	   $empid=$this->input->post("empid");
		$basic=floatval($this->input->post("basic"));
		$pf=$this->input->post("pf");
		$esi=$this->input->post("esi");
		$ptax=$this->input->post("ptax");
		$incentive=$this->input->post("incentive");
		$wrk=$this->input->post("wrk");
		$leave=$this->input->post("leave");
		$holyday=$this->input->post("holyday");
		$otdeduct=$this->input->post("otdeduct");
		$nettot=floatval($this->input->post("nettot"));
		$ta=$this->input->post("ta");
		$da=$this->input->post("da");
		$othra=$this->input->post("otheralw");
		
	 $data_array=array(
				"basicsal"=>$basic,
				"incentive"=>$incentive,
				"pf"=>$pf,
				"esi"=>$esi,
				"ptax"=>$ptax,
				"ta"=>$ta,
				"da"=>$da,
				"otheralwn"=>$othra,
				"gross"=>$nettot,
				"otherdeduct"=>$otdeduct,
				"workingdays"=>$wrk,
				"holiday"=>$holyday,
				"tot_leave"=>$leave,
				"crtdby"=>$this->session->userdata('user_name'),
				"doe"=>date('Y-m-d h:i:s A'),
				"dos"=>date('Y-m-d')
			
			
			
			);
			$this->manage_hr_model->update_payslip($data_array,$empid);
			redirect('Manage_hr/generate_payslip','refresh');
	
  }
  
  public function get_monthnam()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	
	$hr=intval($this->input->post('yr'));
	$getallmonthlist=$this->manage_hr_model->getmonthlist($hr);
	if(isset($getallmonthlist) && !empty($getallmonthlist))
	{
		 echo '  <option value="">--Select--</option>' . PHP_EOL;
		foreach($getallmonthlist as $row)
		{
			$mnth=intval($row->mnth);
			 echo '  <option value="' . $mnth . '">' . date('F', mktime(0,0,0,$mnth)) . '</option>' . PHP_EOL;
											  
		}
	}else{
		echo '  <option value="">--Select--</option>' . PHP_EOL;
	}
  }
  public function print_payslip()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$empid=$this->input->post("empid");
	$month=$this->input->post("month");
	$year=$this->input->post("year");
	$data['getalld']=$this->manage_hr_model->getall_data($empid,$month,$year);
	$this->load->view('hr/print_payslip_pdf',$data);
	
  }
   
	



}