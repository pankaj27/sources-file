<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manufactarer_Controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		//$this->load->library(array('session','authentication'));
		$this->load->model('Manufactarer_model');
		$this->data = array(
            'pre_id' =>8,
           
        );
	}
	public function  craeteModel()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Manufacturer';
		$data['modellist']=$this->Manufactarer_model->getallmodel();
		//$data['getcolor']=$this->Manufactarer_model->getallcolor();
		$this->load->view('Manufacturer/create',$data);
	}
	public function getchasis()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Get Chasis Details';
		date_default_timezone_set('Asia/kolkata');
		$dte=$this->input->post("datename");
		$model=$this->input->post("model");
		$color=$this->input->post("color");
		$qty=$this->input->post("qty");
		
		$mnth=date('m');
		$getmonthcode=$this->Manufactarer_model->getmnthcode($mnth);
		$yr=date('Y');
		$yrt=date('y');
		//$data['modellist']=$this->Manufactarer_model->getallmodel();
		$getchasisno=$this->Manufactarer_model->getallchasisdt($yr,$getmonthcode);
		if(!empty($getchasisno)){
			
			foreach($getchasisno as $row3)
			{
				$chasisno=$row3->chasisno;
			}
			
			$data['chasisdetails']=$chasisno;
			$data['mnthcode']=$getmonthcode;
			$data['yrcode']=$yrt;
			//$chasisid=intval(substr($chasisno, -4));
			//echo $chasisid
			
		}else{
			$data['chasisdetails']="M6REP3085".$getmonthcode.$yrt."B0000";
			$data['mnthcode']=$getmonthcode;
			$data['yrcode']=$yrt;
		}
		$data['dte']=$dte;
		$data['model']=$model;
		$data['color']=$color;
		$data['qty']=$qty;
		$data['modellist']=$this->Manufactarer_model->getallmodel();
		//$data['getlast']
		$this->load->view('Manufacturer/create',$data);
		
	}
	public function printWriteForm()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Print Write Form';
		date_default_timezone_set('Asia/kolkata');
		$dte=$this->input->post("date");
		$mnthcode=$this->input->post("mnthcode");
		$yrcode=$this->input->post("yrcode");
		$chasisno=$this->input->post("chasisno");
		$qty=$this->input->post("qty");
		$orderno=$this->input->post("orderno");
		$model=$this->input->post("model");
		$date=date('d-m-Y h:i:s A');
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		//$this->fpdf->Addpage('legal');
		$this->fpdf->Image("$path",10,10,-300);
		
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->Text(130,45,"Date:$date");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,54,200,54);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,55,200,55);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		//$this->fpdf->Ln($y);
		//$this->fpdf->Ln(30);
		$this->fpdf->ln($y+40);
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Cell(190,10,"SET CONTROLLER ,MOTOR,CHASIS NO ",0,0,'C');	
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,10,"ORDER NO: $orderno ",0,0,'L');	
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,10,"QNTY:  $qty",0,0,'L');	
		
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',8);
		$this->fpdf->cell(10,5,"SL",1,0,'C');
		$this->fpdf->cell(12,5,"MODEL",1,0,'C');
		$this->fpdf->cell(30,5,"CHS NO",1,0,'C');
		$this->fpdf->cell(30,5,"CTRL NO",1,0,'C');
		$this->fpdf->cell(28,5,"MTR NO",1,0,'C');
		$this->fpdf->cell(19,5,"BTR1",1,0,'C');
		$this->fpdf->cell(19,5,"BTR2",1,0,'C');
		$this->fpdf->cell(19,5,"BTR3",1,0,'C');
		$this->fpdf->cell(19,5,"BTR4",1,1,'C');
		$chasisd=$chasisno;
		$lastfid=intval(substr($chasisd,-4));
		$lastid1=intval($lastfid)+1;
							   
		for($i=0;$i<intval($qty);$i++)
		{
			$sl=$i+1;
			$chasisnonew="M6REP3085".$mnthcode.$yrcode."B".str_pad($lastid1,4 ,'0',STR_PAD_LEFT);
			$this->fpdf->SetFont('Arial','',7);
			/*$this->fpdf->cell(10,10,"$sl",1,0,'C');
			$this->fpdf->cell(12,10,"$model",1,0,'C');
			$this->fpdf->cell(30,10,"$chasisnonew",1,0,'C');
			$this->fpdf->cell(30,10,"",1,0,'C');
			$this->fpdf->cell(28,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,0,'C');
			$this->fpdf->cell(19,10,"",1,1,'C');*/
			$this->fpdf->setwidths(array(10,12,30,30,28,19,19,19,19));
			$this->fpdf->row(array("$sl","$model","$chasisnonew","","","","","",""));
			$lastid1++;
			
			
		}
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		
		 $this->fpdf->Output();
	} 
   public function viewmanufactlist()
   {
   	  $this->authentication->is_loggedin($this->session->userdata('user_name'));
			//$userprev=$this->session->userdata('pre_vlg');
			//$moduleid=$this->data['pre_id'];
			$data['title']="Manufacturer Order List"; 
			//if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				$data['orderlst']=$this->Manufactarer_model->getrecentorderlist();
				$this->load->view('Manufacturer/viewmanufactorder',$data);
			
			//}else{
				//redirect('Login','refresh');
			//}
		
   }
   public function generatecontrollerno($id)
   {
   		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['qnty']=$this->Manufactarer_model->get_qntylist($id);
		if(!empty($data['qnty']))
		{
		foreach($data['qnty'] as $row2)
		{
			$qty=$row2->qnty;
			$orderno=$row2->orderno;
			$model=$row2->model;
		}
		$data['mdl']=$model;
		
		$data['orderno']=$orderno;
		$data['model']=$this->Manufactarer_model->getmodelname($model);
		$data['title']='Create Chasis Details';
		date_default_timezone_set('Asia/kolkata');
		//$dte=$this->input->post("datename");
		//$model=$this->input->post("model");
		//$color=$this->input->post("color");
		//$qty=$this->input->post("qty");
		
		$mnth=date('m');
		$getmonthcode=$this->Manufactarer_model->getmnthcode($mnth);
		$yr=date('Y');
		$yrt=date('y');
		//$data['modellist']=$this->Manufactarer_model->getallmodel();
		$getchasisno=$this->Manufactarer_model->getallchasisdt($yr,$getmonthcode);
		if(!empty($getchasisno)){
			
			foreach($getchasisno as $row3)
			{
				$chasisno=$row3->chasisno;
			}
			
			$data['chasisdetails']=$chasisno;
			$data['mnthcode']=$getmonthcode;
			$data['yrcode']=$yrt;
			//$chasisid=intval(substr($chasisno, -4));
			//echo $chasisid
			
		}else{
			$data['chasisdetails']="M6REP3085".$getmonthcode.$yrt."B0000";
			$data['mnthcode']=$getmonthcode;
			$data['yrcode']=$yrt;
		}
		//$data['dte']=$dte;
		//$data['model']=$model;
		//$data['color']=$color;
		$data['qty']=$qty;
		//$data['modellist']=$this->Manufactarer_model->getallmodel();
		//$data['getlast']
		//$this->load->view('Manufacturer/create',$data);
		$this->load->view('Manufacturer/create_chasiscode',$data);
		}else
			{
				redirect('Manufactarer_Controller/viewmanufactlist','refresh');
			}
	
   }
  public function sacechasisdetails()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$tablrow=$this->input->post("tablrow");
		date_default_timezone_set("Asia/kolkata");
		if(isset($tablrow) && !empty($tablrow))
		{
			for($it=1;$it<intval($tablrow);$it++)
			{
				$orderno=$this->input->post("orderno_".$it);
				$model=$this->input->post("modelname_".$it);
				$chasisno=$this->input->post("chasisno_".$it);
				$cntrlno=$this->input->post("cntrlno_".$it);
				if(isset($cntrlno)&& !empty($cntrlno)){
					$cntrlno=$cntrlno;
				}else
				{
						$cntrlno="";
				}
				$motorno=$this->input->post("motorno_".$it);
				if(isset($motorno) && !empty($motorno))
				{
					$motorno=$motorno;
				}else
				{
						$motorno="";
				}
				$btr1=$this->input->post("btr1_".$it);
				if(isset($btr1) && !empty($btr1))
				{
					$btr1=$btr1;
				}else{
					$btr1="";
				}
				$btr2=$this->input->post("btr2_".$it);
				if(isset($btr2) && !empty($btr2))
				{
					$btr2=$btr2;
				}else{
					$btr2="";
				}
				$btr3=$this->input->post("btr3_".$it);
				if(isset($btr3) && !empty($btr3))
				{
					$btr3=$btr3;
				}else{
					$btr3="";
				}
				$btr4=$this->input->post("btr4_".$it);
				if(isset($btr4) && !empty($btr4))
				{
					$btr4=$btr4;
				}else{
					$btr4="";
				}
				$mnthcode=$this->input->post("mnthcode_".$it);
				$yrcod=$this->input->post("yrcode_".$it);
				$manfyr=$this->input->post("manfyr_".$it);
				if(isset($cntrlno) && isset($chasisno)&& isset($motorno))
				{
					$data_array=array(
						"orderno"=>$orderno,
						"monthcode"=>$mnthcode,
						"yearcode"=>$yrcod,
						"manfYr"=>$manfyr,
						"chasisno"=>$chasisno,
						"motorno"=>$motorno,
						"controlerno"=>$cntrlno,
						"batteryno1"=>$btr1,
						"batteryno2"=>$btr2,
						"batteryno3"=>$btr3,
						"batteryno4"=>$btr4,
						"doe"=>date('Y-m-d'),
						"model"=>$model,
						"qty"=>"1",
						"crtd"=>$this->session->userdata('user_name')
						
					
					);
					$this->Manufactarer_model->save_manufactred_item($data_array);
				}
			}
            $data_array_update=array(
				"status"=>1,
				
			);
			$this->Manufactarer_model->update_req_manf($data_array_update,$orderno);
            $data_array_booking_status=array(
		   	"getpassstatus"=>"1"
		   );
			$this->Manufactarer_model->updategetpassstatus($data_array_booking_status,$orderno);
			
		}
       //redirect('Manufactarer_Controller/viewmanufactlist','refresh');
  }
	public function available_car()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['getreadycar']=$this->Manufactarer_model->getready_car();
	
	
	}
	public function print_getpass()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$order=$this->input->post("orderid");
		$getorderdetails=$this->Manufactarer_model->gettotal_orderdetails($order);
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		//$this->fpdf->Addpage('legal');
		//$this->fpdf->Image("$path",10,10,-300);
		
		/*$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->Text(130,45,"Date:");
		$this->fpdf->SetFont('Arial','B',12);
		//$this->fpdf->Line(10,54,200,54);
		//$this->fpdf->SetFont('Arial','',10);
		//$this->fpdf->Line(10,55,200,55);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		//$this->fpdf->Ln($y);
		//$this->fpdf->Ln(30);
		$this->fpdf->ln($y+40);
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Cell(190,10,"SET CONTROLLER ,MOTOR,CHASIS NO ",0,0,'C');	
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,10,"ORDER NO:  ",0,0,'L');	
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,10,"QNTY:  ",0,0,'L');	
		*/
		if(isset($getorderdetails) && !empty($getorderdetails))
		{
			foreach($getorderdetails as $row)
			{
				$bkid=$row->bokingid;
				$customercode=$row->custid;
				
			}
			$do=date('d-M-Y h:i:s A');
		}
		$getcustdetails=$this->Manufactarer_model->getcustdetails($customercode);
		foreach($getcustdetails as $rowc){ $custname=$rowc->name;$custyp=$rowc->custtype; }
		$add="30(33/1) N.T Road, Padmabati Colony ,Baidyabati, Hooghly,West Bengal-712222, India,     Phone No:033-64517771,Whatsapp No: 9804267746";
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(190,10,"G.K RICKSHOW",0,0,'C')	;
		$this->fpdf->ln(5);
		$this->fpdf->cell(150);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(40,5,"COPY 1",1,0,'R')	;
		$this->fpdf->ln(10);
		$this->fpdf->setwidths(array(63,63,64));
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->SetAligns(array("C","C","L"));	
		//$this->fpdf->text
		
		$this->fpdf->Row(array($this->fpdf->Image("$path",13,23,80,100),"INTERNAL GETPASS","$add"));	
		///new row
		$this->fpdf->setwidths(array(20,30,20,60,20,40));
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetAligns(array("L","L","L","L","L","L"));	
		
		$this->fpdf->Row(array("Booking ID","$bkid","Cust ID","$customercode","DATE","$do"));
		$this->fpdf->setwidths(array(30,100,30,30));
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetAligns(array("L","L","L","L"));	
		
		$this->fpdf->Row(array("CUST NAME","$custname","TYPE","$custyp"));
		
		$this->fpdf->setwidths(array(20,40,80,20,30));
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetAligns(array("C","C","C","C","C","C"));	
		$this->fpdf->Row(array("Sl No","Model","Particulars","Qnty","Remarks"));
		if(isset($getorderdetails) && !empty($getorderdetails))
		{
			$sl=1;
			foreach($getorderdetails as $row)
			{
				$this->fpdf->SetFont('Arial','I',10);
				$this->fpdf->setwidths(array(20,40,80,20,30));
				$this->fpdf->SetAligns(array("C","C","C","C","C","C"));	
				$part=$row->particulars;
				$partex=explode("(",$part);
				$particular=$partex[0];
				$model=rtrim($partex[1],")");
				$qnty=$row->qnty;
				$this->fpdf->Row(array("$sl","$model","$particular","$qnty",""));
		
				$sl++;
			}
			if($sl<5)
			{
				for($it=$sl;$it<=5;$it++)
				{
					$this->fpdf->SetFont('Arial','I',10);
					$this->fpdf->setwidths(array(20,40,80,20,30));
				$this->fpdf->SetAligns(array("C","C","C","C","C","C"));	
				$this->fpdf->Row(array("$it","","","",""));
		
				}
			}
			
		}
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->ln(5);
		$this->fpdf->cell(190,10,"Note:-This getpass used for internal purpose",0,0,'L');
		$this->fpdf->ln(7);
		
	     $this->fpdf->SetFont('Arial','I',10);
		 $this->fpdf->setwidths(array(140,50));
	     $this->fpdf->SetAligns(array("L","L"));	
	    $this->fpdf->Row(array("Prepaired by/checked by","PASS IN/OUT"));
		$this->fpdf->Row(array("",""));
		$this->fpdf->ln(25);
		$getx=$this->fpdf->getx();
		$gety=$this->fpdf->getY();
		//$this->fpdf->SetLineWidth(0.1);
		//$this->fpdf->SetDash(2,2); //5mm on, 5mm off
		$this->fpdf->Line($getx,$gety,199,$gety);
		$this->fpdf->ln(10);
		$add="30(33/1) N.T Road, Padmabati Colony ,Baidyabati, Hooghly,West Bengal-712222, India,     Phone No:033-64517771,Whatsapp No: 9804267746";
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(190,10,"G.K RICKSHOW",0,0,'C')	;
		$this->fpdf->ln(5);
		$this->fpdf->cell(150);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(40,5,"COPY 2",1,0,'R')	;
		$this->fpdf->ln(10);
		$this->fpdf->setwidths(array(63,63,64));
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->SetAligns(array("C","C","L"));	
		//$this->fpdf->text
		
		$this->fpdf->Row(array($this->fpdf->Image("$path",$getx+5,$gety+23,80,100),"INTERNAL GETPASS","$add"));	
		///new row
		$this->fpdf->setwidths(array(20,30,20,60,20,40));
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetAligns(array("L","L","L","L","L","L"));	
		
		$this->fpdf->Row(array("Booking ID","$bkid","Cust ID","$customercode","DATE","$do"));
		$this->fpdf->setwidths(array(30,100,30,30));
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetAligns(array("L","L","L","L"));	
		
		$this->fpdf->Row(array("CUST NAME","$custname","TYPE","$custyp"));
		
		$this->fpdf->setwidths(array(20,40,80,20,30));
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetAligns(array("C","C","C","C","C","C"));	
		$this->fpdf->Row(array("Sl No","Model","Particulars","Qnty","Remarks"));
		if(isset($getorderdetails) && !empty($getorderdetails))
		{
			$sl=1;
			foreach($getorderdetails as $row)
			{
				$this->fpdf->SetFont('Arial','I',10);
				$this->fpdf->setwidths(array(20,40,80,20,30));
				$this->fpdf->SetAligns(array("C","C","C","C","C","C"));	
				$part=$row->particulars;
				$partex=explode("(",$part);
				$particular=$partex[0];
				$model=rtrim($partex[1],")");
				$qnty=$row->qnty;
				$this->fpdf->Row(array("$sl","$model","$particular","$qnty",""));
		
				$sl++;
			}
			if($sl<5)
			{
				for($it=$sl;$it<=5;$it++)
				{
					$this->fpdf->SetFont('Arial','I',10);
					$this->fpdf->setwidths(array(20,40,80,20,30));
				$this->fpdf->SetAligns(array("C","C","C","C","C","C"));	
				$this->fpdf->Row(array("$it","","","",""));
		
				}
			}
			
		}
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->ln(5);
		$this->fpdf->cell(190,10,"Note:-This getpass used for internal purpose",0,0,'L');
		$this->fpdf->ln(7);
		
	     $this->fpdf->SetFont('Arial','I',10);
		 $this->fpdf->setwidths(array(140,50));
	     $this->fpdf->SetAligns(array("L","L"));	
	    $this->fpdf->Row(array("Prepaired by/checked by","PASS IN/OUT"));
		$this->fpdf->Row(array("",""));
		$this->fpdf->ln(10);
		$getx=$this->fpdf->getx();
		$gety=$this->fpdf->getY();
		//$this->fpdf->SetLineWidth(0.1);
		//$this->fpdf->SetDash(2,2); //5mm on, 5mm off
		$this->fpdf->Line($getx,$gety,199,$gety);
		
		
					   
				   
		
		 $this->fpdf->Output();
		
	}
}