<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forcast_planing_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Forcast_planing_model');
	}
	
}