<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bokking_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		//$this->load->library('fpdf_geninvoice');
		
		//$this->load->library('numbertowords');
		$this->load->model('Booking_model');
		$this->load->model('AccountManage_model');
		//$this->load->model('Sales_Model');
		//$this->load->model('stockManage_model');
	}
	public function createretailbooking()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Accounts";
	$data['models']=$this->AccountManage_model->getallmodel();
	$invoice=$this->AccountManage_model->getlastinvoice();
	if(!empty($invoice))
	{
		//$invoiceid=explode("/",$invoice);
		$invoiceid=substr($invoice,-5);
		$invoid=intval($invoiceid);
		$invoid=intval($invoid)+1;
		$invoid2=str_pad($invoid,5,"0",STR_PAD_LEFT);
		$dt=date('y');
		$data['invoice']="GKINV".$dt."$invoid2";
	}else
		{
			$dt=date('y');
			$data['invoice']="GKINV".$dt."0001";
		}
	$getlastorder=$this->AccountManage_model->getlastorder();
	if(!empty($getlastorder))
	{
		$bkid=intval(substr($getlastorder,-5));
		$bkid=$bkid+1;
		$bkid2=str_pad($bkid,5,"0",STR_PAD_LEFT);
		$data['booking']="GKSLSBK$bkid2";
	}else
	{
		$data['booking']="GKSLSBK00000";	
			
	}
	$data['bankdetails']=$this->Booking_model->getallbankdetails();
	$this->load->view("booking/creatretailbook",$data);
	}
	public function gettablelist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$model=$this->input->post("model");
		$getmodelprice=$this->Booking_model->getmodelmrprice($model);
		if(!empty($getmodelprice) && !empty($getmodelprice))
		{
			foreach($getmodelprice as $rowmrp)
			{
				$mrpmodel=floatval($rowmrp->mainpr);
			}
		}else{
			$mrpmodel=0;
		}
		$getexcise=$this->Booking_model->getexcise();
		if(!empty($getexcise) && !empty($getexcise))
		{
			foreach($getexcise as $rowexcise)
			{
				$excise=floatval($rowexcise->exciswamnt);
				$cst=floatval($rowexcise->cstamnt);
				$vatamnt=floatval($rowexcise->vatamnt);
			}
		}else
		{
			$excise=0;	
		}
		$reqty=intval($this->input->post("reqty"));
		$battery=floatval($this->input->post("battery"));
		$charger=floatval($this->input->post("charger"));
		$unitprice=floatval($mrpmodel)+floatval($battery)+floatval($charger);
		if($battery>0 && $charger>0)
		{
			$txt="(with battery & charger)";
		}
		if($battery>0 && $charger==0 )
		{
			$txt="(with battery )";
		}
		if($battery==0 && $charger>0 )
		{
			$txt="(with  charger)";
		}
		if($battery==0 && $charger==0 )
		{
			$txt="(without battery & charger)";
		}
		if($battery==999999){$battery=0;}
		if($charger==999999){$charger=0;}
		$unitprice=floatval($mrpmodel)+floatval($battery)+floatval($charger);
		//echo $unitprice;
		/*for($sl=1;$sl<=$reqty;$sl++)
		{
			
		} */
		$tottalpr=floatval($unitprice)*$reqty;
		$result=array();
		$result=array("particulars"=>"E-Rickshaw($model)","excise"=>"$excise","cst"=>"$cst","vat"=>$vatamnt,"txt"=>"$txt","qty"=>"$reqty","unitpr"=>"$unitprice","total"=>"$tottalpr");
		echo json_encode($result);
		
	}
 //##########################################  save Booking ########################################
    public function savebooking()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		$bookingid=$this->input->post("invoicno");
		$bookingdate=$this->input->post("orderdate");
		
		$custame=$this->input->post("custname");
		$custid=$this->input->post("custid");
		$add1=$this->input->post("add1");
		$add2=$this->input->post("add2");
		$custtyp=$this->input->post("custtyp");
		$email=$this->input->post("email");
		$phnono=$this->input->post("phnono");
		$voterid=$this->input->post("voterid");
		$panno=$this->input->post("panno");
		$vattin=$this->input->post("vattin");
		$cst=$this->input->post("cst");
		$pin=$this->input->post("pin");
		$deposit=floatval($this->input->post("deposit"));
		$purpose=$this->input->post("purpose");
		$paymentmode=$this->input->post("paymentmode");
		$chqno=$this->input->post("chqno");
		$bankname=$this->input->post("bankname");
		$branch=$this->input->post("branch");
		$delivary=$this->input->post("delivary");
		$cattyp=$this->input->post("cattyp");
		$mname=$this->input->post("mname");
		$reqty=$this->input->post("reqty");
		if(strtoupper($cattyp)=="PRODUCT")
		{
			$excise=$this->input->post("excise");
			$exciseamnt=$this->input->post("exciseamnt");
			$cst=$this->input->post("cstvat");
			$cstexplode=explode("@",$cst);
			$cst1=$cstexplode[0];
			$csttx=$cstexplode[1];
			$cstamnt=$this->input->post("cstv");
			$nettl=$this->input->post("nettl");
			$netassval=$this->input->post("netassval");
			 $colorrow=intval($this->input->post("colorrow"));
			$codenname="";
			for($c=1;$c<=$colorrow;$c++)
			{
				$colorcode=$this->input->post("color_".$c);
				if(isset($colorcode) && !empty($colorcode))
				{
					//$code=$c;
					 $codenname .="$colorcode->$c#";
				}
				
				
				//echo "<br>";
				//array_push($colorcode,$codenname);
				//$colorcode .= $codenname;
			}
			//echo $codenname;
			//$colorcodeimplode=implode(",",$colorcode);
			//20->1#5->2#
			 $tabtotrow=intval($this->input->post("tabtotrow"));
			for($totr=1;$totr<=$tabtotrow;$totr++)
			{
				$particulars=$this->input->post("particulars_".$totr);
				$txt=$this->input->post("txt_".$totr);
				$qnty=$this->input->post("qnty_".$totr);
				$unitpr=$this->input->post("unit_".$totr);
				$total=$this->input->post("total_".$totr);
				$data_arraysave=array(
					"bokingid"=>$bookingid,
					"custid"=>$custid,
					"doe"=>$bookingdate,
					"particulars"=>$particulars,
					"cate"=>$txt,
					"qnty"=>$qnty,
					"unitpr"=>$unitpr,
					"total"=>$total,
					"color"=>$codenname,
					"tax"=>$cst1,
					"taxpercent"=>$csttx,
					"taxamount"=>$cstamnt,
					"excise1"=>$excise,
					"expectdoe"=>$delivary,
					"exciseamount"=>$exciseamnt,
					"grand"=>$nettl,
					"status"=>1,
					"uid"=>$this->session->userdata('user_name')
				
				
				);
				//print_r($data_arraysave);
				$this->Booking_model->savereatsilbooking($data_arraysave);
			}
		
			
		}
		
		if(strtoupper($cattyp)=="PARTS")
		{
			$cst=$this->input->post("cstvat");
			$cstexplode=explode("@",$cst);
			$cst1=$cstexplode[0];
			$csttx=$cstexplode[1];
			$cstamnt=$this->input->post("cstv");
			$nettl=$this->input->post("nettl");
			$netassval=$this->input->post("netassval");
			$tabtotrow=intval($this->input->post("tottabrow"));
			for($totr=1;$totr<=$tabtotrow;$totr++)
			{
				$chk=$this->input->post("rick_".$totr);
				if(!empty($chk) && isset($chk))
				{
				$particulars=$this->input->post("partsname_".$totr);
				//$txt=$this->input->post("txt_".$totr);
				$qnty=$this->input->post("totqty_".$totr);
				$unitpr=$this->input->post("unitprice_".$totr);
				$total=$this->input->post("totalmrp_".$totr);
				$data_arraysave=array(
					"bokingid"=>$bookingid,
					"custid"=>$custid,
					"doe"=>$bookingdate,
					"particulars"=>$particulars,
					"qnty"=>$qnty,
					"unitpr"=>$unitpr,
					"total"=>$total,
					"tax"=>$cst1,
					"taxpercent"=>$csttx,
					"taxamount"=>$cstamnt,
					"expectdoe"=>$delivary,
					"grand"=>$nettl,
					"status"=>1,
					"uid"=>$this->session->userdata('user_name')
				
				
				);
				//print_r($data_arraysave);
			$this->Booking_model->savereatsilbooking($data_arraysave);
				
				}
			}
			
			
		}
		
		//cust details save 
		//echo "<br>=============<br>";
		/*if(strtoupper($paymentmode)=="CHEQUE" || strtoupper($paymentmode)=="OTHERS")
		{
			$data_array_custsave=array(
			"clientid"=>$custid,
			"name"=>$custame,
			"custtype"=>$custtyp,
			"email"=>$email,
			"phone"=>$phnono,
			"add1"=>$add1,
			"add2"=>$add2,
			"pin"=>$pin,
			"pan"=>$panno,
			"tin_vat"=>$vattin,
			"cst"=>$cst,
			"doe"=>date('Y-m-d h:i:s A')
			
			
		);
			
		}
		if(strtoupper($paymentmode)=="CASH")
		{
			$data_array_custsave=array(
			"clientid"=>$custid,
			"name"=>$custame,
			"custtype"=>$custtyp,
			"email"=>$email,
			"phone"=>$phnono,
			"add1"=>$add1,
			"add2"=>$add2,
			"pin"=>$pin,
			"pan"=>$panno,
			"tin_vat"=>$vattin,
			"cst"=>$cst,
			"balance"=>$deposit,
			"doe"=>date('Y-m-d h:i:s A'),
			
			
		);
			
		}
		
		//print_r($data_array_custsave);
		//echo "<br>=============<br>";
		$this->Booking_model->savecustdata($data_array_custsave);
		/////////////////////////////////    transaction master account  //////////////////////////////////////
		//                                                                                                  //
		///////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
			$data_array_transaction=array(
			"clientID"=>$custid,
			"dat"=>date('Y-m-d'),
			"type"=>$paymentmode,
			"paid_amt"=>$deposit,
			"boking_ID"=>$bookingid,
			"cheque_no"=>$chqno,
			"bankName"=>$bankname,
			"branchName"=>$branch,
			"purpose"=>$purpose,
			"doe"=>date('Y-m-d h:i:s A'),
			"submitby"=>$this->session->userdata('user_name')
		);
		
		*/
		//print_r($data_array_transaction);
		//$this->Booking_model->savemaintransaction($data_array_transaction);
		
		
		
		
		
		
		redirect('sales_Controller/vieworder','refresh');
		
		
		
		
		
	}

////////////////////////////////////////////////   manage pi invoice print   /////////////////////////////////
  public function viewpiinvoice($id)
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$bkid=$id;
	$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$image1="assets/logo/bank_small.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gkpiinvoice.png";
		$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$text1="Dear Sir,";
		$text2="    We are pleased to inform you that your  booking is successfully done and  look forward to your Interest. Please review the information carefully and contact our respetive accounts department/sales executive immediately of any changes call 24X7 helpline number (033)-64517771: ";
		$text3="All Payments must be made by DD,RTGS,NEFT or A/C Payee cheque only Our resplonsibility ceases as sonn as goods leave our permises. Disputes if any are subject to Serampore Hooghly Jurisdiction inly Failure to send C-Form as applicable within 90 day will invoice additional tax as per central/local sales tax,vat act. Over due interest @21% will be charged if payment is not received within 30days from date of invoice.Goods once sold will not be taken back or return";
		$getdata=$this->Booking_model->getdistinctbookinglist($bkid);
		foreach($getdata as $row)
		{
			$dte=$row->doe;
			$sls=$row->sname;
			$cltid=$row->custid;
			$delivery=$row->expectdoe;
		}
		$buyerdet=$this->Booking_model->getbuyerdetail($cltid);
		foreach($buyerdet as $rowc)
		{
			$comname=$rowc->compname;
			$custtyp=$rowc->custtype;
			$custname=$rowc->name;
			
			$add1=$rowc->add1;
			$add2=$rowc->add2;
			$countrymname=$rowc->country;
			$state=$rowc->state;
			$pin=$rowc->pin;
			$district=$rowc->district;
			$phno=$rowc->phone;
			$doe=$rowc->doe;
			$tinvat=$rowc->tin_vat;
			
			//$tin=$rowc->tin;
		}
		if(strtoupper($custtyp)=="RETAILER")
		{
			$comname=$custname;
		}else
		{
			$comname=$comname;
		}
		$this->fpdf->Image("$path",0,0,210,298,'png');
		$this->fpdf->ln(40);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(20,5,"NO.",1,0,'C');
		$this->fpdf->cell(35,5,"$bkid",1,0,'C');
		$this->fpdf->cell(74);
		$this->fpdf->cell(25,5,"DATE:",1,0,'C');
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->cell(35,5,"$doe",1,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(55,5,"BUYER'S ADDRESS",1,0,'C');
		//company name------
		$this->fpdf->text(12,70," $comname");
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		if(isset($add1)){
			$this->fpdf->text(12,$y+15," $add1");
			 $y=$y+20;
		}
		if(isset($add2))
		{
			
			$this->fpdf->text(12,$y," $add2");
			$y=$y+5;
		}
		if(isset($district))
		{
			$this->fpdf->text(12,$y," $district");
			$y=$y+5;
		}
		if(isset($state))
		{
			$this->fpdf->text(12,$y," $state");
			$y=$y+5;
		}
		if(isset($countrymname))
		{
			$this->fpdf->text(12,$y," $countrymname");
			$y=$y+5;
		}
		if(isset($pin))
		{
			$this->fpdf->text(12,$y,"PIN: $pin");
			$y=$y+5;
		}
		if(isset($phno))
		{
			$this->fpdf->text(12,$y,"Mob: $phno");
		}
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',10);
		  $this->fpdf->text($x+78,$y+10,"GK RICKSHAW PVT LTD. ");
		  $y=$y+10;
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+78,$y+5,"30(33/1) N.T Road,Padmabati ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Colony, Baidyabati, Hooghly, ");
		
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"West Bengal-712222, India ");
		$y=$y+5;
		 $this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text($x+78,$y+5,"TIN NO: 19731597605 ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Phone: 033-64517771 ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Mob: +919903197821 ");
		$this->fpdf->cell(74);
		 $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(60,5,"OFFICE ADDRESS",1,1,'C');
		$this->fpdf->cell(55,45,"",1,0,'C');
		$this->fpdf->cell(74);
		$this->fpdf->cell(60,45,"",1,1,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(35,5,"Buyer's TIN NO",1,0,'C');
		$this->fpdf->cell(40,5,"$tinvat",1,0,'C');
		$this->fpdf->cell(39);
		$this->fpdf->cell(35,5,"Ex.Delivery Date",1,0,'C');
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->cell(40,5,"$delivery",1,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->cell(20);
		$this->fpdf->SetWidths(array(35,50,20,40,44));
		$this->fpdf->SetAligns(array("C","C","C","C","R"));
		
		$this->fpdf->Row(array("Parts Code","Particulars","Qty(pcs)","Rate(INR)","Value(INR)"));
		$i=1;$tot1=0;
		foreach($getdata as $row){
		
		$particular=$row->particulars;
		$atg=$row->cate;
		if(!empty($atg) &&  isset($atg))
		{
			$particular=$particular."(".$atg.")";
		}else{
			$particular=$particular;
		}
		$qty=$row->qnty;
		$unitpr=number_format($row->unitpr,2);
		$tot=$row->total;
		$vat=$row->tax;
		$vat=strtoupper($vat);
		$taxper=$row->taxpercent;
		$taxamount=$row->taxamount;
		$excise1=$row->excise1;
		$exciseamount=$row->exciseamount;
		$grand=$row->grand;
		$grand=number_format($grand,2);
		$tot3=number_format($row->total,2);
		$tot1=$tot1+floatval($tot);
		//$tot1=number_format($tot1,2);
		
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->SetWidths(array(35,50,20,40,44));
		$this->fpdf->SetAligns(array("C","C","C","C","R"));
		$this->fpdf->Row(array("","$particular","$qty","$unitpr","$tot3"));
		$i++;
		}
		//$tot1=number_format($tot1,2);
		//$this->fpdf->Cell(130,5,'Net Total',1,0,'R');
		//$this->fpdf->Cell(50,5,"$tot1",1,1,'L');
		if(floatval($exciseamount)>0)
		{
			$this->fpdf->SetWidths(array(145,44));
			$this->fpdf->SetAligns(array("C","R"));
			
			$this->fpdf->Row(array("Excise duty @ $excise1%","$exciseamount"));
		
		}
		if(isset($vat) && isset($taxper) && isset($taxamount)){
			$this->fpdf->SetWidths(array(145,44));
			$this->fpdf->SetAligns(array("C","R"));
			
			$this->fpdf->Row(array(" $vat @ $taxper","$taxamount"));
		}
		
		$this->fpdf->SetWidths(array(145,44));
		$this->fpdf->SetAligns(array("R","R"));
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Row(array("Grand Total(INR)","$grand"));
		
		$this->fpdf->SetWidths(array(189));
		$this->fpdf->SetAligns(array("C"));
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->Row(array("Excluding Transporation Cost"));
		$this->fpdf->SetWidths(array(80,109));
		$this->fpdf->SetAligns(array("L","L"));
		$this->fpdf->SetFont('Arial','',11);
		$this->fpdf->Row2(array($this->fpdf->Image($image1, $this->fpdf->GetX()+2, $this->fpdf->GetY()+2,50,50,'png'),"$text3"));
		$this->fpdf->cell(30,20,"Customer Signature:",0,0,'L');
		$this->fpdf->cell(110);
		$this->fpdf->cell(30,20,"Authorized Signature",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->cell(20,30,$this->fpdf->Image($img2, $this->fpdf->GetX()+140, $this->fpdf->GetY()+1,30,30,'png'),0,0,'C');
		$this->fpdf->ln(5);
		
		
		
		
		/*$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(7);
		$this->fpdf->MultiCell(180,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(180,5,"Proforma Invoice",0,0,'C');
		$this->fpdf->ln(7);
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(25,5,"Booking ID ",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $bkid",0,0,'L');
		$this->fpdf->cell(30,5," ",0,0,'L');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(45,5,"Sales Exec.",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $sls ",0,1,'L');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(25,5,"Date ",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $dte ",0,1,'L');
		
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(20,5,'Sl.No',1,0,'L');
		$this->fpdf->Cell(50,5,'Prticulars',1,0,'L');
		$this->fpdf->Cell(20,5,'Qnty',1,0,'L');
		$this->fpdf->Cell(40,5,'Unit Price.',1,0,'L');
		$this->fpdf->Cell(50,5,'Total',1,1,'L');
		//$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',10);
		$i=1;$tot1=0;
		foreach($getdata as $row){
		$this->fpdf->SetWidths(array(20,50,20,40,50));
		$particular=$row->particulars;
		$atg=$row->cate;
		if(!empty($atg) &&  isset($atg))
		{
			$particular=$particular."(".$atg.")";
		}else{
			$particular=$particular;
		}
		$qty=$row->qnty;
		$unitpr=number_format($row->unitpr,2);
		$tot=$row->total;
		$tot3=number_format($row->total,2);
		$tot1=$tot1+floatval($tot);
		//$tot1=number_format($tot1,2);
		$this->fpdf->Row(array("$i","$particular","$qty","$unitpr","$tot3"));
		$i++;
		}
		$tot1=number_format($tot1,2);
		$this->fpdf->Cell(130,5,'Net Total',1,0,'R');
		$this->fpdf->Cell(50,5,"$tot1",1,1,'L');
		//$filename="Fpdfoutput/pi_invoice.pdf";
					//echo $vendidemailimplode;
        //$this->fpdf->Output($filename,'F');*/
        $this->fpdf->Output();
		//$data['bkid']=$bkid;
		//$getmail=$this->Booking_model->getclientmail($cltid);
		//$data['cstml']=$getmail;
		//$this->load->view("send_mail/sendpi",$data);
		//$message='Mail with Attachment send succesfully.....';
		// $this->session->set_flashdata('message',$message);
		 //redirect('login','refresh');
		//redirect('Paymentcontroller/viewbokkinglist','refresh');
	
}
public function createorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='Create Order';
		$user=$this->session->userdata('uname');
		$data['models']=$this->Booking_model->getmodelsdetails();
		$data['allmaterial']=$this->Booking_model->get_material();
		$data['getcolorcode']=$this->Booking_model->getall_colorcode();
		$data['getallproduct']=$this->Booking_model->getallproduct();
		$data['customer']=$this->Booking_model->getcustomername($user);
		//$data['spareparts']=$this->Booking_model->getspareparts();
		$this->load->view('booking/createbooking',$data);	
	}
	public function getdetails_purchase()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id=$this->input->post('id');
		$specid=$this->input->post("specid");
		$result=$this->Booking_model->get_alldetails($id);
		foreach($result as $row)
		{
			$materialid=$row->materiel_id;
			$materialnam=$row->materialname;
			$unit=$row->unit;
		}
		$getspecid=$this->Booking_model->getspecification($specid);
		foreach($getspecid as $rowspe)
		{
			$spectit=$rowspe->specification;
		}
		$result=array("matid"=>"$materialid","matname"=>"$materialnam","specif"=>"$spectit","unit"=>"$unit");
		echo json_encode($result);
	}
	public function getcustmer()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
   	$email=$this->input->post("custmail");
	$getcustdetails=$this->Booking_model->getcustdetails($email);
	//print_r($getcustdetails);
	$result=array();
    if(!empty($getcustdetails) && isset($getcustdetails))
	{
		foreach($getcustdetails as $row)
		{
			$comp=$row->compname;
			$name=$row->name;
			$image=$row->image;
			$custid=$row->clientid;
			$email=$row->email;
			$sid=$row->sid;
			$sname=$row->sname;
		}
		$result=array("comp"=>"$comp","name"=>"$name","image"=>"$image","custid"=>$custid,"email"=>"$email","sid"=>"$sid","sname"=>"$sname");
		
	}
  	echo json_encode($result);
  }
public function getmodeldet()
  {
  	$model=$this->input->post("cattyp");
	$getallmodel=$this->Booking_model->getallmodel();
	if(isset($getallmodel) && !empty($getallmodel))
	{
		
			
			
			echo '<div class="form-group">
											<select name="type" class="form-control" id="modeltype" onchange="getmodeltype()" required >
																			<option value="">--Select type--</option>';
																			$i=1;
									foreach($getallmodel as $row)
		                             {
		                             	echo '<option value="'.$row->productname.'_'.$i.'">'.$row->productname .'</option>';
									$i++; }
																			
																		echo '</select>
											<label for="custName"></label>
										</div>';
		
	}
  }
  public function getmodellistbyparts()
{
	$model=$this->input->post("cattyp");
	$getallmodel=$this->Booking_model->getallmodel();
	if(isset($getallmodel) && !empty($getallmodel))
	{

			echo '<div class="form-group">
											<select name="modeltype" class="form-control" id="modeltype" onchange="getmodeltypebyparts()" required>
																			<option value="">--Select type--</option>';
																			$i=1;
									foreach($getallmodel as $row)
		                             {
		                             	echo '<option value="'.$row->productname.'_'.$i.'">'.$row->productname .'</option>';
									$i++; }
																			
																		echo '</select>
											<label for="custName"></label>
										</div>';
		
	}
	
	
}
public function getmodelprice()
{
	echo "hello";
}
public function getvatdetails()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $vat=$this->input->post("vatcst");
	$nettot= $this->input->post("nettot");
	 if($vat=="cst"){
	 	$getvat=$this->Booking_model->getcstpercent($vat);
	 }
	 if($vat=="vat")
	 {
	 	$getvat=$this->Booking_model->getvatpercent($vat);
	 }
	// $nettot=$this->input->post("nettot");
	 $vatto=((floatval($nettot)*floatval($getvat))/100);
	 $netr=floatval($nettot)+floatval($vatto);
	 $result=array("vat"=>"$getvat","vatamnt"=>"$vatto","grandtot"=>"$netr");
	 echo json_encode($result);
	
}
public function getexcisedetails()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 //$excise=$this->input->post("vatcst");
	$grandtot= $this->input->post("grandtot");
	$excise=$this->Booking_model->getexciseduty();
	// $nettot=$this->input->post("nettot");
	 $exciseamnt=((floatval($grandtot)*floatval($excise))/100);
	 $netr=floatval($grandtot)+floatval($exciseamnt);
	 $result=array("excise"=>"$excise","exciseamnt"=>"$exciseamnt","grandtot"=>"$netr");
	 echo json_encode($result);
}
public function autocomplete()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$user=$this->session->userdata('user_name');
	$term=$this->input->get('term');
	$getdata=$this->Booking_model->getsearchdata($user,$term);
	foreach($getdata as $row)
	{
		$data[]=strtoupper($row->name);
		
	}
	foreach($getdata as $row)
	{
		$data[]=($row->email);
		
	}
	foreach($getdata as $row)
	{
		$data[]=strtoupper($row->compname);
		
	}
	foreach($getdata as $row)
	{
		$data[]=strtoupper($row->clientid);
		
	}
	echo json_encode($data);
	
}
public function getallspare_parts_sort_by_modelname()
	{
	   $modelid=$this->input->post("modcode");
		$modelname=$this->input->post("modnam");
		$getparts=$this->Booking_model->getparts_sort_by_modelname($modelname);
		echo '<ol   id="allspareparts">';
						//echo '<li><small>Spare Parts list</small></li>';
						if(!empty($getparts)){
							 $i=1; 
							 foreach($getparts as $row){ 
								$diff=$row->diff;
								$reoder=$row->reorderlevel; 
								$partsid=$row->materiel_id;
								$prtsamnt=$row->dispr;
								$getspecifi=$this->Booking_model->getspecifbypartsid($partsid);
								if($diff<$reoder){
									//echo '<li  class="btn btn-block ink-reaction btn-danger"  title="'. $row->materialname.'('.$row->qnty.')" ><a  id="item_$i" href="javascript:anchor_test('.$row->id.')" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small>'. $row->materialname.'('. $row->qnty.')</small></a></li>';
									echo '<li   title="'. $row->materialname.'"("'.$row->qnty.'")">';
							 	//echo '<a  id="item_ $i" href="javascript:anchor_test('. $row->id.' )" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
								echo '<a  id="item_ $i" href="javascript:void(0);" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
							 	 echo '<div class="tile-content">';
										
										echo '<div class="tile-text" style="font-weight: bold;"><small>'.$row->materialname.'('. $row->qnty.')</small></div>';
									echo '</div>';
							   echo '</a>' ;
							 	echo '</li>';
								echo '<div class="modal fade" id="myModal_'.$row->id.'" role="dialog">
								    <div class="modal-dialog modal-md">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">'. $row->materialname.'</h4>
								        </div>
								        <div class="modal-body">
								        <div class="row">
								          <div class="col-md-12">
								        	 <form class="form-horizontal">';
								        	 if(isset($getspecifi) && !empty($getspecifi)){
								        	 	
											   echo ' <div class="form-group">
											    <div class="col-md-2"></div>
											    <div class="col-md-3">
											      <h4>Select Specification:  </h4>
											      </div>
											      
											      <div class="col-md-6">
											      <select name="specifi" class="form-control" id="speci_'.$row->id.'">';
												  
											      	foreach($getspecifi as $spe)
													{
														echo '<option value="'.$spe->id.'">'.$spe->specification.'</option>';
													}
											      	
											      
											      echo '</select>
											        
											      </div>
											    </div>';
											 }else{
											 	echo '<input type="hidden" value="9999
											 	"class="form-control" id="speci_'.$row->id.'" placeholder="No of parts">';
											 }
											    echo '<div class="form-group">
											      
											    </div>
											    
											    <div class="form-group">
											     <div class="col-md-2"></div>
											      <div class="col-md-3">
											        <h4>Enter No Of Parts:</h4>
											      </div>
											      
											      <div class="col-md-6">
											        <input type="text" class="form-control" id="noprts_'.$row->id.'" placeholder="No of parts">
											        <input type="hidden" value="'.$prtsamnt.'" id="prtsamnt_'.$row->id.'">
											      </div>
											    </div>
											    
											  </form>
										  </div>
										</div>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" onclick="anchor_test('. $row->id.' )">Submit</button>
								        </div>
								      </div>
								    </div>
							 </div>';
									$i++;
								}else
									{
											//echo '<li    title="'. $row->materialname.'('.$row->qnty.')" ><a  id="item_$i" href="javascript:anchor_test('.$row->id.')" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small>'. $row->materialname.'('. $row->qnty.')</small></a></li>';
											echo '<li   class="tile" title="'. $row->materialname.'"("'.$row->qnty.'")"">';
							 	//echo '<a  id="item_ $i" href="javascript:anchor_test('. $row->id.' )" >';
							 	echo '<a  id="item_ $i" href="javascript:void(0);" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
							 	 echo '<div class="tile-content">';
										
										echo '<div class="tile-text" style="font-weight: bold;"><small>'.$row->materialname.'('. $row->qnty.')</small></div>';
									echo '</div>';
							   echo '</a>' ;
							 	echo '</li>';
								echo '<div class="modal fade" id="myModal_'.$row->id.'" role="dialog">
								    <div class="modal-dialog modal-md">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">'. $row->materialname.'</h4>
								        </div>
								        <div class="modal-body">
								        <div class="row">
								          <div class="col-md-12">
								        	 <form class="form-horizontal">';
											    if(isset($getspecifi) && !empty($getspecifi)){
								        	 	
											   echo ' <div class="form-group">
											    <div class="col-md-2"></div>
											    <div class="col-md-3">
											      <h4>Select Specification:  </h4>
											      </div>
											      
											      <div class="col-md-6">
											      <select name="specifi" class="form-control" id="speci_'.$row->id.'">';
												  
											      	foreach($getspecifi as $spe)
													{
														echo '<option value="'.$spe->id.'">'.$spe->specification.'</option>';
													}
											      	
											      
											      echo '</select>
											        
											      </div>
											    </div>';
											 }else{
											 	echo '<input type="hidden" value="9999
											 	"class="form-control" id="speci_'.$row->id.'" placeholder="No of parts">';
											 }
											    echo '<div class="form-group">
											    </div>
											    <div class="form-group">
											      
											    </div>
											    
											    <div class="form-group">
											     <div class="col-md-2"></div>
											      <div class="col-md-3">
											       <h4> Enter No Of Parts:</h4>
											      </div>
											      
											      <div class="col-md-6">
											        <input type="text" class="form-control" id="noprts_'.$row->id.'" placeholder="No of parts">
											         <input type="hidden" value="'.$prtsamnt.'" id="prtsamnt_'.$row->id.'">
											      </div>
											    </div>
											    
											  </form>
										  </div>
										</div>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" onclick="anchor_test('. $row->id.' )">Submit</button>
								        </div>
								      </div>
								    </div>
							 </div>';
								
									$i++;	
								}
								//echo  ' <li style="border:1px solid #c2c2c2;"></li>';
							
								
							
						   } 
					echo '</ol>';
					
					}else{
						echo "<h5 style='color:red;'>No Spare Parts Available</h5>";
					}
		//print_r($getparts);
	
	}
public function bookingsave()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$custid=$this->input->post("compid");
	$notr=$this->input->post('numofrows');
	$sid=$this->input->post('sid');
	$sname=$this->input->post('sname');
	date_default_timezone_set("Asia/kolkata");
	$getbookingid=$this->Booking_model->getbookingid();
	if(empty($getbookingid))
	{
		$getbookingid=1;
		$bkid="GKSLSBK".str_pad($getbookingid, 5 , '0', STR_PAD_LEFT);
	}else{
		$getbookingid=intval(substr($getbookingid, -5))+1;
		$bkid="GKSLSBK".str_pad($getbookingid, 5 , '0', STR_PAD_LEFT);
	}
	for($i=1;$i<=$notr;$i++)
	{
		$particular=$this->input->post("modelname_$i");
		$getprtsname=$this->Booking_model->getpartsname($particular);
		$vatcst=$this->input->post("vatcst");
		if(isset($vatcst)){  $vatcst=$vatcst ; }else{ $vatcst=""; }
		$vatcstpercent=$this->input->post("vatcstpercent");
		if(isset($vatcstpercent)){  $vatcstpercent=$vatcstpercent ; }else{ $vatcstpercent=""; }
		$vatamnt=$this->input->post("vat_amnt");
		if(isset($vatamnt)){  $vatamnt=$vatamnt ; }else{ $vatamnt=""; }
		$excise=$this->input->post("excise");
		if(isset($excise)){  $excise=$excise ; }else{ $excise=""; }
		$exciseamnt=$this->input->post("excise_amnt");
		if(isset($exciseamnt)){  $exciseamnt=$exciseamnt ; }else{ $exciseamnt=""; }
		$grandtot=$this->input->post("grandtotal");
		if(isset($grandtot)){  $grandtot=$grandtot ; }else{ $grandtot=""; }
		if(!empty($getprtsname))
		{
			foreach($getprtsname as $row)
			{
				$particual=$row->materialname;
			}
		}else
			{
				$particual=$particular;
			}
		$cate=$this->input->post("specif_$i");
		$qnty=$this->input->post("prqty_$i");
		$unit=$this->input->post("amount_$i");
		$tot=$this->input->post("tot1_$i");
		$color=$this->input->post("colorspe_$i");
		if(isset($color)){
			$color=$color;
		}else{
			$color="";
		}
			$e=1;
		if(isset($cate) && !empty($cate))
		{
			
			$data_aray=array(
				"custid"=>$custid,
				"bokingid"=>$bkid,
				"doe"=>date('Y-m-d h:i:s A'),
				"particulars"=>$particual,
				"cate"=>$cate,
				"qnty"=>$qnty,
				"unitpr"=>$unit,
				"total"=>$tot,
				"color"=>$color,
				"tax"=>$vatcst,
				"taxpercent"=>$vatcstpercent,
				"taxamount"=>$vatamnt,
				"excise1"=>$excise,
				"exciseamount"=>$exciseamnt,
				"grand"=>$grandtot,
				"sid"=>$sid,
				"sname"=>$sname,
				"status"=>$e
			
			);
			$this->Booking_model->savebkorder($data_aray);
		}
		else {
			$data_aray=array(
				"custid"=>$custid,
				"bokingid"=>$bkid,
				"doe"=>date('Y-m-d h:i:s A'),
				"particulars"=>$particual,
				"qnty"=>$qnty,
				"unitpr"=>$unit,
				"total"=>$tot,
				"tax"=>$vatcst,
				"taxpercent"=>$vatcstpercent,
				"taxamount"=>$vatamnt,
				"excise1"=>$excise,
				"exciseamount"=>$exciseamnt,
				"grand"=>$grandtot,
				
				"sid"=>$sid,
				"sname"=>$sname,
				"status"=>$e
			
			);
			$this->Booking_model->savebkorder($data_aray);
		}
		//echo "<br>";
	}
//	redirect('Paymentcontroller/viewbokkinglist','refresh');
redirect('sales_Controller/vieworder','refresh');
	
  }
 //922017
 public function getpdf_order()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
 	$dat=$this->input->post("date");
	$chs=$this->input->post("choose");
	
 	$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$image1="assets/logo/bank_small.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gkpiinvoice.png";
		$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$text1="Dear Sir,";
		$text2="   We are pleased to inform you that your  booking is successfully done and  look forward to your Interest. Please review the information carefully and contact our respetive accounts department/sales executive immediately of any changes call 24X7 helpline number (033)-64517771: ";
		$text3="All Payments must be made by DD,RTGS,NEFT or A/C Payee cheque only Our resplonsibility ceases as sonn as goods leave our permises. Disputes if any are subject to Serampore Hooghly Jurisdiction inly Failure to send C-Form as applicable within 90 day will invoice additional tax as per central/local sales tax,vat act. Over due interest @21% will be charged if payment is not received within 30days from date of invoice.Goods once sold will not be taken back or return";
		$this->fpdf->SetFont('Arial','B',16);
		$x=$this->fpdf->GetX();
		$y=$this->fpdf->GetY();
		$this->fpdf->cell(190,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(190,10,"Latest Order Details Status",0,0,'C');
		
		$this->fpdf->ln(20);
		
		//$this->fpdf->cell(20);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetWidths(array(30,30,40,40,10,20,20));
		$this->fpdf->SetAligns(array("C","C","C","C","C","R","C"));
		
		$this->fpdf->Row(array("BOOKINGID","CUSTOMERID","CUSTOMER NAME","PARTICULARS","QNT","BILL AMOUNT","STATUS"));
		if($chs=="all")
		{
			$get_bookingdetails=$this->Booking_model->getorderlist_all($dat);
		}
		if($chs=="pending")
		{
			$get_bookingdetails=$this->Booking_model->getorderlist_pending($dat);
			
		}
		if($chs=="approve")
		{
			$get_bookingdetails=$this->Booking_model->getorderlist_approve($dat);
		}
		if(isset($get_bookingdetails) && !empty($get_bookingdetails))
		{
			$bkid2="";
			foreach($get_bookingdetails as $rowst)
			{
				$bkid=$rowst->bokingid;
				$custid=$rowst->custid;
				$custnme=$this->Booking_model->getcustnam($custid);
				$particulars=$rowst->particulars.$rowst->cate;
				$qnty=$rowst->qnty;
				$gtot=$rowst->grand;
				$paymentsta=intval($rowst->paymentstatus);
				$stockstatus=intval($rowst->stockstatus);
				if($stockstatus>0 && $paymentsta>0 ){ $st=1; }else{ if($stockstatus>0 && $paymentsta==0 ){ $st=0;  } if($stockstatus==0 && $paymentsta>0 ){ $st=0; }if($stockstatus==0 && $paymentsta==0 ){ $st=0;  } }  	
				if($st==1){ $stat="Approve"; }else{ $stat="Pending"; }
				$this->fpdf->SetFont('Arial','',9);
				$this->fpdf->SetWidths(array(30,30,40,40,10,20,20));
				$this->fpdf->SetAligns(array("C","C","C","C","C","R","C"));
				if($bkid!=$bkid2)
				{
					$this->fpdf->Row(array("$bkid","$custid","$custnme","$particulars","$qnty","$gtot","$stat"));
				}else{
					$this->fpdf->Row(array("","","","$particulars","$qnty","",""));
				}
				$bkid2=$bkid;
				
			}
		}
		
		
        $this->fpdf->Output();
		
	
 } 
	public function get_detailsorder($bkid)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$bkid=$bkid;
		$data['bkid']=$bkid;
		$data['title']="Order Processed";
		$data['detailsbooking']=$this->Booking_model->getallbookingdeta_ils($bkid);
		$data['model_name']=$this->Booking_model->getall_modellist();
		$data['warehouse']=$this->Booking_model->getware_house();
		
		$this->load->view('stockmanage/order_process',$data);
	 	
	}
	public function updtewarehouse_booking()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$bkid=$bkid;
		 $tablerow=intval($this->input->post("tablerow"));
		 $category=$this->input->post("category");
		 $bokkingid=$this->input->post("bookig_id_new");
		if(isset($category)=="model"){
		if(isset($tablerow) && !empty($tablerow)){
			for($tr=1;$tr<$tablerow;$tr++)
			{
				 $bkid=$this->input->post("bkidnew_".$tr);
				$wrhcod=$this->input->post("wrehousecode_".$tr);
				$modelcode=$this->input->post("model_".$tr);
				$getmodelcode=$this->Booking_model->getmodelcode($modelcode);
				$qnty=$this->input->post("qnty_".$tr);
				$data_array_update_booking_order=array(
					"processstatus"=>2,
					"warehouse_cod"=>$wrhcod,
					
				);
				$get_warehouse_order=$this->Booking_model->getlaststockcode();
				$data_array_stock_warehousecode=array(
					"bkid"=>$bokkingid,
					"stockcode"=>$get_warehouse_order,
					"modelname"=>$getmodelcode,
					"qnty"=>$qnty,
					"wrehsecode"=>$wrhcod,
					"crtd"=>$this->session->userdata('user_name'),
					"dos"=>date('Y-m-d'),
					"doe"=>date('Y-m-d h:i:s A')
				
				);
				print_r($data_array_stock_warehousecode);
				echo "<br>";
				$this->Booking_model->save_wareorder_list($data_array_stock_warehousecode);
				//print_r($data_array_update_booking_order);
				//echo "<br>";
				$this->Booking_model->get_update_booking_order($data_array_update_booking_order,$bkid);
			}
			
		}
		}
		if(isset($category)=="spareparts")
		{
			
		}
		redirect('AcountsManage_Controller/view_booking_details','refresh');
	}
	
   
}