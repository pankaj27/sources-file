<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Purchase_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		//$this->load->library(array('session','authentication'));
		$this->load->model('Purchase_model');
	}
	
	public function purchase_dash()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
    	$this->load->view('purchase_master/purchase_dashboard',$data);
	}
	public function createNew()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
		$data['allmaterial']=$this->Purchase_model->get_material();
		$data['allvendors']=$this->Purchase_model->getall_vendors();
		$data['getallproduct']=$this->Purchase_model->getallproduct();
		$data['getcolorcode']=$this->Purchase_model->getall_colorcode();
		$purorder=$this->Purchase_model->getpurchaseorder();
		if(empty($purorder))
		{
			$invID="1";
			$data['purchaseorder']="GK/".date('y')."/".(date('y')+1)."/".str_pad($invID, 5 , '0', STR_PAD_LEFT);
			$data['refno']="REF/"."GK/".date('y')."/".(date('y')+1)."/".str_pad($invID, 5 , '0', STR_PAD_LEFT);
		}else{
			foreach($purorder as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['purchaseorder']="GK/".date('y')."/".(date('y')+1)."/". str_pad($invID, 5 , '0', STR_PAD_LEFT);
			$data['refno']="REF/"."GK/".date('y')."/".(date('y')+1)."/".str_pad($invID, 5 , '0', STR_PAD_LEFT);
		}
		//print_r($data['allmaterial']);
    	$this->load->view('purchase_master/create',$data);
	}
	public function getdetails_purchase()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id=$this->input->post('id');
		$result=$this->Purchase_model->get_alldetails($id);
		foreach($result as $row)
		{
			$materialid=$row->	materiel_id;
			$materialnam=$row->materialname;
		}
		$result=array("matid"=>"$materialid","matname"=>"$materialnam");
		echo json_encode($result);
	}
	public function getvender_list()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$venid=$this->input->post('vendors');
		$result=$this->Purchase_model->getvenders_dtails($venid);
		if(empty($result))
		{
			$result=$this->Purchase_model->getvenders_dtails_excepttransaction($venid);
			foreach($result as $row)
			{
			$vendername=$row->vcompany;
			$venderlastrans="";
			$lastrandt="";
			$lastquatation="";
			$purchaseorder="";
			$venderid=$row->vender_id;
			$vemail=$row->vemail;
			$vphone=$row->vphno;
			$add1=$row->add1;
			$cst=$row->cst;
			$vat=$row->vat;
			$country=$row->country;
			$contact1=$row->contactname1;
			$contactemail1=$row->contactemail1;
			$contactphno1=$row->contactphno1;
			$contactname2=$row->contactname2;
			$contactemail2=$row->contactemail2;
			$contactphno2=$row->contactphno2;
			$bankname1=$row->bankname1;
			$bankacc1=$row->bankacc1;
			$bankifsc1=$row->bankifsc1;
			$bankswift1=$row->bankswift1;
			$branch1=$row->branch1;
			$bankname2=$row->bankname2;
			$bankacc2=$row->bankacc2;
			$bankifsc2=$row->bankifsc1;
			$bankswift2=$row->bankswift2;
			$branch2=$row->branch2;
			
			
			
			}
		}else{
			foreach($result as $row)
		{
			$vendername=$row->vcompany;
			$venderlastrans=$row->amount;
			$lastrandt=$row->purchasedate;
			$lastquatation=$row->qatationno;
			$purchaseorder=$row->purchaseorderno;
			$venderid=$row->vender_id;
			$vemail=$row->vemail;
			$vphone=$row->vphno;
			$add1=$row->add1;
			$cst=$row->cst;
			$vat=$row->vat;
			$country=$row->country;
			$contact1=$row->contactname1;
			$contactemail1=$row->contactemail1;
			$contactphno1=$row->contactphno1;
			$contactname2=$row->contactname2;
			$contactemail2=$row->contactemail2;
			$contactphno2=$row->contactphno2;
			$bankname1=$row->bankname1;
			$bankacc1=$row->bankacc1;
			$bankifsc1=$row->bankifsc1;
			$bankswift1=$row->bankswift1;
			$branch1=$row->branch1;
			$bankname2=$row->bankname2;
			$bankacc2=$row->bankacc2;
			$bankifsc2=$row->bankifsc1;
			$bankswift2=$row->bankswift2;
			$branch2=$row->branch2;
			
			
			
		}
			
		}
		
		
		$result2=array("branch2"=>"$branch2","bankswift2"=>"$bankswift2","bankifsc2"=>"$bankifsc2","bankacc2"=>"$bankacc2","bankname2"=>"$bankname2","branch1"=>"$branch1","bankswift1"=>"$bankswift1","bankifsc1"=>"$bankifsc1","bankacc1"=>"$bankacc1","bankname1"=>"$bankname1","contactphno2"=>"$contactphno2","contactemail2"=>"$contactemail2","contactname2"=>"$contactname2","contactphno1"=>"$contactphno1","contactemail1"=>"$contactemail1","vender_id"=>"$venderid","vemail"=>"$vemail","vphone"=>"$vphone","$add1"=>"add1","cst"=>"$cst","vat"=>"$vat","country"=>"$country","contact1"=>"$contact1","vcompany"=>"$vendername","venderlastrans"=>"$venderlastrans","lastrandt"=>"$lastrandt","lastquatation"=>"$lastquatation","purchaseorder"=>"$purchaseorder");
		//$result2=array("branch2"=>"$branch2","bankswift2"=>"$bankswift2","bankifsc2"=>"$bankifsc2","bankacc2"=>"$bankacc2","bankname2"=>"$bankname2","branch1"=>"$branch1","bankswift1"=>"$bankswift1","bankifsc1"=>"$bankifsc1","bankacc1"=>"$bankacc1","bankname1"=>"$bankname1","contactphno2"=>"$contactphno2","contactemail2"=>"$contactemail2","contactname2"=>"$contactname2","contactphno1"=>"$contactphno1","contactemail1"=>"$contactemail1","vender_id"=>"$venderid","vemail"=>"$vemail","vphone"=>"$vphone","$add1"=>"add1","cst"=>"$cst","vat"=>"$vat","country"=>"$country","contact1"=>"$contact1","vcompany"=>"$vendername","venderlastrans"=>"$venderlastrans","lastrandt"=>"$lastrandt","lastquatation"=>"$lastquatation","purchaseorder"=>"$purchaseorder");
		echo json_encode($result2);
	}
	public function save_purchaseorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		$pono=$this->input->post('pono');
		$dte=$this->input->post('dte');
		$refno=$this->input->post('refno');
		$notr=$this->input->post('numofrows');
		
        //$this->fpdf->Output($filename,'F');
		 //$this->fpdf->Output("$filename",'F');
		$item=array();$model1=array();
		for($i=1;$i<=$notr;$i++)
		{
			$matid=$this->input->post("matid_$i");
			$modelname=$this->input->post("modelname_$i");
			$matqty=$this->input->post("prqty1_$i");
			$modelid=$this->input->post("modelid1_$i");
			$specificat=$this->input->post("specification_$i");
			$colorspeci=$this->input->post("colorspe_$i");
			if(isset($matid) && !empty($matid) && isset($matqty) && !empty($matqty))
			{
				$item1=$matid.";".$modelname.";".$matqty;
			
			   array_push($item,$item1);
			}
			if(isset($modelid) && !empty($modelid) && isset($matqty) && !empty($matqty))
			{
				$mode2=$modelid.";".$modelname.";".$matqty.";".$specificat.";".$colorspeci;
				array_push($model1,$mode2);
			}
			
		}
		$modimplode=implode(",",$model1);
		$itemimplode=implode(",",$item);echo $itemimplode ; echo "<br>" ; echo $modimplode ; 
	   $ven=$this->input->post('vendorid');
	   $ven1=implode(",",$ven);
	   $ven=explode(",",$ven1);
	   print_r($ven);
	   $ven2=array();
	   foreach($ven as $row)
	   {
	   	if(in_array($row,$ven2))
		{
			
		}else{
			array_push($ven2,$row);
		}
	   }
	  // $ven1=array_unique($ven);
	  print_r($ven2);
	  $data['vid']=$ven2;
	   
		$vendorid=implode(",",$this->input->post('vendorid'));
		
		
		$dataarray=array(
			"poid"=>$pono,
			"doe"=>$dte,
			"refno"=>$refno,
			"spareparts"=>$itemimplode,
			"modelcode"=>$modimplode,
			"vendors"=>$vendorid
		);
		$this->Purchase_model->savepurcsaeorder($dataarray);
		$data['poid']=$pono;
		$data['refno']=$refno;
		$data['vendorslist']=$vendorid;
		$data['doe']=$dte;
		$data['poid']=$pono;
		$data['refno']=$refno;
		$data['item_product']=$itemimplode;
		
		
		$venderlist=explode(",",$vendorid);
		$vendmail=array();
			
			$vid=$row;
			$get_venderemail=$this->Purchase_model->getvenderemail($vid);
			foreach($get_venderemail as $row)
			{
				$venderemail=$row->vemail;
				$vender_name=$row->vcompany;
				$vendid=$row->vender_id;
				array_push($vendmail,$venderemail);
				
			}
		//$data['name']=$vender_name;
		//$data['email']=$venderemail;
		//$data['venid']=$vendid;
		
		$vendidemailimplode=implode(",",$vendmail);
		$data['vendmail']=$vendidemailimplode;
		$text1="Dear Sir,";
		$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(5);
		$this->fpdf->MultiCell(160,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Spare Parts Requirement List:-",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf->Cell(30,5,'Parts ID',1,0,'C');
		$this->fpdf->Cell(60,5,'Spare Parts Name',1,0,'C');
		$this->fpdf->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf->Cell(30,5,'M.Code',1,0,'C');
		$this->fpdf->Cell(20,5,'Quantity',1,1,'C');
		if(!empty($itemimplode)){
		$itemlist=explode(",",$itemimplode);
		$i=1;
		foreach($itemlist as $row)
		{
			$list=explode(";",$row);
			print_r($list);
			$itemid=$list[0];
			
			$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"$itemid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(60,5,"$productname",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$modelcode",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$itemqty",1,1,'C');
		$i++;
		}
		}
		if(isset($modimplode) && !empty($modimplode)){
		$modimplodelist=explode(",",$modimplode);
		
		foreach($modimplodelist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			//$itemid=$list[0];
			
			//$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			//foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(60,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$model_name",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$qty",1,1,'C');
		$i++;
		}
		}
		//GK/16-17/1_1,GK/16-17/20,GK/16-17/19,GK/16-17/18,GK/16-17/17,GK/16-17/16,GK/16-17/15,GK/16-17/14,GK/16-17/2,GK/16-17/33,GK/16-17/32,GK/16-17/31,GK/16-17/23,GK/16-17/24,GK/16-17/25,GK/16-17/26,GK/16-17/28,GK/16-17/29,GK/16-17/30,GK/16-17/27,GK/16-17/22,GK/16-17/8,GK/16-17/4,GK/16-17/5,GK/16-17/6,GK/16-17/7,GK/16-17/3,GK/16-17/9,GK/16-17/13,GK/16-17/12,GK/16-17/11,GK/16-17/10,
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Specification Requirement List",0,0,'L');
		$this->fpdf->ln(5);
		if(isset($modimplode) && !empty($modimplode)){
		$modellist=explode(",",$modimplode);
		$i=1;
		foreach($modellist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			$spec=$list[3];
			$color=$list[4];
			//echo $color;
			//echo "<br>++++++++++<br>";
			 $this->fpdf->SetFont('Arial','B',12);
		   $this->fpdf->cell(150,5,"$i. $model_name",0,0,"L");
		   $this->fpdf->ln(5);
		   $colorexplode=explode("#",$color);
		   $countcolor=count($colorexplode);
		  // print_r($countcolor);
		   $ck=1;
		   $colorexplode=array_filter($colorexplode);
		  // print_r($colorexplode);
		  $this->fpdf->Cell(160,5,"Color Specification for $model_name ",1,1,'C');
		  foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcode=$colval[1];
			 $getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;
			      $diffcol=explode(",",$colcod);
			      $r=intval($diffcol[0]);
				  $g=intval($diffcol[1]);
				  $b=intval($diffcol[2]);
			  }
			 
			 	$this->fpdf->SetFillColor($r,$g,$b);
			   $this->fpdf->Cell(16,5,"",1,0,'C',true);
			
			  
			
			 
		  }
		   $this->fpdf->ln(5);
		   foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcdeval=$colval[0];
			 /*$getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;
			      $diffcol=explode(",",$colcod);
			      $r=intval($diffcol[0]);
				  $g=intval($diffcol[1]);
				  $b=intval($diffcol[2]);
			  }*/
			 
			 	//$this->fpdf->SetFillColor($r,$g,$b);
			   $this->fpdf->Cell(16,5,"$colorcdeval",1,0,'C');
			
			  
			
			 
		  }
		   
		   $this->fpdf->ln(10);
		   $k=1;
		   $this->fpdf->SetFont('Arial','B',10);
		   $this->fpdf->SetFillColor(255,0,0);
		    $this->fpdf->Cell(15,5,"Slno.",1,0,'C',true);
			$this->fpdf->Cell(30,5,'PartsId',1,0,'C');
			$this->fpdf->Cell(45,5,'Name',1,0,'C');
			$this->fpdf->Cell(85,5,'Specification',1,1,'C');
			$specexplode=explode("||",$spec);
			$specexplode=array_filter($specexplode);echo "<br>=================<br>";
			print_r($specexplode);
			$this->fpdf->SetFont('Arial','',6);
			foreach($specexplode as $spec2 )
			{
				$this->fpdf->SetFont('Arial','',6);
				$specimplode1=explode("_",$spec2);
				//print_r($specimplode1);
				//echo "<br>";
			   $countspec=count($specimplode1);
			 // echo "<br>";
				if($countspec>1)
				{
					$partsid=$specimplode1[0];
					$sptxt=$specimplode1[1];
					$getspectxt=$this->Purchase_model->getspectxt($sptxt);
					foreach($getspectxt as $row){ $ssptxt2=$row->specification;}
				}else{
					$partsid=$specimplode1[0];
					$ssptxt2="";
				}
				
				if(isset($ssptxt2) && !empty($ssptxt2))
				{
					$ssptxt2=$ssptxt2;
				}else{
					$ssptxt2="";
				}
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
				
				foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
				$this->fpdf->Cell(15,5,"$k",1,0,'C');
			    $this->fpdf->Cell(30,5,"$partsid",1,0,'C');
			   $this->fpdf->Cell(45,5,"$productname",1,0,'C');
			    $this->fpdf->SetFont('Arial','',6);
			   $this->fpdf->Cell(85,5,"$ssptxt2",1,1,'C');
			   $k++;
			}
			
			$i++;
		   
		}
		}
		//$this->fpdf->Cell(40,10,'Hello Worldadfdafdsfdssdf!');
		
		$filename="Fpdfoutput/test.pdf";
		echo $vendidemailimplode;
        //$this->fpdf->Output($filename,'F');
		 $this->fpdf->Output("$filename",'F');
		 $this->load->view("send_mail/sendemail",$data);
		 

	}
  public function getdetails12($productid)
  {
  	
  	//echo "hello";
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	echo "hello";
	//$pid=$productid;
	//$alldetails=$this->Purchase_model->getalldt($pid);
  // print_r($alldetails);
  }
	
	
}