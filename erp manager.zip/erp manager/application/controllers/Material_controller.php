<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Material_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Material_model');
	}
	
	public function purchase_dash()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
    	$this->load->view('purchase/material_dashboard',$data);
	}
	
}