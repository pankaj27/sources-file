<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_warehouse extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->library('fpdf_gen');
		
		$this->load->model('stockManage_model');
		$this->load->model('Manage_warehouse_model');
		$this->load->model('Manufactarer_model');
		$this->data = array(
            'pre_id' =>5,
           
        );
	}
		public function vieworder_details()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				//echo 'true';
				//
				$uid=$this->session->userdata('user_id');
				$getgodown=$this->Manage_warehouse_model->getgodowncode($uid);
				$data['getgodwon']=$getgodown;
				$data['title']="View Latest Order Details";
				
				$data['getbooking_details']=$this->Manage_warehouse_model->get_bookingdetails($getgodown);
				$this->load->view('warehouse/vieworder',$data);
			}else{
				
				redirect('Login','refresh');
				
				
			}
               //echo 'true';
              
               
              
            
		}
		public function get_viewdetails_order($id,$gdownid)
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				//echo 'true';
				//redirect('Login','refresh');
				$getmodelname=$this->Manage_warehouse_model->getmodeldetails($id);
				$reslt=$this->Manage_warehouse_model->getqnty($id);
				$resltex=explode(";",$reslt);
				$data['qnty']=$resltex[0];
				$data['modelname']=$resltex[1];
				$data['getstockdetails']=$this->Manage_warehouse_model->get_stock_detailsin_warehouse($gdownid);
				$data['title']="Warehouse Order Details";
				$data['modelnme']=$this->Manage_warehouse_model->getmodelname($resltex[1]);
		        $data['getpareparts']=$this->stockManage_model->getsparepartsbymodel($data['modelnme']);
		
				$data['ordid']=$id;
				$data['gdowncode']=$this->Manage_warehouse_model->get_godowncode($gdownid);
				$data['model']=$this->stockManage_model->getmodel();
		        $data['temp_data']=$this->stockManage_model->getallpono_godownmodel($data['gdowncode'],$data['modelnme']);
				//print_r($data['temp_data']);
				$data['gdid']=$gdownid;
				$data['boxstock']=$this->Manage_warehouse_model->getboswisestock($gdownid,$data['modelnme']);
				$data['allsparepart']=$this->Manage_warehouse_model->getallspareparts($getmodelname);
				$this->load->view('warehouse/stock_details',$data);
				
				
			}else
			{
					redirect('Login','refresh');
			}
			
		}
		public function getall_print_list()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				$cat=$this->input->post("category");
				if($cat==1)
				{
					$modelcode=$this->input->post();
					$this->load->view('warehouse/boestockprint',$data);
				}
				if($cat==2)
				{
					
					
				}
				
				
				
			
			}else{
				redirect('Login','refresh');
			}
			
			
		}
		public function get_checkorder()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
			$manf=$this->input->post("manf");
			date_default_timezone_set("Asia/Kolkata");
			//$logistic=$this->input->post("logis");
			$ordername=$this->input->post("ordername");
			$modelnme=$this->input->post("modelnme");
			$ordername1=$ordername;
			//$transfertp=$this->input->post("transfertp");
			$warehouse=$this->input->post("warehouse");
		    $pocount=$this->input->post('ponocount');
			$get_manfactid=$this->Manage_warehouse_model->getlastmanufatid();
			$getbookingid=$this->Manage_warehouse_model->getbookingid($ordername);
			//$trackno=$this->input->post("trackno");
			//$partyname=$this->input->post("partyname");
			//$drivername=$this->input->post("drivername");
			//$drivercontact=$this->input->post("drivercontact");
			$ordername=$getbookingid;
			$boxcount=$this->input->post("boxcount");
		   $boxprtscount=$this->input->post("boxprts");
		   $indiprts=$this->input->post("indiprts");
		  $boxname1="";$boxqty1="";
		  if(isset($manf) && !empty($manf)){
			$transfertp=$manf;
			$totmodelqnty=$this->input->post("modelqty");
			$data_updte=array(
				"status"=>1
			);
			$this->Manage_warehouse_model->updatestats($data_updte,$ordername1);
			$data_manfact=array(
							 "orderno"=>$ordername,
							 "doe"=>date('Y-m-d'),
							 "model"=>$modelnme,
							 "qnty"=>$totmodelqnty,
							 //"warehousecode"=>
							 "dos"=>date('Y-m-d h:i:s A'),
							 "crtdby"=>$this->session->userdata('user_name'),
							 "manfactid"=>$get_manfactid,
							 "warehousecode"=>$warehouse,
							 
							);
							//print_r($data_manfact);
							$this->Manage_warehouse_model->save_manfact($data_manfact);
		for($po=1;$po<=intval($pocount);$po++)
		{
			$warehouse1=$warehouse;
		      $pono=$this->input->post("pono_$po");//echo "&nbsp;&nbsp;";
			 $totporow=$this->input->post("totporow_$po");
			//echo "<br>"; 
			// echo $po;
			 for($totr=1;$totr<intval($totporow);$totr++)
			 {
			 	 $totr;
				//echo "<br>====";
			 	 $bx="boxnme_".$po."_".$totr;
				// "<br>";
			 	$crt="currentbx_".$po."_".$totr;
				$prts="boxprtsname_".$po."_".$totr;
				$prtsq="boxprtsqty_".$po."_".$totr;
			 	$boxname=$this->input->post($bx);
				
				if($boxname==$boxname1){
					$boxqty=$boxqty1;
					
				}else{
					$boxqty=$this->input->post($crt);
				}
				
				  $prtsid=$this->input->post($prts);
				 $prtsqty=$this->input->post($prtsq);
				//echo "+++++++++++++++++";	
//////////////////////////individual parts--------------
				$indiprts1="partsini_".$po."_".$totr;
				$indiprtsqty1="indiprtsqty_".$po."_".$totr;
                $indiprts=$this->input->post($indiprts1); 
                $indiprtsqty=$this->input->post($indiprtsqty1);
                 //echo "+++++++++++++++++";
			 // echo "<br>";
				if(isset($prtsqty) && !empty($prtsqty) && isset($prtsid) && !empty($prtsid)&& intval($prtsqty)>0)
				{
					
					//echo $boxname.$boxqty.$prtsid.$prtsqty;
							$getmodel=$this->stockManage_model->getmodelname($prtsid);
							if(intval($boxqty)>0){
							$data_array=array(
							    "orderno"=>$ordername,
								"model"=>$modelnme,
								"pono"=>$pono,
								"trnstype"=>$transfertp,
								"boxno"=>$boxname,
								"boxqty"=>$boxqty,
								"partsid"=>$prtsid,
								"partsqty"=>$prtsqty,
								//"warehousecode"=>$warehouse1,
								"tot"=>$prtsqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							//print_r($data_array);
							$this->Manage_warehouse_model->savetologistic($data_array);
							
							}
							
						//echo "<br>";
							//$this->stockManage_model->saveorderdategetpass($data_array);
					
				}
				if(isset($indiprtsqty) && !empty($indiprtsqty))
				{
							$getmodel=$this->stockManage_model->getmodelname($indiprts);
							$data_array=array(
							   	"orderno"=>$ordername,
								"model"=>$getmodel,
								"pono"=>$pono,
								"trnstype"=>$transfertp,
								"partsid"=>$indiprts,
								"partsqty"=>$indiprtsqty,
								"tot"=>$indiprtsqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							print_r($data_array);
							//echo "<br>";
						//$this->stockManage_model->saveorderdategetpass($data_array);
				}
				$boxname1=$boxname;
				$boxqty1=$boxqty;
			 }
			 
			
			
		}
		}
			//$this->load->view();
			//$data['getallorderdetails']=$this->stockManage_model->getallorderdetails($orderid);
	     //$this->load->view('warehouse/viewwarehousecheckstock',$data);
			redirect('Manage_warehouse/checkwarehouseorderdetails','refresh')	;
				
				
			
			}else{
				redirect('Login','refresh');
			}
		}
  public function checkwarehouseorderdetails()
  {
  	       $this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				
				$data['getalld']=$this->Manage_warehouse_model->getallwarestockdata();
				
				$this->load->view('warehouse/get_all_stock_warehouse',$data);
			
			}else{
				redirect('Login','refresh');
			}
			
  }
  public function checking_stock_warehouse($id)
  {
  	   $this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				
				$data['orderid']=$id;
		       $data['getallorderdetails']=$this->Manage_warehouse_model->getall_orderdetails($id);
			   //print_r($data['getallorderdetails']);
			   $this->load->view('warehouse/checkingwarehousestockbyorder',$data);
		
			
			}else{
				redirect('Login','refresh');
			}
  }
  public function savefinalgetpass()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
    $orderid=$this->input->post("ordid");
	$prtsqty=$this->input->post("prtsq");
	$shortage=$this->input->post("shortage");
	echo $tot=intval($prtsqty)-intval($shortage);
	$data['editsave']=$this->Manage_warehouse_model->saveedit($orderid,$shortage,$tot);
	
  
  }
  public function print_boxwise($id)
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				
				//$data['orderid']=$id;
		      // $data['getallorderdetails']=$this->Manage_warehouse_model->getall_orderdetails($id);
			  // $this->load->view('warehouse/checkingwarehousestockbyorder',$data);
			   $data['pono']=$id;
		       $this->load->view('warehouse/boxwiseprint',$data);
		
			
			}else{
				redirect('Login','refresh');
			}
  }
  public function print_individual($id)
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				
				//$data['orderid']=$id;
		      // $data['getallorderdetails']=$this->Manage_warehouse_model->getall_orderdetails($id);
			  // $this->load->view('warehouse/checkingwarehousestockbyorder',$data);
			   $data['pono']=$id;
		       $this->load->view('warehouse/indivicualstock',$data);
		
			
			}else{
				redirect('Login','refresh');
			}
  }
  public function save_checkingwarehouse()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				
			  $tottablerow=intval($this->input->post("tottablerow"));
				$order=$this->input->post("orderno");
				for($iq=1;$iq<intval($tottablerow);$iq++){
					$slid=$this->input->post("slid_".$iq);
					$shortage=$this->input->post("shortage_".$iq);
					$tot=$this->input->post("total_".$iq);
					if(isset($shortage) && !empty($shortage))
					{
						$data_arr=array(
							"shortage"=>$shortage,
							"tot"=>$tot
						
						);
						$this->Manage_warehouse_model->update_checkinggatepass($data_arr,$slid);
					}
					$data_array_booking_status=array(
				   	"getpassstatus"=>"1"
				   );
					$this->Manufactarer_model->updategetpassstatus($data_array_booking_status,$order);
					
					
				}
				redirect('Manage_warehouse/checkwarehouseorderdetails','refresh');
				
			
			}else{
				redirect('Login','refresh');
			}
  }
  public function checking_stock_warehouse_form()
  {
  	   $this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				$orderid=$this->input->post('orderid');
				$data['orderid']=$orderid;
				$data['title']="Checking List";
		       $data['getallorderdetails']=$this->Manage_warehouse_model->getall_orderdetails($orderid);
			   //print_r($data['getallorderdetails']);
			   $this->load->view('warehouse/checkingwarehousestockbyorder',$data);
		
			
			}else{
				redirect('Login','refresh');
			}
  }
  public function get_checkorder_second()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$userprev=$this->session->userdata('pre_vlg');
			$moduleid=$this->data['pre_id'];
			if ((strpos($userprev, $moduleid) !== false)|| $userprev==$moduleid) {
				//#####################################################################
			$manf=$this->input->post("manf");
			echo $logis=$this->input->post("logis");
			date_default_timezone_set("Asia/Kolkata");
			//$logistic=$this->input->post("logis");
			$ordername=$this->input->post("ordername");
			$modelnme=$this->input->post("modelnme");
			$ordername1=$ordername;
			//$transfertp=$this->input->post("transfertp");
			 $warehouse=$this->input->post("warehouse");
			 $totrow=$this->input->post("totrow");
		    //$pocount=$this->input->post('ponocount');
			$get_manfactid=$this->Manage_warehouse_model->getlastmanufatid();
			$getbookingid=$this->Manage_warehouse_model->getbookingid($ordername);
			//$trackno=$this->input->post("trackno");
			//$partyname=$this->input->post("partyname");
			//$drivername=$this->input->post("drivername");
			//$drivercontact=$this->input->post("drivercontact");
			$ordername=$getbookingid;
			//$boxcount=$this->input->post("boxcount");
		  // $boxprtscount=$this->input->post("boxprts");
		  // $indiprts=$this->input->post("indiprts");
			if(isset($manf)&& !empty($manf))	
			{
			//echo 1;exit;				
							
						
					
				
				
				if(isset($totrow) && !empty($totrow))
				{
						$totmodelqnty=$this->input->post("modelqty");
							$data_updte=array(
								"status"=>1
							);
							$this->Manage_warehouse_model->updatestats($data_updte,$ordername1);
							$data_manfact=array(
							"orderno"=>$ordername,
							 "doe"=>date('Y-m-d'),
							 "model"=>$modelnme,
							 "qnty"=>$totmodelqnty,
							 //"warehousecode"=>
							 "dos"=>date('Y-m-d h:i:s A'),
							 "crtdby"=>$this->session->userdata('user_name'),
							 "manfactid"=>$get_manfactid,
							 "warehousecode"=>$warehouse,
							 
							);
							//print_r($data_manfact);
							$this->Manage_warehouse_model->save_manfact($data_manfact);
		
					
					
					
					
					
					
					
					
					for($kl=1;$kl<intval($totrow);$kl++)
					{
						 $boxqty=$this->input->post("boxqty_".$kl);
						 $boxnam=$this->input->post("boxname_".$kl);
						$tableid=$this->input->post("reqid_".$kl);
						$reqty=$this->input->post("reqty_".$kl);
						$boxcode=$this->input->post("boxcode_".$kl);
						$reqid=$this->input->post("reqid_".$kl);
						 $partsid=$this->input->post("partsid_".$kl);
						if(isset($boxnam) && !empty($boxnam))
						{
							$data_array=array(
								"doe"=>date('Y-m-d'),
								"orderno"=>$ordername,
								"boxname"=>$boxnam,
								"boxcode"=>$boxcode,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								"dos"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name'),
								"boxqty"=>$boxqty
							);
							//print_r($data_array);
							//echo "<br>";
							$this->Manage_warehouse_model->save_required_qty($data_array);
     ///////////////////////////////////////// update box wise stock  //////////////////////////////////////////////
     $getsell_qty=$this->Manage_warehouse_model->getsellqty($reqid);if(!empty($getsell_qty) && isset($getsell_qty)){ foreach($getsell_qty as $rowbx){ $sl=intval($rowbx->sellqty);}}else{ $sl=0;}
       $newsl=intval($sl)+intval($reqty);
                          $data_array_box=array(
								"sellqty"=>$newsl,
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
							
                           $this->Manage_warehouse_model->update_box_qty($data_array_box,$reqid);

////////////////////////////////////////////// checking stock update     ////////////////////////////////////////////////
							$data_array=array(
							    "orderno"=>$ordername,
								"model"=>$modelnme,
								"trnstype"=>$manf,
								"boxno"=>$boxnam,
								"boxqty"=>$boxqty,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								//"warehousecode"=>$warehouse1,
								"tot"=>$reqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							//print_r($data_array);
							$this->Manage_warehouse_model->savetologistic($data_array);
							
							
		//##################################  godownstock update #######################################
							$getgodownstock=$this->Manage_warehouse_model->getgodownstock($partsid,$warehouse);
							if(!empty($getgodownstock) && isset($getgodownstock))
							{
								foreach($getgodownstock as $row)
								{
									$closestock=intval($row->closestock);
									$gwnid=$row->id;
								}
								$newstock=intval($closestock)-intval($reqty);
								$data_ar=array(
									"openqty"=>$closestock,
									"qty"=>$reqty,
									"closestock"=>$newstock,
									"doe"=>date('Y-m-d'),
									"crted"=>$this->session->userdata('user_name'),
									
								);
								$this->Manage_warehouse_model->upate_godownsock($gwnid,$partsid,$data_ar);
							}
				
		//##############################################  transaction spareparts   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getlast_transaction($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rw)
							{
								$tot=intval($rw->total);
							}
							$newqty=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"date"=>date('Y-m-d'),
								"partsId"=>$partsid,
								"total"=>$newqty,
								"saleQty"=>$reqty,
								"crtd"=>$this->session->userdata('user_name'),
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
							$this->Manage_warehouse_model->savetransactionmasterspareparts($data_array_trns_parts);
							
						  }
		//##############################################  Update main Stock   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getcurrent_stock($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rwmaster)
							{
								$tot=intval($rwmaster->qnty);
								
							}
							$newqtymaster=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"qnty"=>$newqtymaster,
								"openQnty"=>$tot,
								"lastupdt"=>date('Y-m-d h:i:s A'),
								"stockentryupdt"=>$this->session->userdata('user_name')
								
								
							);
							$this->Manage_warehouse_model->update_master_transaction($data_array_trns_parts,$partsid);
							
						  }
		
							//print_r($getgodownstock);
							
						}else{
							
							$data_array=array(
								"doe"=>date('Y-m-d'),
								"orderno"=>$ordername,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								"dos"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name'),
								
							);
							$this->Manage_warehouse_model->save_required_qty($data_array);
							
							
 ///////////////////////////////////////// update box wise stock  //////////////////////////////////////////////
                         $getsell_qty=$this->Manage_warehouse_model->getsellqty($reqid);if(!empty($getsell_qty) && isset($getsell_qty)){ foreach($getsell_qty as $rowbx){ $sl=intval($rowbx->sellqty);}}else{ $sl=0;}
                          $newsl=intval($sl)+intval($reqty);
                          $data_array_box=array(
								"sellqty"=>$newsl,
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
		
                           $this->Manage_warehouse_model->update_box_qty($data_array_box,$reqid);
////////////////////////////////////////////////  checking getpass  stock ///////////////////////////////////////////

////////////////////////////////////////// checking stock update     ////////////////////////////////////////////////
							$data_array=array(
							    "orderno"=>$ordername,
								"model"=>$modelnme,
								"trnstype"=>$manf,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								//"warehousecode"=>$warehouse1,
								"tot"=>$reqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							//print_r($data_array);
							$this->Manage_warehouse_model->savetologistic($data_array);
						

							
		//##################################  godownstock update #######################################
							
							$getgodownstock=$this->Manage_warehouse_model->getgodownstock($partsid,$warehouse);
							if(!empty($getgodownstock) && isset($getgodownstock))
							{
								foreach($getgodownstock as $row)
								{
									$closestock=intval($row->closestock);
									$gwnid=$row->id;
								}
								$newstock=intval($closestock)-intval($reqty);
								$data_ar=array(
									"openqty"=>$closestock,
									"qty"=>$reqty,
									"closestock"=>$newstock,
									"doe"=>date('Y-m-d'),
									"crted"=>$this->session->userdata('user_name'),
									
								);
								$this->Manage_warehouse_model->upate_godownsock($gwnid,$partsid,$data_ar);
							}
		//##############################################  transaction spareparts   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getlast_transaction($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rw)
							{
								$tot=intval($rw->total);
							}
							$newqty=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"date"=>date('Y-m-d'),
								"partsId"=>$partsid,
								"total"=>$newqty,
								"saleQty"=>$reqty,
								"crtd"=>$this->session->userdata('user_name'),
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
							$this->Manage_warehouse_model->savetransactionmasterspareparts($data_array_trns_parts);
							
						  }
		//##############################################  Update main Stock   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getcurrent_stock($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rwmaster)
							{
								$tot=intval($rwmaster->qnty);
								
							}
							$newqtymaster=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"qnty"=>$newqtymaster,
								"openQnty"=>$tot,
								"lastupdt"=>date('Y-m-d h:i:s A'),
								"stockentryupdt"=>$this->session->userdata('user_name')
								
								
							);
							$this->Manage_warehouse_model->update_master_transaction($data_array_trns_parts,$partsid);
							
						  }
		
							//print_r($getgodownstock);
				
							
							//print_r($data_array);
							//echo "<br>";
							
						}
						
					}
				}
				
			}
/*-..................................................................................................................
##########################################################################################################################
//-------------------------------------------------------------------------------------------------------------------------*/
			if(isset($logis) && !empty($logis))
			{
				
							
							
						
					
				
				
				if(isset($totrow) && !empty($totrow))
				{
						$totmodelqnty=$this->input->post("modelqty");
							$data_updte=array(
								"status"=>1
							);
							$this->Manage_warehouse_model->updatestats($data_updte,$ordername1);
							$data_manfact=array(
							"orderno"=>$ordername,
							 "doe"=>date('Y-m-d'),
							 "model"=>$modelnme,
							 "qnty"=>$totmodelqnty,
							 //"warehousecode"=>
							 "dos"=>date('Y-m-d h:i:s A'),
							 "crtdby"=>$this->session->userdata('user_name'),
							 "manfactid"=>$get_manfactid,
							 "warehousecode"=>$warehouse,
							 
							);
							//print_r($data_manfact);
							$this->Manage_warehouse_model->save_manfact($data_manfact);
		
					
					
					
					
					
					
					
					
					for($kl=1;$kl<intval($totrow);$kl++)
					{
						 $boxqty=$this->input->post("boxqty_".$kl);
						 $boxnam=$this->input->post("boxname_".$kl);
						$tableid=$this->input->post("reqid_".$kl);
						$reqty=$this->input->post("reqty_".$kl);
						$boxcode=$this->input->post("boxcode_".$kl);
						$reqid=$this->input->post("reqid_".$kl);
						 $partsid=$this->input->post("partsid_".$kl);
						if(isset($boxnam) && !empty($boxnam))
						{
							$data_array=array(
								"doe"=>date('Y-m-d'),
								"orderno"=>$ordername,
								"boxname"=>$boxnam,
								"boxcode"=>$boxcode,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								"dos"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name'),
								"boxqty"=>$boxqty
							);
							//print_r($data_array);
							//echo "<br>";
							$this->Manage_warehouse_model->save_required_qty($data_array);
     ///////////////////////////////////////// update box wise stock  //////////////////////////////////////////////
     $getsell_qty=$this->Manage_warehouse_model->getsellqty($reqid);if(!empty($getsell_qty) && isset($getsell_qty)){ foreach($getsell_qty as $rowbx){ $sl=intval($rowbx->sellqty);}}else{ $sl=0;}
       $newsl=intval($sl)+intval($reqty);
                          $data_array_box=array(
								"sellqty"=>$newsl,
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
							
                           $this->Manage_warehouse_model->update_box_qty($data_array_box,$reqid);

////////////////////////////////////////////// checking stock update     ////////////////////////////////////////////////
							$data_array=array(
							    "orderno"=>$ordername,
								"model"=>$modelnme,
								"trnstype"=>"$logis",
								"boxno"=>$boxnam,
								"boxqty"=>$boxqty,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								//"warehousecode"=>$warehouse1,
								"tot"=>$reqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							print_r($data_array);
							//$this->Manage_warehouse_model->savetologistic($data_array);
							
							
		//##################################  godownstock update #######################################
							$getgodownstock=$this->Manage_warehouse_model->getgodownstock($partsid,$warehouse);
							if(!empty($getgodownstock) && isset($getgodownstock))
							{
								foreach($getgodownstock as $row)
								{
									$closestock=intval($row->closestock);
									$gwnid=$row->id;
								}
								$newstock=intval($closestock)-intval($reqty);
								$data_ar=array(
									"openqty"=>$closestock,
									"qty"=>$reqty,
									"closestock"=>$newstock,
									"doe"=>date('Y-m-d'),
									"crted"=>$this->session->userdata('user_name'),
									
								);
								$this->Manage_warehouse_model->upate_godownsock($gwnid,$partsid,$data_ar);
							}
				
		//##############################################  transaction spareparts   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getlast_transaction($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rw)
							{
								$tot=intval($rw->total);
							}
							$newqty=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"date"=>date('Y-m-d'),
								"partsId"=>$partsid,
								"total"=>$newqty,
								"saleQty"=>$reqty,
								"crtd"=>$this->session->userdata('user_name'),
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
							$this->Manage_warehouse_model->savetransactionmasterspareparts($data_array_trns_parts);
							
						  }
		//##############################################  Update main Stock   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getcurrent_stock($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rwmaster)
							{
								$tot=intval($rwmaster->qnty);
								
							}
							$newqtymaster=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"qnty"=>$newqtymaster,
								"openQnty"=>$tot,
								"lastupdt"=>date('Y-m-d h:i:s A'),
								"stockentryupdt"=>$this->session->userdata('user_name')
								
								
							);
							$this->Manage_warehouse_model->update_master_transaction($data_array_trns_parts,$partsid);
							
						  }
		
							//print_r($getgodownstock);
							
						}else{
							
							$data_array=array(
								"doe"=>date('Y-m-d'),
								"orderno"=>$ordername,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								"dos"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name'),
								
							);
							$this->Manage_warehouse_model->save_required_qty($data_array);
							
							
 ///////////////////////////////////////// update box wise stock  //////////////////////////////////////////////
                         $getsell_qty=$this->Manage_warehouse_model->getsellqty($reqid);if(!empty($getsell_qty) && isset($getsell_qty)){ foreach($getsell_qty as $rowbx){ $sl=intval($rowbx->sellqty);}}else{ $sl=0;}
                          $newsl=intval($sl)+intval($reqty);
                          $data_array_box=array(
								"sellqty"=>$newsl,
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
		
                           $this->Manage_warehouse_model->update_box_qty($data_array_box,$reqid);
////////////////////////////////////////////////  checking getpass  stock ///////////////////////////////////////////

////////////////////////////////////////// checking stock update     ////////////////////////////////////////////////
							$data_array=array(
							    "orderno"=>$ordername,
								"model"=>$modelnme,
								"trnstype"=>$logis,
								"partsid"=>$partsid,
								"partsqty"=>$reqty,
								//"warehousecode"=>$warehouse1,
								"tot"=>$reqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							//print_r($data_array);
							$this->Manage_warehouse_model->savetologistic($data_array);
						

							
		//##################################  godownstock update #######################################
							
							$getgodownstock=$this->Manage_warehouse_model->getgodownstock($partsid,$warehouse);
							if(!empty($getgodownstock) && isset($getgodownstock))
							{
								foreach($getgodownstock as $row)
								{
									$closestock=intval($row->closestock);
									$gwnid=$row->id;
								}
								$newstock=intval($closestock)-intval($reqty);
								$data_ar=array(
									"openqty"=>$closestock,
									"qty"=>$reqty,
									"closestock"=>$newstock,
									"doe"=>date('Y-m-d'),
									"crted"=>$this->session->userdata('user_name'),
									
								);
								$this->Manage_warehouse_model->upate_godownsock($gwnid,$partsid,$data_ar);
							}
		//##############################################  transaction spareparts   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getlast_transaction($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rw)
							{
								$tot=intval($rw->total);
							}
							$newqty=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"date"=>date('Y-m-d'),
								"partsId"=>$partsid,
								"total"=>$newqty,
								"saleQty"=>$reqty,
								"crtd"=>$this->session->userdata('user_name'),
								"lstupdt"=>date('Y-m-d h:i:s A')
								
							);
							$this->Manage_warehouse_model->savetransactionmasterspareparts($data_array_trns_parts);
							
						  }
		//##############################################  Update main Stock   Table  #############################
		                  $getlastransaction=$this->Manage_warehouse_model->getcurrent_stock($partsid);	
						  if(!empty($getlastransaction) && isset($getlastransaction))				
						  {
						  	foreach($getlastransaction as $rwmaster)
							{
								$tot=intval($rwmaster->qnty);
								
							}
							$newqtymaster=intval($tot)-intval($reqty);
							$data_array_trns_parts=array(
								"qnty"=>$newqtymaster,
								"openQnty"=>$tot,
								"lastupdt"=>date('Y-m-d h:i:s A'),
								"stockentryupdt"=>$this->session->userdata('user_name')
								
								
							);
							$this->Manage_warehouse_model->update_master_transaction($data_array_trns_parts,$partsid);
							
						  }
		
							//print_r($getgodownstock);
				
							
							//print_r($data_array);
							//echo "<br>";
							
						}
						
					}
				}
			}
				
				
				
			redirect('Manage_warehouse/checkwarehouseorderdetails','refresh')	;
				
				
				
				
				//###########################################################################
			
			}else{
				redirect('Login','refresh');
			}
  }
		
		
}
