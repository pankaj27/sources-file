<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Purchase_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		$this->load->library('fpdf_gen1');
		//$this->load->library(array('session','authentication'));
		$this->load->model('Purchase_model');
		$this->load->model('Bankinfo_Model');
	}
	
	public function purchase_dash()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
    	$this->load->view('purchase_master/purchase_dashboard',$data);
	}
	public function createNew()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dash Board ';
		$data['allmaterial']=$this->Purchase_model->get_material();
		$data['allvendors']=$this->Purchase_model->getall_vendors();
		$data['getallproduct']=$this->Purchase_model->getallproduct();
		$data['getcolorcode']=$this->Purchase_model->getall_colorcode();
		$purorder=$this->Purchase_model->getpurchaseorder();
		if(isset($purorder) && !empty($purorder))
		{
			$pono=intval(substr($purorder,-5));
			$newpono=$pono+1;
			$newpo=str_pad($newpono,5,"0", STR_PAD_LEFT);
			$npoid="GKPONO".date('ymd').$newpo;
			$newfer="REFGK".date('ymd').$newpo;
			
		}else
		{
			$npoid="GKPONO".date('ymd')."00001";
			$newfer="REFGK".date('ymd')."00001";
		}
		$data['purchaseorder']=$npoid;
		$data['refno']=$newfer;
		/*if(empty($purorder))
		{
			$invID="1";
			$data['purchaseorder']="GK/".date('y')."/".(date('y')+1)."/".str_pad($invID, 5 , '0', STR_PAD_LEFT);
			$data['refno']="REF/"."GK/".date('y')."/".(date('y')+1)."/".str_pad($invID, 5 , '0', STR_PAD_LEFT);
		}else{
			foreach($purorder as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['purchaseorder']="GK/".date('y')."/".(date('y')+1)."/". str_pad($invID, 5 , '0', STR_PAD_LEFT);
			$data['refno']="REF/"."GK/".date('y')."/".(date('y')+1)."/".str_pad($invID, 5 , '0', STR_PAD_LEFT);
		}*/
		//print_r($data['allmaterial']);
    	$this->load->view('purchase_master/create',$data);
	}
	public function getdetails_purchase()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id=$this->input->post('id');
		$specid=$this->input->post("specid");
		$result=$this->Purchase_model->get_alldetails($id);
		foreach($result as $row)
		{
			$materialid=$row->materiel_id;
			$materialnam=$row->materialname;
			$unit=$row->unit;
		}
		$getspecid=$this->Purchase_model->getspecification($specid);
		foreach($getspecid as $rowspe)
		{
			$spectit=$rowspe->specification;
		}
		$result=array("matid"=>"$materialid","matname"=>"$materialnam","specif"=>"$spectit","unit"=>"$unit");
		echo json_encode($result);
	}
	public function getvender_list()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$venid=$this->input->post('vendors');
		$result=$this->Purchase_model->getvenders_dtails($venid);
		if(empty($result))
		{
			$result=$this->Purchase_model->getvenders_dtails_excepttransaction($venid);
			foreach($result as $row)
			{
			$vid=$row->id;
			$vendername=$row->vcompany;
			$venderlastrans="";
			$lastrandt="";
			$lastquatation="";
			$purchaseorder="";
			$venderid=$row->vender_id;
			$vemail=$row->vemail;
			$vphone=$row->vphno;
			$add1=$row->add1;
			$cst=$row->cst;
			$vat=$row->vat;
			$country=$row->country;
			$contact1=$row->contactname1;
			$contactemail1=$row->contactemail1;
			$contactphno1=$row->contactphno1;
			$contactname2=$row->contactname2;
			$contactemail2=$row->contactemail2;
			$contactphno2=$row->contactphno2;
			$bankname1=$row->bankname1;
			$bankacc1=$row->bankacc1;
			$bankifsc1=$row->bankifsc1;
			$bankswift1=$row->bankswift1;
			$branch1=$row->branch1;
			$bankname2=$row->bankname2;
			$bankacc2=$row->bankacc2;
			$bankifsc2=$row->bankifsc1;
			$bankswift2=$row->bankswift2;
			$branch2=$row->branch2;
			
			
			
			}
		}else{
			foreach($result as $row)
		{
			$vendername=$row->vcompany;
			$vid=$row->id;
			$venderlastrans=$row->amount;
			$lastrandt=$row->purchasedate;
			$lastquatation=$row->qatationno;
			$purchaseorder=$row->purchaseorderno;
			$venderid=$row->vender_id;
			$vemail=$row->vemail;
			$vphone=$row->vphno;
			$add1=$row->add1;
			$cst=$row->cst;
			$vat=$row->vat;
			$country=$row->country;
			$contact1=$row->contactname1;
			$contactemail1=$row->contactemail1;
			$contactphno1=$row->contactphno1;
			$contactname2=$row->contactname2;
			$contactemail2=$row->contactemail2;
			$contactphno2=$row->contactphno2;
			$bankname1=$row->bankname1;
			$bankacc1=$row->bankacc1;
			$bankifsc1=$row->bankifsc1;
			$bankswift1=$row->bankswift1;
			$branch1=$row->branch1;
			$bankname2=$row->bankname2;
			$bankacc2=$row->bankacc2;
			$bankifsc2=$row->bankifsc1;
			$bankswift2=$row->bankswift2;
			$branch2=$row->branch2;
			
			
			
		}
			
		}
		
		
		$result2=array("vid"=>"$vid","branch2"=>"$branch2","bankswift2"=>"$bankswift2","bankifsc2"=>"$bankifsc2","bankacc2"=>"$bankacc2","bankname2"=>"$bankname2","branch1"=>"$branch1","bankswift1"=>"$bankswift1","bankifsc1"=>"$bankifsc1","bankacc1"=>"$bankacc1","bankname1"=>"$bankname1","contactphno2"=>"$contactphno2","contactemail2"=>"$contactemail2","contactname2"=>"$contactname2","contactphno1"=>"$contactphno1","contactemail1"=>"$contactemail1","vender_id"=>"$venderid","vemail"=>"$vemail","vphone"=>"$vphone","$add1"=>"add1","cst"=>"$cst","vat"=>"$vat","country"=>"$country","contact1"=>"$contact1","vcompany"=>"$vendername","venderlastrans"=>"$venderlastrans","lastrandt"=>"$lastrandt","lastquatation"=>"$lastquatation","purchaseorder"=>"$purchaseorder");
		//$result2=array("branch2"=>"$branch2","bankswift2"=>"$bankswift2","bankifsc2"=>"$bankifsc2","bankacc2"=>"$bankacc2","bankname2"=>"$bankname2","branch1"=>"$branch1","bankswift1"=>"$bankswift1","bankifsc1"=>"$bankifsc1","bankacc1"=>"$bankacc1","bankname1"=>"$bankname1","contactphno2"=>"$contactphno2","contactemail2"=>"$contactemail2","contactname2"=>"$contactname2","contactphno1"=>"$contactphno1","contactemail1"=>"$contactemail1","vender_id"=>"$venderid","vemail"=>"$vemail","vphone"=>"$vphone","$add1"=>"add1","cst"=>"$cst","vat"=>"$vat","country"=>"$country","contact1"=>"$contact1","vcompany"=>"$vendername","venderlastrans"=>"$venderlastrans","lastrandt"=>"$lastrandt","lastquatation"=>"$lastquatation","purchaseorder"=>"$purchaseorder");
		echo json_encode($result2);
	}
	public function save_purchaseorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		$pono=$this->input->post('pono');
		$dte=$this->input->post('dte');
		$refno=$this->input->post('refno');
		$notr=$this->input->post('numofrows');
		
        //$this->fpdf->Output($filename,'F');
		 //$this->fpdf->Output("$filename",'F');
		$item=array();$model1=array();
		for($i=1;$i<=$notr;$i++)
		{
			$matid=$this->input->post("matid_$i");
			$modelname=$this->input->post("modelname_$i");
			$matqty=$this->input->post("prqty1_$i");
			$modelid=$this->input->post("modelid1_$i");
			$prtspec=$this->input->post("prtspecif_$i");
			 $specificat=$this->input->post("specification_$i");
			$colorspeci=$this->input->post("colorspe_$i");
			if(isset($matid) && !empty($matid) && isset($matqty) && !empty($matqty))
			{
				$item1=$matid.";".$modelname.";".$matqty.";".$prtspec;
			
			   array_push($item,$item1);
			}
			if(isset($modelid) && !empty($modelid) && isset($matqty) && !empty($matqty))
			{
				$mode2=$modelid.";".$modelname.";".$matqty.";".$specificat.";".$colorspeci;
				array_push($model1,$mode2);
			}
			
		}
		$modimplode=implode(",",$model1);
		$itemimplode=implode(",",$item);//echo $itemimplode ; echo "<br>" ; echo $modimplode ; 
	   $ven=$this->input->post('vendorid');
	   $dupven=$this->input->post("dupven");
	  // print_r($dupven);echo "<br>";
	   $dupvenex=explode(",",$dupven);
	   $ven1=implode(",",$ven);
	   $ven=explode(",",$ven1);
	  // print_r($ven);
	   $ven2=array();
	   foreach($ven as $row)
	   {
	   	if(in_array($row,$ven2))
		{
			
		}else{
			array_push($ven2,$row);
		}
	   }
	   
	  // $ven1=array_unique($ven);
	// print_r($ven2);
	// echo"<br>";
	 $vid2=array_diff($ven2,$dupvenex);
	// print_r($vid2);
	  $data['vid']=$vid2;
	   
		$vendorid=implode(",",$vid2);
		
		
		$dataarray=array(
			"poid"=>$pono,
			"doe"=>$dte,
			"refno"=>$refno,
			"spareparts"=>$itemimplode,
			"modelcode"=>$modimplode,
			"vendors"=>$vendorid
		);
		$this->Purchase_model->savepurcsaeorder($dataarray);
		$data['poid']=$pono;
		$data['refno']=$refno;
		$data['vendorslist']=$vendorid;
		$data['doe']=$dte;
		$data['poid']=$pono;
		$data['refno']=$refno;
		$data['item_product']=$itemimplode;
		
		
		$venderlist=explode(",",$vendorid);
		$vendmail=array();
			
			$vid=$row;
			$get_venderemail=$this->Purchase_model->getvenderemail($vid);
			foreach($get_venderemail as $row)
			{
				$venderemail=$row->vemail;
				$vender_name=$row->vcompany;
				$vendid=$row->vender_id;
				array_push($vendmail,$venderemail);
				
			}
		//$data['name']=$vender_name;
		//$data['email']=$venderemail;
		//$data['venid']=$vendid;
		
		$vendidemailimplode=implode(",",$vendmail);
		$data['vendmail']=$vendidemailimplode;
		$text1="Dear Sir,";
		$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(5);
		$this->fpdf->MultiCell(160,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Spare Parts Requirement List:-",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf->Cell(30,5,'Parts ID',1,0,'C');
		$this->fpdf->Cell(40,5,'Parts Name',1,0,'C');
		$this->fpdf->Cell(40,5,'Spec.',1,0,'C');
		$this->fpdf->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf->Cell(30,5,'M.Code',1,0,'C');
		$this->fpdf->Cell(20,5,'Quantity',1,1,'C');
		if(!empty($itemimplode)){
		$itemlist=explode(",",$itemimplode);
		$i=1;
		$this->fpdf->SetFillColor(0,25,51);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetTextColor(255,255,255);		
		$this->fpdf->Cell(190,5,"Required Individual Spareparts",1,1,'L',true);
		$this->fpdf->SetTextColor(0,0,0);
		foreach($itemlist as $row)
		{
			$list=explode(";",$row);
			//print_r($list);
			$itemid=$list[0];
			$speci=$list[3];
			$getspecid=$this->Purchase_model->getspecification($speci);
			foreach($getspecid as $rowspe)
			{
					$spectit=$rowspe->specification;
			}		
			$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"$itemid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(40,5,"$productname",1,0,'C');
			$this->fpdf->SetFont('Arial','I',5);
			$this->fpdf->Cell(40,5,"$spectit",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$modelcode",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$itemqty",1,1,'C');
		$i++;
		}
		}
		if(isset($modimplode) && !empty($modimplode)){
		$modimplodelist=explode(",",$modimplode);
		$this->fpdf->SetFillColor(0,25,51);
		//$this->fpdf->SetFont('Arial','',8);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetTextColor(255,255,255);		
		$this->fpdf->Cell(190,5,"Required Model List",1,1,'L',true);
		$this->fpdf->SetTextColor(0,0,0);
		foreach($modimplodelist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			//$itemid=$list[0];
			
			//$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			//foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(40,5,"",1,0,'C');
			$this->fpdf->Cell(40,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$model_name",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$qty",1,1,'C');
		$i++;
		}
		}
		//GK/16-17/1_1,GK/16-17/20,GK/16-17/19,GK/16-17/18,GK/16-17/17,GK/16-17/16,GK/16-17/15,GK/16-17/14,GK/16-17/2,GK/16-17/33,GK/16-17/32,GK/16-17/31,GK/16-17/23,GK/16-17/24,GK/16-17/25,GK/16-17/26,GK/16-17/28,GK/16-17/29,GK/16-17/30,GK/16-17/27,GK/16-17/22,GK/16-17/8,GK/16-17/4,GK/16-17/5,GK/16-17/6,GK/16-17/7,GK/16-17/3,GK/16-17/9,GK/16-17/13,GK/16-17/12,GK/16-17/11,GK/16-17/10,
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Specification Requirement List",0,0,'L');
		$this->fpdf->ln(5);
		if(isset($modimplode) && !empty($modimplode)){
		$modellist=explode(",",$modimplode);
		$i=1;
		foreach($modellist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			$spec=$list[3];
			$color=$list[4];
			//echo $color;
			//echo "<br>++++++++++<br>";
			 $this->fpdf->SetFont('Arial','B',12);
			  $this->fpdf->cell(150,5,"$i. $model_name",0,0,"L");
		   $this->fpdf->ln(5);
		   $colorexplode=explode("#",$color);
		   $countcolor=count($colorexplode);
		  // echo "<br>";
		  // print_r($countcolor);
		   $ck=1;
		   $spec2= 16 * ($countcolor-1);
		   $colorexplode=array_filter($colorexplode);
		  // print_r($colorexplode);
		  $this->fpdf->Cell(160,5,"Color Specification for $model_name ",0,1,'L');
		  foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcode=$colval[1];
			 $getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;$hexcode=$relt->code_hex;
			      $diffcol=explode(",",$colcod);
			      $r=intval(trim($diffcol[0]));
				  $g=intval(trim($diffcol[1]));
				  $b=intval(trim($diffcol[2]));
			  }
			 
			 	$this->fpdf->SetFillColor($r,$g,$b);
				$this->fpdf->SetFont('Arial','',8);
				$this->fpdf->SetTextColor(255,255,255);
			   $this->fpdf->Cell(16,5,"$hexcode",1,0,'C',true);
			
			  
			
			 
		  }
		  $this->fpdf->SetTextColor(0,0,0);
		   $this->fpdf->ln(5);
		   foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcdeval=$colval[0];
			 /*$getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;
			      $diffcol=explode(",",$colcod);
			      $r=intval($diffcol[0]);
				  $g=intval($diffcol[1]);
				  $b=intval($diffcol[2]);
			  }*/
			 
			 	//$this->fpdf->SetFillColor($r,$g,$b);
			   $this->fpdf->Cell(16,5,"$colorcdeval",1,0,'C');
			
			  
			
			 
		  }
		   
		   $this->fpdf->ln(10);
		   $k=1;
		   $this->fpdf->SetFont('Arial','B',10);
		  // $this->fpdf->SetFillColor(255,0,0);
		    $this->fpdf->Cell(15,5,"Slno.",1,0,'C');
			$this->fpdf->Cell(30,5,'PartsId',1,0,'C');
			$this->fpdf->Cell(40,5,'Name',1,0,'C');
			$this->fpdf->Cell(75,5,'Specification',1,0,'C');
			$this->fpdf->Cell(15,5,'Qty',1,1,'C');
			$specexplode=explode("||",$spec);
			$specexplode=array_filter($specexplode);//echo "<br>=================<br>";
			//print_r($specexplode);
			$this->fpdf->SetFont('Arial','',6);
			$sspxtxt21="";
			foreach($specexplode as $spec2 )
			{
				$this->fpdf->SetFont('Arial','',6);
				$specimplode1=explode("_",$spec2);
				//print_r($specimplode1);
				//echo "<br>";
			   $countspec=count($specimplode1);
			 // echo "<br>";
				if($countspec>1)
				{
					$partsid=$specimplode1[0];
					$sptxt=$specimplode1[1];
					$qtyexpl=explode("@",$sptxt);
					$qtysp=$qtyexpl[1];
					$sptxt[0];
					$getspectxt=$this->Purchase_model->getspectxt($sptxt);
					foreach($getspectxt as $row){ $ssptxt2=$row->specification;}
				}else{
					$partsid=$specimplode1[0];
					
					$ssptxt2="";
				}
				
				/*if(!empty($ssptxt2))
				{
					$ssptxt2=$ssptxt2;
				}else{
					$ssptxt2="";
				}*/
				if($ssptxt2!=$sspxtxt21)
				{
					$ssptxt2=$ssptxt2;
				}else{
					$ssptxt2="";
				}
				
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
				
				foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
				$this->fpdf->Cell(15,5,"$k",1,0,'C');
			    $this->fpdf->Cell(30,5,"$partsid",1,0,'C');
			   $this->fpdf->Cell(40,5,"$productname",1,0,'C');
			    $this->fpdf->SetFont('Arial','',6);
			   $this->fpdf->Cell(75,5,"$ssptxt2",1,0,'C');
			   $this->fpdf->Cell(15,5,"$qtysp",1,1,'C');
			   $k++;
			   $sspxtxt21=$ssptxt2;  
			}
			
			$i++;
		   
		}
		}
		//$this->fpdf->Cell(40,10,'Hello Worldadfdafdsfdssdf!');
		
		$filename="Fpdfoutput/requirementlist.pdf";
		
		//echo $vendidemailimplode;
        //$this->fpdf->Output($filename,'F');
		 $this->fpdf->Output("$filename",'F');
		 $this->load->view("send_mail/send_mail",$data);
		$message='Quotation Order send succesfully.....';
		 $this->session->set_flashdata('message',$message);
			// redirect('login','refresh');
		redirect('Purchase_controller/createNew','refresh');

	}
  public function getdetails12($productid)
  {
  	
  	//echo "hello";
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	echo "hello";
	//$pid=$productid;
	//$alldetails=$this->Purchase_model->getalldt($pid);
  // print_r($alldetails);
  }
   public function getfinalquotation()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$vid=$this->input->post('vid');
	$poid=$this->input->post('pid');
	if(isset($vid) && isset($poid)){
		$data['vid']=$vid;
	   $data['poid']=$poid;
	   $finalpi=array(
		    "vid" => $vid,
			"poid" => $poid
		);
      $this->session->set_userdata($finalpi);
	}else{
		$var=$this->session->userdata;
		$data['vid']=$var['vid'];
	   $data['poid']=$var['poid'];
	   $vid=$var['vid'];
	   $poid=$var['poid'];
	}
	//print_r($data);
	
	$data['getquot']=$this->Purchase_model->getalldetails($vid,$poid);
	$this->load->view('purchase_master/finalpi',$data);
  }
	
	public function getmodname($partsid)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		echo "hello";
	}
	public function finalorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$vid=$this->input->post('vid');
		$poid=$this->input->post('poid');
		$currency=$this->input->post('currency');
		$save=$this->input->post('save_date1');
		$getrefno=$this->Purchase_model->getrefno($poid);
		$getvendetails=$this->Purchase_model->getvendet($vid);
		//$sub=$this->input->post("save_date1");
		//echo $sub;exit;
		foreach($getvendetails as $rov)
		{
			$data['venmail']=$rov->vemail;
		}
		$totalrow=$this->input->post('totalrow');
		$parts=array();$model=array();
		for($i=1;$i<$totalrow;$i++)
		{
			$partsid=$this->input->post("partsid_$i");
			$partsid1=$this->input->post("prtsid1_$i");;
			$modelname=$this->input->post("modelname_$i");
			$qty=$this->input->post("qty_$i");
			$partsrte=$this->input->post("partsrte_$i");
			$finalrte=$this->input->post("finalrte_$i");
			
			$finalprice=$this->input->post("finalprice_$i");
			//$modelqty=$_POST["modelqty_$i"];
			$modelqty=$this->input->post("modelqty_$i");
		 	//$spec=$_POST["speci_$i"];
			$spec=$this->input->post("speci_$i");
		
			if(!empty($partsid))
			{
				$partsstring=$partsid.";".$modelname.";".$qty.";".$partsrte.";".$finalrte.";".$finalprice;
				array_push($parts,$partsstring);
				
				
			}
			if(!empty($partsid1))
			{
				//$modelstring=$modelname.";".$qty.";".$partsrte.";".$finalrte.";".$finalprice;
				$modelstring=$modelname.";$modelqty;".$partsid1.";".$spec.";".$qty.";".$partsrte.";".$finalrte.";".$finalprice;
				array_push($model,$modelstring);
			}
			
		}
		//print_r($parts);
		// "<br>";
		//print_r($model);
		$partsimplode=implode(",",$parts);
		$modelimplode=implode(",",$model);
		$taxxfinal=$this->input->post("taxxfinal");
		$taxarray=array();
		for($k=1;$k<$taxxfinal;$k++)
		{
			$taxtxt=$this->input->post("taxtext_$k");
			$txrte=$this->input->post("taxrte_$k");
			$taxfinal=$this->input->post("taxfinal_$k");
			$taxstring=$taxtxt.";".$txrte.";".$taxfinal;
			array_push($taxarray,$taxstring);
			
			
		}
		$taximplode=implode(",",$taxarray);
		$grandtottal=$this->input->post('grandtottal');
		$fstpmnt=$this->input->post("fstpmnt");
		if(isset($fstpmnt) && !empty($fstpmnt)){
			$fstpmnt1=$fstpmnt;
		}else{
			$fstpmnt1=0.00;
		}
		$sndpmnt=$this->input->post("sndpmnt");
		if(isset($sndpmnt) && !empty($sndpmnt)){
			$sndpmnt1=$sndpmnt;
		}else{
			$sndpmnt1=0.00;
		}
		$thrdpmnt=$this->input->post("thrdpmnt");
		if(isset($thrdpmnt) && !empty($thrdpmnt)){
			$thrdpmnt1=$thrdpmnt;
		}else{
			$thrdpmnt1=0.00;
		}
		$chk=$this->input->post("cheque");
		if(isset($chk) && !empty($chk)){
			$cheq=number_format($chk,2);
		}else{
			$cheq=0.00;
		}
		$chk1=$this->input->post("cheque1");
		if(isset($chk1) && !empty($chk1)){
			$chq1=number_format($chk1,2);
		}else{
			$chq1=0.00;
		}
		$chk2=$this->input->post("cheque2");
		if(isset($chk2) && !empty($chk2)){
			$chq2=number_format($chk2,2);
			
		}else{
			$chq2=0.00;
		}
		$chk3=$this->input->post("cheque3");
		if(isset($chk3) && !empty($chk3)){
			$chq3=number_format($chk3,2);
		}else{
			$chq3=0.00;
		}
		$chk4=$this->input->post("cheque4");
		if(isset($chk4) && !empty($chk4)){
			$chq4=number_format($chk4,2);
		}else{
			$chq4=0.00;
		}
		$csh=$this->input->post("cash");
		if(isset($csh) && !empty($csh)){
			$cash=number_format($csh,2);
		}else{
			$cash=0.00;
		}
		$csh1=$this->input->post("cash1");
		if(isset($csh1) && !empty($csh1))
		{
			$cash1=number_format($csh1,2);
		}else{
			$cash1=0.00;
		}
		$csh2=$this->input->post("cash2");
		if(isset($csh2) && !empty($csh2)){
			$cash2=number_format($csh2,2);
		}else{
			$cash2=0.00;
		}
		$csh3=$this->input->post("cash3");
		if(isset($csh3) && !empty($csh3)){
			$cash3=number_format($csh3,2);
		}else{
			$cash3=0.00;
		}
		$csh4=$this->input->post("cash4");
		if(isset($csh4) && !empty($csh4))
		{
			$cash4=number_format($csh4,2);
		}else{
			$cash4=0.00;
		}
		
		
		
		
		
		
		
		
		
		
		
		$pdate=$this->input->post("pdate");
		$disdate=$this->input->post("disdate");
		$fpoid=intval(substr($poid,-5));
		$fpid=str_pad($fpoid,5,"0",STR_PAD_LEFT);
		$data['bank']=$this->Bankinfo_Model->getalldata();
		$foid="GKFNL".date('ymd').$fpid;
		$dataarray=array(
		   "foid"=>$foid,
		   "venid"=>$vid,
		   "poid"=>$poid,
		   "parts"=>$partsimplode,
		   "model"=>$modelimplode,
		   "fpmnt"=>$fstpmnt1,
		   "spmnt"=>$sndpmnt1,
		   "thpmnt"=>$thrdpmnt1,
		   "fstpmnt"=>$chq1,
		   "ndpmnt"=>$chq2,
		   "thrdpmnt"=>$chq3,
		   "frthamnt"=>$chq4,
		   "restamnt"=>$cheq,
		   "rstfst"=>$cash1,
		   "rstsnd"=>$cash2,
		   "rstthrd"=>$cash3,
		   "rstfrth"=>$cash4,
		   "cashmnt"=>$cash,
		   "procdate"=>$pdate,
		   "disdate"=>$disdate,
		   "total"=>$grandtottal,
		   "currencytyp"=>$currency,
		   "tax"=>$taximplode,
		   "doe"=>date('Y-m-d h:i:s')
		
		);
		//print_r($dataarray);
		$res=$this->Purchase_model->savefinalorder($dataarray);
		if($save==1){
			//echo 1;
			
		$textmsg="we here by precessing you for order as per our previously discuss .Please check details as following ";
		$this->fpdf->SetFont('Arial','B',16);
		$text1="asdadf";
		$text2="dfhhgjjhj";
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		//$this->fpdf->Addpage();
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->Cell(180,5,"Ref No:- $getrefno",0,0,'R');
		$this->fpdf->ln(5);
		$this->fpdf->Cell(180,5,"PI No:- $poid",0,0,'R');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->ln(5);
		$this->fpdf->MultiCell(150,5,"Dear,Sir");
	
		$this->fpdf->MultiCell(160,5,"$textmsg");
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','B',15);
		//$this->fpdf->cell(120,5," Rate Finalized:-",0,0,'L');
		$this->fpdf->cell(120,5," Final Requirement:-",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf->Cell(25,5,'Parts ID',1,0,'C');
		$this->fpdf->Cell(50,5,'Spare Parts Name',1,0,'C');
		$this->fpdf->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf->Cell(25,5,'M.Code',1,0,'C');
		$this->fpdf->Cell(20,5,'Quantity',1,1,'C');
		//$this->fpdf->Cell(25,5,'Rate',1,0,'C');
		//$this->fpdf->Cell(20,5,'Price',1,1,'C');
		$n=1;
		if(!empty($parts) && isset($parts))
		{
			foreach($parts as $row2)
			{
				$row2explode=explode(";",$row2);
				$this->fpdf->SetFont('Arial','',8);
				$partsid=$row2explode[0];
				$modelname=$row2explode[1];
				$qty=$row2explode[2];
				$finalrte=$row2explode[4];
				$finalprice=$row2explode[5];
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
			    //$modelcode=$list[1];
			    $getmodelname=$this->Purchase_model->get_modelname($modelname);
				foreach($getmodelname as $row){ $modelid= $row->productid; }
			    foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			
				$this->fpdf->Cell(10,5,"$n",1,0,'C');
				$this->fpdf->Cell(25,5,"$partsid",1,0,'C');
				$this->fpdf->Cell(50,5,"$productname",1,0,'C');
				$this->fpdf->Cell(20,5,"$modelname",1,0,'C');
				$this->fpdf->Cell(25,5,"$modelid",1,0,'C');
				$this->fpdf->Cell(20,5,"$qty",1,1,'C');
				//$this->fpdf->Cell(25,5,"$finalrte",1,0,'R');
				//$this->fpdf->Cell(20,5,"$finalprice",1,1,'R');
				
				
				
				$n++;
			}
			
		}
		if(!empty($model) && isset($model))
		{
			$modnme="";
			foreach($model as $row3)
			{
				$row3explode=explode(";",$row3);
				$this->fpdf->SetFont('Arial','',8);
				$modelname=$row3explode[0];
				//$modelname=$row2[1];
				$qty=$row3explode[1];
				$finalrte=$row3explode[3];
				$finalprice=$row3explode[4];
				$getmodelname=$this->Purchase_model->get_modelname($modelname);
				foreach($getmodelname as $row){ $modelid= $row->productid; }
				if($modelname!=$modnme){
				$this->fpdf->Cell(10,5,"$n",1,0,'C');
				$this->fpdf->Cell(25,5,"",1,0,'C');
				$this->fpdf->Cell(50,5,'',1,0,'C');
				$this->fpdf->Cell(20,5,"$modelname",1,0,'C');
				$this->fpdf->Cell(25,5,"$modelid",1,0,'C');
				$this->fpdf->Cell(20,5,"$qty",1,1,'C');
				//$this->fpdf->Cell(25,5,"$finalrte",1,0,'R');
				//$this->fpdf->Cell(20,5,"$finalprice",1,1,'R');
				
				
				
				$n++;
				$modnme=$modelname;
				}
			}
			
		}
		if(!empty($taximplode))
		{
			$taxarrayimplode=explode(",",$taximplode);$tx=1;
			foreach($taxarrayimplode as $rowtax)
			{
				$rowtaxexplode=explode(";",$rowtax);
				$txttxt=$rowtaxexplode[0];
				$txtrt=$rowtaxexplode[1];
				$txamnt=$rowtaxexplode[2];
				$this->fpdf->SetFont('Arial','',8);
				$this->fpdf->Cell(60,5,"",1,0,'C');
				$this->fpdf->Cell(20,5,"Tax $tx ",1,0,'C');
				$this->fpdf->Cell(45,5,"$txttxt",1,0,'C');
				$this->fpdf->Cell(25,5,"$txtrt (%)",1,1,'R');
				//$this->fpdf->Cell(20,5,"$txamnt",1,1,'R');
				$tx++;
			}
		}
		$this->fpdf->SetFont('Arial','',8);
		$this->fpdf->Cell(130,5,"Grand Total",1,0,'R');
		if($currency=="dollar")
		{
			$txtc="$$grandtottal";
		}else{
			$txtc="RS.$grandtottal";
		}
		$this->fpdf->Cell(20,5,"$txtc",1,1,'R');
		//$this->fpdf->Cell(20,5,$this->fpdf->html("<h2></h2>"),1,1,'R');
		//if((isset($chq1) && !empty($chq1))|| ((isset($chq1) && !empty($chq1)) )
		$this->fpdf->ln(10);
		//if($sub==2){}
		$this->fpdf->SetFont('Arial','b',10);
		$this->fpdf->Cell(20,5,"Cash & Cheque Payment Details",0,0,'L');
		$this->fpdf->ln(5);
		//1st payment--
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"",1,0,'R');
		$this->fpdf->Cell(50,5,"Amount To be Paid",1,1,'R');
		//$this->fpdf->Cell(50,5,"Cash",1,1,'R');
		$this->fpdf->SetFont('Arial','',8);
		if(floatval($fstpmnt1)>0){
		$this->fpdf->cell(25);
		
		$this->fpdf->Cell(50,5,"1'st Payment",1,0,'R');
		$this->fpdf->Cell(50,5,"$fstpmnt1",1,1,'R');
		
		}
		//$this->fpdf->Cell(50,5,"$cash1",1,1,'R');
		//2nd payment---
		if(floatval($sndpmnt1)>0){
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"2nd Payment",1,0,'R');
		$this->fpdf->Cell(50,5,"$sndpmnt1",1,1,'R');
		}
		//$this->fpdf->Cell(50,5,"$cash2",1,1,'R');
		///3rd payment--
		if(floatval($thrdpmnt1)>0){
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"3rd payment",1,0,'R');
		$this->fpdf->Cell(50,5,"$thrdpmnt1",1,1,'R');
		
		}
		//$this->fpdf->Cell(50,5,"$cash3",1,1,'R');
		//4th payment
		//$this->fpdf->cell(25);
		//$this->fpdf->Cell(50,5,"4th payment",1,0,'R');
		//$this->fpdf->Cell(50,5,"$chq4",1,1,'R');
		//$this->fpdf->Cell(50,5,"$cash4",1,1,'R');
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"Total",1,0,'R');
		if($currency=="dollar")
		{
			$cheq="$$cheq";
			$cash="$$cash";
		}else{
			$cheq="Rs.$cheq";
			$cash="Rs.$cash";
		}
		$this->fpdf->Cell(50,5,"$cheq",1,1,'R');
		//$this->fpdf->Cell(50,5,"$cash",1,1,'R');
		//ppfffdate
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"Processing Date",1,0,'R');
		$this->fpdf->Cell(50,5,"$pdate",1,1,'R');
		//dispatchdate------------
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"Despatched Date",1,0,'R');
		$this->fpdf->Cell(50,5,"$disdate",1,1,'R');
		//############################################################  specification Detail;s-----------------------------
		$getpoinvoice=$this->Purchase_model->getspecificationdetails($poid);
		foreach($getpoinvoice as $row6)
		{
			 $spareparts=$row6->spareparts;
			 $modelcode=$row6->modelcode;
			$modelcode2=$modelcode;
			//echo "<br>=====================<br>";
			
		}
		$text1="Dear Sir,";
		$text2="Details specification and product list as follows.................";
		//$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Addpage();
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(5);
		$this->fpdf->MultiCell(160,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Spare Parts Requirement List:-",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf->Cell(30,5,'Parts ID',1,0,'C');
		$this->fpdf->Cell(60,5,'Spare Parts Name',1,0,'C');
		$this->fpdf->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf->Cell(30,5,'M.Code',1,0,'C');
		$this->fpdf->Cell(20,5,'Quantity',1,1,'C');
		if(!empty($spareparts)){
		$itemlist=explode(",",$spareparts);
		$i=1;
		foreach($itemlist as $row)
		{
			$list=explode(";",$row);
			//print_r($list);
			$itemid=$list[0];
			
			$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"$itemid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(60,5,"$productname",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$modelcode",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$itemqty",1,1,'C');
		$i++;
		}
		}
		if(isset($modelcode2) && !empty($modelcode2)){
		$modimplodelist=explode(",",$modelcode2);
		
		foreach($modimplodelist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			//$itemid=$list[0];
			
			//$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			//foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(60,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$model_name",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$qty",1,1,'C');
		$i++;
		}
		}
		//GK/16-17/1_1,GK/16-17/20,GK/16-17/19,GK/16-17/18,GK/16-17/17,GK/16-17/16,GK/16-17/15,GK/16-17/14,GK/16-17/2,GK/16-17/33,GK/16-17/32,GK/16-17/31,GK/16-17/23,GK/16-17/24,GK/16-17/25,GK/16-17/26,GK/16-17/28,GK/16-17/29,GK/16-17/30,GK/16-17/27,GK/16-17/22,GK/16-17/8,GK/16-17/4,GK/16-17/5,GK/16-17/6,GK/16-17/7,GK/16-17/3,GK/16-17/9,GK/16-17/13,GK/16-17/12,GK/16-17/11,GK/16-17/10,
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Specification Requirement List",0,0,'L');
		$this->fpdf->ln(5);
		if(isset($modelcode2) && !empty($modelcode2)){
			//print_r($modelcode);echo  "<br===<br>";
		$modellist=explode(",",$modelcode2);//print_r($modellist);
	
		$i=1;
		foreach($modellist as $row)
		{
			
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			$spec=$list[3];
			$color=$list[4];
			//echo $color;
			//echo "<br>++++++++++<br>";
			 $this->fpdf->SetFont('Arial','B',12);
		   $this->fpdf->cell(150,5,"$i. $model_name",0,0,"L");
		   $this->fpdf->ln(5);
		   $colorexplode=explode("#",$color);
		   $countcolor=count($colorexplode);
		  // print_r($countcolor);
		   $ck=1;
		    $spec2= 16 * ($countcolor-1);
		   $colorexplode=array_filter($colorexplode);
		  // print_r($colorexplode);
		  $this->fpdf->cell(10);
		  $this->fpdf->Cell(intval($spec2),5,"Color Specification for $model_name ",0,1,'C');
		  foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcode=$colval[1];
			 $getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;$hexcolor=$relt->code_hex;
			      $diffcol=explode(",",$colcod);
			      $r=intval(trim($diffcol[0]));
				  $g=intval(trim($diffcol[1]));
				  $b=intval(trim($diffcol[2]));
			  }
			 
			 	$this->fpdf->SetFillColor($r,$g,$b);
				$this->fpdf->SetTextColor(255,255,255);
			   $this->fpdf->Cell(16,5,"$hexcolor",1,0,'C',true);
			
			  
			
			 
		  }
		   $this->fpdf->ln(5);
		   $this->fpdf->SetTextColor(0,0,0);
		   foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcdeval=$colval[0];
			 /*$getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;
			      $diffcol=explode(",",$colcod);
			      $r=intval($diffcol[0]);
				  $g=intval($diffcol[1]);
				  $b=intval($diffcol[2]);
			  }*/
			 
			 	//$this->fpdf->SetFillColor($r,$g,$b);
			   $this->fpdf->Cell(16,5,"$colorcdeval",1,0,'C');
			
			  
			
			 
		  }
		   
		   $this->fpdf->ln(10);
		   $k=1;
		   $this->fpdf->SetFont('Arial','B',10);
		  // $this->fpdf->SetFillColor(255,0,0);
		    $this->fpdf->Cell(15,5,"Slno.",1,0,'C');
			$this->fpdf->Cell(30,5,'PartsId',1,0,'C');
			$this->fpdf->Cell(45,5,'Name',1,0,'C');
			$this->fpdf->Cell(85,5,'Specification',1,1,'C');
			$specexplode=explode("||",$spec);
			$specexplode=array_filter($specexplode);
			//echo "<br>=================<br>";
			//print_r($specexplode);
			$this->fpdf->SetFont('Arial','',6);
			foreach($specexplode as $spec2 )
			{
				$this->fpdf->SetFont('Arial','',6);
				$specimplode1=explode("_",$spec2);
				//print_r($specimplode1);
				//echo "<br>";
			   $countspec=count($specimplode1);
			 // echo "<br>";
				if($countspec>1)
				{
					$partsid=$specimplode1[0];
					$sptxt=$specimplode1[1];
					$getspectxt=$this->Purchase_model->getspectxt($sptxt);
					foreach($getspectxt as $row){ $ssptxt2=$row->specification;}
				}else{
					$partsid=$specimplode1[0];
					$ssptxt2="";
				}
				
				if(isset($ssptxt2) && !empty($ssptxt2))
				{
					$ssptxt2=$ssptxt2;
				}else{
					$ssptxt2="";
				}
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
				
				foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
				$this->fpdf->Cell(15,5,"$k",1,0,'C');
			    $this->fpdf->Cell(30,5,"$partsid",1,0,'C');
			   $this->fpdf->Cell(45,5,"$productname",1,0,'C');
			    $this->fpdf->SetFont('Arial','',6);
			   $this->fpdf->Cell(85,5,"$ssptxt2",1,1,'C');
			   $k++;
			}
			
			$i++;
		   
		}
		}

        $this->fpdf->Addpage();
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		
		$text6="Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.. comes from a line in section 1.10.32.andard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from de Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.Where can I get some?here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.5paragraphs";
		
		$this->fpdf->SetFont('Arial','B',15);
			$this->fpdf->ln(10);
			$this->fpdf->cell(180,5,"Term & Condition",0,0,'C');
			$this->fpdf->ln(5);
			$this->fpdf->SetFont('Arial','',8);
			$this->fpdf->MultiCell(150,5,"$text6");
		
				
					$filename="Fpdfoutput/Finalqtpi.pdf";
					//echo $vendidemailimplode;
       				 $this->fpdf->Output($filename,'F');
					 //$this->fpdf->Output("$filename",'F');
		 			 $this->load->view("send_mail/send_final_mail_qt",$data);
				
			
			//$this->fpdf->Output("$filename1",'F');
			//$this->fpdf->Output("$filename",'F');
		 			 //$this->load->view("send_mail/send_final_mail",$data);
		 	  // $this->load->view("send_mail/send_final_mail",$data);
		}
		if($save==2){
		for($gh=0;$gh<2;$gh++)
		{
		if($gh==0){
		$textmsg="we here by precessing you for order as per our previously discuss .Please check details as following ";
		$this->fpdf->SetFont('Arial','B',16);
		$text1="asdadf";
		$text2="dfhhgjjhj";
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		//$this->fpdf->Addpage();
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->SetFont('Arial','I',8);
		$this->fpdf->Cell(180,5,"Ref No:- $getrefno",0,0,'R');
		$this->fpdf->ln(5);
		$this->fpdf->Cell(180,5,"PI No:- $poid",0,0,'R');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->ln(5);
		$this->fpdf->MultiCell(150,5,"Dear,Sir");
	
		$this->fpdf->MultiCell(160,5,"$textmsg");
		$this->fpdf->ln(3);
		$this->fpdf->SetFont('Arial','B',15);
		//$this->fpdf->cell(120,5," Rate Finalized:-",0,0,'L');
		$this->fpdf->cell(120,5," Final Requirement:-",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf->Cell(25,5,'Parts ID',1,0,'C');
		$this->fpdf->Cell(50,5,'Spare Parts Name',1,0,'C');
		$this->fpdf->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf->Cell(25,5,'M.Code',1,0,'C');
		$this->fpdf->Cell(20,5,'Quantity',1,1,'C');
		//$this->fpdf->Cell(25,5,'Rate',1,0,'C');
		//$this->fpdf->Cell(20,5,'Price',1,1,'C');
		$n=1;
		if(!empty($parts) && isset($parts))
		{
			foreach($parts as $row2)
			{
				$row2explode=explode(";",$row2);
				$this->fpdf->SetFont('Arial','',8);
				$partsid=$row2explode[0];
				$modelname=$row2explode[1];
				$qty=$row2explode[2];
				$finalrte=$row2explode[4];
				$finalprice=$row2explode[5];
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
			    //$modelcode=$list[1];
			    $getmodelname=$this->Purchase_model->get_modelname($modelname);
				foreach($getmodelname as $row){ $modelid= $row->productid; }
			    foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			
				$this->fpdf->Cell(10,5,"$n",1,0,'C');
				$this->fpdf->Cell(25,5,"$partsid",1,0,'C');
				$this->fpdf->Cell(50,5,"$productname",1,0,'C');
				$this->fpdf->Cell(20,5,"$modelname",1,0,'C');
				$this->fpdf->Cell(25,5,"$modelid",1,0,'C');
				$this->fpdf->Cell(20,5,"$qty",1,1,'C');
				//$this->fpdf->Cell(25,5,"$finalrte",1,0,'R');
				//$this->fpdf->Cell(20,5,"$finalprice",1,1,'R');
				
				
				
				$n++;
			}
			
		}
		if(!empty($model) && isset($model))
		{
			$modnme="";
			foreach($model as $row3)
			{
				$row3explode=explode(";",$row3);
				$this->fpdf->SetFont('Arial','',8);
				$modelname=$row3explode[0];
				//$modelname=$row2[1];
				$qty=$row3explode[1];
				$finalrte=$row3explode[3];
				$finalprice=$row3explode[4];
				$getmodelname=$this->Purchase_model->get_modelname($modelname);
				foreach($getmodelname as $row){ $modelid= $row->productid; }
				if($modelname!=$modnme){
				$this->fpdf->Cell(10,5,"$n",1,0,'C');
				$this->fpdf->Cell(25,5,"",1,0,'C');
				$this->fpdf->Cell(50,5,'',1,0,'C');
				$this->fpdf->Cell(20,5,"$modelname",1,0,'C');
				$this->fpdf->Cell(25,5,"$modelid",1,0,'C');
				$this->fpdf->Cell(20,5,"$qty",1,1,'C');
				//$this->fpdf->Cell(25,5,"$finalrte",1,0,'R');
				//$this->fpdf->Cell(20,5,"$finalprice",1,1,'R');
				
				
				
				$n++;
				$modnme=$modelname;
				}
			}
			
		}
		if(!empty($taximplode))
		{
			$taxarrayimplode=explode(",",$taximplode);$tx=1;
			foreach($taxarrayimplode as $rowtax)
			{
				$rowtaxexplode=explode(";",$rowtax);
				$txttxt=$rowtaxexplode[0];
				$txtrt=$rowtaxexplode[1];
				$txamnt=$rowtaxexplode[2];
				$this->fpdf->SetFont('Arial','',8);
				$this->fpdf->Cell(60,5,"",1,0,'C');
				$this->fpdf->Cell(20,5,"Tax $tx ",1,0,'C');
				$this->fpdf->Cell(45,5,"$txttxt",1,0,'C');
				$this->fpdf->Cell(25,5,"$txtrt (%)",1,1,'R');
				//$this->fpdf->Cell(20,5,"$txamnt",1,1,'R');
				$tx++;
			}
		}
		$this->fpdf->SetFont('Arial','',8);
		$this->fpdf->Cell(130,5,"Grand Total",1,0,'R');
		if($currency=="dollar")
		{
			$txtc="$$grandtottal";
		}else{
			$txtc="RS.$grandtottal";
		}
		$this->fpdf->Cell(20,5,"$txtc",1,1,'R');
		//$this->fpdf->Cell(20,5,$this->fpdf->html("<h2></h2>"),1,1,'R');
		//if((isset($chq1) && !empty($chq1))|| ((isset($chq1) && !empty($chq1)) )
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','b',10);
		$this->fpdf->Cell(20,5,"Cash & Cheque Payment Details",0,0,'L');
		$this->fpdf->ln(5);
		//1st payment--
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"",1,0,'R');
		$this->fpdf->Cell(50,5,"Cheque",1,0,'R');
		$this->fpdf->Cell(50,5,"Cash",1,1,'R');
		$this->fpdf->SetFont('Arial','',8);
		if(floatval($chq1)<1 && floatval($cash1)<1)
		{
			
		}else{
			$this->fpdf->cell(25);
			$this->fpdf->Cell(50,5,"1'st Payment",1,0,'R');
			$this->fpdf->Cell(50,5,"$chq1",1,0,'R');
			$this->fpdf->Cell(50,5,"$cash1",1,1,'R');
		}
		
		//2nd payment---
		if(floatval($chq2)<1 && floatval($cash2)<1)
		{
			
		}else{
			$this->fpdf->cell(25);
			$this->fpdf->Cell(50,5,"2nd Payment",1,0,'R');
			$this->fpdf->Cell(50,5,"$chq2",1,0,'R');
			$this->fpdf->Cell(50,5,"$cash2",1,1,'R');
		}
		//3rd payment--
		if(floatval($chq3)<1 && floatval($chq3)<1)
		{
			
		}else{
			$this->fpdf->cell(25);
			$this->fpdf->Cell(50,5,"3rd payment",1,0,'R');
			$this->fpdf->Cell(50,5,"$chq3",1,0,'R');
			$this->fpdf->Cell(50,5,"$chq3",1,1,'R');
		}
		//4th payment
		if(floatval($chq4)<1 && floatval($cash4)<1)
		{
			
		}else{
			$this->fpdf->cell(25);
			$this->fpdf->Cell(50,5,"4th payment",1,0,'R');
			$this->fpdf->Cell(50,5,"$chq4",1,0,'R');
			$this->fpdf->Cell(50,5,"$cash4",1,1,'R');
		}
		$this->fpdf->cell(25);
		$this->fpdf->Cell(50,5,"Total",1,0,'R');
		if($currency=="dollar")
		{
			$cheq="$$cheq";
			$cash="$$cash";
		}else{
			$cheq="Rs.$cheq";
			$cash="Rs.$cash";
		}
		$this->fpdf->Cell(50,5,"$cheq",1,0,'R');
		$this->fpdf->Cell(50,5,"$cash",1,1,'R');
		//ppfffdate
		$this->fpdf->cell(25);
		$this->fpdf->Cell(75,5,"Processing Date",1,0,'R');
		$this->fpdf->Cell(75,5,"$pdate",1,1,'R');
		//dispatchdate------------
		$this->fpdf->cell(25);
		$this->fpdf->Cell(75,5,"Despatched Date",1,0,'R');
		$this->fpdf->Cell(75,5,"$disdate",1,1,'R');
		//############################################################  specification Detail;s-----------------------------
		$getpoinvoice=$this->Purchase_model->getspecificationdetails($poid);
		foreach($getpoinvoice as $row6)
		{
			 $spareparts=$row6->spareparts;
			 $modelcode=$row6->modelcode;
			$modelcode2=$modelcode;
			//echo "<br>=====================<br>";
			
		}
		$text1="Dear Sir,";
		$text2="Details specification and product list as follows.................";
		//$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Addpage();
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(5);
		$this->fpdf->MultiCell(160,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Spare Parts Requirement List:-",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf->Cell(30,5,'Parts ID',1,0,'C');
		$this->fpdf->Cell(60,5,'Spare Parts Name',1,0,'C');
		$this->fpdf->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf->Cell(30,5,'M.Code',1,0,'C');
		$this->fpdf->Cell(20,5,'Quantity',1,1,'C');
		if(!empty($spareparts)){
		$itemlist=explode(",",$spareparts);
		$i=1;
		foreach($itemlist as $row)
		{
			$list=explode(";",$row);
			//print_r($list);
			$itemid=$list[0];
			
			$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"$itemid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(60,5,"$productname",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$modelcode",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$itemqty",1,1,'C');
		$i++;
		}
		}
		if(isset($modelcode2) && !empty($modelcode2)){
		$modimplodelist=explode(",",$modelcode2);
		
		foreach($modimplodelist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			//$itemid=$list[0];
			
			//$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			//foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			
			$this->fpdf->Cell(10,5,"$i",1,0,'C');
			$this->fpdf->Cell(30,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(60,5,"",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$model_name",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf->SetFont('Arial','',6);
			$this->fpdf->Cell(20,5,"$qty",1,1,'C');
		$i++;
		}
		}
		//GK/16-17/1_1,GK/16-17/20,GK/16-17/19,GK/16-17/18,GK/16-17/17,GK/16-17/16,GK/16-17/15,GK/16-17/14,GK/16-17/2,GK/16-17/33,GK/16-17/32,GK/16-17/31,GK/16-17/23,GK/16-17/24,GK/16-17/25,GK/16-17/26,GK/16-17/28,GK/16-17/29,GK/16-17/30,GK/16-17/27,GK/16-17/22,GK/16-17/8,GK/16-17/4,GK/16-17/5,GK/16-17/6,GK/16-17/7,GK/16-17/3,GK/16-17/9,GK/16-17/13,GK/16-17/12,GK/16-17/11,GK/16-17/10,
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(120,5,"Specification Requirement List",0,0,'L');
		$this->fpdf->ln(5);
		if(isset($modelcode2) && !empty($modelcode2)){
			//print_r($modelcode);echo  "<br===<br>";
		$modellist=explode(",",$modelcode2);//print_r($modellist);
	
		$i=1;
		foreach($modellist as $row)
		{
			
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			$spec=$list[3];
			$color=$list[4];
			//echo $color;
			//echo "<br>++++++++++<br>";
			 $this->fpdf->SetFont('Arial','B',12);
		   $this->fpdf->cell(150,5,"$i. $model_name",0,0,"L");
		   $this->fpdf->ln(5);
		   $colorexplode=explode("#",$color);
		   $countcolor=count($colorexplode);
		  // print_r($countcolor);
		   $ck=1;
		    $spec2= 16 * ($countcolor-1);
		   $colorexplode=array_filter($colorexplode);
		  // print_r($colorexplode);
		  $this->fpdf->cell(10);
		  $this->fpdf->Cell(intval($spec2),5,"Color Specification for $model_name ",0,1,'C');
		  foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcode=$colval[1];
			 $getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;$hexcolor=$relt->code_hex;
			      $diffcol=explode(",",$colcod);
			      $r=intval(trim($diffcol[0]));
				  $g=intval(trim($diffcol[1]));
				  $b=intval(trim($diffcol[2]));
			  }
			 
			 	$this->fpdf->SetFillColor($r,$g,$b);
				$this->fpdf->SetTextColor(255,255,255);
			   $this->fpdf->Cell(16,5,"$hexcolor",1,0,'C',true);
			
			  
			
			 
		  }
		   $this->fpdf->ln(5);
		   $this->fpdf->SetTextColor(0,0,0);
		   foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcdeval=$colval[0];
			 /*$getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;
			      $diffcol=explode(",",$colcod);
			      $r=intval($diffcol[0]);
				  $g=intval($diffcol[1]);
				  $b=intval($diffcol[2]);
			  }*/
			 
			 	//$this->fpdf->SetFillColor($r,$g,$b);
			   $this->fpdf->Cell(16,5,"$colorcdeval",1,0,'C');
			
			  
			
			 
		  }
		   
		   $this->fpdf->ln(10);
		   $k=1;
		   $this->fpdf->SetFont('Arial','B',10);
		  // $this->fpdf->SetFillColor(255,0,0);
		    $this->fpdf->Cell(15,5,"Slno.",1,0,'C');
			$this->fpdf->Cell(30,5,'PartsId',1,0,'C');
			$this->fpdf->Cell(45,5,'Name',1,0,'C');
			$this->fpdf->Cell(85,5,'Specification',1,1,'C');
			$specexplode=explode("||",$spec);
			$specexplode=array_filter($specexplode);
			//echo "<br>=================<br>";
			//print_r($specexplode);
			$this->fpdf->SetFont('Arial','',6);
			foreach($specexplode as $spec2 )
			{
				$this->fpdf->SetFont('Arial','',6);
				$specimplode1=explode("_",$spec2);
				//print_r($specimplode1);
				//echo "<br>";
			   $countspec=count($specimplode1);
			 // echo "<br>";
				if($countspec>1)
				{
					$partsid=$specimplode1[0];
					$sptxt=$specimplode1[1];
					$getspectxt=$this->Purchase_model->getspectxt($sptxt);
					foreach($getspectxt as $row){ $ssptxt2=$row->specification;}
				}else{
					$partsid=$specimplode1[0];
					$ssptxt2="";
				}
				
				if(isset($ssptxt2) && !empty($ssptxt2))
				{
					$ssptxt2=$ssptxt2;
				}else{
					$ssptxt2="";
				}
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
				
				foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
				$this->fpdf->Cell(15,5,"$k",1,0,'C');
			    $this->fpdf->Cell(30,5,"$partsid",1,0,'C');
			   $this->fpdf->Cell(45,5,"$productname",1,0,'C');
			    $this->fpdf->SetFont('Arial','',6);
			   $this->fpdf->Cell(85,5,"$ssptxt2",1,1,'C');
			   $k++;
			}
			
			$i++;
		   
		}
		}

        $this->fpdf->Addpage();
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		
		$text6="Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.. comes from a line in section 1.10.32.andard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from de Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.Where can I get some?here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.5paragraphs";
		
		$this->fpdf->SetFont('Arial','B',15);
			$this->fpdf->ln(10);
			$this->fpdf->cell(180,5,"Term & Condition",0,0,'C');
			$this->fpdf->ln(5);
			$this->fpdf->SetFont('Arial','',8);
			$this->fpdf->MultiCell(150,5,"$text6");
		
				
					$filename="Fpdfoutput/finalpi.pdf";
					//echo $vendidemailimplode;
       				 $this->fpdf->Output($filename,'F');
					 //$this->fpdf->Output("$filename",'F');
		 			 $this->load->view("send_mail/send_final_mail",$data);
				
			
			//$this->fpdf->Output("$filename1",'F');
			//$this->fpdf->Output("$filename",'F');
		 			 //$this->load->view("send_mail/send_final_mail",$data);
		 	  // $this->load->view("send_mail/send_final_mail",$data);
		}else{
			
			
		$textmsg="we here by precessing you for order as per our previously discuss .Please check details as following ";
		$this->fpdf2->SetFont('Arial','B',16);
		$text1="asdadf";
		$text2="dfhhgjjhj";
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf2->Image("$path4",10,10,-300);
		//$this->fpdf2->Addpage();
		$this->fpdf2->Image("$path",10,10,-300);
		$this->fpdf2->SetFont('Arial','B',12);
		$this->fpdf2->Text(130,20,"Office Address");
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf2->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf2->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf2->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf2->SetFont('Arial','B',12);
		$this->fpdf2->Line(10,45,200,45);
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->Line(10,46,200,46);
		$x=$this->fpdf2->GetX(); 
		$y=$this->fpdf2->GetY();
		$this->fpdf2->Ln($y);
		$this->fpdf2->Ln(30);
		$this->fpdf2->SetFont('Arial','I',8);
		$this->fpdf2->Cell(180,5,"Ref No:- $getrefno",0,0,'R');
		$this->fpdf2->ln(5);
		$this->fpdf2->Cell(180,5,"PI No:- $poid",0,0,'R');
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->ln(5);
		$this->fpdf2->MultiCell(150,5,"Dear,Sir");
	
		$this->fpdf2->MultiCell(160,5,"$textmsg");
		$this->fpdf2->ln(3);
		$this->fpdf2->SetFont('Arial','B',15);
		$this->fpdf2->cell(120,5,"Final Requirement:-",0,0,'L');
		$this->fpdf2->ln(10);
		$this->fpdf2->SetFont('Arial','B',10);
		$this->fpdf2->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf2->Cell(25,5,'Parts ID',1,0,'C');
		$this->fpdf2->Cell(50,5,'Spare Parts Name',1,0,'C');
		$this->fpdf2->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf2->Cell(25,5,'M.Code',1,0,'C');
		$this->fpdf2->Cell(20,5,'Quantity',1,1,'C');
		//$this->fpdf2->Cell(25,5,'Rate',1,0,'C');
		//$this->fpdf2->Cell(20,5,'Price',1,1,'C');
		$n=1;
		if(!empty($parts) && isset($parts))
		{
			foreach($parts as $row2)
			{
				$row2explode=explode(";",$row2);
				$this->fpdf2->SetFont('Arial','',8);
				$partsid=$row2explode[0];
				$modelname=$row2explode[1];
				$qty=$row2explode[2];
				$finalrte=$row2explode[4];
				$finalprice=$row2explode[5];
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
			    //$modelcode=$list[1];
			    $getmodelname=$this->Purchase_model->get_modelname($modelname);
				foreach($getmodelname as $row){ $modelid= $row->productid; }
			    foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			
				$this->fpdf2->Cell(10,5,"$n",1,0,'C');
				$this->fpdf2->Cell(25,5,"$partsid",1,0,'C');
				$this->fpdf2->Cell(50,5,"$productname",1,0,'C');
				$this->fpdf2->Cell(20,5,"$modelname",1,0,'C');
				$this->fpdf2->Cell(25,5,"$modelid",1,0,'C');
				$this->fpdf2->Cell(20,5,"$qty",1,1,'C');
				//$this->fpdf2->Cell(25,5,"$finalrte",1,0,'R');
				//$this->fpdf2->Cell(20,5,"$finalprice",1,1,'R');
				
				
				
				$n++;
			}
			
		}
		if(!empty($model) && isset($model))
		{
			$modnm="";
			foreach($model as $row3)
			{
				$row3explode=explode(";",$row3);
				$this->fpdf2->SetFont('Arial','',8);
				$modelname=$row3explode[0];
				//$modelname=$row2[1];
				$qty=$row3explode[1];
				$finalrte=$row3explode[3];
				$finalprice=$row3explode[4];
				$getmodelname=$this->Purchase_model->get_modelname($modelname);
				foreach($getmodelname as $row){ $modelid= $row->productid; }
				if($modelname!=$modnm){
				$this->fpdf2->Cell(10,5,"$n",1,0,'C');
				$this->fpdf2->Cell(25,5,"",1,0,'C');
				$this->fpdf2->Cell(50,5,'',1,0,'C');
				$this->fpdf2->Cell(20,5,"$modelname",1,0,'C');
				$this->fpdf2->Cell(25,5,"$modelid",1,0,'C');
				$this->fpdf2->Cell(20,5,"$qty",1,1,'C');
				//$this->fpdf2->Cell(25,5,"$finalrte",1,0,'R');
				//$this->fpdf2->Cell(20,5,"$finalprice",1,1,'R');
				
				
				
				$n++;
				$modnm=$modelname;
				}
			}
			
		}
		if(!empty($taximplode))
		{
			$taxarrayimplode=explode(",",$taximplode);$tx=1;
			foreach($taxarrayimplode as $rowtax)
			{
				$rowtaxexplode=explode(";",$rowtax);
				$txttxt=$rowtaxexplode[0];
				$txtrt=$rowtaxexplode[1];
				$txamnt=$rowtaxexplode[2];
				$this->fpdf2->SetFont('Arial','',8);
				$this->fpdf2->Cell(60,5,"",1,0,'C');
				$this->fpdf2->Cell(20,5,"Tax $tx ",1,0,'C');
				$this->fpdf2->Cell(45,5,"$txttxt",1,0,'C');
				$this->fpdf2->Cell(25,5,"$txtrt (%)",1,1,'R');
				//$this->fpdf2->Cell(20,5,"$txamnt",1,1,'R');
				$tx++;
			}
		}
		$this->fpdf2->SetFont('Arial','',8);
		$this->fpdf2->Cell(130,5,"Grand Total",1,0,'R');
		if($currency=="dollar")
		{
			$txtc="$$grandtottal";
		}else{
			$txtc="RS.$grandtottal";
		}
		$this->fpdf2->Cell(20,5,"$txtc",1,1,'R');
		//$this->fpdf2->Cell(20,5,$this->fpdf2->html("<h2></h2>"),1,1,'R');
		
		$this->fpdf2->ln(10);
		$this->fpdf2->SetFont('Arial','b',10);
		$this->fpdf2->Cell(20,5,"Cheque Payment Details",0,1,'L');
		$this->fpdf->ln(5);
		//1st payment--
		$this->fpdf2->cell(25);
		$this->fpdf2->Cell(50,5,"",1,0,'R');
		$this->fpdf2->Cell(50,5,"Cheque",1,1,'R');
		//$this->fpdf->Cell(50,5,"Cash",1,1,'R');
		$this->fpdf2->SetFont('Arial','',10);
		if(floatval($chq1>0)){
			$this->fpdf2->cell(25);
			$this->fpdf2->Cell(50,5,"1'st Payment",1,0,'R');
			$this->fpdf2->Cell(50,5,"$chq1",1,1,'R');
		}
		
		//$this->fpdf->Cell(50,5,"$cash1",1,1,'R');
		//2nd payment---
		if(floatval($chq2>0)){
			$this->fpdf2->cell(25);
			$this->fpdf2->Cell(50,5,"2nd Payment",1,0,'R');
			$this->fpdf2->Cell(50,5,"$chq2",1,1,'R');
		}
		//$this->fpdf->Cell(50,5,"$cash2",1,1,'R');
		//3rd payment--
		if(floatval($chq3>0)){
			$this->fpdf2->cell(25);
			$this->fpdf2->Cell(50,5,"3rd payment",1,0,'R');
			$this->fpdf2->Cell(50,5,"$chq3",1,1,'R');
		}
		//$this->fpdf->Cell(50,5,"$cash3",1,1,'R');
		//4th payment
		if(floatval($chq4>0)){
			$this->fpdf2->cell(25);
			$this->fpdf2->Cell(50,5,"4th payment",1,0,'R');
			$this->fpdf2->Cell(50,5,"$chq4",1,1,'R');
		}
		//$this->fpdf->Cell(50,5,"$cash4",1,1,'R');
		if($currency=="dollar")
		{
			$cheq="$cheq";
			//$cash="$$cash";
		}else{
			$cheq="Rs.$cheq";
			//$cash="Rs.$cash";
		}
		$this->fpdf2->cell(25);
		$this->fpdf2->Cell(50,5,"Total",1,0,'R');
		$this->fpdf2->Cell(50,5,"$cheq",1,1,'R');
	//	$this->fpdf->Cell(50,5,"$cash",1,1,'R');
		//ppfffdate
		$this->fpdf2->cell(25);
		$this->fpdf2->Cell(50,5,"Processing Date",1,0,'R');
		$this->fpdf2->Cell(50,5,"$pdate",1,1,'R');
		//dispatchdate------------
		$this->fpdf2->cell(25);
		$this->fpdf2->Cell(50,5,"Despatched Date",1,0,'R');
		$this->fpdf2->Cell(50,5,"$disdate",1,1,'R');
		//############################################################  specification Detail;s-----------------------------
		$getpoinvoice=$this->Purchase_model->getspecificationdetails($poid);
		foreach($getpoinvoice as $row6)
		{
			 $spareparts=$row6->spareparts;
			 $modelcode=$row6->modelcode;
			$modelcode2=$modelcode;
			//echo "<br>=====================<br>";
			
		}
		$text1="Dear Sir,";
		$text2="Details specification and product list as follows.................";
		//$this->fpdf2->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf2->Image("$path4",10,10,-300);
		$this->fpdf2->Addpage();
		$this->fpdf2->Image("$path",10,10,-300);
		$this->fpdf2->SetFont('Arial','B',12);
		$this->fpdf2->Text(130,20,"Office Address");
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf2->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf2->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf2->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf2->SetFont('Arial','B',12);
		$this->fpdf2->Line(10,45,200,45);
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->Line(10,46,200,46);
		$x=$this->fpdf2->GetX(); 
		$y=$this->fpdf2->GetY();
		$this->fpdf2->Ln($y);
		$this->fpdf2->Ln(30);
		$this->fpdf2->MultiCell(150,5,"$text1");
		$this->fpdf2->ln(5);
		$this->fpdf2->MultiCell(160,5,"$text2");
		$this->fpdf2->SetFont('Arial','B',15);
		$this->fpdf2->cell(120,5,"Spare Parts Requirement List:-",0,0,'L');
		$this->fpdf2->ln(10);
		$this->fpdf2->SetFont('Arial','B',10);
		$this->fpdf2->Cell(10,5,'Sl.No',1,0,'C');
		$this->fpdf2->Cell(30,5,'Parts ID',1,0,'C');
		$this->fpdf2->Cell(60,5,'Spare Parts Name',1,0,'C');
		$this->fpdf2->Cell(20,5,'M.Name',1,0,'C');
		$this->fpdf2->Cell(30,5,'M.Code',1,0,'C');
		$this->fpdf2->Cell(20,5,'Quantity',1,1,'C');
		if(!empty($spareparts)){
		$itemlist=explode(",",$spareparts);
		$i=1;
		foreach($itemlist as $row)
		{
			$list=explode(";",$row);
			//print_r($list);
			$itemid=$list[0];
			
			$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(10,5,"$i",1,0,'C');
			$this->fpdf2->Cell(30,5,"$itemid",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(60,5,"$productname",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(20,5,"$modelcode",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(20,5,"$itemqty",1,1,'C');
		$i++;
		}
		}
		if(isset($modelcode2) && !empty($modelcode2)){
		$modimplodelist=explode(",",$modelcode2);
		
		foreach($modimplodelist as $row)
		{
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			//$itemid=$list[0];
			
			//$getproduct_name=$this->Purchase_model->get_poductname($itemid); 
			$modelcode=$list[1];
			$getmodelname=$this->Purchase_model->get_modelname($modelcode);
			foreach($getmodelname as $row){ $modelid= $row->productid; }
			//foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
			$itemqty=$list[2];
			
			$this->fpdf2->Cell(10,5,"$i",1,0,'C');
			$this->fpdf2->Cell(30,5,"",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(60,5,"",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(20,5,"$model_name",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(30,5,"$modelid",1,0,'C');
			$this->fpdf2->SetFont('Arial','',6);
			$this->fpdf2->Cell(20,5,"$qty",1,1,'C');
		$i++;
		}
		}
		//GK/16-17/1_1,GK/16-17/20,GK/16-17/19,GK/16-17/18,GK/16-17/17,GK/16-17/16,GK/16-17/15,GK/16-17/14,GK/16-17/2,GK/16-17/33,GK/16-17/32,GK/16-17/31,GK/16-17/23,GK/16-17/24,GK/16-17/25,GK/16-17/26,GK/16-17/28,GK/16-17/29,GK/16-17/30,GK/16-17/27,GK/16-17/22,GK/16-17/8,GK/16-17/4,GK/16-17/5,GK/16-17/6,GK/16-17/7,GK/16-17/3,GK/16-17/9,GK/16-17/13,GK/16-17/12,GK/16-17/11,GK/16-17/10,
		$this->fpdf2->ln(5);
		$this->fpdf2->SetFont('Arial','B',15);
		$this->fpdf2->cell(120,5,"Specification Requirement List",0,0,'L');
		$this->fpdf2->ln(5);
		if(isset($modelcode2) && !empty($modelcode2)){
			//print_r($modelcode);echo  "<br===<br>";
		$modellist=explode(",",$modelcode2);//print_r($modellist);
	
		$i=1;
		foreach($modellist as $row)
		{
			
			$list=explode(";",$row);
			$modelid=$list[0];
			$model_name=$list[1];
			$qty=$list[2];
			$spec=$list[3];
			$color=$list[4];
			//echo $color;
			//echo "<br>++++++++++<br>";
			 $this->fpdf2->SetFont('Arial','B',12);
		   $this->fpdf2->cell(150,5,"$i. $model_name",0,0,"L");
		   $this->fpdf2->ln(5);
		   $colorexplode=explode("#",$color);
		 //  print_r($colorexplode);
		   $countcolor=count($colorexplode);
		  // print_r($countcolor);
		   $ck=1;
		    $spec2= 16 * ($countcolor-1);
		   $colorexplode=array_filter($colorexplode);
		  // print_r($colorexplode);
		  $this->fpdf2->cell(10);
		  $this->fpdf2->Cell(intval($spec2),5,"Color Specification for $model_name ",0,1,'C');
		  foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcode=$colval[1];
			 $getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;$hexcolor=$relt->code_hex;
			      $diffcol=explode(",",$colcod);
			      $r=intval(trim($diffcol[0]));
				  $g=intval(trim($diffcol[1]));
				  $b=intval(trim($diffcol[2]));
			  }
			 
			 	$this->fpdf2->SetFillColor($r,$g,$b);
				$this->fpdf2->SetTextColor(255,255,255);
			   $this->fpdf2->Cell(16,5,"$hexcolor",1,0,'C',true);
			
			  
			
			 
		  }
		  
		   $this->fpdf2->ln(5);
		   $this->fpdf2->SetTextColor(0,0,0);
		   foreach($colorexplode as $row)
		  {
		  	 $colrval=$row;
			 $colval=explode("->",$colrval);
			 $colorcdeval=$colval[0];
			 /*$getcolorresult=$this->Purchase_model->get_colorrgbcode($colorcode);
			 foreach($getcolorresult as $relt){  $colcod=$relt->rgb_code;
			      $diffcol=explode(",",$colcod);
			      $r=intval($diffcol[0]);
				  $g=intval($diffcol[1]);
				  $b=intval($diffcol[2]);
			  }*/
			 
			 	//$this->fpdf2->SetFillColor($r,$g,$b);
			   $this->fpdf2->Cell(16,5,"$colorcdeval",1,0,'C');
			
			  
			
			 
		  }
		   
		   $this->fpdf2->ln(10);
		   $k=1;
		   $this->fpdf2->SetFont('Arial','B',10);
		  // $this->fpdf2->SetFillColor(255,0,0);
		    $this->fpdf2->Cell(15,5,"Slno.",1,0,'C');
			$this->fpdf2->Cell(30,5,'PartsId',1,0,'C');
			$this->fpdf2->Cell(45,5,'Name',1,0,'C');
			$this->fpdf2->Cell(85,5,'Specification',1,1,'C');
			$specexplode=explode("||",$spec);
			$specexplode=array_filter($specexplode);
			//echo "<br>=================<br>";
			//print_r($specexplode);
			$this->fpdf2->SetFont('Arial','',6);
			foreach($specexplode as $spec2 )
			{
				$this->fpdf2->SetFont('Arial','',6);
				$specimplode1=explode("_",$spec2);
				//print_r($specimplode1);
				//echo "<br>";
			   $countspec=count($specimplode1);
			 // echo "<br>";
				if($countspec>1)
				{
					$partsid=$specimplode1[0];
					$sptxt=$specimplode1[1];
					$getspectxt=$this->Purchase_model->getspectxt($sptxt);
					foreach($getspectxt as $row){ $ssptxt2=$row->specification;}
				}else{
					$partsid=$specimplode1[0];
					$ssptxt2="";
				}
				
				if(isset($ssptxt2) && !empty($ssptxt2))
				{
					$ssptxt2=$ssptxt2;
				}else{
					$ssptxt2="";
				}
				$getproduct_name=$this->Purchase_model->get_poductname($partsid); 
				
				foreach($getproduct_name as $row){ $productname=$row->materialname ; } 
				$this->fpdf2->Cell(15,5,"$k",1,0,'C');
			    $this->fpdf2->Cell(30,5,"$partsid",1,0,'C');
			   $this->fpdf2->Cell(45,5,"$productname",1,0,'C');
			    $this->fpdf2->SetFont('Arial','',6);
			   $this->fpdf2->Cell(85,5,"$ssptxt2",1,1,'C');
			   $k++;
			}
			
			$i++;
		   
		}
		}

        $this->fpdf2->Addpage();
		$this->fpdf2->Image("$path",10,10,-300);
		$this->fpdf2->SetFont('Arial','B',12);
		$this->fpdf2->Text(130,20,"Office Address");
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf2->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf2->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf2->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf2->SetFont('Arial','B',12);
		$this->fpdf2->Line(10,45,200,45);
		$this->fpdf2->SetFont('Arial','',10);
		$this->fpdf2->Line(10,46,200,46);
		$x=$this->fpdf2->GetX(); 
		$y=$this->fpdf2->GetY();
		$this->fpdf2->Ln($y);
		$this->fpdf2->Ln(30);
		
		$text6="Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.. comes from a line in section 1.10.32.andard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from de Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.Where can I get some?here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.5paragraphs";
		
		$this->fpdf2->SetFont('Arial','B',15);
			$this->fpdf2->ln(10);
			$this->fpdf2->cell(180,5,"Term & Condition",0,0,'C');
			$this->fpdf2->ln(5);
			$this->fpdf2->SetFont('Arial','',8);
			$this->fpdf2->MultiCell(150,5,"$text6");
		
				
			
					$filename1="fpdfoutput/finalpi2.pdf";
						//echo $vendidemailimplode;
				        $this->fpdf2->Output($filename1,'F');
						// $this->fpdf2->Output("$filename",'F');
						 $this->load->view("send_mail/send_final_mail1",$data);
				
			//$this->fpdf2->Output("$filename1",'F');
			//$this->fpdf2->Output("$filename",'F');
		 			 //$this->load->view("send_mail/send_final_mail",$data);
		 	  // $this->load->view("send_mail/send_final_mail",$data);
					
					
				
			
		}
		}
		}
		$message='Final Orde Send Succesfully.....';
		 $this->session->set_flashdata('message',$message);
		
		redirect('Purchase_controller/viewquotation','refresh');
		
	}
  public function viewquotation()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	$data['getdetails']=$this->Purchase_model->getquotationlist();
  	$this->load->view('purchase_master/viewquotation',$data);
  }
  public function viewpilist()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	//$data['']
  	$data['viewpilist']=$this->Purchase_model->getallfinalpono();
  	$this->load->view('purchase_master/podetails',$data);
  }
  public function getpurchasepaymentdetails()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
  	$pono=$this->input->post('pono');
	$getallpodetails=$this->Purchase_model->gettallpodetails($pono);
	foreach($getallpodetails as $row)
	{
		$foid=$row->foid;
		$venid=$row->venid;
		$poid=$row->poid;
		$parts=$row->parts;
		$model=$row->model;
		$fstpmnt=$row->fstpmnt;
		$ndpmnt=$row->ndpmnt;
		$thrdpmnt=$row->thrdpmnt;
		$procdate=$row->procdate;
		$disdate=$row->disdate;
		$tax=$row->tax;
		
	}
	$result=array("foid"=>"$foid","venid"=>"$venid","poid"=>"$poid","parts"=>"$parts","model"=>"$model","fstpmnt"=>"$fstpmnt","ndpmnt"=>"$ndpmnt","thrdpmnt"=>"$thrdpmnt","procdate"=>"$procdate","disdate"=>"$disdate","tax"=>"$tax");
	echo json_encode($result);
  }
  public function Search_podeati()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$pono=$this->input->post('pono');
	$data['podetails']=$this->Purchase_model->gettallpodetails($pono);
	$data['pono1']=$pono;
	$data['viewpilist']=$this->Purchase_model->getallfinalpono();
	$this->load->view('purchase_master/podetails',$data);
  }
  public function Search_podeatils()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$pono=$this->input->post('pono');
	$data['podetails']=$this->Purchase_model->gettallpodetails($pono);
	$data['pono1']=$pono;
	$data['viewpilist']=$this->Purchase_model->getallfinalpono();
	$this->load->view('purchase_master/podetails',$data);
  }
  public function savepayment()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$pono=$this->input->post('pono');
	date_default_timezone_set("Asia/Kolkata");
	$data['podetails']=$this->Purchase_model->gettallpodetails($pono);
	
	for($i=1;$i<4;$i++)
	{
		$sub=$this->input->post("submit$i");
		if(isset($sub))
		{
			$invoiceno=$this->input->post("invoiceno$i");
			$venid=$this->input->post('venid');
			$pono=$this->input->post('pono');
			$paymentno=$this->input->post("paymentno$i");
			$amount=$this->input->post("amount$i");
			$paytyp=$this->input->post("paymenttype$i");
			$accno=$this->input->post("accno".$i);
			$cheq=$this->input->post("chequeno$i");
			$bank=$this->input->post("bankname$i");
			$branch=$this->input->post("branch$i");
			$dataarray=array(
			 "invoiceno"=>$invoiceno,
			 "pono"=>$pono,
			 "venid"=>$venid,
			 "paymentyp"=>$paytyp,
			 "paymentno"=>$paymentno,
			 "amount"=>$amount,
			 "bank"=>$bank,
			 "cheque"=>$cheq,
			 "branch"=>$branch,
			 "doe"=>date('Y-m-d h: i: s')
			
			
			);
			
////////////////////////////minus from account cash/bank
			if($paytyp=="cash"){
				
				
				
				$getlastbalanceincash=$this->Purchase_model->getlasttransactionincash();
				if(isset($getlastbalanceincash) && !empty($getlastbalanceincash))
				{
					foreach($getlastbalanceincash as $rowcash)
					{
						$balanceincash=floatval($rowcash->balance);
						$txno=$rowcash->txnno;			
					}
					$openbal=floatval($balanceincash);
					$txno=intval(substr($txno,-6));
					$newtxno=$txno+1;
					$ntxn=str_pad($newtxno,5,"0",STR_PAD_LEFT);
					$txno="TXNGK".$ntxn;
					
				}else{
					$balanceincash=0;
					$txno="TXNGK000001";
				}
				$balanceincash=floatval($balanceincash)-floatval($amount);
			  $data_array_cash=array(
					"invoiceno"=>$invoiceno,
					"credit"=>$amount,
					"balance"=>$balanceincash,
					"doe"=>date('Y-m-d'),
					"txnno"=>$txno,
					"crtd"=>$this->session->userdata('user_name'),
					"cdoe"=>date('Y-m-d h:i:s A')
			   );
			   $this->Purchase_model->savecashtransaction($data_array_cash);
			   $data_arr_cash=array(
				   	"openbal"=>$openbal,
				   	"closebal"=>$balanceincash,
				   	"dos"=>date('Y-m-d'),
				   	"crtdby"=>$this->session->userdata('user_name')
			    );
				$this->Purchase_model->updatecashtransaction($data_arr_cash);
				//paid to supplier account
				$getlastbalancesupplier=$this->Purchase_model->getlastsuppbalance($venid);
				foreach($getlastbalancesupplier as $rowsupbal)
				{
					$sbalance=floatval($rowsupbal->balance);
				}
				//fort supplier tracsaction table
				$getlasttransupp=$this->Purchase_model->getlasttransactionsupplier($venid);
				if(isset($getlasttransupp) && !empty($getlasttransupp))
				{
					foreach($getlasttransupp as $rowspl)
					{
						$fbalance=floatval($rowspl->balance);
					}
					$fbalancenew=floatval($fbalance)+floatval($amount);
				}else{
					$fbalancenew=floatval($sbalance)+floatval($amount);
				}
				
				$data_arr_custtran=array(
					"custid"=>$venid,
					"invoiceno"=>$invoiceno,
					"doe"=>date('d-m-Y'),
					"purpose"=>"purchase",
					"remark"=>"Purchase perpose",
					"accno"=>$venid,
					"debit"=>$amount,
					"balance"=>$fbalancenew,
					"dos"=>date('Y-m-d h:i:s A'),
					"crtd"=>$this->session->userdata('user_name'),
					"crtdid"=>$this->session->userdata('user_id')
				);
				//insert into supplier transaction table
				$this->Purchase_model->savesuppliertransaction($data_arr_custtran);
				$data_array_supmain=array(
					"balance"=>$fbalancenew
				
				);
				$this->Purchase_model->updatesuppliertransaction($data_array_supmain,$venid);
				
			}else{
///////////////////// update on 24012017  ////////////////
                
				$getlastbalanceincash=$this->Purchase_model->getlasttransactioninbank($accno);
				if(isset($getlastbalanceincash) && !empty($getlastbalanceincash))
				{
					foreach($getlastbalanceincash as $rowcash)
					{
						$balanceincash=floatval($rowcash->balance);
						$txno=$rowcash->txnno;			
					}
					$txno=intval(substr($txno,-6));
					$newtxno=$txno+1;
					$ntxn=str_pad($newtxno,5,"0",STR_PAD_LEFT);
					$txno="TXNGK".$ntxn;
					
				}else{
					$balanceincash=0;
					$txno="TXNGK000001";
				}
				$balanceincash=floatval($balanceincash)-floatval($amount);
			  $data_array_bank=array(
				"invoiceno"=>$invoiceno,
				"accno"=>$accno,
				"credit"=>$amount,
				"balance"=>$balanceincash,
				"doe"=>date('Y-m-d'),
				"txnno"=>$txno,
				"crtd"=>$this->session->userdata('user_name'),
				"cdoe"=>date('Y-m-d h:i:s A'),
			   );
			   $this->Purchase_model->savebanktransaction($data_array_bank);
			   //update on bank 
			   $data_array_bankbal=array(
			   	"balance"=>$balanceincash
			   );
			   $this->Purchase_model->updatebankbal($data_array_bankbal,$accno);
			   //update on supplier account
			   //paid to supplier account
				$getlastbalancesupplier=$this->Purchase_model->getlastsuppbalance($venid);
				foreach($getlastbalancesupplier as $rowsupbal)
				{
					$sbalance=floatval($rowsupbal->balance);
				}
				//fort supplier tracsaction table
				$getlasttransupp=$this->Purchase_model->getlasttransactionsupplier($venid);
				if(isset($getlasttransupp) && !empty($getlasttransupp))
				{
					foreach($getlasttransupp as $rowspl)
					{
						$fbalance=floatval($rowspl->balance);
					}
					$fbalancenew=floatval($fbalance)+floatval($amount);
				}else{
					$fbalancenew=floatval($sbalance)+floatval($amount);
				}
				
				$data_arr_custtran=array(
					"custid"=>$venid,
					"invoiceno"=>$invoiceno,
					"doe"=>date('d-m-Y'),
					"purpose"=>"purchase",
					"remark"=>"Purchase perpose",
					"accno"=>$venid,
					"debit"=>$amount,
					"balance"=>$fbalancenew,
					"dos"=>date('Y-m-d h:i:s A'),
					"crtd"=>$this->session->userdata('user_name'),
					"crtdid"=>$this->session->userdata('user_id')
				);
				//insert into supplier transaction table
				$this->Purchase_model->savesuppliertransaction($data_arr_custtran);
				$data_array_supmain=array(
					"balance"=>$fbalancenew
				
				);
				$this->Purchase_model->updatesuppliertransaction($data_array_supmain,$venid);
				
				
				
				
			}
		}
		
	}
	$data['alldetails']=$dataarray;
	$res=$this->Purchase_model->savepayment($dataarray);
	//print_r($data['alldetails']);exit;
	
	
	$data['pono1']=$pono;
	$data['viewpilist']=$this->Purchase_model->getallfinalpono();
	 $this->load->view("send_mail/send_mail_confirm",$data);
	
     redirect("Purchase_controller/viewpilist",'refresh');
  }
	
	public function getval()
	{
		echo "hello";
	}
	public function getallspare_parts_sort_by_modelname()
	{
		$modelid=$this->input->post("modcode");
		$modelname=$this->input->post("modnam");
		$getparts=$this->Purchase_model->getparts_sort_by_modelname($modelname);
		echo '<ul class="nav nav-pills nav-stacked nav-icon" style="overflow: scroll;height:500px;" id="allspareparts">';
						//echo '<li><small>Spare Parts list</small></li>';
						if(!empty($getparts)){
							 $i=1; 
							 foreach($getparts as $row){ 
								$diff=$row->diff;
								$reoder=$row->reorderlevel; 
								$partsid=$row->materiel_id;
								$getspecifi=$this->Purchase_model->getspecifbypartsid($partsid);
								if($diff<$reoder){
									//echo '<li  class="btn btn-block ink-reaction btn-danger"  title="'. $row->materialname.'('.$row->qnty.')" ><a  id="item_$i" href="javascript:anchor_test('.$row->id.')" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small>'. $row->materialname.'('. $row->qnty.')</small></a></li>';
									echo '<li   class="tile" title="'. $row->materialname.'"("'.$row->qnty.'")">';
							 	//echo '<a  id="item_ $i" href="javascript:anchor_test('. $row->id.' )" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
								echo '<a  id="item_ $i" href="javascript:void(0);" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
							 	 echo '<div class="tile-content">';
										echo '<div class="tile-icon">';
											echo '<i class="fa fa-crosshairs" aria-hidden="true"></i>';
										echo '</div>';
										echo '<div class="tile-text" style="color:red;font-weight: bold;"><small>'.$row->materialname.'('. $row->qnty.')</small></div>';
									echo '</div>';
							   echo '</a>' ;
							 	echo '</li>';
								echo '<div class="modal fade" id="myModal_'.$row->id.'" role="dialog">
								    <div class="modal-dialog modal-md">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">'. $row->materialname.'</h4>
								        </div>
								        <div class="modal-body">
								        <div class="row">
								          <div class="col-md-12">
								        	 <form class="form-horizontal">';
								        	 if(isset($getspecifi) && !empty($getspecifi)){
								        	 	
											   echo ' <div class="form-group">
											    <div class="col-md-2"></div>
											    <div class="col-md-3">
											      <h4>Select Specification:  </h4>
											      </div>
											      
											      <div class="col-md-6">
											      <select name="specifi" class="form-control" id="speci_'.$row->id.'">';
												  
											      	foreach($getspecifi as $spe)
													{
														echo '<option value="'.$spe->id.'">'.$spe->specification.'</option>';
													}
											      	
											      
											      echo '</select>
											        
											      </div>
											    </div>';
											 }else{
											 	echo '<input type="hidden" value="9999
											 	"class="form-control" id="speci_'.$row->id.'" placeholder="No of parts">';
											 }
											    echo '<div class="form-group">
											      
											    </div>
											    
											    <div class="form-group">
											     <div class="col-md-2"></div>
											      <div class="col-md-3">
											        <h4>Enter No Of Parts:</h4>
											      </div>
											      
											      <div class="col-md-6">
											        <input type="text" class="form-control" id="noprts_'.$row->id.'" placeholder="No of parts">
											      </div>
											    </div>
											    
											  </form>
										  </div>
										</div>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" onclick="anchor_test('. $row->id.' )">Submit</button>
								        </div>
								      </div>
								    </div>
							 </div>';
									$i++;
								}else
									{
											//echo '<li    title="'. $row->materialname.'('.$row->qnty.')" ><a  id="item_$i" href="javascript:anchor_test('.$row->id.')" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small>'. $row->materialname.'('. $row->qnty.')</small></a></li>';
											echo '<li   class="tile" title="'. $row->materialname.'"("'.$row->qnty.'")"">';
							 	//echo '<a  id="item_ $i" href="javascript:anchor_test('. $row->id.' )" >';
							 	echo '<a  id="item_ $i" href="javascript:void(0);" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
							 	 echo '<div class="tile-content">';
										echo '<div class="tile-icon">';
											echo '<i class="fa fa-crosshairs" aria-hidden="true"></i>';
										echo '</div>';
										echo '<div class="tile-text" style="font-weight: bold;"><small>'.$row->materialname.'('. $row->qnty.')</small></div>';
									echo '</div>';
							   echo '</a>' ;
							 	echo '</li>';
								echo '<div class="modal fade" id="myModal_'.$row->id.'" role="dialog">
								    <div class="modal-dialog modal-md">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">'. $row->materialname.'</h4>
								        </div>
								        <div class="modal-body">
								        <div class="row">
								          <div class="col-md-12">
								        	 <form class="form-horizontal">';
											    if(isset($getspecifi) && !empty($getspecifi)){
								        	 	
											   echo ' <div class="form-group">
											    <div class="col-md-2"></div>
											    <div class="col-md-3">
											      <h4>Select Specification:  </h4>
											      </div>
											      
											      <div class="col-md-6">
											      <select name="specifi" class="form-control" id="speci_'.$row->id.'">';
												  
											      	foreach($getspecifi as $spe)
													{
														echo '<option value="'.$spe->id.'">'.$spe->specification.'</option>';
													}
											      	
											      
											      echo '</select>
											        
											      </div>
											    </div>';
											 }else{
											 	echo '<input type="hidden" value="9999
											 	"class="form-control" id="speci_'.$row->id.'" placeholder="No of parts">';
											 }
											    echo '<div class="form-group">
											    </div>
											    <div class="form-group">
											      
											    </div>
											    
											    <div class="form-group">
											     <div class="col-md-2"></div>
											      <div class="col-md-3">
											       <h4> Enter No Of Parts:</h4>
											      </div>
											      
											      <div class="col-md-6">
											        <input type="text" class="form-control" id="noprts_'.$row->id.'" placeholder="No of parts">
											         
											      </div>
											    </div>
											    
											  </form>
										  </div>
										</div>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" onclick="anchor_test('. $row->id.' )">Submit</button>
								        </div>
								      </div>
								    </div>
							 </div>';
								
									$i++;	
								}
								//echo  ' <li style="border:1px solid #c2c2c2;"></li>';
							
								
							
						   } 
					echo '</ul>';
					
					}else{
						echo "<h5 style='color:red;'>No Spare Parts Available</h5>";
					}
		//print_r($getparts);
		
		
		
		
		
	}
	public function deletepodetails($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$posid=$id;
		$delete=$this->Purchase_model->deleteposdetaild($posid);
		if($delete==1)
		{
		 $message1='Deleted Succesfully .....';
		     $this->session->set_flashdata('message',$message1);
			 //$res=$this->Venders_model->insert_venderlist($data_array);
		}else{
			 $message2='Sorry !There Is an error.....';
		     $this->session->set_flashdata('message2',$message2);
		}
		redirect('Purchase_controller/viewpilist','refresh');
		
		
	}
	public function get_quatationstatus()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id=$this->input->post('id');
		$getall=$this->Purchase_model->getall_quatation_status();
	}
	public function getvendorssssid()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$vid=$this->input->post("vid1");
		$getvendorssss=$this->Purchase_model->getvendorrss($vid);
		foreach($getvendorssss as $rowprts)
		{
			$venid=$rowprts->vender_id;
		}
		$result=array("venid"=>"$venid");
		//print_r($getvendorssss);
		echo json_encode($result);
		//echo $vid;
		
	}
	////update on 24072016
	public function getallaccdetails()
	{
		$bank1=$this->input->post('bank1');
		$resbankacc=$this->Purchase_model->getaccdetails($bank1);
		if(!empty($resbankacc) && isset($resbankacc))
		{
			echo "<option value=''></option>";
			foreach($resbankacc as $rowban)
			{
				echo "<option value='".$rowban->accno."'>".$rowban->accno."</option>";
			}
		}
	}
	public function getallbalancedetails()
	{
		$acnno=$this->input->post("accno");
		$getbalance=$this->Purchase_model->getbalancedetails($acnno);
		$result=array();
		if(isset($getbalance) && !empty($getbalance))
		{
			foreach($getbalance as $rowbala)
			{
				$branch=$rowbala->branchname;
				$balance=$rowbala->balance;
				
			}
		}
		else {
			$branch="";
			$balance="";
		}
		$result=array("branch"=>"$branch","balance"=>"$balance");
		echo json_encode($result);
	}
//#########################################################  update on 422017  ##################################

  public function purchaseorderentry()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['Title']="Purchase Order Entry ";
	$data['model']=$this->Purchase_model->getmodeldetail();
	$data['supplier']=$this->Purchase_model->getsupplierdetails();
	$data['viewpurchaseorder']=$this->Purchase_model->viewallpurchaseorder();
	$this->load->view('purchase_master/purchaseorderentry',$data);
		
 	
 }
 public function get_parts()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$model=$this->input->post("model");
	$getpartsall=$this->Purchase_model->getpartsall($model);
	if(isset($getpartsall) && !empty($getpartsall))
	{
		foreach($getpartsall as $rw)
		{
			echo '<option value="'.$rw->id.'">'.$rw->materialname.'</option>';
		}
	}else{
		echo '<option value="">--select--</option>';
	}
 }
 public function get_modeldt()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$model=$this->input->post("department");
	$getmod=$this->Purchase_model->getmodeldetail();
	 $res=array();
	$res2="";
	if(!empty($getmod) && isset($getmod))
	{
		$res2 .='<option value="">--select--</option>';
		foreach($getmod as $rws)
		{
			$res2 .='<option value="'.$rws->productname.'">'.$rws->productname.'</option>';
		}
		$res2 .='<option value="OTHERS">OTHERS</option>';
	}else{
		$res2 .='<option value="">--select--</option>';
	}
      $res2 .='<option value="">--select--</option>';
	$res=array("res"=>"$res2");
	echo json_encode($res);
 }
 public function get_suppliid()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
     $supnam=$this->input->post("supnam");
	$getsupplid=$this->Purchase_model->getsuppliyid($supnam);
	if(!empty($getsupplid) && isset($getsupplid))
	{
		foreach($getsupplid as $row)
		{
			$supid=$row->vender_id;
		}
	}else
	{
		 $supid="";	
	}
	echo $supid;
 }
 public function savepurchasevoucher()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$supid=$this->input->post("supplyid");
	$incoiceno=$this->input->post("invoice");
   //$supname=$this->input->post();
   $orderdte=$this->input->post("orderdate");
   $deliverydte=$this->input->post("deliverydate");
   $refno=$this->input->post("reference");
    $tottablerow=intval($this->input->post("tablerow"));
 // echo "<br>";
   $tax1=$this->input->post("tax_1");if(isset($tax1) && !empty($tax1)){ $tax1=$tax1;}else{ $tax1=""; }
    $taxper1=$this->input->post("taxp_1");if(isset($taxper1)&& !empty($taxper1)){ $taxper1=$taxper1;}else{$taxper1="";}
    $taxamnt1=$this->input->post("taxtt_1");if(isset($taxamnt1)&& !empty($taxamnt1)){ $taxamnt1=$taxamnt1;}else{$taxamnt1="";}
   $tax2=$this->input->post("tax_2");if(isset($tax2) && !empty($tax2)){ $tax2=$tax2;}else{ $tax2=""; }
   $taxper2=$this->input->post("taxp_2");if(isset($taxper2)&& !empty($taxper2)){ $taxper2=$taxper2;}else{$taxper2="";}
   $taxamnt2=$this->input->post("taxtt_2");if(isset($taxamnt2)&& !empty($taxamnt2)){ $taxamnt2=$taxamnt2;}else{$taxamnt2="";}
   /*$tax3=$this->input->post("tax_3");if(isset($tax3) && !empty($tax3)){ $tax3=$tax3;}else{ $tax3=""; }
   $taxper3=$this->input->post("taxp_3");if(isset($taxper3)&& !empty($taxper3)){ $taxper3=$taxper3;}else{$taxper3="";}
   $taxamnt3=$this->input->post("taxtt_3");if(isset($taxamnt3)&& !empty($taxamnt3)){ $taxamnt3=$taxamnt3;}else{$taxamnt3="";}*/
   $miss=$this->input->post("miss_tot");
   $gtot=$this->input->post("tot_tal");
   if(isset($miss) && !empty($miss)){ $miss=$miss;}else{ $miss=""; }
   if(isset($tottablerow) && !empty($tottablerow))
   {
   	for($tr=1;$tr<=$tottablerow;$tr++)
	{
		$model=$this->input->post("model_".$tr);
		$particulars=$this->input->post("particulars_".$tr);
		$qty=$this->input->post("qty_".$tr);
		$unitpr=$this->input->post("price_".$tr);
		$tot=$this->input->post("total_".$tr);
		if(isset($tot) && !empty($tot) &&isset($model) && isset($particulars)){
		$data_array=array(
			"invoiceno"=>$incoiceno,
			"supplierid"=>$supid,
			"orderdate"=>$orderdte,
			"delivrydate"=>$deliverydte,
			"refno"=>$refno,
			"model"=>$model,
			"particulars"=>$particulars,
			"qty"=>$qty,
			"unitprice"=>$unitpr,
			"totalprice"=>$tot,
			"tax1"=>$tax1,
			"tax1per"=>$taxper1,
			"tax1amnt"=>$taxamnt1,
			"tax2"=>$tax2,
			"tax2per"=>$taxper2,
			"tax2amnt"=>$taxamnt2,
			/*"tax3"=>$tax3,
			"tax3per"=>$taxper3,
			"tax3amnt"=>$taxamnt3,*/
			"miss"=>$miss,
			"gtotal"=>$gtot,
			"crtdby"=>$this->session->userdata('user_name'),
			"doe"=>date('Y-m-d h:i:s A'),
			"crtdid"=>$this->session->userdata('user_id'),
			
		
		
		
		);
		print_r($data_array);
		//echo "<br>";
		$this->Purchase_model->savepurchaseorder($data_array);
		
		
		}
		
	}
   }
   if(isset($tax1) && !empty($tax1) && isset($taxper1) && !empty($taxper1) && isset($taxamnt1) && !empty($taxamnt1) )
   {
   	$data_arry_tax=array(
		"invoiceno"=>$incoiceno,
		"taxname"=>$tax1,
		"taxper"=>$taxper1,
		"taxamnt"=>$taxamnt1,
		"gtotal"=>$gtot,
		"doe"=>date('Y-m-d h:i:s A'),
		"crtdby"=>$this->session->userdata('user_name'),
		
	
	
	);
	$this->Purchase_model->savetoutgoingtax($data_arry_tax);
   }
   /*if(isset($tax3) && !empty($tax3) && isset($taxper3) && !empty($taxper3) && isset($taxamnt3) && !empty($taxamnt3) )
   {
   	$data_arry_tax=array(
		"invoiceno"=>$incoiceno,
		"taxname"=>$tax3,
		"taxper"=>$taxper3,
		"taxamnt"=>$taxamnt3,
		"gtotal"=>$gtot,
		"doe"=>date('Y-m-d h:i:s A'),
		"crtdby"=>$this->session->userdata('user_name'),
		
	
	
	);
	$this->Purchase_model->savetoutgoingtax($data_arry_tax);
   }*/
   if(isset($tax2) && !empty($tax2) && isset($taxper2) && !empty($taxper2) && isset($taxamnt2) && !empty($taxamnt2) )
   {
   	$data_arry_tax=array(
		"invoiceno"=>$incoiceno,
		"taxname"=>$tax2,
		"taxper"=>$taxper2,
		"taxamnt"=>$taxamnt2,
		"gtotal"=>$gtot,
		"doe"=>date('Y-m-d h:i:s A'),
		"crtdby"=>$this->session->userdata('user_name'),
		
	
	
	);
	$this->Purchase_model->savetoutgoingtax($data_arry_tax);
   }
  redirect('Purchase_controller/purchaseorderentry',$data);
   
   
 }
  
 
}