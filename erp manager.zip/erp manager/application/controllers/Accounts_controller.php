<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Accounts_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		$this->load->library('fpdf_gen');
		//$this->load->library('fpdf_geninvoice');
		
		$this->load->library('numbertowords');
		$this->load->model('Account_model');
		
		$this->load->model('Sales_Model');
		$this->load->model('stockManage_model');
	}
	public function viewinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$data['gettaxliabilities']=$this->Account_model->gettaxinfo();
		$data['bankname']=$this->Account_model->getallbavkdetails();
		$data['paidtax']=$this->Account_model->getpaidtax();
		$data['getunpaistds']=$this->Account_model->getunpaidtds();
		$data['paidtds']=$this->Account_model->paidtds();
		$data['totpaid']=$this->Account_model->totpaidtds();
		$data['unpdtds']=$this->Account_model->totunpaidtds();
		$data['bankname']=$this->Account_model->getallbavkdetails();
		
		$this->load->view("taxliabilites/create",$data);
	}
	public function getallaccno()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$bank=$this->input->post("banknmae");
		$getaccno=$this->Account_model->getallaccno($bank);
		if(isset($getaccno) && !empty($getaccno))
		{
			echo "<option value=''>--select--</option>";
			foreach($getaccno as $row)
			{
				echo "<option value='".$row->accno."'>".$row->accno."</option>";
			}
		}
	}
	public function getaccountsdetailse()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		$accno=$this->input->post("accno");
		$getaccdetails=$this->Account_model->getaccdetails($accno);
		$result=array();
		foreach($getaccdetails as $row)
		{
			$branch=$row->branchname;
			$balance=$row->balance;
		}
		$result=array("branch"=>"$branch","balance"=>"$balance");
		echo json_encode($result);
		
	}
	public function saveallcurrentliabilkities()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		date_default_timezone_set("Asia/kolkata");
		$paytyp=$this->input->post("paytyp");
		$bankname=$this->input->post("bankname");
		$accno=$this->input->post("accno"); 
		$branch=$this->input->post("branchname");
		$total=$this->input->post("total");
		$temptot=$this->input->post("hidetot");
		$date=$this->input->post("date");
		$interest=$this->input->post("itrate");
		if(isset($interest) && !empty($interest)){
			$interest=$interest;
			$remark="curent Liabilities paid with interest($interest)";
		}else
			{
				$interest="";
				$remark="current Liabilities paid ";
			}
				
		$tablerow=intval($this->input->post("tablerow"));
		for($i=1;$i<=$tablerow;$i++)
		{
			$excise=$this->input->post("excise_".$i);
			$exciseper=$this->input->post("excisepercent_".$i);
			$cstvat=$this->input->post("cstvat_".$i);
			
			$cstsvatinfo=$this->input->post("taxinfo_".$i);
			$cstvatper=$this->input->post("taxpercet_".$i);
			$invoiceno=$this->input->post("invoiceinfo_".$i);
			
			if(isset($excise))
			{
				//echo $excise;
				//echo "<br>";
				///invoice table update 
				$getexstatus=$this->Account_model->getexstatus($invoiceno);
				foreach($getexstatus as $roest){ $cstvatstatus=intval($roest->cstvatstatus);}
				if($cstvatstatus==1)
				{
					$datainvoice=array(
					"excisestatus"=>"1",
					"taxstatus"=>"1"
				   );
				   $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}else{
					$datainvoice=array(
					"excisestatus"=>"1"
				   );
				   $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}
				///taxduty table insert
				$getinsertstatus=$this->Account_model->getinsertstatus($invoiceno);
				if(empty($getinsertstatus))
				{
					$datatacduyinsert=array(
						"doe"=>$date,
						"invoiceno"=>$invoiceno,
						"excisepercent"=>$exciseper,
						"excise"=>$excise,
						"totalliab"=>$total,
						"withoutint"=>$temptot,
						"intr"=>$interest,
						"crtdby"=>$this->session->userdata('user_name'),
						"dos"=>date('Y-m-d h:i:s A')
					
					);
					$this->Account_model->savetaxandduty($datatacduyinsert);
				}else{
					foreach($getinsertstatus as $rowtaxduty)
					{
						$excise=floatval($rowtaxduty->excise);
						$cst=floatval($rowtaxduty->cstamnt);
						$vat=floatval($rowtaxduty->vatamnt);
						
					}
				 	$tottaxduty=$excise+$cst+$vat;
					$dataupdatetaxduty=array(
						"doe"=>$date,
						"invoiceno"=>$invoiceno,
						"excisepercent"=>$exciseper,
						"excise"=>$excise,
						"totalliab"=>$tottaxduty,
						"withoutint"=>$temptot,
						"intr"=>$interest,
						"crtdby"=>$this->session->userdata('user_name'),
						"dos"=>date('Y-m-d h:i:s A')
					
					);
					$this->Account_model->updatetaxandduty($dataupdatetaxduty,$invoiceno);
					
				}
				
			}
			if(isset($cstvat))
			{
				///invoice table update
				$getexstatus=$this->Account_model->getexstatus($invoiceno);
				foreach($getexstatus as $roest){ $excisestatus=intval($roest->excisestatus);}
				if($excisestatus==1)
				{
					$datainvoice=array(
					"cstvatstatus"=>"1",
					"taxstatus"=>"1"
				   );
				  $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}else{
					$datainvoice=array(
					"cstvatstatus"=>"1"
				   );
				   $this->Account_model->updateexcisestatus($invoiceno,$datainvoice);
				}
				
			///taxduty table insert
			   if(strtoupper($cstsvatinfo)=="CST")
			   {
			   		$getinsertstatus=$this->Account_model->getinsertstatus($invoiceno);
					if(empty($getinsertstatus))
					{
						$datatacduyinsert=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"cstpercent"=>$cstvatper,
							"cstamnt"=>$cstvat,
							"totalliab"=>$total,
							"withoutint"=>$temptot,
							"intr"=>$interest,
							"crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->savetaxandduty($datatacduyinsert);
					}else{
						foreach($getinsertstatus as $rowtaxduty)
						{
							$excise=floatval($rowtaxduty->excise);
							$cst=floatval($rowtaxduty->cstamnt);
							$vat=floatval($rowtaxduty->vatamnt);
							
						}
						 $tottaxduty=$excise+$cst+$vat+floatval($cstvat);
						$dataupdatetaxduty=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"cstpercent"=>$cstvatper,
							"cstamnt"=>$cstvat,
							"totalliab"=>$tottaxduty,
							"withoutint"=>$temptot,
						    "intr"=>$interest,
						    "crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->updatetaxandduty($dataupdatetaxduty,$invoiceno);
						
					}
			   	
			   }
               if(strtoupper($cstsvatinfo)=="VAT")
			   {
			   		$getinsertstatus=$this->Account_model->getinsertstatus($invoiceno);
					if(empty($getinsertstatus))
					{
						$datatacduyinsert=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"vatpercent"=>$cstvatper,
							"vatamnt"=>$total,
							"totalliab"=>$total,
							"withoutint"=>$temptot,
						    "intr"=>$interest,
							"crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->savetaxandduty($datatacduyinsert);
					}else{
						foreach($getinsertstatus as $rowtaxduty)
						{
							$excise=floatval($rowtaxduty->excise);
							$cst=floatval($rowtaxduty->cstamnt);
							$vat=floatval($rowtaxduty->vatamnt);
							
						}
						 $tottaxduty=$excise+$cst+$vat+floatval($cstvat);
						$dataupdatetaxduty=array(
							"doe"=>$date,
							"invoiceno"=>$invoiceno,
							"vatpercent"=>$cstvatper,
							"vatamnt"=>$cstvat,
							"totalliab"=>$tottaxduty,
							"withoutint"=>$temptot,
						    "intr"=>$interest,
						    "crtdby"=>$this->session->userdata('user_name'),
							"dos"=>date('Y-m-d h:i:s A')
						
						);
						$this->Account_model->updatetaxandduty($dataupdatetaxduty,$invoiceno);
						
					}
			   	
			   }
               //cash in hand transaction
               
				
			}
		}
		if(strtoupper($paytyp)=="CASH")
			   {
			   	         $getlastbalance=$this->Account_model->getallcashinhandlastbalance();
						 foreach($getlastbalance as $rowcash){ $balance=floatval($rowcash->closebal);}
			   				$totalcash=floatval($balance)-floatval($total);
							$data_array_cashinhand=array(
								"closebal"=>$totalcash
							
							);
							$this->Account_model->updatecashinhand($data_array_cashinhand);
							$getlasbalanceincashtrans=$this->Account_model->getlasttransbalance();
							if(!empty($getlasbalanceincashtrans)){
							foreach($getlasbalanceincashtrans as $rowtrans)
							{
								$balancetrns=floatval($rowtrans->balance);
								$txno=$rowtrans->txnno;
							}
							$txnost=intval(substr($txno, -6));
							$nexttx=$txnost+1;
							
							$nexttx2=str_pad($nexttx,6,"0", STR_PAD_LEFT);
							$newtxno="TXNGK".$nexttx2;
							}else
								{
									$newtxno="TXNGK000001";
								}
							$tranbal=floatval($balancetrns)-floatval($total);
							$data_array_trans=array(
								"credit"=>$total,
								"balance"=>$tranbal,
								"doe"=>date('Y-m-d'),
								"remark"=>$remark,
								"crtd"=>$this->session->userdata('user_name'),
								"txnno"=>$newtxno,
								"cdoe"=>date('Y-m-d h:i:s A')
							);
							$this->Account_model->getbalancetransupdate($data_array_trans);
			   			
			   		
			   	
			   }
			   //cash in bank transaction  
			   if(strtoupper($paytyp)=="BANK")
			   {
			           $getlastbalancebank=$this->Account_model->getallbank($accno);
						 foreach($getlastbalancebank as $rowbalance){ $balancebank=floatval($rowbalance->balance);}
						 //echo $balancebank;
						 // "<br>";
			   				 $totalcashbank=floatval($balancebank)-floatval($total);
							$data_array_cashinbank=array(
								"balance"=>$totalcashbank
							
							);
							$this->Account_model->updatecashinbank($data_array_cashinbank,$accno);
							$getlasbalanceinbanktrans=$this->Account_model->getlastbanktransbalance($accno);
							if(!empty($getlasbalanceinbanktrans)){
							foreach($getlasbalanceinbanktrans as $rowtrans)
							{
								$balancetrns=floatval($rowtrans->balance);
								$txno=$rowtrans->txnno;
							}
							$txnost=intval(substr($txno, -6));
							$nexttx=$txnost+1;
							
							$nexttx2=str_pad($nexttx,6,"0", STR_PAD_LEFT);
							$newtxno="TXNGK".$nexttx2;
							}else
								{
									$newtxno="TXNGK000001";
								} //echo "<br>";
						     $tranbal=floatval($balancetrns)-floatval($total);
						
							$data_array_trans_bank=array(
							   "accno"=>$accno,
								"credit"=>$total,
								"balance"=>$tranbal,
								"remark"=>$remark,
								"doe"=>date('Y-m-d'),
								"crtd"=>$this->session->userdata('user_name'),
								"cdoe"=>date('Y-m-d h:i:s A'),
								"txnno"=>$newtxno,
							);
							//print_r($data_array_trans_bank);
							$this->Account_model->getbankbalancetransupdate($data_array_trans_bank);
			   			
			   		
			   }
             redirect("Accounts_controller/viewinfo",'refresh');
	}
//update on 22012017
 public function sundrydebtors()
 {
 	    $this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Sundry Debtors";
		$data['cnflist']=$this->Account_model->getallcnfcust();
		$data['dealerlist']=$this->Account_model->getalldealercust();
		$data['subdealerlist']=$this->Account_model->getallsubdealercust();
		$data['retailerlist']=$this->Account_model->getallretailcust();
		//$data['bankname']=$this->Account_model->getallbavkdetails();
		//$data['paidtax']=$this->Account_model->getpaidtax();
		$this->load->view("taxliabilites/sundrydebtors",$data);
 }
 public function getalltransavtion($id)
 {
 	  $this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $data['title']="Sundry Debtors";
	  $data['getdata']=$this->Account_model->getalltransactiondetails($id);
	  foreach($data['getdata'] as $row)
	  {
	  	$custype=$row->custtype;
		$compname=$row->compname;
		$name=$row->name;
	  }
	  if($custype=="RETAILER")
	  {
	  	$data['com']=$name;
	  }else{
	  	$data['com']=$compname;
	  }
	$this->load->view("taxliabilites/sundrydebtorsalltransaction",$data);
 }
 //update on 24012017
 public function sundrucreditors()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $data['title']="Sundry Creditors";
	 $data['getdata']=$this->Account_model->getalldatasupplier();
	 //foreach()
	 $this->load->view("taxliabilites/sundrycrediters",$data);
 }
 public function getalltransactionsupplier($id)
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $data['title']="Sundry Creditors";
	  $data['getdata']=$this->Account_model->getalltransactionsupply($id);
	  foreach($data['getdata'] as $row)
	  {
	  	
		$name=$row->vcompany;
	  }
	  	$data['com']=$name;
	  
	$this->load->view("taxliabilites/sundrycreditorsalltransaction",$data);
 }
 public function getallinvoiceno($id)
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Purchase Details";
	
	
	
 }
 public function paytds()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="TDS Details";
	$data['getunpaistds']=$this->Account_model->getunpaidtds();
	$data['paidtds']=$this->Account_model->paidtds();
	$data['totpaid']=$this->Account_model->totpaidtds();
	$data['unpdtds']=$this->Account_model->totunpaidtds();
	$data['bankname']=$this->Account_model->getallbavkdetails();
	$this->load->view("taxliabilites/tdspaynew",$data);
 }
 public function acpayble()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Accounts Payments";
	$data['purpose']=$this->Account_model->getpurpose();
	$data['accounthead']=$this->Account_model->getaccounthead();
	$data['bankname']=$this->Account_model->getbankdetails();
	$this->load->view("taxliabilites/acpayee",$data);
 }
 public function getaccno()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Accounts Payments";
	$bankname=$this->input->post("bankname");
	$getaccno=$this->Account_model->getacc_no($bankname);
	if(!empty($getaccno) && isset($getaccno))
	{
		echo "<option value=''>--select accno--</option>";
		foreach($getaccno as $row)
		{
			echo "<option value='".$row->accno."'>".$row->accno."</option>";
		}
	}
	
 }
  public function gettdsdetails()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Accounts Payments";
	$amnt=floatval($this->input->post("amount"));
	$resultarr=array();
	$gettdsdetails=$this->Account_model->gettdsdetails();
	$tdsamnt=(floatval($amnt)*floatval($gettdsdetails))/100;
	$reveamnt=floatval($amnt)-floatval($tdsamnt);
	$resultarr=array("tdsper"=>"$gettdsdetails","tdsamnt"=>"$tdsamnt","pamnt"=>"$reveamnt");
	echo json_encode($resultarr);
	
  }
  public function savepaymentstds()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Accounts Payments";
	date_default_timezone_set("ASIA/Kolkata");
	$name=$this->input->post("name");
	$pan=$this->input->post("pan");
	$purpose=$this->input->post("purpose");
	$accountgroup=$this->input->post("accountgroup");
	$payfrom=$this->input->post("payfrom");
	$tdspay=$this->input->post("tdsapplicable");
	$invoice=$this->input->post("invoiceno");
	$date=$this->input->post("date");
	$mant=floatval($this->input->post('amount'));
	if($payfrom=="bank")
	{
		$chqno=$this->input->post("chqno");
		$accno=$this->input->post("accno");
		$pamnt=floatval($this->input->post("pamnt"));
		$tdssamnt=floatval($mant)-floatval($pamnt);
		//$gettdsamnt=$this->
		$data_tdspay=array(
		    "name"=>$name,
		    "pan"=>$pan,
			"invoiceno"=>$invoice,
			"invoiceamnt"=>$mant,
			"remarks"=>$purpose,
			"accountgroup"=>$accountgroup,
			"debit"=>$tdssamnt,
			"balance"=>$tdssamnt,
			"doe"=>date('Y-m-d'),
			"dos"=>date('Y-m-d h:i:s A'),
			"crtdby"=>$this->session->userdata('user_name'),
			
		
		);
		if(floatval($tdssamnt>0))
		{
			$this->Account_model->savetransactiontds($data_tdspay);
		}
		//save temp data  in bank 
		$data_banksave=array(
			"name"=>$name,
			"pan"=>$pan,
	        "payby"=>"CHEQUE",
			"invoiceno"=>$invoice,
			"amnt"=>$pamnt,
			"tdsamnt"=>$tdssamnt,
			"chqno"=>$chqno,
			"acno"=>$accno,
			"doe"=>date('Y-m-d'),
			"dos"=>date('Y-m-d h:i:s A'),
			"purpose"=>$purpose,
	        "accountgroup"=>$accountgroup,
	      
			"crtd"=>$this->session->userdata('user_name')
		
		
		);
		$this->Account_model->savebanktempdata($data_banksave);
		
		
		
	}
	if($payfrom=="cash")
	{
		/*$pamnt=floatval($this->input->post("pamnt"));
		
		$getcashinhand=$this->Account_model->getcashinhand();
		foreach($getcashinhand as $rowcash){ $balance=$rowcash->closebal;}
		$newcash=floatval($balance)-floatval($pamnt);
		$data_array_cash=array(
			"openbal"=>$balance,
			"closebal"=>$newcash,
			"doe"=>date('Y-m-d h:i:s A'),
		
		);
		//update cash in hand account
		//$this->Account_model->cashinhandupdate($data_array_cash);
		//get last result in cash in hand transaction
		$getcashintransaction=$this->Account_model->getcashinhandtran();
		if(!empty($getcashintransaction)&& isset($getcashintransaction))
		{
			foreach($getcashintransaction as $rowtrancash)
			{
				$balance1=$rowtrancash->balance;
				$txno=$rowtrancash->txnno;
				
				
			}
			$newtx=intval(substr($txno,-5));
			$newt=$newtx+1;
			$nwt=str_pad($newt,5,"0",STR_PAD_LEFT);
			$txn="TXNGK".$nwt;
		}else{
			$balance1=0;
			$txn="TXNGK00001";
		}
		$credit=floatval($pamnt);
		$mbal=floatval($balance1)-floatval($credit);
		$data_array_cashinhndtransc=array(
			"invoiceno"=>$invoice,
			"credit"=>$credit,
			"balance"=>$mbal,
			"remark"=>$purpose,
			"doe"=>date('Y-m-d'),
			"crtd"=>$this->session->userdata('user_name'),
			"txnno"=>$txn,
			"cdoe"=>date('Y-m-d h:i:s A')
		
		);
		$this->Account_model->cashinhnstraninsert($data_array_cashinhndtransc);
		//tds paytransaction
		$tdssamnt=floatval($mant)-floatval($pamnt);
		//$gettdsamnt=$this->
		$data_tdspay=array(
		    "name"=>$name,
		    "pan"=>$pan,
			"invoiceno"=>$invoice,
			"invoiceamnt"=>$mant,
			"remarks"=>$purpose,
			"accountgroup"=>$accountgroup,
			"debit"=>$tdssamnt,
			"balance"=>$tdssamnt,
			"doe"=>date('Y-m-d'),
			"dos"=>date('Y-m-d h:i:s A'),
			"crtdby"=>$this->session->userdata('user_name'),
			
		
		);
		if(floatval($tdssamnt>0))
		{
			$this->Account_model->savetransactiontds($data_tdspay);
		}*/
#################################################################################################################
//                                                                                                            //
#################################################################################################################
       //$chqno=$this->input->post("chqno");
		//$accno=$this->input->post("accno");
		$pamnt=floatval($this->input->post("pamnt"));
		$tdssamnt=floatval($mant)-floatval($pamnt);
		//$gettdsamnt=$this->
		$data_tdspay=array(
		    "name"=>$name,
		    "pan"=>$pan,
			"invoiceno"=>$invoice,
			"invoiceamnt"=>$mant,
			"remarks"=>$purpose,
			"accountgroup"=>$accountgroup,
			"debit"=>$tdssamnt,
			"balance"=>$tdssamnt,
			"doe"=>date('Y-m-d'),
			"dos"=>date('Y-m-d h:i:s A'),
			"crtdby"=>$this->session->userdata('user_name'),
			
		
		);
		if(floatval($tdssamnt>0))
		{
			$this->Account_model->savetransactiontds($data_tdspay); //insert into tds pay table
		}
		//save temp data  in bank 
		$data_banksave=array(
			"name"=>$name,
			"pan"=>$pan,
			"payby"=>"CASH",
			"invoiceno"=>$invoice,
			"amnt"=>$pamnt,
			"tdsamnt"=>$tdssamnt,
			"doe"=>date('Y-m-d'),
			"dos"=>date('Y-m-d h:i:s A'),
			"purpose"=>$purpose,
			"accountgroup"=>$accountgroup,
		    
			"crtd"=>$this->session->userdata('user_name')
		
		
		);
		$this->Account_model->savebanktempdata($data_banksave); //insrt into pvoucher table
		
		
	}
      // redirect('Accounts_controller/paytds','refresh');
       redirect('Accounts_controller/acpayble','refresh');
	
  }
  public function savetdsamount()
  {
  	
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Dashboard";
		date_default_timezone_set("Asia/kolkata");
		$paytyp=$this->input->post("paytyp");
		$bankname=$this->input->post("bankname");
		$accno=$this->input->post("accno");
		$branch=$this->input->post("branchname");
		$total=$this->input->post("total");
		$date=$this->input->post("date");
		$temptot=$this->input->post("hidetot2");
		$interset=$this->input->post("itrate2");
		if(isset($interset)&& !empty($interset))
		{
			$interset=$interset;
		}else{
			$interset="";
		}
		
				
		$tablerow=intval($this->input->post("tablerow"));
		$tdid=array();
		for($i=1;$i<=$tablerow;$i++)
		{
			$tdsid=$this->input->post("slno_".$i);
			$tdsamnt=$this->input->post("tds_".$i);
			if(isset($tdsamnt) && !empty($tdsamnt))
			{
				$this->Account_model->updatetdsamnt($tdsid);
				array_push($tdid,$tdsid);
				
			}
			
			
		}
		$tdidimplode=implode(",",$tdid);
		if(strtoupper($paytyp)=="CASH")
			   {
			   	
				  //before approved   pay the amount
				    $data_pvoucherarray=array(
						"name"=>"TDS PAYEE",
						"payby"=>"CASH",
						"amnt"=>$temptot,
						"intrestamnt"=>$total,
						"interest"=>$interset,
						"doe"=>date('Y-m-d'),
						"dos"=>date('Y-m-d h:i:s A'),
						"purpose"=>"For TDS return",
						"tdsid"=>$tdidimplode,
						"crtd"=>$this->session->userdata('user_name')
					
					
					);
					$this->Account_model->insertapprovevucher($data_pvoucherarray);
				
			   	        /* $getlastbalance=$this->Account_model->getallcashinhandlastbalance();
						 foreach($getlastbalance as $rowcash){ $balance=floatval($rowcash->closebal);}
			   				$totalcash=floatval($balance)-floatval($total);
							$data_array_cashinhand=array(
								"closebal"=>$totalcash
							
							);
							$this->Account_model->updatecashinhand($data_array_cashinhand);
							$getlasbalanceincashtrans=$this->Account_model->getlasttransbalance();
							if(!empty($getlasbalanceincashtrans)){
							foreach($getlasbalanceincashtrans as $rowtrans)
							{
								$balancetrns=floatval($rowtrans->balance);
								$txno=$rowtrans->txnno;
							}
							$txnost=intval(substr($txno, -6));
							$nexttx=$txnost+1;
							
							$nexttx2=str_pad($nexttx,6,"0", STR_PAD_LEFT);
							$newtxno="TXNGK".$nexttx2;
							}else
								{
									$newtxno="TXNGK000001";
								}
							$tranbal=floatval($balancetrns)-floatval($total);
							$data_array_trans=array(
								"credit"=>$total,
								"balance"=>$tranbal,
								"doe"=>date('Y-m-d'),
								"crtd"=>$this->session->userdata('user_name'),
								"txnno"=>$newtxno,
								"cdoe"=>date('Y-m-d h:i:s A')
							);
							$this->Account_model->getbalancetransupdate($data_array_trans);*/
			   			
			   		
			   	
			   }
			   //cash in bank transaction  
			   if(strtoupper($paytyp)=="BANK")
			   {
			   	   $chequno=$this->input->post("chequno");
				     $data_pvoucherarray=array(
						"name"=>"TDS PAYEE",
						"payby"=>"CHEQUE",
						"chqno"=>$chequno,
						"acno"=>$accno,
						"amnt"=>$temptot,
						"intrestamnt"=>$total,
						"interest"=>$interset,
						
						"doe"=>date('Y-m-d'),
						"dos"=>date('Y-m-d h:i:s A'),
						"purpose"=>"For TDS return",
						"tdsid"=>$tdidimplode,
						"crtd"=>$this->session->userdata('user_name')
					
					
					);
					$this->Account_model->insertapprovevucher($data_pvoucherarray);
			   	
			           /*$getlastbalancebank=$this->Account_model->getallbank($accno);
						 foreach($getlastbalancebank as $rowbalance){ $balancebank=floatval($rowbalance->balance);}
						 //echo $balancebank;
						 // "<br>";
			   				 $totalcashbank=floatval($balancebank)-floatval($total);
							$data_array_cashinbank=array(
								"balance"=>$totalcashbank
							
							);
							$this->Account_model->updatecashinbank($data_array_cashinbank,$accno);
							$getlasbalanceinbanktrans=$this->Account_model->getlastbanktransbalance($accno);
							if(!empty($getlasbalanceinbanktrans)){
							foreach($getlasbalanceinbanktrans as $rowtrans)
							{
								$balancetrns=floatval($rowtrans->balance);
								$txno=$rowtrans->txnno;
							}
							$txnost=intval(substr($txno, -6));
							$nexttx=$txnost+1;
							
							$nexttx2=str_pad($nexttx,6,"0", STR_PAD_LEFT);
							$newtxno="TXNGK".$nexttx2;
							}else
								{
									$newtxno="TXNGK000001";
								} //echo "<br>";
						     $tranbal=floatval($balancetrns)-floatval($total);
						
							$data_array_trans_bank=array(
								"credit"=>$total,
								"balance"=>$tranbal,
								"doe"=>date('Y-m-d'),
								"crtd"=>$this->session->userdata('user_name'),
								"cdoe"=>date('Y-m-d h:i:s A'),
								"txnno"=>$newtxno,
							);
							$this->Account_model->getbankbalancetransupdate($data_array_trans_bank);*/
			   			
			   		
			   }
             redirect("Accounts_controller/paytds",'refresh');
  }
  public function approvepaymentbycashier()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	$data['getpayment']=$this->Account_model->gettemppayment();
	$this->load->view("Accounts/approvepayments",$data);
		
  }
  public function updateamounttransaction()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	date_default_timezone_set("Asia/Kolkata");
	$data['title']="Dashboard";
	$accno=$this->input->post("accno");
	$purpose=$this->input->post("purpose");
	$payamnt=floatval($this->input->post("payamnt"));
	$dte=$this->input->post("dte");
	$chqno=$this->input->post("chqno");
	$checkedby=$this->input->post("checkedby");
	$remrk=$this->input->post("rmrk");
	if(isset($remrk)){ $remrk=$remrk ; }else{ $remrk=""; }
	$pvoucherslno=$this->input->post("pvoucherslno");
	$clgdate=$this->input->post("dte");
	$payby=$this->input->post("payby");
	$apprv=$this->input->post("checkedby");
	$rmrk=$this->input->post("rmrk");
	if(strtoupper($payby)=="CASH"){
		//########################## cash transaction   
		//echo "hello"; 
		$getcashbalance=$this->Account_model->getcashinhad();
		//print_r($getcashbalance);
		foreach($getcashbalance as $rowcsh){ $balance2c=floatval($rowcsh->closebal);}
		 $newbal=floatval($balance2c)-floatval($payamnt);
		$datamainb=array("closebal"=>$newbal);
		$this->Account_model->updatecashmanibl($datamainb);
		//exit; 
		//transactuon part  
		$getlasttransaction_cash=$this->Account_model->getlast_transaction_cash();
		if(!empty($getlasttransaction_cash))
		{
			foreach($getlasttransaction_cash as $rwcsh)
			{
				$balance=$rwcsh->balance;
			}
			$newbalcsh=floatval($balance)-floatval($payamnt);
			$data_cashtran=array(
				"credit"=>$payamnt,
				"balance"=>$newbalcsh,
				"remark"=>$remrk,
				"doe"=>date('Y-m-d'),
				"crtd"=>$this->session->userdata('user_name'),
				"cdoe"=>date('Y-m-d h:i:s A'),
				
			
			
			);
			$this->Account_model->updatecusttran_cash($data_cashtran);
		}
		
		
		
		
		
		
		
		
		
	}else{
/////////////////////bank main balance update 
    $getlastbalance=$this->Account_model->getlastbalance($accno);
	foreach($getlastbalance as $row)
	{
		$mbalance=floatval($row->balance);
	}
	$newbalance=floatval($mbalance)-floatval($payamnt);
     $data_bankmain=array(
	 	"balance"=>$newbalance
	 );
	 $this->Account_model->updatebankmainbalance($data_bankmain,$accno);
	//exit;
///////////////////////   update bank transaction  
     $getlasttransaction=$this->Account_model->getlasttransactionbank($accno);	
	 $getlasttxno=$this->Account_model->getlasttrans();
	 if(isset($getlasttransaction) &&!empty($getlasttransaction)){
	    foreach($getlasttransaction as $rowbn)
		 {
		 	$balance=floatval($rowbn->balance);
			//$txno=$rowbn->txno;
			
		 }
		 
		 //$txnon=intval(substr)
	 }else
	 {
	 		$balance=0;
	 }
	 	$nbal=floatval($balance)-floatval($payamnt);
		$data_array_bntran=array(
			"accno"=>$accno,
			"credit"=>$payamnt,
			"balance"=>$nbal,
			"remark"=>$purpose,
			"doe"=>date('Y-m-d'),
			"chequeno"=>$chqno,
			"txnno"=>$getlasttxno,
			"crtd"=>$this->session->userdata('user_name'),
			"cdoe"=>date('Y-m-d h:i:s A'),
			
		
		);
		
		$this->Account_model->insertbanktransac($data_array_bntran);
	   // print_r($data_array_bntran);exit;
	  }
 //////////////////////////  pvoucher update 	
	 $data_array_pvoucherupdte=array(
	 	"clgdte"=>$clgdate,
	 	"apprvby"=>$apprv,
	 	"remarkapprve"=>$rmrk,
	 	"status"=>'1'
	 );
	 $this->Account_model->updatepvouchertran($data_array_pvoucherupdte,$pvoucherslno);
	///////////////////////  tds serial no
	$gettdssrno=$this->Account_model->gettdsserialno($pvoucherslno);
	if(!empty($gettdssrno)&& isset($gettdssrno))
	{
		foreach($gettdssrno as $rowtds)
		{
			$tdssl=$rowtds->tdsid;
		}
		$tdsslexplode=explode(",",$tdssl);
		$tdscount=count($tdsslexplode);
		for($td=0;$td<$tdscount;$td++)
		{
			$this->Account_model->updatetdstab($tdsslexplode[$td]);
		}
	}
	 redirect('Accounts_controller/approvepaymentbycashier');
	 
  }
 ////////////////////////////////////////////////////////////////  update  on 27012017
   public function receipt_amount()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
	       // date_default_timezone_set("Asia/Kolkata");
			$data['purpose']=$this->Account_model->purpose_list();
			$data['accounthead']=$this->Account_model->getaccounthead();
	
			$this->load->view("taxliabilites/Receipt_amount_view",$data);	
		}
				
		public function save_receipt_amount()
		{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
	        date_default_timezone_set("Asia/Kolkata");
	
			$amt=$this->input->post('paymant');
			$pyamt=$this->input->post("payamt");
			$custid=$this->input->post("custid");
			$refno=$this->input->post("refno");
			$invno=$this->input->post("invno");
			$purpose=$this->input->post("purpose");
			$remarks=$this->input->post("remarks");
			$accountgroup=$this->input->post("accountgroup");
			if($amt=="cash"){
				// echo 1;
				//$dt=$this->Account_model->getcash_hand();
				$data_casharray=array(
					"clientID"=>$custid,
					"dat"=>date('Y-m-d'),
					"type"=>"cash",
					"refno"=>$refno,
					"paid_amt"=>$pyamt,
					"remark"=>$remarks,
					"purpose"=>$purpose,
					"accounthead"=>$accountgroup,
					"doe"=>date('Y-m-d'),
					"invoiceno"=>$invno,
					"lstupdte"=>date('Y-m-d h:i:s A'),
					"submitby"=>$this->session->userdata('user_name')
				
				);
				$this->Account_model->savecashreceipt($data_casharray);
				print_r($data_casharray);
				
		     }
			if($amt=="bank"){
				//echo 2;
				//$dt=$this->Account_model->getcash_hand();
				$pmod=$this->input->post("paymentmode");
				$chqno=$this->input->post("chq");
				$bank=$this->input->post("bank");
				$branch=$this->input->post("branch");
				
				$data_casharray=array(
					"clientID"=>$custid,
					"dat"=>date('Y-m-d'),
					"type"=>$pmod,
					"cheque_no"=>$chqno,
					"refno"=>$refno,
					"bankName"=>$bank,
					"branchName"=>$branch,
					"paid_amt"=>$pyamt,
					"remark"=>$remarks,
					"purpose"=>$purpose,
					"accounthead"=>$accountgroup,
					"doe"=>date('Y-m-d'),
					"invoiceno"=>$invno,
					"lstupdte"=>date('Y-m-d h:i:s A'),
					"submitby"=>$this->session->userdata('user_name')
				
				);
				$this->Account_model->savecashreceipt($data_casharray);
				print_r($data_casharray);
				
		     }
			//redirect('AcountsManage_Controller/viewreceiptamnt','refresh');
		}

	public function cashinhand()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['Title']="Cash In Hand";
		$data['cashinhnd']=$this->Account_model->getcashinhad();
		$data['daybal']=$this->Account_model->getalltransaction_day();
		$data['tottrans']=$this->Account_model->gettottrans();
		$this->load->view("taxliabilites/cashbook",$data);	
	    //date_default_timezone_set("Asia/Kolkata");
	
		
	}
	public function getmainbalantran()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$date_from = $this->input->post("frmdte");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte");  
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
					<tr>
						<th>DATE</th>
						<th>OPENNIG BALANCE</th>
						<th>CLOSING BALANCE</th>
					</tr>
				</thead>
				<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			//echo "<br>";
			$minval=$this->Account_model->getminval($d);
			if(!empty($minval)&& isset($minval))
			{
				
				$getopenbalnce=$this->Account_model->getopenbal($minval);
				$maxval=$this->Account_model->getclosebal($d);
				$closebal=$this->Account_model->getclose_bal($maxval);
				echo '<tr>
						<td>'.$d.'</td>
						<td>'.number_format($getopenbalnce,2).'</td>
						<td>'.number_format($closebal,2).'</td>
					</tr>';
				
				
			}else{
				
			}
			//if(!empty($minval))
			//{
				
			//}
			
			
			
		}
		echo '</tbody>';
		
											
		
	}
   public function getmaintransaction()
   {
   		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$date_from = $this->input->post("frmdte");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte");  
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
				<tr>
					<th>DATE</th>
					<th>REMARKS</th>
					<th>DEBIT</th>
					<th>CREDIT</th>
					<th>BALANCE</th>
				</tr>
			</thead>
			<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			 $gettrans=$this->Account_model->gettotal_transaction($d);
			 if(!empty($gettrans) && isset($gettrans))
			 {
			 	foreach($gettrans as $rowtottran){
			 	echo '
			 	<tr>
			 		<td>'.$d.'</td>
			 		<td>'. $rowtottran->remark.$inv .'</td>
			 		<td>';
			 		 if(($rowtottran->debit)>0){ echo number_format(($rowtottran->debit),2); } 
			 		echo  '</td><td>';
			 		 if(($rowtottran->credit)>0) { echo number_format(($rowtottran->credit),2); }  
			 		 echo'
			 		 </td><td>
			 		 '. number_format(($rowtottran->balance),2)  .'</td></tr>';
			 }
			 }
			
			
		}
		echo '</tbody>';
   	
   	
   }
    public function getstatement()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('frmdte');
		$tdtetrn=$this->input->post('tdte');
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DETAIL CASH IN HAND  TRANSACTION",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,90,25,25,30));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		$this->fpdf->statement(array("DATE","REMARKS","DEBIT","CREDIT","BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			
			$getalltran=$this->Account_model->getall_transaction_cashin_hand();
			if(!empty($getalltran) && isset($getalltran))
			{
				foreach($getalltran as $rowtr)
				{
					$doe=$rowtr->doe;
					$rmrk=$rowtr->remark." ".$rowtr->invoiceno;
					$debit=$rowtr->debit;
					if(floatval($debit>0))
					{
						$debit=$debit;
					}else{
						$debit="";
					}
					$credit=$rowtr->credit;
					if(floatval($credit>0))
					{
						$credit=$credit;
					}else{
						$credit="";
					}
					$balance=$rowtr->balance;
					$this->fpdf->SetFont('Arial','',8);
					$this->fpdf->SetAligns(array("C","L","R","R","R"));
					$this->fpdf->statement(array("$doe","$rmrk","$debit","$credit","$balance"));
		
				}
			}
			
		}else{
			$date_from = $this->input->post('frmdtetrn');  
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		    $date_to = $this->input->post('tdtetrn');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			 $gettrans=$this->Account_model->gettotal_transaction($d);
				 if(!empty($gettrans) && isset($gettrans))
				 {
				 	foreach($gettrans as $rowtr){
				 		$doe=$rowtr->doe;
					$rmrk=$rowtr->remark." ".$rowtr->invoiceno;
					$debit=$rowtr->debit;
					if(floatval($debit>0))
					{
						$debit=$debit;
					}else{
						$debit="";
					}
					$credit=$rowtr->credit;
					if(floatval($credit>0))
					{
						$credit=$credit;
					}else{
						$credit="";
					}
					$balance=$rowtr->balance;
					$this->fpdf->SetFont('Arial','',8);
					$this->fpdf->SetAligns(array("C","L","R","R","R"));
					$this->fpdf->statement(array("$doe","$rmrk","$debit","$credit","$balance"));
		
						
					}
				 }
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
		
	}
  public function getstatementopenbal()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('frmdte');
		$tdtetrn=$this->input->post('tdte');
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY CASH  BALANCE ",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,80,75));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","R","R"));
		$this->fpdf->statement(array("DATE","OPENNING BALANCE","CLOSING BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getalltran=$this->Account_model->getall_distinctdate();
			if(!empty($getalltran) && isset($getalltran))
			{
				foreach($getalltran as $rowtr)
				{
					$d=$rowtr->doe;
					$minval=$this->Account_model->getminval($d);
					if(!empty($minval)&& isset($minval))
					{
						
						$getopenbalnce=$this->Account_model->getopenbal($minval);
						$maxval=$this->Account_model->getclosebal($d);
						$closebal=$this->Account_model->getclose_bal($maxval);
						$this->fpdf->setwidths(array(20,80,75));
						$this->fpdf->SetFont('Arial','B',9);
					 	 $this->fpdf->SetAligns(array("C","R","R"));
						$this->fpdf->statement(array("$d","$getopenbalnce","$closebal"));
				
						
						
					}else{
						
					}
					
				}
			}
			
		}else{
			$date_from = $this->input->post('frmdte');  
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		    $date_to = $this->input->post('tdte');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			$minval=$this->Account_model->getminval($d);
			if(!empty($minval)&& isset($minval))
			{
				
				$getopenbalnce=$this->Account_model->getopenbal($minval);
				$maxval=$this->Account_model->getclosebal($d);
				$closebal=$this->Account_model->getclose_bal($maxval);
				$this->fpdf->setwidths(array(20,80,75));
				$this->fpdf->SetFont('Arial','B',9);
			 	 $this->fpdf->SetAligns(array("C","R","R"));
				$this->fpdf->statement(array("$d","$getopenbalnce","$closebal"));
		
				
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }
  public function bankbook()
  {
  	    $this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['Title']="Cash In Hand";
		//$data['cashinhnd']=$this->Account_model->getcashinhad();
		//$data['daybal']=$this->Account_model->getalltransaction_day();
		//$data['tottrans']=$this->Account_model->gettottrans();
		$data['accno']=$this->Account_model->getallaccountno();
		$data['totbankbalance']=$this->Account_model->gettotalbalance();
		$data['bankname']=$this->Account_model->getallbankname();
		$this->load->view("taxliabilites/bankbook",$data);	
  }
  public function getall_accno()
  {
  	 $this->authentication->is_loggedin($this->session->userdata('user_name'));
  	$bankname=$this->input->post("bnamkname");
	$getaccno=$this->Account_model->getalldistinctaccno($bankname);
	if(!empty($getaccno) && isset($getaccno))
	{
		echo '<option value=""></option>';
		foreach($getaccno as $rowacc)
		{
			echo '<option value="'.$rowacc->accno.'">'.$rowacc->accno.'</option>';
		}
	}
	
  }
  public function getall_opencloseinfo()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$accno=$this->input->post("accno");
	$getbankname=$this->Account_model->getbank_name($accno);
	$getdistinctdate=$this->Account_model->getdistinct_date($accno);
	//print_r($getdistinctdate);
  	if(!empty($getdistinctdate) && isset($getdistinctdate))
  	{
  	   echo '<div class="col-md-12">
  	   				<div class="row">									
							<div class="col-md-12" style="height: 300px;overflow: scroll;" id="searchmaintrns">
									<table class="table table-bordered table-hover" id="printable">
											<thead>
												<tr>
													<th>DATE</th>
													<th>BANK NAME</th>
													<th>ACCOUNT NAME</th>
													<th>OPENNIG BALANCE</th>
													<th>CLOSING BALANCE</th>
												</tr>
											   </thead>
												<tbody>';
												foreach($getdistinctdate as $rowbnk){
													$doe=$rowbnk->doe;
													$minval=$this->Account_model->getminbal($accno,$doe);
													$maxbal=$this->Account_model->getmaxbal($accno,$doe);
													
													echo '<tr>
														<td>'.$rowbnk->doe.'</td>
														<td>'.$getbankname.'</td>
														<td>'.$accno.'</td>
														<td>'.$minval.'</td>
														<td>'.$maxbal.'</td>
																					
													</tr>';
												}								
												echo '</tbody>
										</table>
																		
									</div>
									</div>
							</div>';
	
 	}
 	
 	}
  public function getmainbalantran_bank()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$accno=$this->input->post("accno");
		$date_from = $this->input->post("frmdte");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte");  
		
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	  $getbankname=$this->Account_model->getbank_name($accno);
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
					<tr>
						<th>DATE</th>
						<th>BANK NAME</th>
						<th>ACCOUNT NO</th>
						<th>OPENNIG BALANCE</th>
						<th>CLOSING BALANCE</th>
					</tr>
				</thead>
				<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			//echo "<br>";
			//$minval=$this->Account_model->getminval($d);
			$minval=$this->Account_model->getminbal($accno,$d);
			$maxbal=$this->Account_model->getmaxbal($accno,$d);
				
			if(!empty($minval)&& isset($minval))
			{
				
					echo '<tr>
						<td>'.$d.'</td>
						<td>'.$getbankname.'</td>
						<td>'.$accno.'</td>
						<td>'.number_format($minval,2).'</td>
						<td>'.number_format($maxbal,2).'</td>
					</tr>';
				
				
			}else{
				
			}
			//if(!empty($minval))
			//{
				
			//}
			
			
			
		}
		echo '</tbody>';
		
					
  }
  public function getstatementopenbal_bank()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('frmdte');
		$tdtetrn=$this->input->post('tdte');
		$accno=$this->input->post("accn");
		$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY BANK OPENNING & CLOSING  BALANCE",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(180,10,"ACCOUNT NO:- $accno  :: BANK NAME:- $getbankname",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,80,75));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","R","R"));
		$this->fpdf->statement(array("DATE","OPENNING BALANCE","CLOSING BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getdistinctdate=$this->Account_model->getdistinct_date($accno);
			if(!empty($getdistinctdate) && isset($getdistinctdate))
			{
					foreach($getdistinctdate as $rowbnk){
					$doe=$rowbnk->doe;
					$minval=$this->Account_model->getminbal($accno,$doe);
					$maxbal=$this->Account_model->getmaxbal($accno,$doe);
													
					if(!empty($minval)&& isset($minval))
					{
						
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,80,75));
						$this->fpdf->SetFont('Arial','B',9);
					 	 $this->fpdf->SetAligns(array("C","R","R"));
						$this->fpdf->statement(array("$doe","$minval","$maxbal"));
				
						
						
					}else{
						
					}
					
				}
			}
			
		}else{
			
			 $date_from = $this->input->post('frmdte');  //exit;
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		   $date_to = $this->input->post('tdte');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			//$minval=$this->Account_model->getminval($d);
			$minval=$this->Account_model->getminbal($accno,$d);
			$maxbal=$this->Account_model->getmaxbal($accno,$d);
			//print_r($minval);
			
			
			if(!empty($minval)&& isset($minval))
			{
				
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
			   //	$closebal=$this->Account_model->getclose_bal($maxval);
				$this->fpdf->setwidths(array(20,80,75));
				$this->fpdf->SetFont('Arial','B',9);
			 	 $this->fpdf->SetAligns(array("C","R","R"));
				$this->fpdf->statement(array("$d","$minval","$maxbal"));
		
				
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }
 public function getall_debit_vredit_trans_info()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $accno=$this->input->post("accno");
	//$getbankname=$this->Account_model->getbank_name($accno);
	$getdistinct_date=$this->Account_model->get_transaction_details($accno);
	//print_r($getdistinct_date);
  	if(!empty($getdistinct_date) && isset($getdistinct_date))
  	{
  	   echo '<div class="col-md-12">
  	   				<div class="row">									
							<div class="col-md-12" style="height: 300px;overflow: scroll;" id="searchmaintrns">
									<table class="table table-bordered table-hover" id="printable">
											<thead>
												<tr>
													<th>DATE</th>
													<th>REMARKS</th>
													<th>DEBIT</th>
													<th>CREDIT</th>
													<th>BALANCE</th>
												</tr>
											   </thead>
												<tbody>';
												foreach($getdistinct_date as $rowbnk){
													$doe=$rowbnk->doe;
													$remarks=$rowbnk->remark;
													$chqno=floatval($rowbnk->chequeno);
													$debit=floatval($rowbnk->debit);
													if($debit>0){ $debit=$debit;}else{ $debit=""; }
													$credit=$rowbnk->credit;
													if($credit>0){ $credit=$credit; }else{ $credit="";}
													$baalnce=$rowbnk->balance;
													//$minval=$this->Account_model->getminbal($accno,$doe);
													//$maxbal=$this->Account_model->getmaxbal($accno,$doe);
													
													echo '<tr>
														<td>'.$doe.'</td>
														<td>'.$remarks."($chqno)".'</td>
														<td>'.$debit.'</td>
														<td>'.$credit.'</td>
														<td>'.$baalnce.'</td>
																					
													</tr>';
												}								
												echo '</tbody>
										</table>
																		
									</div>
									</div>
							</div>';
	
 	}
 	
 	}
   public function getmaintransaction_bank()
   {
   	  $this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$date_from = $this->input->post("frmdte");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte");  
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	  $accno=$this->input->post("accno");
		//$data['Title']="Cash In Hand";
		echo '<div class="row">
															<div class="col-md-12" style="overflow:scroll; height: 530px;">
																<table class="table table-bordered table-hover" id="printable_2" >
																	<thead>
																		<tr>
																			 <th>DATE</th>
																			 <th>REMARKS</th>
																			 <th>DEBIT</th>
																			 <th>CREDIT</th>
																			 <th>BALANCE</th>
																			
																		</tr>
																	</thead>
																	<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			 $gettrans=$this->Account_model->gettotal_transaction_bank($d,$accno);
			// print_r($gettrans);
			 if(!empty($gettrans) && isset($gettrans))
			 {
			 	foreach($gettrans as $rowtottran){
			 	echo '
			 	<tr>
			 		<td>'.$d.'</td>
			 		<td>'. $rowtottran->remark."(".$rowtottran->chequeno.")" .'</td>
			 		<td>';
			 		 if(($rowtottran->debit)>0){ echo number_format(($rowtottran->debit),2); } 
			 		echo  '</td><td>';
			 		 if(($rowtottran->credit)>0) { echo number_format(($rowtottran->credit),2); }  
			 		 echo'
			 		 </td><td>
			 		 '. number_format(($rowtottran->balance),2)  .'</td></tr>';
			 }
			 }
			
			
		}
		echo '</tbody>
																</table>
															</div>
														</div> ';
   }
  public function getstatement_bank()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('frmdtetrn');
		$tdtetrn=$this->input->post('tdtetrn');
		$accno=$this->input->post("accn_transaction");
		$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY BANK TRANSACTION",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(180,10,"ACCOUNT NO:- $accno  :: BANK NAME:- $getbankname",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,50,30,30,30));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		$this->fpdf->statement(array("DATE","REMARKS","DEBIT","CREDIT"," BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getdistinctdate=$this->Account_model->get_transaction_details($accno);
			//print_r($getdistinctdate);
			
			if(!empty($getdistinctdate) && isset($getdistinctdate))
			{
			
				
					foreach($getdistinctdate as $rowbnk){
					$doe=$rowbnk->doe;
					$remarks=$rowbnk->remark;
					$chqno=floatval($rowbnk->chequeno);
					$debit=floatval($rowbnk->debit);
					if($debit>0){ $debit=number_format($debit,2);}else{ $debit=""; }
					$credit=$rowbnk->credit;
					if($credit>0){ $credit=number_format($credit,2); }else{ $credit="";}
					$baalnce=number_format($rowbnk->balance,2);
																				
						
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks($chqno)","$debit","$credit","$baalnce"));
				
						
						
					
				}
			}
			
		}else{
			
			 $date_from = $this->input->post('frmdtetrn');  //exit;
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		   $date_to = $this->input->post('tdtetrn');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			//$minval=$this->Account_model->getminval($d);
			 $gettrans=$this->Account_model->gettotal_transaction_bank($d,$accno);
			 //print_r($minval);
			
			
			if(!empty($gettrans)&& isset($gettrans))
			{
				foreach($gettrans as $rowbnk){
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
			   //	$closebal=$this->Account_model->getclose_bal($maxval);
				$doe=$rowbnk->doe;
				$remarks=$rowbnk->remark;
				$chqno=floatval($rowbnk->chequeno);
				$debit=floatval($rowbnk->debit);
				if($debit>0){ $debit=number_format($debit,2);}else{ $debit=""; }
				$credit=$rowbnk->credit;
				if($credit>0){ $credit=number_format($credit,2); }else{ $credit="";}
				$baalnce=number_format($rowbnk->balance,2);
				$this->fpdf->setwidths(array(20,50,30,30,30));
				$this->fpdf->SetFont('Arial','',9);
				$this->fpdf->SetAligns(array("C","L","R","R","R"));
				$this->fpdf->statement(array("$doe","$remarks($chqno)","$debit","$credit","$baalnce"));
				 
			}
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }

//#########################################################  update on  31012017 #######################################
  public function empsalary()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['deartmentds']=$this->Account_model->getdepartsments();
	
	
  }
  public function outgoingtax()
  {
  	  $this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $data['outgoingtax']=$this->Account_model->getoutgoingtax();
	  $this->load->view('Accounts/outgoingtax',$data);
  }
  public function expnc()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['indexp']=$this->Account_model->getallindirectexpence();
	$this->load->view('taxliabilites/expence',$data);
	  
  }
  public function get_indirectexpence_transaction()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$date_from = $this->input->post("frmdte");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte");  
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
																		
															<tr>
																<th>DATE</th>
																<th>REMARKS</th>
																<th>Exp. Purpose</th>
																<th>AMOUNT</th>
																
																<th>BALANCE</th>
																
															</tr>
															
														</thead>
														<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			//echo "<br>";
			$get_dt=$this->Account_model->get_transbyday($d);
			if(!empty($get_dt)&& isset($get_dt))
			{
				$tot=0;
				foreach($get_dt as $rowtrns){
					$tot=floatval($tot)+floatval($rowtrns->amnt);
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
				//$closebal=$this->Account_model->getclose_bal($maxval);
				echo '<tr>
					     <td>'. $rowtrns->doe.'</td>
					     <td>'.$rowtrns->name.'</td>
					     <td>'.$rowtrns->purpose.'</td>
					     <td style="text-align: right;"> '.number_format($rowtrns->amnt,2).'</td>
						  <td></td>
					</tr>';
				
				}
					echo '
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="text-align: right;">'.number_format($tot,2).'</td>
						</tr>
				
				';

			}else{
				
			}
			//if(!empty($minval))
			//{
				
			//}
			
			
			
		}
		echo '</tbody>';
		
				
  }
  public function getpdfresult()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('idtdfrom');
		$tdtetrn=$this->input->post('idtdto');
		//$accno=$this->input->post("accn_transaction");
		//$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY INDIRECT EXPENSE TRANSACTION",0,0,'C');
		$this->fpdf->ln(5);
		//$this->fpdf->cell(180,10,"ACCOUNT NO:- $accno  :: BANK NAME:- $getbankname",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,50,30,30,30));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		$this->fpdf->statement(array("DATE","REMARKS","EXP. PURPOSE","AMOUNT"," BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getdistinctdate=$this->Account_model->get_transaction_inderect();
			//print_r($getdistinctdate);
			$tto=0;
			if(!empty($getdistinctdate) && isset($getdistinctdate))
			{
			
				
					foreach($getdistinctdate as $rowbnk){
					$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
					
				}
					$tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}
			
		}else{
			
			 $date_from = $this->input->post('idtdfrom');  //exit;
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		   $date_to = $this->input->post('idtdto');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			//$minval=$this->Account_model->getminval($d);
			 $gettrans=$this->Account_model->get_transaction_inderect_day($d);
			 //print_r($minval);
			
			
			if(!empty($gettrans)&& isset($gettrans))
			{
				$tto=0;
				foreach($gettrans as $rowbnk){
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
			   //	$closebal=$this->Account_model->getclose_bal($maxval);
				$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
			}
            $tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }
  public function get_directexpence_transaction()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$date_from = $this->input->post("frmdte1");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte1");  
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
																		
															<tr>
																<th>DATE</th>
																<th>REMARKS</th>
																<th>Exp. Purpose</th>
																<th>AMOUNT</th>
																
																<th>BALANCE</th>
																
															</tr>
															
														</thead>
														<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			//echo "<br>";
			$get_dt=$this->Account_model->get_transbyday_direct($d);
			if(!empty($get_dt)&& isset($get_dt))
			{
				$tot=0;
				foreach($get_dt as $rowtrns){
					$tot=floatval($tot)+floatval($rowtrns->amnt);
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
				//$closebal=$this->Account_model->getclose_bal($maxval);
				echo '<tr>
					     <td>'. $rowtrns->doe.'</td>
					     <td>'.$rowtrns->name.'</td>
					     <td>'.$rowtrns->purpose.'</td>
					     <td style="text-align: right;"> '.number_format($rowtrns->amnt,2).'</td>
						  <td></td>
					</tr>';
				
				}
					echo '
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="text-align: right;">'.number_format($tot,2).'</td>
						</tr>
				
				';

			}else{
				
			}
			//if(!empty($minval))
			//{
				
			//}
			
			
			
		}
		echo '</tbody>';
  }
  public function getpdfdirect_result()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('idtdfrom');
		$tdtetrn=$this->input->post('idtdto');
		//$accno=$this->input->post("accn_transaction");
		//$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY DIRECT EXPENSE TRANSACTION",0,0,'C');
		$this->fpdf->ln(5);
		//$this->fpdf->cell(180,10,"ACCOUNT NO:- $accno  :: BANK NAME:- $getbankname",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,50,30,30,30));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		$this->fpdf->statement(array("DATE","REMARKS","EXP. PURPOSE","AMOUNT"," BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getdistinctdate=$this->Account_model->get_transaction_direct();
			//print_r($getdistinctdate);
			$tto=0;
			if(!empty($getdistinctdate) && isset($getdistinctdate))
			{
			
				
					foreach($getdistinctdate as $rowbnk){
					$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
					
				}
					$tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}
			
		}else{
			
			 $date_from = $this->input->post('idtdfrom');  //exit;
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		   $date_to = $this->input->post('idtdto');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			//$minval=$this->Account_model->getminval($d);
			 $gettrans=$this->Account_model->get_transaction_direct_day($d);
			 //print_r($minval);
			
			
			if(!empty($gettrans)&& isset($gettrans))
			{
				$tto=0;
				foreach($gettrans as $rowbnk){
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
			   //	$closebal=$this->Account_model->getclose_bal($maxval);
				$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
			}
            $tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }
  public function get_indirect_expence_individual()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $indtrns=$this->input->post("indtrns");
	$getalltrans_details=$this->Account_model->gettrans_dr($indtrns);
	if(!empty($getalltrans_details) && isset($getalltrans_details))
	{
		echo '
		     <div class="col-md-12" ><center><h3><b>Transaction Of '.$indtrns.'</b></h3></center></div>
		      <div class="col-md-12">
			<form action="'.base_url().'Accounts_controller/getpdfresult_individual_expnce" method="post" target="_blank">
													<div class="col-md-3"><input type="date" name="idtdfrom" class="frmd" id="idtdfrom" placeholder="form date" /></div>
													<div class="col-md-2"></div>
													<div class="col-md-3"><input type="date" name="idtdto" class="tomd" id="idtdto"  placeholder="to date"/></div>
													<div class="col-md-1"></div>
													
													<div class="col-md-3">
													<input type="hidden" name="prpos" id="prpos" value="'.$indtrns.'"/>
														&nbsp;&nbsp;<button type="button" class="btn btn-primary" onclick="gettrans_details_individuals();"><i class="fa fa-search" aria-hidden="true"></i></button>
														&nbsp;&nbsp;
														<button type="submit" class="btn btn-primary" ><i class="fa fa-print" aria-hidden="true"></i></button>
													</form>
													</div>
												</div>
												<div class="col-md-12" id="msg2" style="color:red"></div>
												<div class="col-md-12" >
													<table class="table table-bordered table-hover" id="printable" >
														<thead>
																		
															<tr>
																<th>DATE</th>
																<th>REMARKS</th>
																<th>Exp. Purpose</th>
																<th>AMOUNT</th>
																
																<th>BALANCE</th>
																
															</tr>
															
														</thead>
														<tbody>';
															// $qry=mysqli_query($con,"select * from pvoucher where ucase(accountgroup)='15' and status='1' order by id asc"); 
															$getindirct_ex=$this->Account_model->gettrans_dr($indtrns);
															
															
															 if(isset($getindirct_ex) && !empty($getindirct_ex)){  $sl=1; $tot=0;
														     foreach($getindirct_ex as $rotrnsd){ 
														    	$tot=floatval($tot)+floatval($rotrnsd->amnt);
														    
															echo '<tr>
																<td> '.$rotrnsd->doe.' </td>
																<td> '.$rotrnsd->name.' </td>
																<td> '.$rotrnsd->purpose.' </td>
																<td style="text-align: right;"> '.number_format($rotrnsd->amnt,2).'</td>
																
																<td></td>
															</tr>';
															}
															echo'<tr>
																<td></td>
																<td></td>
																<td></td>
																<td></td>
																<td style="text-align: right;">'. number_format($tot,2).'</td>
																
																
															</tr>';
															 } 
														echo '</tbody>
													</table>
												</div>';
	                   
					
	                   }
  }
public function get_direct_expence_individual()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	 $indtrns=$this->input->post("indtrns");
	$getalltrans_details=$this->Account_model->gettrans_direct($indtrns);
	if(!empty($getalltrans_details) && isset($getalltrans_details))
	{
		echo '
		     <div class="col-md-12" ><center><h3><b>Transaction Of '.$indtrns.'</b></h3></center></div>
		      <div class="col-md-12">
			<form action="'.base_url().'Accounts_controller/getpdfresult_individual_expnce_direct" method="post" target="_blank">
													<div class="col-md-3"><input type="date" name="idtdfrom" class="frmd" id="idtdfrom" placeholder="form date" /></div>
													<div class="col-md-2"></div>
													<div class="col-md-3"><input type="date" name="idtdto" class="tomd" id="idtdto"  placeholder="to date"/></div>
													<div class="col-md-1"></div>
													
													<div class="col-md-3">
													<input type="hidden" name="prpos" id="prpos" value="'.$indtrns.'"/>
														&nbsp;&nbsp;<button type="button" class="btn btn-primary" onclick="gettrans_details_individuals_direct();"><i class="fa fa-search" aria-hidden="true"></i></button>
														&nbsp;&nbsp;
														<button type="submit" class="btn btn-primary" ><i class="fa fa-print" aria-hidden="true"></i></button>
													</form>
													</div>
												</div>
												<div class="col-md-12" id="msg2" style="color:red"></div>
												<div class="col-md-12" >
													<table class="table table-bordered table-hover" id="printable" >
														<thead>
																		
															<tr>
																<th>DATE</th>
																<th>REMARKS</th>
																<th>Exp. Purpose</th>
																<th>AMOUNT</th>
																
																<th>BALANCE</th>
																
															</tr>
															
														</thead>
														<tbody>';
															// $qry=mysqli_query($con,"select * from pvoucher where ucase(accountgroup)='15' and status='1' order by id asc"); 
															$getindirct_ex=$this->Account_model->gettrans_direct($indtrns);
															
															
															 if(isset($getindirct_ex) && !empty($getindirct_ex)){  $sl=1; $tot=0;
														     foreach($getindirct_ex as $rotrnsd){ 
														    	$tot=floatval($tot)+floatval($rotrnsd->amnt);
														    
															echo '<tr>
																<td> '.$rotrnsd->doe.' </td>
																<td> '.$rotrnsd->name.' </td>
																<td> '.$rotrnsd->purpose.' </td>
																<td style="text-align: right;"> '.number_format($rotrnsd->amnt,2).'</td>
																
																<td></td>
															</tr>';
															}
															echo'<tr>
																<td></td>
																<td></td>
																<td></td>
																<td></td>
																<td style="text-align: right;">'. number_format($tot,2).'</td>
																
																
															</tr>';
															 } 
														echo '</tbody>
													</table>
												</div>';
	                   
					
	                   }
  }
  public function getpdfresult_individual_expnce()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('idtdfrom');
		$tdtetrn=$this->input->post('idtdto');
		$prpos=$this->input->post("prpos");
		//$accno=$this->input->post("accn_transaction");
		//$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY INDIRECT EXPENSE TRANSACTION",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(180,10,"TRANSACTION FOR $prpos",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,50,30,30,30));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		$this->fpdf->statement(array("DATE","REMARKS","EXP. PURPOSE","AMOUNT"," BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getdistinctdate=$this->Account_model->get_transaction_inderect_individual($prpos);
			//print_r($getdistinctdate);
			$tto=0;
			if(!empty($getdistinctdate) && isset($getdistinctdate))
			{
			
				
					foreach($getdistinctdate as $rowbnk){
					$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
					
				}
					$tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}
			
		}else{
			
			 $date_from = $this->input->post('idtdfrom');  //exit;
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		   $date_to = $this->input->post('idtdto');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			//$minval=$this->Account_model->getminval($d);
			 $gettrans=$this->Account_model->get_transaction_inderect_day_individual($d,$prpos);
			 //print_r($minval);
			
			
			if(!empty($gettrans)&& isset($gettrans))
			{
				$tto=0;
				foreach($gettrans as $rowbnk){
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
			   //	$closebal=$this->Account_model->getclose_bal($maxval);
				$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
			}
            $tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }
public function getpdfresult_individual_expnce_direct()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		$frmdte=$this->input->post('idtdfrom');
		$tdtetrn=$this->input->post('idtdto');
		$prpos=$this->input->post("prpos");
		//$accno=$this->input->post("accn_transaction");
		//$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,10,"DAY BY DAY INDIRECT EXPENSE TRANSACTION",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(180,10,"TRANSACTION FOR $prpos",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"From: $frmdte",0,0,'L');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','I',10);
		$this->fpdf->cell(150);
		$this->fpdf->cell(20,5,"To: $tdtetrn",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->line(5,40,200,40);
		$this->fpdf->ln(5);
		$this->fpdf->setwidths(array(20,50,30,30,30));
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->SetAligns(array("C","L","R","R","R"));
		$this->fpdf->statement(array("DATE","REMARKS","EXP. PURPOSE","AMOUNT"," BALANCE"));
		if(empty($frmdte) || empty($tdtetrn))
		{
			$getdistinctdate=$this->Account_model->get_transaction_direct_individual($prpos);
			//print_r($getdistinctdate);
			$tto=0;
			if(!empty($getdistinctdate) && isset($getdistinctdate))
			{
			
				
					foreach($getdistinctdate as $rowbnk){
					$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
					
				}
					$tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}
			
		}else{
			
			 $date_from = $this->input->post('idtdfrom');  //exit;
		    $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
          //  echo "<br>";
		   // Specify the end date. This date can be any English textual format  
		   $date_to = $this->input->post('idtdto');  
		   $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
		   for ($i=$date_from; $i<=$date_to; $i+=86400)
			{
			 $d=date('Y-m-d', $i);
			//$minval=$this->Account_model->getminval($d);
			 $gettrans=$this->Account_model->get_transaction_direct_day_individual($d,$prpos);
			 //print_r($minval);
			
			
			if(!empty($gettrans)&& isset($gettrans))
			{
				$tto=0;
				foreach($gettrans as $rowbnk){
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
			   //	$closebal=$this->Account_model->getclose_bal($maxval);
				$doe=$rowbnk->doe;
					$remarks=$rowbnk->name;
					$prps=$rowbnk->purpose;
					$amnt=floatval($rowbnk->amnt);
					$tto=floatval($tto)+ floatval($amnt);
					//$chqno=floatval($rowbnk->chequeno);
					//$debit=floatval($rowbnk->debit);
																				
						$amnt2=number_format($amnt,2);
						//$getopenbalnce=$this->Account_model->getopenbal($minval);
						//$maxval=$this->Account_model->getclosebal($d);
						//$closebal=$this->Account_model->getclose_bal($maxval);
						//$maxbal=$this->Account_model->getmaxbal($accno,$d);
						$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("$doe","$remarks","$prps","$amnt2",""));
				
						
						
			}
            $tot2=number_format($tto,2);
					$this->fpdf->setwidths(array(20,50,30,30,30));
		                 $this->fpdf->SetFont('Arial','',9);
		                $this->fpdf->SetAligns(array("C","L","R","R","R"));
		// $this->fpdf->SetAligns(array("C","L","R","R","R"));
						$this->fpdf->statement(array("","","","","$tot2"));
				
			}else{
				
			}
				
		    }
	
		}
		
		$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
  }
public function get_indirectexpence_transaction_individ()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$prpos=$this->input->post("trns");
		$date_from = $this->input->post("frmdte");
		$date_from=date("Y-m-d", strtotime($date_from));  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte"); 
		$date_to =date("Y-m-d", strtotime($date_to));
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
																		
															<tr>
																<th>DATE</th>
																<th>REMARKS</th>
																<th>Exp. Purpose</th>
																<th>AMOUNT</th>
																
																<th>BALANCE</th>
																
															</tr>
															
														</thead>
														<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			//echo "<br>";
			$get_dt=$this->Account_model->get_transbyday_ind($d,$prpos);
			if(!empty($get_dt)&& isset($get_dt))
			{
				$tot=0;
				foreach($get_dt as $rowtrns){
					$tot=floatval($tot)+floatval($rowtrns->amnt);
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
				//$closebal=$this->Account_model->getclose_bal($maxval);
				echo '<tr>
					     <td>'. $rowtrns->doe.'</td>
					     <td>'.$rowtrns->name.'</td>
					     <td>'.$rowtrns->purpose.'</td>
					     <td style="text-align: right;"> '.number_format($rowtrns->amnt,2).'</td>
						  <td></td>
					</tr>';
				
				}
					echo '
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="text-align: right;">'.number_format($tot,2).'</td>
						</tr>
				
				';

			}else{
				
			}
			//if(!empty($minval))
			//{
				
			//}
			
			
			
		}
		echo '</tbody>';
}
public function get_directexpence_transaction_individ()
{
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$frmdte=$this->input->post("frmdte");
		//$todte=$this->input->post("trdte");
		$prpos=$this->input->post("trns");
		$date_from = $this->input->post("frmdte");  
		$date_from=date("Y-m-d", strtotime($date_from));
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("trdte"); 
		$date_to= date("Y-m-d", strtotime($date_to));
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		//$data['Title']="Cash In Hand";
		echo '<thead>
																		
															<tr>
																<th>DATE</th>
																<th>REMARKS</th>
																<th>Exp. Purpose</th>
																<th>AMOUNT</th>
																
																<th>BALANCE</th>
																
															</tr>
															
														</thead>
														<tbody>';
		for ($i=$date_from; $i<=$date_to; $i+=86400)
		{
			 $d=date('Y-m-d', $i);
			//echo "<br>";
			$get_dt=$this->Account_model->get_transbyday_ind_direct($d,$prpos);
			if(!empty($get_dt)&& isset($get_dt))
			{
				$tot=0;
				foreach($get_dt as $rowtrns){
					$tot=floatval($tot)+floatval($rowtrns->amnt);
				//$getopenbalnce=$this->Account_model->getopenbal($minval);
				//$maxval=$this->Account_model->getclosebal($d);
				//$closebal=$this->Account_model->getclose_bal($maxval);
				echo '<tr>
					     <td>'. $rowtrns->doe.'</td>
					     <td>'.$rowtrns->name.'</td>
					     <td>'.$rowtrns->purpose.'</td>
					     <td style="text-align: right;"> '.number_format($rowtrns->amnt,2).'</td>
						  <td></td>
					</tr>';
				
				}
					echo '
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="text-align: right;">'.number_format($tot,2).'</td>
						</tr>
				
				';

			}else{
				
			}
			//if(!empty($minval))
			//{
				
			//}
			
			
			
		}
		echo '</tbody>';
}
######################################################  Profit & Loss Account  ####################################################################
 public function profitandloss()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Profit & Loss Account";
	$this->load->view('taxliabilites/profitandloss',$data);
 }
 public function get_profitandloss()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	//$fromdte=$this->input->post("frmdte");
	//$todte=$this->input->post("trdte");
	//$prpos=$this->input->post("trns");
    $date_from = $this->input->post("frmdte");
   // $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
    //  echo "<br>";
    // Specify the end date. This date can be any English textual format  
	$date_to = $this->input->post("trdte"); 
	$totpurchasebal=0;
	$totsales=0;
	$purcase=0;
	$sell=0;
	$indtot=0;
	$didtot=0;
	$totpurchasebal=0;
	// $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
//#####################################    calculate total indirect expence #######################################
	$gettottalindirectexpe=$this->Account_model->getinderctexpenc($date_from,$date_to);
	if(isset($gettottalindirectexpe) && !empty($gettottalindirectexpe))
	{ $indtot=0;
		foreach($gettottalindirectexpe as $rowindex){ $bl=floatval($rowindex->amnt);$indtot=floatval($indtot)+floatval($bl); }
	}
//#####################################    calculate total direct expence #######################################
	$gettottaldirectexpe=$this->Account_model->getderctexpenc($date_from,$date_to);
	if(isset($gettottaldirectexpe) && !empty($gettottaldirectexpe))
	{ $didtot=0;
		foreach($gettottaldirectexpe as $rowdirectdex){ $bldirect=floatval($rowdirectdex->amnt);$didtot=floatval($didtot)+floatval($bldirect); }
	}
//#####################################    calculate total Purchase bills without tax #######################################
	$gettottalpurchasewithouttax=$this->Account_model->getcurrent_purchasebillwithouttax($date_from,$date_to);
	if(isset($gettottalpurchasewithouttax) && !empty($gettottalpurchasewithouttax))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewithouttax);
	}
	
	
//#####################################    calculate total Purchase bills with tax 14.5 % #######################################
	$gettottalpurchasewith_tax=$this->Account_model->getcurrent_purchasebillwith_tax($date_from,$date_to);
	//$totpurchasebal=0;
	

	if(isset($gettottalpurchasewith_tax) && !empty($gettottalpurchasewith_tax))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewith_tax);
	}
//#####################################    calculate total Purchase bills with tax 5 % #######################################
	$gettottalpurchasewith_tax_less=$this->Account_model->getcurrent_purchasebillwith_tax_less($date_from,$date_to);
	//$totpurchasebal=0;
	

	if(isset($gettottalpurchasewith_tax_less) && !empty($gettottalpurchasewith_tax_less))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewith_tax_less);
	}
 //#####################################    calculate total Purchase bills for import #######################################
	$gettottalpurchasewith_import=$this->Account_model->getcurrent_purchase_import($date_from,$date_to);
	//$totpurchasebal=0;
	

	if(isset($gettottalpurchasewith_import) && !empty($gettottalpurchasewith_import))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewith_import);
	}
 
  

	//print_r($gettottalindirectexpe);
	echo '
	<div class="col-md-6">
	<table class="table table-bordered table-hover">';
		echo'<thead>
				<tr>
					<th>Particulars</th>
					<th></th>
					<th></th>
					
				</tr>
			</thead>
			<tbody>';
/////////////////////////////////////   Purchase Account   88888888888888888888888888888888888
        if($totpurchasebal>0){
        	echo '
			  <tr>
			     <td><b>Purchase Accounts</b></td>
			     <td></td>
			     <td style="text-align:right;">'.number_format($totpurchasebal,2).'</td>
			  </tr>';
			  //purchase import
			  if(isset($gettottalpurchasewith_import) && !empty($gettottalpurchasewith_import))
	            { 
	
				echo '<tr>
					<td>&nbsp;&nbsp;<i>Purchase Import</i></td>
					<td style="text-align:right;">'.number_format($gettottalpurchasewith_import,2).'</td>
					<td></td>
					
					
				</tr>
			
			
			';
			}
			  
	      //purchase store
			  if(isset($gettottalpurchasewithouttax) && !empty($gettottalpurchasewithouttax))
	           {
				echo '<tr>
					<td>&nbsp;&nbsp;<i>Purchase Store</i></td>
					<td style="text-align:right;">'.number_format($gettottalpurchasewithouttax,2).'</td>
					<td></td>
					
					
				</tr>';
			   }
			   //purchase @14.5%
				if(isset($gettottalpurchasewith_tax) && !empty($gettottalpurchasewith_tax))
	            { 
	
				echo '<tr>
					<td>&nbsp;&nbsp;<i>Purchase @ 14.5%</i></td>
					<td style="text-align:right;">'.number_format($gettottalpurchasewith_tax,2).'</td>
					<td></td>
					
					
				</tr>
			
			
			';
			}
            //purchase @5%
             if(isset($gettottalpurchasewith_tax_less) && !empty($gettottalpurchasewith_tax_less))
	            { 
	
				echo '<tr>
					<td>&nbsp;&nbsp;<i>Purchase @ 5%</i></td>
					<td style="text-align:right;">'.number_format($gettottalpurchasewith_tax_less,2).'</td>
					<td></td>
					
					
				</tr>
			
			
			';
			}
			}  
			
	
///////////////////////////////////////////   End of direct Expense///////////////////////////////////////////////////	
	

/////////////////////////////////////   Direct Expense  88888888888888888888888888888888888
         if(isset($gettottalindirectexpe) && !empty($gettottalindirectexpe))
	     {
			echo '
			  <tr>
			     <td><b>Direct Expenses</b></td>
			     <td></td>
			     <td style="text-align:right;">'.number_format($didtot,2).'</td>
			  </tr>';
			  $getdistinct_directex=$this->Account_model->getdistict_directexp();
			  if(isset($getdistinct_directex) && !empty($getdistinct_directex))
	          {
	          	
		         foreach($getdistinct_directex as $rowdispr){
		          $prp=$rowdispr->purpos;
					 $distot_directexp=$this->Account_model->getdistinct_directexpnc($prp);
	           
			  
				echo '<tr>
					<td>&nbsp;&nbsp;<i>'.$prp.'</i></td>
					<td style="text-align:right;">'.number_format($distot_directexp,2).'</td>
					<td></td>
					
					
				</tr>
			
			
			';
			  }
			  }
			  }
	
///////////////////////////////////////////   End of direct Expense///////////////////////////////////////////////////	
	
	
	
/////////////////////////////////////   Indirect Expense  88888888888888888888888888888888888
         if(isset($gettottalindirectexpe) && !empty($gettottalindirectexpe))
	     {
			echo '
			  <tr>
			     <td><b>Indirect Expenses</b></td>
			     <td></td>
			     <td style="text-align:right;">'.number_format($indtot,2).'</td>
			  </tr>';
			  $getdistinctindirectex=$this->Account_model->getdistict_indirectexp();
			  if(isset($getdistinctindirectex) && !empty($getdistinctindirectex))
	          {
	          	
		         foreach($getdistinctindirectex as $rowdispr){
		          $prp=$rowdispr->purpos;
					 $distotindirectexp=$this->Account_model->getdistinct_indirectexpnc($prp);
	           
			  
				echo '<tr>
					<td>&nbsp;&nbsp;<i>'.$prp.'</i></td>
					<td style="text-align:right;">'.number_format($distotindirectexp,2).'</td>
					<td></td>
					
					
				</tr>
			
			
			';
			  }
			  }
			  }
	
///////////////////////////////////////////   End of Indirect Expense//	
	
	
	
	
	
	
	echo '</tbody></table></div>';
	$purcase=floatval($purcase)+floatval($indtot)+floatval($didtot)+floatval($totpurchasebal);
//#################################################           sales details           ####################################################################
////////////////////////////////////////////////            get sale  @2%              
$getcst=$this->Account_model->getcst_val($date_from,$date_to);
if(isset($getcst)&& !empty($getcst)){
	$totsales=floatval($totsales)+floatval($getcst);
	
}
////////////////////////////////////////////////            get sale  @14.5%              
$get_vat_sales=$this->Account_model->getvat_sale($date_from,$date_to);
print_r($get_vat_sales);
if(isset($get_vat_sales)&& !empty($get_vat_sales)){
	$totsales=floatval($totsales)+floatval($get_vat_sales);
	
}
////////////////////////////////////////////////            get sale  @5%              
$get_vat_sales_less=$this->Account_model->getvat_sale_less($date_from,$date_to);
if(isset($get_vat_sales_less)&& !empty($get_vat_sales_less)){
	$totsales=floatval($totsales)+floatval($get_vat_sales_less);
	
}

//print_r($getcst);
	echo '<div class="col-md-6">
			<table class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>Particulars</th>
						<th></th>
						<th></th>
						
						
					</tr>
				</thead>
				<tbody>
				';
				if(floatval($totsales)>0){
					echo '<tr>
						<td><b>Sales Accounts</b></td>
						<td></td>
						<td style="text-align:right;">'.number_format($totsales,2).'</td>
					</tr>';
					//cst sales
					if(floatval($getcst)>0){
						echo 
						'<tr>
							<td>&nbsp;&nbsp;<i>Sales @ 2.00%</i></td>
							<td style="text-align:right;">'.number_format($getcst,2).'</td>
							<td></td>
					    </tr>
						';
						
						
					}
					//vat  sales @14.5 %
					if(isset($get_vat_sales)&& !empty($get_vat_sales)){
						echo 
						'<tr>
							<td>&nbsp;&nbsp;<i>Sales @ 14.5%</i></td>
							<td style="text-align:right;">'.number_format($get_vat_sales,2).'</td>
							<td></td>
					    </tr>
						';
						
						
					}
					//vat  sales @5.00 %
					if(floatval($get_vat_sales_less)>0){
						echo 
						'<tr>
							<td>&nbsp;&nbsp;<i>Sales @ 5.00%</i></td>
							<td style="text-align:right;">'.number_format($get_vat_sales_less,2).'</td>
							<td></td>
					    </tr>
						';
						
						
					}
                  
					}
                    
				echo '</tbody>
			</table></div>';
		$sell=floatval($sell)+floatval($totsales);
		if($sell>$purcase){ $profit=floatval($sell)-floatval($purcase); $adjusttot=$sell; }
		if($purcase>$sell){ $loss=floatval($purcase)-floatval($sell); $adjusttot=$purcase;}
		if($purcase==$sell){ $profit="";$loss=""; $adjusttot=$purcase; }
			echo '
			   <div class="col-md-12">
				<div class="col-md-6">
				  <table class="table table-bordered table-hover">
				   <tbody>
				   ';
				   if(isset($profit)&& !empty($profit)){
				   	echo '<tr>
				   	  <td>&nbsp;&nbsp;Net Profit</td>
				   		<td colspan="2" style="text-align:right;">'.number_format($profit,2).'</td>
				   		
				   	</tr>';
				   }else{
				   	 echo '<tr>
				   	     <td>&nbsp;&nbsp;Net Profit</td>
				   		<td colspan="2" style="text-align:right;"></td>
				   		
				   	</tr>';
				   }
				   	echo '<tr>
				   	
				   		<td colspan="3" style="text-align:right;"><b><h4>'.number_format($adjusttot,2).'</h4></b></td>
				   		
				   	</tr>
				   </tbody>
				  </table>
				</div>
				<div class="col-md-6">
				<table class="table table-bordered table-hover">
				   <tbody>
				   ';
				    if(isset($loss)&& !empty($loss)){
				   	echo '<tr>
				   	   <td>Net Loss</td>
				   		<td colspan="2" style="text-align:right;">'.number_format($loss,2).'</td>
				   		
				   	</tr>';
					}
					else
						{
								echo '<tr>
				   	  <td>Net Loss</td>
				   		<td colspan="2" style="text-align:right;"></td>
				   		
				   	</tr>';
								
						}
				   echo '<tr>
				   	   
				   		<td colspan="3" style="text-align:right;"><b><h4>'.number_format($adjusttot,2).'</h4></b></td>
				   		
				   	</tr>
				   </tbody>
				  </table>
				</div>
				</div>
			
			
			';
			
	
	
	
 }
//########################################################################################################################
      /*   printing purpose   */
//######################################################################################################################
 public function printprofitandloss()
 {
 	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$invoicetxt="ISSUE OF INVOICE UNDER RULE 11 OF CENTRAL EXCISE RULES 2002";
		//$frmdte=$this->input->post('idtdfrom');
		//$tdtetrn=$this->input->post('idtdto');
		 $date_from = $this->input->post("formdte");
		 $date_from1 = date("d-M-Y", strtotime($date_from));
	   // $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
	    //  echo "<br>";
	    // Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("tomdte");
		$date_to1 = date("d-M-Y", strtotime($date_to)); 
		
		//$accno=$this->input->post("accn_transaction");
		//$getbankname=$this->Account_model->getbank_name($accno);
		$declt="Declaration: We declare that this invoice shows the actual price of the goods descrive and that all particulars are true and correct.";
		//$getbookingdetails=$this->AccountManage_model->getbookingdetls($bkid);
		$img="assets/logo/logo.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		//$this->fpdf->addpage();
		//$pdf=$this->fpdf();
		//$this->fpdf->orientation("P");
		//$this->fpdf->Image("$path",80,1,195,250,'png');
		//$newDate = date("d-m-Y", strtotime($originalDate));
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->cell(180,10,"G.K RICKSHOW PVT LTD",0,0,'C');
		$this->fpdf->ln(8);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(180,5,"30(33/1),N.T.Road ,Padmabati Colony",0,0,'C');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(180,5,"Baidyabati,Hooghly-712222",0,0,'C');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(180,5,"Ph: 8420070085/033-6451-7771",0,0,'C');
		$this->fpdf->ln(4);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(180,5,"E-mail: gkrickshow@yahoo.in",0,0,'C');
		$this->fpdf->ln(6);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(180,5,"Profit & Loss A/c",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(180,5,"$date_from1   to    $date_to1",0,0,'C');
		$this->fpdf->ln(10);
		$x=$this->fpdf->getx();
		$y=$this->fpdf->gety();
		$this->fpdf->line($x-5,$y,$x+195,$y);
		$this->fpdf->line($x-5,$y+8,$x+195,$y+8);
		$this->fpdf->line($x+95,$y,$x+95,$y+235);
		$this->fpdf->line($x-5,$y,$x-5,$y+235);
		$this->fpdf->line($x+195,$y,$x+195,$y+235);
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->text($x,$y+5,"Particulars");
		$this->fpdf->SetFont('Arial','B',9);
		$this->fpdf->text($x+100,$y+5,"Particulars");
		
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text($x+50,$y+5,"$date_from1 to $date_to1");
		$this->fpdf->SetFont('Arial','I',9);
		$this->fpdf->text($x+150,$y+5,"$date_from1 to $date_to1");
		$totpurchasebal=0;
	$totsales=0;
	$purcase=0;
	$sell=0;
	$indtot=0;
	$didtot=0;
	$pnb=0;
	$totpurchasebal=0;
	// $date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
//#####################################    calculate total indirect expence #######################################
	$gettottalindirectexpe=$this->Account_model->getinderctexpenc($date_from,$date_to);
	if(isset($gettottalindirectexpe) && !empty($gettottalindirectexpe))
	{ $indtot=0;
		foreach($gettottalindirectexpe as $rowindex){ $bl=floatval($rowindex->amnt);$indtot=floatval($indtot)+floatval($bl); }
	}
//#####################################    calculate total direct expence #######################################
	$gettottaldirectexpe=$this->Account_model->getderctexpenc($date_from,$date_to);
	if(isset($gettottaldirectexpe) && !empty($gettottaldirectexpe))
	{ $didtot=0;
		foreach($gettottaldirectexpe as $rowdirectdex){ $bldirect=floatval($rowdirectdex->amnt);$didtot=floatval($didtot)+floatval($bldirect); }
	}
//#####################################    calculate total Purchase bills without tax #######################################
	$gettottalpurchasewithouttax=$this->Account_model->getcurrent_purchasebillwithouttax($date_from,$date_to);
	if(isset($gettottalpurchasewithouttax) && !empty($gettottalpurchasewithouttax))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewithouttax);
	}
	
	
//#####################################    calculate total Purchase bills with tax 14.5 % #######################################
	$gettottalpurchasewith_tax=$this->Account_model->getcurrent_purchasebillwith_tax($date_from,$date_to);
	//$totpurchasebal=0;
	

	if(isset($gettottalpurchasewith_tax) && !empty($gettottalpurchasewith_tax))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewith_tax);
	}
//#####################################    calculate total Purchase bills with tax 5 % #######################################
	$gettottalpurchasewith_tax_less=$this->Account_model->getcurrent_purchasebillwith_tax_less($date_from,$date_to);
	//$totpurchasebal=0;
	

	if(isset($gettottalpurchasewith_tax_less) && !empty($gettottalpurchasewith_tax_less))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewith_tax_less);
	}
 //#####################################    calculate total Purchase bills for import #######################################
	$gettottalpurchasewith_import=$this->Account_model->getcurrent_purchase_import($date_from,$date_to);
	//$totpurchasebal=0;
	

	if(isset($gettottalpurchasewith_import) && !empty($gettottalpurchasewith_import))
	{ 
		$totpurchasebal=floatval($totpurchasebal)+floatval($gettottalpurchasewith_import);
	}
 
    $x=$x;
	$x1=$x;
	$y=$y+12;
	$y1=$y;
	 /////////////////////////////////////   Purchase Account   88888888888888888888888888888888888
        if($totpurchasebal>0){
        	$pnb=number_format($totpurchasebal,2);
        	$this->fpdf->SetFont('Arial','B',10);
        	$this->fpdf->text($x,$y,"Purchase Accounts");
			$this->fpdf->text($x+65,$y,"$pnb");
        	/*echo '
			  <tr>
			     <td><b>Purchase Accounts</b></td>
			     <td></td>
			     <td style="text-align:right;">'.number_format($totpurchasebal,2).'</td>
			  </tr>';*/
			  //purchase import
			  if(isset($gettottalpurchasewith_import) && !empty($gettottalpurchasewith_import))
	            {
	            	$imprt=number_format($gettottalpurchasewith_import,2);
		        	$this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+4,"Purchase Import");
					$this->fpdf->text($x+45,$y+4,"$imprt");
		       
			       $y=$y+4;
			}
			  
	      //purchase store
			  if(isset($gettottalpurchasewithouttax) && !empty($gettottalpurchasewithouttax))
	           {
	           	   $Store=number_format($gettottalpurchasewithouttax,2);
		        	$this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+4,"Purchase Store");
					$this->fpdf->text($x+45,$y+4,"$Store",'R');
				
				$y=$y+4;
			   }
	    //purchase @14.5%
			   
				if(isset($gettottalpurchasewith_tax) && !empty($gettottalpurchasewith_tax))
	            {
	            	$p145=number_format($gettottalpurchasewith_tax,2);
		        	$this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+4,"Purchase @ 14.5%");
					$this->fpdf->text($x+45,$y+4,"$p145",'R'); 
					$y=$y+4;
	           
			}
            //purchase @5%
             if(isset($gettottalpurchasewith_tax_less) && !empty($gettottalpurchasewith_tax_less))
	            {
	            	$p5=number_format($gettottalpurchasewith_tax_less,2);
		        	$this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+4,"Purchase @ 5%");
					$this->fpdf->text($x+45,$y+4,"$p5",'R'); 
	          
			}
				/////////////////////////////////////   Direct Expense  88888888888888888888888888888888888
         if(isset($gettottalindirectexpe) && !empty($gettottalindirectexpe))
	     {
	     	$y=$y+8;
	     	$didtot1=number_format($didtot,2);
        	$this->fpdf->SetFont('Arial','B',10);
        	$this->fpdf->text($x,$y+4,"Direct Expenses");
			$this->fpdf->text($x+65,$y+4,"$didtot1");
        	$y=$y+4;
			  $getdistinct_directex=$this->Account_model->getdistict_directexp();
			  if(isset($getdistinct_directex) && !empty($getdistinct_directex))
	          {
	          	 //$y=$y+4;
		         foreach($getdistinct_directex as $rowdispr){
		          $prp=$rowdispr->purpos;
					 $distot_directexp=$this->Account_model->getdistinct_directexpnc($prp);
	                 $distot_directexp=number_format($distot_directexp,2);
		        	$this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+4,"$prp");
					$this->fpdf->text($x+45,$y+4,"$distot_directexp",'R');
			    $y=$y+4;
				
			  }
			  }
			  }
	
///////////////////////////////////////////   End of direct Expense///////////////////////////////////////////////////	
	
	
	
/////////////////////////////////////   Indirect Expense  88888888888888888888888888888888888
        if(isset($gettottalindirectexpe) && !empty($gettottalindirectexpe))
	     {
	     	$y=$y+8;
	     	$indtot1=number_format($indtot,2);
        	$this->fpdf->SetFont('Arial','B',10);
        	$this->fpdf->text($x,$y+4,"Indirect Expenses");
			$this->fpdf->text($x+65,$y+4,"$indtot1");
        	$y=$y+4;
			  $getdistinctindirectex=$this->Account_model->getdistict_indirectexp();
			  if(isset($getdistinctindirectex) && !empty($getdistinctindirectex))
	          {
	          	
		         foreach($getdistinctindirectex as $rowdispr){
		          $prp=$rowdispr->purpos;
					 $distotindirectexp=$this->Account_model->getdistinct_indirectexpnc($prp);
					 $distotindirectexp=number_format($distotindirectexp,2);
	                 $this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+4,"$prp");
					$this->fpdf->text($x+45,$y+4,"$distotindirectexp",'R');
			       $y=$y+4;
			  
			  }
			  }
			  }
	
	
				
			}
$purcase=floatval($purcase)+floatval($indtot)+floatval($didtot)+floatval($totpurchasebal);
//#############################################################################  dsale
//#################################################           sales details           ####################################################################
////////////////////////////////////////////////            get sale  @2%              
$getcst=$this->Account_model->getcst_val($date_from,$date_to);
if(isset($getcst)&& !empty($getcst)){
	$totsales=floatval($totsales)+floatval($getcst);
	
}
////////////////////////////////////////////////            get sale  @14.5%              
$get_vat_sales=$this->Account_model->getvat_sale($date_from,$date_to);
//print_r($get_vat_sales);
if(isset($get_vat_sales)&& !empty($get_vat_sales)){
	$totsales=floatval($totsales)+floatval($get_vat_sales);
	
}
////////////////////////////////////////////////            get sale  @5%              
$get_vat_sales_less=$this->Account_model->getvat_sale_less($date_from,$date_to);
if(isset($get_vat_sales_less)&& !empty($get_vat_sales_less)){
	$totsales=floatval($totsales)+floatval($get_vat_sales_less);
	
}



			if(floatval($totsales)>0){
				$totsales2=number_format($totsales,2);
	        	$this->fpdf->SetFont('Arial','B',10);
	        	$this->fpdf->text($x1+100,$y1,"Sales Accounts");
				$this->fpdf->text($x1+165,$y1,"$totsales2");
	        	
					/*echo '<tr>
						<td><b>Sales Accounts</b></td>
						<td></td>
						<td style="text-align:right;">'.number_format($totsales,2).'</td>
					</tr>';*/
					//cst sales
					if(floatval($getcst)>0){
						$getcst=number_format($getcst,2);
			        	$this->fpdf->SetFont('Arial','I',9);
			        	$this->fpdf->text($x1+105,$y1+4,"Sales @ 2.00%");
						$this->fpdf->text($x1+145,$y1+4,"$getcst",'R');
					
					    $y1=$y1+4;
						/*echo 
						'<tr>
							<td>&nbsp;&nbsp;<i>Sales @ 2.00%</i></td>
							<td style="text-align:right;">'.number_format($getcst,2).'</td>
							<td></td>
					    </tr>
						';
						*/
						
					}
					//vat  sales @14.5 %
					if(isset($get_vat_sales)&& !empty($get_vat_sales)){
						$get_vat_sales=number_format($get_vat_sales,2);
			        	$this->fpdf->SetFont('Arial','I',9);
			        	$this->fpdf->text($x1+105,$y1+4,"Sales @ 14.5%");
						$this->fpdf->text($x1+145,$y1+4,"$get_vat_sales",'R');
					
					    $y1=$y1+4;
						/*echo 
						'<tr>
							<td>&nbsp;&nbsp;<i>Sales @ 14.5%</i></td>
							<td style="text-align:right;">'.number_format($get_vat_sales,2).'</td>
							<td></td>
					    </tr>
						';
						*/
						
					}
					//vat  sales @5.00 %
					if(floatval($get_vat_sales_less)>0){
						$get_vat_sales_less=number_format($get_vat_sales_less,2);
			        	$this->fpdf->SetFont('Arial','I',9);
			        	$this->fpdf->text($x1+105,$y1+4,"Sales @ 5.00%");
						$this->fpdf->text($x1+145,$y1+4,"$get_vat_sales_less",'R');
					
					    $y1=$y1+4;
						/*echo 
						'<tr>
							<td>&nbsp;&nbsp;<i>Sales @ 5.00%</i></td>
							<td style="text-align:right;">'.number_format($get_vat_sales_less,2).'</td>
							<td></td>
					    </tr>
						';*/
						
						
					}
                  
					}
///############################################   profit and loss calulate  
         $sell=floatval($sell)+floatval($totsales);
		if($sell>$purcase){ $profit=floatval($sell)-floatval($purcase); $adjusttot=$sell; }
		if($purcase>$sell){ $loss=floatval($purcase)-floatval($sell); $adjusttot=$purcase;}
		if($purcase==$sell){ $profit="";$loss=""; $adjusttot=$purcase; }
	     if(isset($profit)&& !empty($profit)){
	     	        $prof=number_format($profit,2);
			   $yl=$y;
	     	        $this->fpdf->SetFont('Arial','B',10);
		        	$this->fpdf->text($x+5,$y+50,"Net Profit");
					$this->fpdf->text($x+65,$y+50,"$prof",'R');
			       $y=$y+6;
				   
				   }else{
				   	 $this->fpdf->SetFont('Arial','I',9);
		        	$this->fpdf->text($x+5,$y+50,"");
					$this->fpdf->text($x+65,$y+50,"",'R');
			       $y=$y+6;
				   }
				   $adj=number_format($adjusttot,2);
				   $this->fpdf->SetFont('Arial','B',11);
		        	$this->fpdf->text($x,$y+51,"Total");
					$this->fpdf->text($x+65,$y+51,"$adj",'R');
			       $y=$y+6;
				   
             if(isset($loss)&& !empty($loss)){
             	     $loss1=number_format($loss,2);
	     	        $this->fpdf->SetFont('Arial','B',9);
		        	$this->fpdf->text($x+100,$yl+50,"Net Loss");
					$this->fpdf->text($x+165,$yl+50,"$loss1",'R');
			       $yl=$yl+6;
				   	
					}
					else
						{
								$this->fpdf->SetFont('Arial','I',9);
						        $this->fpdf->text($x+105,$yl+50,"");
								$this->fpdf->text($x+165,$yl+50,"",'R');
							      $yl=$yl+6;
								
						}
						$adj2=number_format($adjusttot,2);
				   $this->fpdf->SetFont('Arial','B',11);
		        	$this->fpdf->text($x+100,$yl+51,"Total");
					$this->fpdf->text($x+165,$yl+51,"$adj2",'R');
			       $y=$y+6;
				     $this->fpdf->SetFont('Arial','',4);
				   $this->fpdf->line($x-5,$yl+46,$x+195,$yl+46);
				   $this->fpdf->line($x-5,$yl+54,$x+195,$yl+54);
				   
				   

			
	//$this->fpdf->ln()
		//$this->fpdf->text($x,$y+1,"Particulars");
		
		
		
		
		
		//$this->fpdf->cell(180,10,"ACCOUNT NO:- $accno  :: BANK NAME:- $getbankname",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','I',10);
	    $this->fpdf->cell(150);
		$this->fpdf->ln(5);
		
		//$this->fpdf->Image($img, 1,1,33,33,'png');
		
		$this->fpdf->output();
	
 }
 

   
}