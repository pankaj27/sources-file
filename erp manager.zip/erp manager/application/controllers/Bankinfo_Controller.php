<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bankinfo_Controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Bankinfo_Model');
	}
	public function creat()
	{
			$this->authentication->is_loggedin($this->session->userdata('user_name'));
			$data['acctyp']=$this->Bankinfo_Model->getbankacctyp();
			$this->load->view('bankinfo/creat',$data);
	}
	public function saveinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		date_default_timezone_set("Asia/Kolkata");
		$bname=strtoupper($this->input->post('bname'));
		$branch=strtoupper($this->input->post('branch'));
		$accNo=$this->input->post('accNo');
		$accName=strtoupper($this->input->post('accName'));
		$balence=$this->input->post('balence');
		$ifsc=strtoupper($this->input->post('ifsc'));
		$acctyp=$this->input->post("acctyp");
		
		$swift=strtoupper($this->input->post('swift'));
		$crtd=strtoupper($this->session->userdata('user_name'));
		
		$data_array=array(
			"bankname"=>$bname,
			"branchname"=>$branch,
			"accno"=>$accNo,
			"acctyp"=>$acctyp,
			"accname"=>$accName,
			"balance"=>$balence,
			"ifsc"=>$ifsc,
			"swiftcode"=>$swift,
			"crtd"=>$crtd,
			"doe"=>date('Y-m-d h:i:s A')
		);
		$this->Bankinfo_Model->saveinfo($data_array);
		redirect('Bankinfo_Controller/viewinfo');
	}
	public function viewinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['alldata']=$this->Bankinfo_Model->getalldata();
		
		$this->load->view('bankinfo/viewinfo',$data);
	}
	public function deleteinfo($id)
	{
		$id1=$id;
		$this->Bankinfo_Model->deleteinfo($id1);
		redirect('Bankinfo_Controller/viewinfo');
	}
	public function editinfo($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$data['edit']=$this->Bankinfo_Model->fetchinfo1($id1);
		$data['acctyp']=$this->Bankinfo_Model->getbankacctyp();
		$this->load->view('bankinfo/editinfo',$data);
	}
	public function updateinfo()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		date_default_timezone_set("Asia/Kolkata");
		$id=$this->input->post('id');
		
		$bname=strtoupper($this->input->post('bname'));
		$branch=strtoupper($this->input->post('branch'));
		$accNo=$this->input->post('accNo');
		$accName=strtoupper($this->input->post('accName'));
		$balence=strtoupper($this->input->post('balence'));
		$ifsc=strtoupper($this->input->post('ifsc'));
		$swift=strtoupper($this->input->post('swift'));
		$crtd=$this->session->userdata('user_name');
		$acctyp=$this->input->post("acctyp");
		
		$data_array=array(
			"bankname"=>$bname,
			"branchname"=>$branch,
			"accno"=>$accNo,
			"accname"=>$accName,
			"acctyp"=>$acctyp,
			"balance"=>$balence,
			"ifsc"=>$ifsc,
			"swiftcode"=>$swift,
			"crtd"=>$crtd,
			"doe"=>date('Y-m-d h:i:s A')
		);
		$this->Bankinfo_Model->updateinfo($data_array,$id);
		redirect('Bankinfo_Controller/viewinfo');
	}
	
	
		
}
