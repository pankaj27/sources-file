<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bill_of_cost_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('Bill_of_cost_model');
	}
	public function bill_of_cost_dash()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']='User Dashboard';
		$this->load->view("bills_of_cost/bills_of_cost_dash");
	}
}