<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class NewBrand_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->model('newBrand_model');
	}
	public function modelEntry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$modelcode=$this->newBrand_model->getModelCode();
		if(empty($modelcode))
		{
			$invID="1";
			$data['modelcodes']="GK/PR/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($modelcode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['modelcodes']="GK/PR/".date('y')."-".(date('y')+1)."/".$invID;
		}
		$data['model']=$this->newBrand_model->fetchmodel();
    	$this->load->view('model_entry/create',$data);
	}
	public function editModelEntry($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;		
		$data['model']=$this->newBrand_model->fetchModelEntry($id1);
    	$this->load->view('model_entry/editNewEntry',$data);
	}
	public function updatNewEnrey()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id	=$this->input->post('id');
		$data_array=array(
			'brand'=>$this->input->post('brand'),
			'productname'=>$this->input->post('modelName'),
			'productid'=>$this->input->post('modelcode'),
			
			'batteryPower'=>$this->input->post('batteryPower'),
			'batteryModel'=>$this->input->post('batteryModel'),
			'clsModel'=>$this->input->post('clsModel'),
			
			'disPric_excld'=>$this->input->post('disPric_excld'),
			'disPric_incld'=>$this->input->post('disPric_incld'),
			'dis2subPric_excld'=>$this->input->post('dis2subPric_excld'),
			'dis2subPric_incld'=>$this->input->post('dis2subPric_incld'),
			'sub2dis_excld'=>$this->input->post('sub2dis_excld'),
			'sub2dis_incld'=>$this->input->post('sub2dis_incld'),
			
			'vat'=>$this->input->post('vat'),
			'Sales'=>$this->input->post('Sales'),
			'excise'=>$this->input->post('excise'),
			'cst'=>$this->input->post('cst'),
			'custom'=>$this->input->post('custom'),
			
			'servpaid'=>$this->input->post('servpaid'),
			'servday'=>$this->input->post('servday'),
			'motorPower'=>$this->input->post('motorPower'),
			'seatcap'=>$this->input->post('seatcap'),
			'grossvhc'=>$this->input->post('grossvhc'),
			'bodyType'=>$this->input->post('bodyType'),
			//'fuelUsed'=>$this->input->post('fuelUsed'),
			'mfgYear'=>$this->input->post('mfgYear'),
			//'unLoadwt'=>$this->input->post('unLoadwt'),
			//'octrail'=>$this->input->post('octrail')
			);
		$this->newBrand_model->updatNewEnrey($data_array,$id);
				
		redirect('newBrand_controller/viewmodel','refresh');	
	}
	public function deleteModelEntry($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$this->newBrand_model->deleteModelEntry($id1);
		redirect('newBrand_controller/viewmodel','refresh');
	}
	public function save_new_stock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$mopdel=$this->input->post('modelName');
		
		$data_array=array(	
			'brand'=>$this->input->post('brand'),
			'productname'=>$this->input->post('modelName'),
			'productid'=>$this->input->post('modelcode'),
			
			'batteryPower'=>$this->input->post('batteryPower'),
			'batteryModel'=>$this->input->post('batteryModel'),
			'clsModel'=>$this->input->post('clsModel'),
			
			//'disPric_excld'=>$this->input->post('disPric_excld'),
			//'disPric_incld'=>$this->input->post('disPric_incld'),
			//'dis2subPric_excld'=>$this->input->post('dis2subPric_excld'),
			//'dis2subPric_incld'=>$this->input->post('dis2subPric_incld'),
			//'sub2dis_excld'=>$this->input->post('sub2dis_excld'),
			//'sub2dis_incld'=>$this->input->post('sub2dis_incld'),
			
			'vat'=>$this->input->post('vat'),
			'Sales'=>$this->input->post('Sales'),
			'excise'=>$this->input->post('excise'),
			'cst'=>$this->input->post('cst'),
			'custom'=>$this->input->post('custom'),
			
			
			'servpaid'=>$this->input->post('servpaid'),
			'servday'=>$this->input->post('servday'),
			'motorPower'=>$this->input->post('motorPower'),
			'seatcap'=>$this->input->post('seatcap'),
			'grossvhc'=>$this->input->post('grossvhc'),
			'bodyType'=>$this->input->post('bodyType'),
			
			'mfgYear'=>$this->input->post('mfgYear'),
			
		);
		$checkmodelentry=$this->newBrand_model->checkmodelexist($mopdel);
		if(empty($checkmodelentry))
		{
			$checkdataex=$this->newBrand_model->save_stock($data_array);
			$message1='Product Inserted Succesfully....';
		     $this->session->set_flashdata('message',$message1);
		}else{
			$message1='Product not inserted....';
		    $this->session->set_flashdata('message',$message1);
		}
		
		redirect('newBrand_controller/viewmodel','refresh');
	}
	public function viewmodel()
	{
		
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$modelcode=$this->newBrand_model->getModelCode();
		if(empty($modelcode))
		{
			$invID="1";
			$data['modelcodes']="GK/PR/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($modelcode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['modelcodes']="GK/PR/".date('y')."-".(date('y')+1)."/".$invID;
		}
		$data['model']=$this->newBrand_model->fetchmodel();
    	$this->load->view('model_entry/viewmodel',$data);
	
	}
	
	///////...................../////////////////
	
	public function sparePartsEntry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$partscode=$this->newBrand_model->getPartsCode();
		if(empty($partscode))
		{
			$invID="1";
			$data['prtscodes']="GK/PC/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($partscode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['prtscodes']="GK/PC/".date('y')."-".(date('y')+1)."/".$invID;
		}
		$data['model']=$this->newBrand_model->fetchallmodel();
		$data['parts']=$this->newBrand_model->fetchSpareParts();
    	$this->load->view('model_entry/newSpareParts',$data);
	}
	public function saveSpareParts()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$excise=$this->input->post('excise');
		$custom=$this->input->post('custom');
		$mname=$this->input->post('mName');
		$partsname=$this->input->post('partsName');
		$getparts=$this->newBrand_model->checkpartsexistornot($mname,$partsname);
		if(empty($getparts) && !empty($getparts)){
		$data_array=array(		
			'mName'=>$this->input->post('mName'),
			'materialname'=>$this->input->post('partsName'),
			'unit'=>$this->input->post('unit'),
			'materiel_id'=>$this->input->post('partsCode'),
			'description'=>$this->input->post('description'),
			
			//'disPric_excld'=>$this->input->post('disPric_excld'),
			//'dis2subPric_excld'=>$this->input->post('dis2subPric_excld'),
			//'sub2dis_excld'=>$this->input->post('sub2dis_excld'),
			
			'vat'=>$this->input->post('vat'),
			"excise"=>$this->input->post('excise'),
			"custom"=>$this->input->post('custom'),
			'Sales'=>$this->input->post('Sales'),
			'Road'=>$this->input->post('Road'),
			'cst'=>$this->input->post('cst'),
			
			'reorderlevel'=>$this->input->post('reOrdering'),
			'minStk'=>$this->input->post('minStk')
		);
		//print_r($data_array);
		//$checkspareparts=$this
		$checkdataex=$this->newBrand_model->saveSpareParts($data_array);
		
		$modelName=$this->newBrand_model->getabc();
		foreach($modelName as $row2)
		{
			$proid=$row2->id;
			$productid=$row2->materiel_id;
		}
		  $abcd=$this->input->post('divnorow');
		for($i=1;$i<=intval($abcd);$i++)
		{
			$sp=$this->input->post("sp_$i");
			if(isset($sp) && !empty($sp)){
			$data_array2=array(
				'productid'=>$proid,
				"parts_id"=>$productid,
				'specification'=>$sp
			);
				//print_r($data_array2);
				$checkdataex=$this->newBrand_model->savespecification($data_array2);
			
			}
		}
		}else{
			
		}
		
		//redirect('newBrand_controller/viewspareparts','refresh');
	}
	public function editSpareParts($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$data['parts']=$this->newBrand_model->editSpareParts($id1);
		$data['specific']=$this->newBrand_model->fetchSpecific($id1);
    	$this->load->view('model_entry/editSpareParts',$data);
	}
	public function updateSpareParts()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id	=$this->input->post('id');
		$tpartsid=$this->input->post('partsCode');
		
		$data_array=array(
			'mName'=>$this->input->post('mName'),
			'materialname'=>$this->input->post('partsName'),
			'unit'=>$this->input->post('unit'),
			'materiel_id'=>$this->input->post('partsCode'),
			'description'=>$this->input->post('description'),
			
			//'disPric_excld'=>$this->input->post('disPric_excld'),
			//'disPric_incld'=>$this->input->post('disPric_incld'),
			//'dis2subPric_excld'=>$this->input->post('dis2subPric_excld'),
			//'dis2subPric_incld'=>$this->input->post('dis2subPric_incld'),
			//'sub2dis_excld'=>$this->input->post('sub2dis_excld'),
			//'sub2dis_incld'=>$this->input->post('sub2dis_incld'),
			
			'vat'=>$this->input->post('vat'),
			'Sales'=>$this->input->post('Sales'),
			'Road'=>$this->input->post('Road'),
			'cst'=>$this->input->post('cst'),
			'excise'=>$this->input->post('excise'),
			'custom'=>$this->input->post('custom'),
			
			'reorderlevel'=>$this->input->post('reOrdering'),
			'minStk'=>$this->input->post('minStk')
			);
		
		$this->newBrand_model->updateSpareParts($data_array,$id);
		 $abcd=$this->input->post('asdf');
		 for($i=1;$i<=intval($abcd);$i++)
		{
			$sp=$this->input->post("sp_$i");
			$partsCode=$this->input->post("partsCode");
			$speid=$this->input->post("speid_$i");
			if(empty($speid)){
				$data_array2=array(
				'productid'=>$id,
				"parts_id"=>$tpartsid,
				'specification'=>$sp
			);
			$checkdataex=$this->newBrand_model->savespecification($data_array2);
			
			}else{
				$data_array2=array(
				'specification'=>$sp
			);
			$this->newBrand_model->updatespecification($data_array2,$partsCode);
			
			}
			//print_r($data_array2);
			
		}
	redirect('newBrand_controller/viewspareparts','refresh');
	}
	public function deleteSpareParts($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$id1=$id;
		$this->newBrand_model->deleteSpareParts($id1);
		redirect('newBrand_controller/viewspareparts','refresh');
	}
	public function delspac()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$speid=$this->input->post("speid");
		$res=$this->newBrand_model->deletespec($speid);
		return $res;
		
	}
	public function viewspareparts()
	{
		
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$partscode=$this->newBrand_model->getPartsCode();
		if(empty($partscode))
		{
			$invID="1";
			$data['prtscodes']="GK/PC/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($partscode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['prtscodes']="GK/PC/".date('y')."-".(date('y')+1)."/".$invID;
		}
		$data['model']=$this->newBrand_model->fetchallmodel();
		$data['parts']=$this->newBrand_model->fetchSpareParts();
    	
    	$this->load->view('model_entry/viewspareparts',$data);
	
	}
}