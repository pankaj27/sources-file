<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class StockManage_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','pagination','upload','image_lib'));
		//$this->load->library(array('session','authentication'));
		$this->load->library('fpdf_gen');
		
		$this->load->model('stockManage_model');
	}
	public function boxwiseentry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Admin Dashboard";
		$data['godown']=$this->stockManage_model->fetchgodown();
		$this->load->view("stockmanage/boxwiseentry",data);
		
	}
	public function stockentrybox()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Stock Entry";
		$data['godown']=$this->stockManage_model->fetchgodown();
		//$data['getpurchase']=$this->stockManage_model->getallpurchase();
		$this->load->view('stockmanage/stockentrybox',$data);
	}
	public function getpurchaselist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Stock Entry";
		$pono=$this->input->post('pono');
		$data['pono']=$pono;
		$data['getpurchaselist']=$this->stockManage_model->getallpurchaselist($pono);
		//print_r($data['getpurchaselist']);
		$deatgetspa=$data['getpurchaselist'];
		$modlar=array();
		if(isset($deatgetspa) && !empty($deatgetspa)){
		foreach($deatgetspa as $rowpurcsdet)
		{
			$model=$rowpurcsdet->modelcode;
			$parts=$rowpurcsdet->spareparts;
		}
		$modelsin=explode(",",$model);
		$count_model=count($modelsin);
		$partsin=explode(",",$parts);
		$count_parts=count($partsin);
		if(!empty($model) && isset($model)){
		for($mk=0;$mk<$count_model;$mk++)
		{
			$modelarr=$modelsin[$mk];
			$modelim=explode(";",$modelarr);
			$modelim=array_filter($modelim);
			if(!empty($modelim)){
			//print_r($modelim);
			$mnam=$modelim[1];
			$mqty=$modelim[2];
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			
			}
			//array_push($modlar,$mnam);
		}
		}
		if(!empty($parts) && isset($parts)){
		for($mk=0;$mk<$count_parts;$mk++)
		{
			$partsarr=$partsin[$mk];
			$parts=explode(";",$partsarr);
			$modelim=array_filter($parts);
			if(!empty($modelim)){
			//print_r($modelim);
			$mnam=$modelim[1];
			$mqty=1;
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			
			}
			//array_push($modlar,$mnam);
		}
		}
		$modlarimplode=implode(",",$modlar);
		//echo $modlarimplode;
		//$modlarimplode=explode(",",$modlarimplode);
		//echo $modlarimplode=count($modlarimplode);
		$data['modelnamedropdwn']=$modlarimplode;
		$data['godown']=$this->stockManage_model->fetchgodown();
		}
	   //print_r($data['modelnamedropdwn']);echo 1;
		//$data['getpurchase']=$this->stockManage_model->getallpurchase();
		$this->load->view('stockmanage/stockentrybox',$data);
	}
	public function getallspare_parts_sort_by_modelname()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$modelname=$this->input->post('modelname');
		$getspareparts=$this->stockManage_model->getallspareparts($modelname);
		$i=1;
		if(!empty($getspareparts)){
		foreach($getspareparts as $rowparts)
		{
			echo '<li style="border-bottom:1px solid #c2c2c2;background-color:#4caf50;color:white;padding:5px;">';
				echo '<a id="parts_'.$rowparts->id.'_'.$i.'" href="javascript:putpartsqtybyparts('.$i.','.$rowparts->id.')" style="display:block;text-decoration:none; color:white;font-weight:bolder;>
				  <div class="tile-content">
						
						<div class="tile-text">'.$rowparts->materialname.'</div>
					</div>
				</a>
		  </li>';
		}
		}else
			{
				echo "";
			}
	}
	public function getdetails_stocklist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$prtsid=$this->input->post('prtsmid');
		$pono=$this->input->post('pono');
		$mtqy=$this->input->post("mtqy");
		//echo json_encode($resultarray);
		$mty=explode(",",$mtqy);
		//echo json_encode($mty);
		array_pop($mty);
		//$mty=implode(";",)
		//$mqtr=$mty[1];
		//$mtnme=$mty[0];
		$mtyimplode=implode(",",$mty);
		$mtyimplodeex=explode(";",$mtyimplode);
		//echo json_encode($mtyimplodeex);exit;
		$mqtr=$mtyimplodeex[1];
		$mtnme=$mtyimplodeex[0];
		$getpartsdetails=$this->stockManage_model->getpartsdetailsbyprtsid($prtsid);
		foreach($getpartsdetails as $rowprtsdetails)
		{
			$prtsname=$rowprtsdetails->materialname;
			$prtsid=$rowprtsdetails->materiel_id;
			$prtmid=$rowprtsdetails->id;
			$unit=$rowprtsdetails->unit;
			$mnbe=$rowprtsdetails->mName;
		}
		$totqtr=intval($mqtr)*intval($unit);
		//$totqtr="oo";
		//$getpqty=$this->stockManage_model->getpqtybypono($pono,$prtsid);
	 
		//foreach()
		$resultarray=array("partsname"=>"$prtsname","partsid"=>"$prtsid","partmid"=>"$prtmid","unit"=>"$unit","mty"=>"$mtyimplode","rstqty"=>"$totqtr","modelnameprts"=>"$mnbe");
		echo json_encode($resultarray);
		
	}
	public function stockentrycopy()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$user=$this->session->userdata('user_name');
		 $totrow=$this->input->post('totrow');
		$pono=$this->input->post('pono');
		$godown=$this->input->post('godown');
		$boxname=$this->input->post('boxname');
		$boxqty=$this->input->post('nobox');
		$model=$this->input->post("modelname");
		$modelex=explode(";",$model);
		$model1=$modelex[0];
		 $entrp=$this->input->post("entrytp");
		$totrowexplode=explode(",",$totrow);
		//print_r($totrowexplode);
	     $totrwcount=count($totrowexplode);
		$temp_stock=array();
		if($entrp=="box"){
		for($j=0;$j<intval($totrwcount);$j++)
		{
		     $rowid=$totrowexplode[$j];
			$prtsid=$rowid;
			$prtsqty=$this->input->post("tablerow_$prtsid");
			 $unit=$this->input->post("unit2_$prtsid");
			//if(!empty($prtsid) && !empty($prtsqty))
			//{
				
				$stokstring=$prtsid.";".$prtsqty.";".$unit;
				array_push($temp_stock,$stokstring);
			//
			///
			
			//echo $rowid;
		}
		array_pop($temp_stock);
		$temp_stockemplode=implode(",",$temp_stock);
		$data_array=array(
			"pono"=>$pono,
			"modelname"=>$model1,
			"warehouse"=>$godown,
			"boxname"=>$boxname,
			"totalbox"=>$boxqty,
			"stock"=>$temp_stockemplode,
			"doe"=>date('Y-m-d h:i:s'),
			"credtd"=>$user
		
		);
		}
		if($entrp=="indi")
		{
			for($j=0;$j<$totrwcount;$j++)
		{
			 $rowid=$totrowexplode[$j];
			$prtsid=$rowid;
			$prtsqty=$this->input->post("tablerow_$prtsid");
			 $unit=$this->input->post("unit2_$prtsid");
			 $pkg=$this->input->post("pkg2_$prtsid");
			//if(!empty($prtsid) && !empty($prtsqty))
			//{
				
				$stokstring=$prtsid.";".$prtsqty.";".$unit.";".$pkg;
				array_push($temp_stock,$stokstring);
			//
			///
			
			//echo $rowid;
		}
		array_pop($temp_stock);
		$temp_stockemplode=implode(",",$temp_stock);
		$data_array=array(
			"pono"=>$pono,
			"modelname"=>$model1,
			"warehouse"=>$godown,
			"stockindi"=>$temp_stockemplode,
			"doe"=>date('Y-m-d h:i:s'),
			"credtd"=>$user
		
		);
		}
		$this->stockManage_model->savetempdatabystockorder($data_array);
		$data['title']="Stock Entry";
		//$pono=$this->input->post('pono');
		$data['pono']=$pono;
		$data['getpurchaselist']=$this->stockManage_model->getallpurchaselist($pono);
		//print_r($data['getpurchaselist']);
		$deatgetspa=$data['getpurchaselist'];
		$modlar=array();
		foreach($deatgetspa as $rowpurcsdet)
		{
			$model=$rowpurcsdet->modelcode;
			$parts=$rowpurcsdet->spareparts;
		}
		$modelsin=explode(",",$model);
		$count_model=count($modelsin);
		$partsin=explode(",",$parts);
		$count_parts=count($partsin);
		
		for($mk=0;$mk<$count_model;$mk++)
		{
			$modelarr=$modelsin[$mk];
			$modelim=explode(";",$modelarr);
			$modelim=array_filter($modelim);
			if(!empty($modelim)){
			//print_r($modelim);
			$mnam=$modelim[1];
			$mqty=$modelim[2];
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			
			}
			//array_push($modlar,$mnam);
		}
		for($mk=0;$mk<$count_parts;$mk++)
		{
			$partsarr=$partsin[$mk];
			$parts=explode(";",$partsarr);
			$modelim=array_filter($parts);
			if(!empty($modelim)){
			//print_r($modelim);
			$mnam=$modelim[1];
			$mqty=1;
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			
			}
			//array_push($modlar,$mnam);
		}
		//$data['modelname']=$modlar;
		$modlarimplode=implode(",",$modlar);
		$data['modelnamedropdwn']=$modlarimplode;
		$data['godown']=$this->stockManage_model->fetchgodown();
		///print_r($data['modelnamedropdwn']);echo 2;
		//$data['getpurchase']=$this->stockManage_model->getallpurchase();
		$data['temp_data']=$this->stockManage_model->getalldatatemptable($pono);
		$this->load->view('stockmanage/stockentrybox',$data);
		
		//print_r($temp_stock);
	}
	public function stocktempsavedata()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$pono=$this->input->post("pono");//
		$data['getalltemdataprts']=$this->stockManage_model->getalldata($pono);
		foreach($data['getalltemdataprts'] as $row)
		{
			$warehouse=$row->warehouse;
			$temid=$row->id;
			$getwarehouse=$this->stockManage_model->getwarehousename($warehouse);
			$getwarehouseexplode=explode(",",$getwarehouse);
			$gowndnme=$getwarehouseexplode[0];
			$godownid=$getwarehouseexplode[1];
			$model=$row->modelname;
			$boxqty=$row->totalbox;
			$boxstock=$row->stock;
			$boxname=$row->boxname;
			$stockindi=$row->stockindi;
			if(!empty($boxstock) && isset($boxstock))
			{
				$boxstockexplode=explode(",",$boxstock);
				$getboxcode=$this->stockManage_model->getlastboxcode();
				foreach($boxstockexplode as $rowbox)
				{
					$rowboxex=explode(";",$rowbox);
					$modelcode=$rowboxex[0];
					$modelqty=intval($rowboxex[1]);
					$modelspeid=$rowboxex[2];
					$totmodelqty=intval($modelqty)*intval($boxqty);
					$getmodeldtls=$this->stockManage_model->getmoddet($modelcode);
					$getmodeldtlsex=explode(";",$getmodeldtls);
					$mqnty=intval($getmodeldtlsex[0]);
					$mopqnty=intval($getmodeldtlsex[1]);
					//$modelnme=
					$curenqty=intval($mqnty)+intval($totmodelqty);
					$data_array=array(
						"openQnty"=>$mqnty,
						"qnty"=>$curenqty
					);
					print_r($data_array);
					echo 1;
					echo "<br>";
					$this->stockManage_model->updaematerialmaster($data_array,$modelcode);
					$data_arraytrsf=array(
						"date"=>date('Y-m-d'),
						"model_id"=>$model,
						"partsId"=>$modelcode,
						"assignmentno"=>$pono,
						"openingQty"=>$mqnty,
						"newqty"=>$totmodelqty,
						"total"=>$curenqty
					);
					print_r($data_arraytrsf);
					echo 2;
					echo "<br>";
					
					$this->stockManage_model->savetransfer_spareparts($data_arraytrsf);
					$getgodownstock2=$this->stockManage_model->getgodownstockdetails($modelcode,$model,$modelspeid,$godownid);
					if(empty($getgodownstock2)&& isset($getgodownstock2))	
						{
							$data_array_godownnew=array(
							"partsid"=>$modelcode,
							"mnme"=>$model,
							"spefcid"=>$modelspeid,
							"gdownid"=>$godownid,
							"qty"=>$totmodelqty,
							"doe"=>date('Y-m-d'),
							"crted"=>$this->session->userdata('user_name')
						);
						print_r($data_array_godownnew);
						echo 3 ;
					    echo "<br>";
					
						$this->stockManage_model->savegodownstock($data_array_godownnew);
						
						
					
							//$bxqty=$bxqty;
							
						
						
						
						
						//---------------------------------------  end of box stock --------------------------
						
					}else{
						$getgodownstockex=explode(",",$getgodownstock2);
						$getgodownstock=$getgodownstockex[0];
						$godwnstockid=$getgodownstockex[1];
						$gdstockcrnt=intval($getgodownstock)+intval($totmodelqty);
					
						$data_array_godownupdate=array(
					
						"qty"=>$gdstockcrnt,
						"doe"=>date('Y-m-d'),
						"crted"=>$this->session->userdata('user_name')
						);
						print_r($data_array_godownupdate);
						echo 4;
					     echo "<br>";
					
						$this->stockManage_model->updategownstock($data_array_godownupdate,$godwnstockid);
					}
					$dataarray=array(
							"boxname"=>$boxname,
							"boxcode"=>$getboxcode,
							"modelname"=>$model,
							"partsid"=>$modelcode,
							"qty"=>$totmodelqty,
							"boxqty"=>$boxqty,
							"godowncode"=>$godownid,
							"doe"=>date('Y-m-d'),
							"crtd"=>$this->session->userdata('user_name')
							
						);
						print_r($dataarray);
						echo 5;
					    echo "<br>";
					
						$this->stockManage_model->saveboxstock($dataarray);
						
					
				}
			}
           if(isset($stockindi) && !empty($stockindi))
		   {
		   	 $stockexplode=explode(",",$stockindi);
			 foreach($stockexplode as $rowsto)
			 {
			 	 $stockinsert=explode(";",$rowsto);
				 $partcode=$stockinsert[0];
				 $getmodelcode=$this->stockManage_model->getmodelcodebyprt($partcode);
				 $modelspeid=$stockinsert[1];
				 $partsunit=intval($stockinsert[2]);
				 $partsqty=intval($stockinsert[3]);
				 $totmodelqty=intval($partsunit)* intval($partsqty);
				 $getmodeldtls=$this->stockManage_model->getmoddet($partcode);
				 $getmodeldtlsex=explode(";",$getmodeldtls);
				 $mqnty=intval($getmodeldtlsex[0]);
				 $mopqnty=intval($getmodeldtlsex[1]);
				 $getboxcode=$this->stockManage_model->getlastboxcode();
					//$modelnme=
				 $curenqty=intval($mqnty)+intval($totmodelqty);
				$data_array=array(
						"openQnty"=>$mqnty,
						"qnty"=>$curenqty
					);
				$this->stockManage_model->updaematerialmaster($data_array,$partcode);
				$data_arraytrsf=array(
						"date"=>date('Y-m-d'),
						"model_id"=>$getmodelcode,
						"partsId"=>$partcode,
						"assignmentno"=>$pono,
						"openingQty"=>$mqnty,
						"newqty"=>$totmodelqty,
						"total"=>$curenqty
					);	
					//print_r($data_arraytrsf);
					//echo $modelcode.$getmodelcode.$modelspeid.$godownid;
					//exit;
					$this->stockManage_model->savetransfer_spareparts($data_arraytrsf);
					$getgodownstock2=$this->stockManage_model->getgodownstockdetails($partcode,$getmodelcode,$modelspeid,$godownid);
					if(empty($getgodownstock2)&& isset($getgodownstock2))	
						{
							$data_array_godownnew=array(
							"partsid"=>$partcode,
							"mnme"=>$model,
							"spefcid"=>$modelspeid,
							"gdownid"=>$godownid,
							"qty"=>$totmodelqty,
							"doe"=>date('Y-m-d'),
							"crted"=>$this->session->userdata('user_name')
						);
						$this->stockManage_model->savegodownstock($data_array_godownnew);
						
					}else{
						$getgodownstockex=explode(",",$getgodownstock2);
						$getgodownstock=$getgodownstockex[0];
						$godwnstockid=$getgodownstockex[1];
						$gdstockcrnt=intval($getgodownstock)+intval($totmodelqty);
					
						$data_array_godownupdate=array(
					
						"qty"=>$gdstockcrnt,
						"doe"=>date('Y-m-d'),
						"crted"=>$this->session->userdata('user_name')
						);
						$this->stockManage_model->updategownstock($data_array_godownupdate,$godwnstockid);
					}
					$dataarray=array(
							"boxname"=>$boxname,
							"boxcode"=>$getboxcode,
							"modelname"=>$model,
							"partsid"=>$partcode,
							"qty"=>$totmodelqty,
							"boxqty"=>$totmodelqty,
							"godowncode"=>$godownid,
							"doe"=>date('Y-m-d'),
							"crtd"=>$this->session->userdata('user_name')
							
						);
						$this->stockManage_model->saveboxstock($dataarray);
						
			
				 
				 
			 }
			 
		   	
			
		   }
			$this->stockManage_model->update_tem_table($temid);
			
		}
		$this->load->view('stockmanage/viewstockentrylist',$data);
		//print_r($gettemdata);
		//exit;
	
	}
	public function viewallstockentry()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		// $pono=$this->input->post("pono");//
		$data['getalltemdataprtsall']=$this->stockManage_model->getalldatastock();
		$this->load->view('stockmanage/viewstockentrylist',$data);
		
	}
	public function print_pdfstock($pono)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		// $pono=$this->input->post("pono");//
		//$data['getalltemdataprtsall']=$this->stockManage_model->getalldatastock();o
		 $data['pono']=$pono;
		$this->load->view('stockmanage/getpdfviewstock',$data);
		
	}
	public function checkingstock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Checking stockEntry";
		$this->load->view('stockmanage/checkingstock',$data);
	}
	public function checkstocked()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Checking stockEntry";
		$pono=$this->input->post("pono");
		$data['pono']=$pono;
		$data['temp_data']=$this->stockManage_model->getalldata($pono);
		$data['getpurchaselist']=$this->stockManage_model->getallpurchaselist($pono);
		//print_r($data['getpurchaselist']);
		$deatgetspa=$data['getpurchaselist'];
		$modlar=array();
		foreach($deatgetspa as $rowpurcsdet)
		{
			$model=$rowpurcsdet->modelcode;
			$parts=$rowpurcsdet->spareparts;
		}
		$modelsin=explode(",",$model);
		$count_model=count($modelsin);
		$partsin=explode(",",$parts);
		$count_parts=count($partsin);
		for($mk=0;$mk<$count_model;$mk++)
		{
			$modelarr=$modelsin[$mk];
			$modelim=explode(";",$modelarr);
			$modelim=array_filter($modelim);
			if(!empty($modelim)){
			//print_r($modelim);
			$mnam=$modelim[1];
			$mqty=$modelim[2];
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			
			}
			//array_push($modlar,$mnam);
		}
		for($mk=0;$mk<$count_parts;$mk++)
		{
			$partsarr=$partsin[$mk];
			$parts=explode(";",$partsarr);
			$modelim=array_filter($parts);
			if(!empty($modelim)){
			//print_r($modelim);
			$mnam=$modelim[1];
			$mqty=1;
			$mnam=$mnam.";".$mqty;
			if(in_array($mnam,$modlar)){
					
				
			}else{
				array_push($modlar,$mnam);
			}
			
			}
			//array_push($modlar,$mnam);
		}
		 $modlarimplode=implode(",",$modlar);
		$data['modelname2']=$modlarimplode;
		//print_r($data['modelname2']);
		$this->load->view('stockmanage/checkingstock',$data);
	}
	/*public function purchaseorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		//print_r($data['box']);
		$this->load->view("stockmanage/purchaseorder",$data);
	}
	public function savetemporder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Order";
		$model=$this->input->post("modelname");
		$qty=$this->input->post("qty");
		$getallparts=$this->stockManage_model->getallspareparts2($model);
		$gettemorderid=$this->stockManage_model->getlasttemorderid();
		if(empty($gettemorderid))
		{
			$tempoid=1;
		}else{
			$tempoid=intval($gettemorderid)+1;
		}
		
		foreach($getallparts as $row)
		{
			$partscode=$row->materiel_id;
			$partsname=$row->materialname;
			$unit=$row->unit;
			$totunit=intval($unit)*intval($qty);
			
			$data_array=array(
			    "temporderid"=>$tempoid,
				"modelname"=>$model,
				"qty"=>$qty,
				"partsname"=>$partsname,
				"prtsqty"=>$totunit,
				"prtscode"=>$partscode,
				"doe"=>date('Y-m-d h:i:s A'),
				"doe2"=>date('Y-m-d'),
				"crdtby"=>$this->session->userdata('user_name')
				
			);
			$this->stockManage_model->savemodelsorder($data_array);
			
		}
		//$data_array=array(
		$data['getalltempdataid']=$this->stockManage_model->getalltemporderdata($model,$qty,$tempoid);
		//);
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		$data['model1']=$model;
		$data['qty2']=$qty;
		//print_r($data['box']);
		$this->load->view("stockmanage/purchaseorder",$data);
	}*/
	//////////////////////////////////////////////  by abhishek/////////////////////////
	public function purchaseorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		
		$ordercode=$this->stockManage_model->getOrderCode();
		if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}
		
		$data['godown']=$this->stockManage_model->fetchgodown();
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		//$data['stockmodel']=//
		//print_r($data['box']);
		//$data['temp_data']=$this->stockManage_model->getallpono();
		$this->load->view("stockmanage/purchaseorder",$data);
	}
	public function purchaseorder_new()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		
		
		$ordercode=$this->stockManage_model->getOrderCode();
		if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}
		
		$data['godown']=$this->stockManage_model->fetchgodown();
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		//$data['stockmodel']=//
		//print_r($data['box']);
		//$data['temp_data']=$this->stockManage_model->getallpono();
		$this->load->view("stockmanage/purchaseorder_new",$data);
	}
	public function savedata()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$ordercode=$this->stockManage_model->getOrderCode();
		if(empty($ordercode))
		{
			$invID="1";
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}else{
			foreach($ordercode as $row)
			{
				$id=$row->id;
			}
			$invID=$id+1;
			$data['ordercodes']="GKORD/".date('y')."-".(date('y')+1)."/".$invID;
		}
		$orderno=$this->input->post("orderno");
		$model=$this->input->post("model");
		$transfer=$this->input->post("transfer");
		$godown=$this->input->post("godown");
		$trackno=$this->input->post("trackno");
		$partiname=$this->input->post("partyname");
		$custcode=$this->input->post("partycode");
		$balance=$this->input->post("balance");
		//$drivername=$this->input->post("drivername");
		
		$drivercontact=$this->input->post("drivercontact");
		$data['modelnme']=$model;
		$data['ordernme']=$orderno;
		$data['transfr']=$transfer;
		$data['godwn']=$godown;
		$data['trackno']=$trackno;
		$data['partyname']=$partiname;
		$data['partycode']=$custcode;
		$data['balance']=$balance;
		
		//$data['drivername']=$drivername;
		$data['drivercontact']=$drivercontact;
		$data_array=array(
			'Order_Code'=>$orderno,
			'modelName'=>$model,
			'transfer_Type'=>$transfer,
			'godown'=>$godown
		);
		//print_r($data_array);
		//$checkdataex=$this->stockManage_model->save_data($data_array);
		$data['getpareparts']=$this->stockManage_model->getsparepartsbymodel($model);
		$data['godown']=$this->stockManage_model->fetchgodown();
		//$data['ordercodes']=$orderno;
		$data['title']="Order";
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		$data['stockmodel']=$this->stockManage_model->getstockmodeldis($godown);
		if(isset($godown) && !empty($godown) && empty($model))
		{
			
			$data['temp_data']=$this->stockManage_model->getallpono_godown($godown);
		}
		if(isset($godown)&& !empty($godown) && isset($model) && !empty($model))
		{
			
			$data['temp_data']=$this->stockManage_model->getallpono_godownmodel($godown,$model);
		}
		
		$this->load->view("stockmanage/purchaseorder_new",$data);
		//redirect("stockManage_controller/purchaseorder",'refresh');
	}
	public function savetemporder()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Order";
		$model=$this->input->post("modelname");
		$qty=$this->input->post("qty");
		$getallparts=$this->stockManage_model->getallspareparts2($model);
		$gettemorderid=$this->stockManage_model->getlasttemorderid();
		if(empty($gettemorderid))
		{
			$tempoid=1;
		}else{
			$tempoid=intval($gettemorderid)+1;
		}
		
		foreach($getallparts as $row)
		{
			$partscode=$row->materiel_id;
			$partsname=$row->materialname;
			$unit=$row->unit;
			$totunit=intval($unit)*intval($qty);
			
			$data_array=array(
			    "temporderid"=>$tempoid,
				"modelname"=>$model,
				"qty"=>$qty,
				"partsname"=>$partsname,
				"prtsqty"=>$totunit,
				"prtscode"=>$partscode,
				"doe"=>date('Y-m-d h:i:s A'),
				"doe2"=>date('Y-m-d'),
				"crdtby"=>$this->session->userdata('user_name')
				
			);
			$this->stockManage_model->savemodelsorder($data_array);
			
		}
		//$data_array=array(
		$data['getalltempdataid']=$this->stockManage_model->getalltemporderdata($model,$qty,$tempoid);
		//);
		$data['model']=$this->stockManage_model->getmodel();
		$data['spareparts']=$this->stockManage_model->getspareparts();
		$data['box']=$this->stockManage_model->getboxwisestock();
		$data['model1']=$model;
		$data['qty2']=$qty;
		//print_r($data['box']);
		$this->load->view("stockmanage/purchaseorder",$data);
	}
///////////////////////////////  end of by abhishek/////////////////////////////////////////////
	public function viewallstock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="View Stock";
		//$model=$this->input->post("modelname");
		$data['model']=$this->stockManage_model->getmodel();
		$data['parts']=$this->stockManage_model->getspareparts();
		$data['downstock']=$this->stockManage_model->getgodownstock();
		$data['specistock']=$this->stockManage_model->getspecfstock();
		$data['getalldata']=$this->stockManage_model->getallstockdata();
		$this->load->view("stockmanage/viewallstock",$data);
		
	}
	public function getstocklist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$warehouse=$this->input->post("godown");
		$model=$this->input->post("model");
		$parts=$this->input->post('parts');
		$specification=$this->input->post("specf");
	
		if(isset($warehouse) && empty($model) && empty($parts) && empty($specification))
		{
			$data['stock']=$this->stockManage_model->getalldatastockgodown($warehouse);
		}
		if(isset($model) && empty($warehouse) && empty($parts) && empty($specification))
		{
			$data['modeldata']=$this->stockManage_model->getallmodeldata($model);
		}
		if(isset($model) && isset($warehouse) && empty($parts) && empty($specification))
		{
			$data['modelwrehsedata']=$this->stockManage_model->getallmodelwrsedata($model,$warehouse);
		}
		if(isset($model) && isset($parts) && empty($warehouse) && empty($specification))
		{
			$data['prtsnowrsehse']=$this->stockManage_model->getallprtsnowrhse($model,$parts);
		}
		if(isset($model) && isset($parts) && isset($warehouse) && empty($specification))
		{
			$data['prtsyswrsehse']=$this->stockManage_model->getallprtsyswrhse($model,$parts,$warehouse);
		}
		if(isset($model) && isset($parts) && isset($specification) && empty($warehouse))
		{
			$data['getspef1']=$this->stockManage_model->getallspecifiprtsnowrs($model,$parts,$specification);
		}
		if(isset($model) && isset($parts) && isset($specification) && isset($warehouse))
		{
			$data['getspef2']=$this->stockManage_model->getallspecifiprtsnowrs2($model,$parts,$specification,$warehouse);
		}
		$data['model']=$this->stockManage_model->getmodel();
		//$data['parts']=$this->stockManage_model->getspareparts();
		$data['downstock']=$this->stockManage_model->getgodownstock();
		//$data['specistock']=$this->stockManage_model->getspecfstock();
		$data['model2']=$model;
		$data['godown2']=$warehouse;
		$data['title']="View stock";
		$this->load->view("stockmanage/viewallstock",$data);
	}
	public function getallspareparts()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$mname=$this->input->post("mname");
		$getallspareparts=$this->stockManage_model->getallsparepartsstock($mname);
		echo "<option value=''>&nbsp;</option>";
		foreach($getallspareparts as $row)
		{
			echo "<option value='".$row->id."'>".$row->materialname."</option>";
		}
		
	}
	public function getspecification()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$spareparts=$this->input->post("spareparts");
		$getspecification=$this->stockManage_model->getallspecification($spareparts);
		echo "<option value=''>&nbsp;</option>";
		foreach($getspecification as $row)
		{
			echo "<option value='".$row->id."'>".$row->specification."</option>";
		}
	}
	public function getallgetpass()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$ordername=$this->input->post("ordername");
		$modelnme=$this->input->post("modelnme");
		$transfertp=$this->input->post("transfertp");
		$warehouse=$this->input->post("warehouse");
	    $pocount=$this->input->post('ponocount');
		$trackno=$this->input->post("trackno");
		$partyname=$this->input->post("partyname");
		$drivername=$this->input->post("drivername");
		$drivercontact=$this->input->post("drivercontact");
		$boxcount=$this->input->post("boxcount");
		$boxprtscount=$this->input->post("boxprts");
		$indiprts=$this->input->post("indiprts");
		$boxname1="";$boxqty1="";
		for($po=1;$po<=intval($pocount);$po++)
		{
			
		      $pono=$this->input->post("pono_$po");//echo "&nbsp;&nbsp;";
			 $totporow=$this->input->post("totporow_$po");
			//echo "<br>"; 
			// echo $po;
			 for($totr=1;$totr<intval($totporow);$totr++)
			 {
			 	 $totr;
				//echo "<br>====";
			 	 $bx="boxnme_".$po."_".$totr;
				// "<br>";
			 	$crt="currentbx_".$po."_".$totr;
				$prts="boxprtsname_".$po."_".$totr;
				$prtsq="boxprtsqty_".$po."_".$totr;
			 	$boxname=$this->input->post($bx);
				
				if($boxname==$boxname1){
					$boxqty=$boxqty1;
					
				}else{
					$boxqty=$this->input->post($crt);
				}
				
				  $prtsid=$this->input->post($prts);
				 $prtsqty=$this->input->post($prtsq);
				//echo "+++++++++++++++++";	
//////////////////////////individual parts--------------
				$indiprts1="partsini_".$po."_".$totr;
				$indiprtsqty1="indiprtsqty_".$po."_".$totr;
                $indiprts=$this->input->post($indiprts1); 
                $indiprtsqty=$this->input->post($indiprtsqty1);
                 //echo "+++++++++++++++++";
			 // echo "<br>";
				if(isset($prtsqty) && !empty($prtsqty) && isset($prtsid) && !empty($prtsid)&& intval($prtsqty)>0)
				{
					
					//echo $boxname.$boxqty.$prtsid.$prtsqty;
							$getmodel=$this->stockManage_model->getmodelname($prtsid);
							$data_array=array(
							    "trackno"=>$trackno,
							    "trackcontact"=>$drivercontact,
							    "driver"=>$drivername,
							    "partyname"=>$partyname,
								"orderno"=>$ordername,
								"model"=>$getmodel,
								"pono"=>$pono,
								"trnstype"=>$transfertp,
								"boxno"=>$boxname,
								"boxqty"=>$boxqty,
								"partsid"=>$prtsid,
								"partsqty"=>$prtsqty,
								"tot"=>$prtsqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							//print_r($data_array);
						//echo "<br>";
							$this->stockManage_model->saveorderdategetpass($data_array);
					
				}
				if(isset($indiprtsqty) && !empty($indiprtsqty))
				{
							$getmodel=$this->stockManage_model->getmodelname($indiprts);
							$data_array=array(
							    "trackno"=>$trackno,
							    "trackcontact"=>$drivercontact,
							    "driver"=>$drivername,
							    "partyname"=>$partyname,
								"orderno"=>$ordername,
								"model"=>$getmodel,
								"pono"=>$pono,
								"trnstype"=>$transfertp,
								"partsid"=>$indiprts,
								"partsqty"=>$indiprtsqty,
								"tot"=>$indiprtsqty,
								"doe"=>date('Y-m-d h:i:s A'),
								"crtd"=>$this->session->userdata('user_name')
							
							);
							//print_r($data_array);
							//echo "<br>";
						$this->stockManage_model->saveorderdategetpass($data_array);
				}
				$boxname1=$boxname;
				$boxqty1=$boxqty;
			 }
			 
			
			
		}
      
					$data['title']="View Order";
					$data['allorder']=$this->stockManage_model->getallorderlist();
					//print_r($data['allorder']);
					$this->load->view("stockmanage/vieworder",$data);
		
		
	}
	public function viewallorderlist()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="View Order";
		$data['allorder']=$this->stockManage_model->getallorderlist();
		//print_r($data['allorder']);
		$this->load->view("stockmanage/vieworder",$data);
	}
	public function print_getpass($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="View Order";
		$oid=$id;
		$data['print_getpass']=$this->stockManage_model->getallorderlistindi($oid);
	     // print_r($data['print_getpass']);
		//$data['oid']=$oid;
		//$this->load->view("stockmanage/print_getpass",$data);
		//$getalldetails=
		foreach($data['print_getpass'] as $row)
		{
			$orderno=$row->orderno;
			$trackn=$row->trackno;
			$trnf=$row->trnstype;
			$driv=$row->driver;
			$trackcontact=$row->trackcontact;
			$partyname=$row->partyname;
		}
		//$getbuyercode=$this->stockManage_model->getallpatycode($partyname);
		//$getbuyercodeex=explode(",",$getbuyercode);
		//$buycode=$getbuyercodeex[0];
		//$buyermail=$getbuyercodeex[1];
		$buycode="";
		$text1="Dear Sir,";
		$text2="Please send us the required quotation for the given list of products";
		$text="     For GATEPASS Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		//$this->fpdf->Ln($y);
		//$this->fpdf->Ln(30);
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Text($x+80,$y+50,"GATEPASS");	
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		
		$this->fpdf->ln(55);
		$this->fpdf->SetFont('Arial','',10);
		
		$this->fpdf->multicell(190,5,"$text");
		$this->fpdf->ln(10);
		$this->fpdf->cell(10);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(40,10,"ORDER NO",0,0,'L');
		$this->fpdf->cell(40,10,": $orderno",0,0,'L');
		$this->fpdf->cell(45,10,"TRANSFER TYPE",0,0,'L');
		$this->fpdf->cell(45,10,": $trnf",0,1,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(40,10,"BUYER'S CODE",0,0,'L');
		$this->fpdf->cell(40,10,": $buycode",0,1,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(40,10,"BUYER'S NAME",0,0,'L');
		$this->fpdf->cell(80,10,": $partyname",0,1,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(40,10,"VEHICLE NO",0,0,'L');
		$this->fpdf->cell(40,10,": $trackn",0,0,'L');
		
		$this->fpdf->cell(45,10,"DRIVER NO",0,0,'L');
		$this->fpdf->cell(45,10,": $trackcontact",0,1,'L');
		$this->fpdf->ln(30);
		//$this->fpdf->cell(10);
		//$this->fpdf->cell(90,5,"Date",0,1,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(90,5,"----------------------------------------------",0,0,'L');
		$this->fpdf->cell(90,5,"----------------------------------------------",0,1,'R');
		//$this->fpdf->ln(5);
		$this->fpdf->cell(10);
		$this->fpdf->cell(80,5,"Signature",0,0,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(90,5,"Date",0,1,'C');
		
		
		 $this->fpdf->Output();
	}
	public function checkinggetpass()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Checking Gatepass";
		$this->load->view("stockmanage/checkinggetpass",$data);
		
	}
	public function getalldetailsbyorderid()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Checking Gatepass";
		$orderid=$this->input->post("orderid");
		$data['orderid']=$orderid;
		$data['getallorderdetails']=$this->stockManage_model->getallorderdetails($orderid);
		$this->load->view("stockmanage/checkinggetpass",$data);
	}
  public function getorderfinalprint()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="Print Order";
		$ord=$this->input->post("ord");
	    $submit=$this->input->post("print");
		//$data['oid']=$ord;
		//$this->load->view("stockmanage/printgetpassorderlist",$data);getpdfviewstock.php
		//$this->load->view("stockmanage/getpdfviewstock",$data);
		if($submit=="print"){
		$datalall=$this->stockManage_model->getallorderdetails($ord);
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Cell(190,10,"",0,0,'C');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->ln(5);
		$this->fpdf->cell(190,10,"ORDER NO: $ord",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(190,10,"TRUCK NO:",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(190,10,"DRIVER NAME:",0,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->cell(190,10,"CONTACT NO:",0,0,'C');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(190,5,"DETAILS ORDER LIST",0,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->setFillColor(0,102,0);
		$this->fpdf->setTextColor(255,255,255);
		$this->fpdf->cell(15,7,"Slno",1,0,'C',TRUE);
		$this->fpdf->cell(35,7,"Box No",1,0,'C',TRUE);
		$this->fpdf->cell(60,7,"Name",1,0,'C',TRUE);
		$this->fpdf->cell(20,7,"Qty",1,0,'C',TRUE);
		//$this->fpdf->cell(15,7,"Unit",1,0,'C',TRUE);
		$this->fpdf->cell(25,7,"PKG",1,0,'C',TRUE);
		
		$this->fpdf->cell(12,7,"CHK1",1,0,'C',TRUE);
		$this->fpdf->cell(12,7,"CHK2",1,0,'C',TRUE);
		$this->fpdf->cell(10,7,"",1,1,'C',TRUE);
		$this->fpdf->setTextColor(0,0,0);
		$k=1;
		$boxno1="";$boxqty1="";$boxno2="";
		foreach($datalall as $row)
		{
			$boxno=$row->boxno;
			$boxqty=$row->boxqty;
			$partsid=$row->partsid;
			$partsqty=$row->tot;
			$getprtsname=$this->stockManage_model->getprtsnamebyprtid($partsid);
			$this->fpdf->setTextColor(0,0,0);
				/*$this->fpdf->cell(15,7,"$k",1,0,'C');
				$this->fpdf->cell(35,7,"$boxno",'LTR',0,'C',0);//$this->fpdf->Cell(15,7,' ','LTR',0,'L',0);
				$this->fpdf->cell(60,7,"",1,0,'C');
				$this->fpdf->cell(20,7,"",1,0,'C');
				//$this->fpdf->cell(15,7,"Unit",1,0,'C',TRUE);
				$this->fpdf->cell(25,7,"$boxqty",1,0,'C');
				$x=$this->fpdf->getX();
				$y=$this->fpdf->getY();
				$this->fpdf->cell(12,7,"",1,0,'C');
				$x=$this->fpdf->getX();
				$y=$this->fpdf->getY();
				$this->fpdf->cell(12,7,"",1,0,'C');
				$this->fpdf->cell(10,7,"",1,1,'C');
				$boxno1=$boxno;
				//$k++;
			//}else{*/
			$this->fpdf->cell(15,7,"$k",1,0,'C');
			if(!empty($boxno) && ($boxno!=$boxno1)){
				$this->fpdf->cell(35,7,"$boxno",'LTR',0,'C',0);
				$boxno1=$boxno;
			}else{
				if(!empty($boxno))
				{
					$this->fpdf->cell(35,7,"",0,0,'C');
				}else
					{
					 $this->fpdf->cell(35,7,"",1,0,'C');
					}
				
			}
			
			$this->fpdf->cell(60,7,"$getprtsname",1,0,'C');
			$this->fpdf->cell(20,7,"$partsqty",1,0,'C');
			//$this->fpdf->cell(15,7,"Unit",1,0,'C',TRUE);
			if(!empty($boxqty) &&($boxno!=$boxno2) ){
				$this->fpdf->cell(25,7,"$boxqty",'LTR',0,'C',0);
				$boxqty1=$boxqty;
				$boxno2=$boxno;
			}else{
				if(!empty($boxqty))
				{
					$this->fpdf->cell(25,7,"",0,0,'C');
				}else
					{
					 $this->fpdf->cell(25,7,"$partsqty",1,0,'C');
					}
				
			}
			//$this->fpdf->cell(25,7,"",1,0,'C');
			$x=$this->fpdf->getX();
			$y=$this->fpdf->getY();
			$this->fpdf->cell(12,7,$this->fpdf->Rect($x+2,$y+1,5,5),1,0,'C');
			$x=$this->fpdf->getX();
			$y=$this->fpdf->getY();
			$this->fpdf->cell(12,7,$this->fpdf->Rect($x+2,$y+1,5,5),1,0,'C');
			$this->fpdf->cell(10,7,"",1,1,'C');
			$k++;
			//$boxno2=$boxno;
			//}
		//$k++;
		}
      $this->fpdf->cell(110,7,"Total",1,0,'C');
	   $this->fpdf->cell(20,7,"",1,0,'C');
	   $this->fpdf->cell(25,7,"",1,0,'C');
	   $this->fpdf->cell(12,7,"",1,0,'C');
	   $this->fpdf->cell(12,7,"",1,0,'C');
	   $this->fpdf->cell(10,7,"",1,1,'C');
		$this->fpdf->Output();
		
		}
   if($submit=="printgetpass")
   {
   		$data['print_getpass']=$this->stockManage_model->getallorderlist($ord);
		//print_r($data['allorder']);
		//$data['oid']=$oid;
		//$this->load->view("stockmanage/print_getpass",$data);
		//$getalldetails=
		foreach($data['print_getpass'] as $row)
		{
			$orderno=$row->orderno;
			$trackn=$row->trackno;
			$trnf=$row->trnstype;
			$driv=$row->driver;
			$trackcontact=$row->trackcontact;
			$partyname=$row->partyname;
		}
		$getbuyercode=$this->stockManage_model->getallpatycode($partyname);
		$getbuyercodeex=explode(",",$getbuyercode);
		$buycode=$getbuyercodeex[0];
		$buyermail=$getbuyercodeex[1];
		$text1="Dear Sir,";
		$text2="Please send us the required quotation for the given list of products";
		$text="     For GATEPASS Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="login_assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		//$this->fpdf->Ln($y);
		//$this->fpdf->Ln(30);
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Text($x+80,$y+50,"GATEPASS OUT");	
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		
		$this->fpdf->ln(55);
		$this->fpdf->SetFont('Arial','',10);
		
		$this->fpdf->multicell(190,5,"$text");
		$this->fpdf->ln(10);
		$this->fpdf->cell(10);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(40,10,"ORDER NO",0,0,'L');
		$this->fpdf->cell(40,10,": $orderno",0,0,'L');
		$this->fpdf->cell(45,10,"TRANSFER TYPE",0,0,'L');
		$this->fpdf->cell(45,10,": $trnf",0,1,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(40,10,"BUYER'S CODE",0,0,'L');
		$this->fpdf->cell(40,10,": $buycode",0,1,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(40,10,"BUYER'S NAME",0,0,'L');
		$this->fpdf->cell(80,10,": $partyname",0,1,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(40,10,"VEHICLE NO",0,0,'L');
		$this->fpdf->cell(40,10,": $trackn",0,0,'L');
		
		$this->fpdf->cell(45,10,"DRIVER NO",0,0,'L');
		$this->fpdf->cell(45,10,": $trackcontact",0,1,'L');
		$this->fpdf->ln(30);
		//$this->fpdf->cell(10);
		//$this->fpdf->cell(90,5,"Date",0,1,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(90,5,"----------------------------------------------",0,0,'L');
		$this->fpdf->cell(90,5,"----------------------------------------------",0,1,'R');
		//$this->fpdf->ln(5);
		$this->fpdf->cell(10);
		$this->fpdf->cell(80,5,"Signature",0,0,'L');
		$this->fpdf->cell(10);
		$this->fpdf->cell(90,5,"Date",0,1,'C');
		
		
		 $this->fpdf->Output();
   }
		
  }
  public function savestocklist()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Print Order";
	$oid=$this->input->post('oid');
	$data_array=array(
		"Order_Code"=>$oid
	);
	$this->stockManage_model->saveoidlast($data_array);
		
  }
  public function getpartycode()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$gettrst=$this->input->post("gettrst");
		$getresult=$this->stockManage_model->getpartylist();
		/*foreach($getresult as $row)
		{
			
		}*/
		echo '<select id="partycode" name="partycode" class="form-control" onchange="getbalance()">';
		echo '<option value="">select customer code</option>';
		foreach($getresult as $row){
	    		echo '<option value="'.$row->clientid.' "> '.$row->clientid.'</option>';
		}
		echo '</select>';
		//echo '<label for="godown">CUSTOMER CODE</label>';
  }
  public function getclientdetails()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$particode=$this->input->post("prticode");
		$getresult=$this->stockManage_model->getpartydetails($particode);
  	   foreach($getresult as $row)
	   {
	   	  $cilentname=$row->compname;
		  $balance=$row->balance;
	   }
	   $result=array("clientname"=>"$cilentname","balance"=>"$balance");
	   echo json_encode($result);
  }
  public function savefinalgetpass()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
    $orderid=$this->input->post("ordid");
	$prtsqty=$this->input->post("prtsq");
	$shortage=$this->input->post("shortage");
	echo $tot=intval($prtsqty)-intval($shortage);
	$data['editsave']=$this->stockManage_model->saveedit($orderid,$shortage,$tot);
	
  
  }
//=================================  update on 271222016   ============================================
  public function stockpreentry()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	$data['warehouse']=$this->stockManage_model->getwarehouse();
	$data['model']=$this->stockManage_model->getallmodel();
	$this->load->view('stockmanage/stockentr',$data);
  }
  public function getallsparepartsbymoel()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	$model=$this->input->post("mName");
	$warehouse=$this->input->post("wareh");
	$data['wrh']=$warehouse;
	$data['modelname']=$model;
	$data['wrehseid']=$this->stockManage_model->getwrehseid($warehouse);
	$data['warehouse']=$this->stockManage_model->getwarehouse();
	
	$data['model']=$this->stockManage_model->getallmodel();
	$data['alcommonparts']=$this->stockManage_model->getallpartsbymodel($model);
	$this->load->view('stockmanage/stockentr',$data);
  }
  public function savestocknorml()
  {
  	$this->authentication->is_loggedin($this->session->userdata('user_name'));
	$data['title']="Dashboard";
	date_default_timezone_set("Asia/Kolkata");
	echo $wrehousecode=$this->input->post("wrehousecode");
   echo $rowcon=intval($this->input->post("rowcoun"));
   exit;
	for($i=1;$i<$rowcon;$i++)
	{
		 $model=$this->input->post("model_$i");
		 $matid=$this->input->post("matid_$i");
		$speficrow=intval($this->input->post("sperow_$i"));
		if($speficrow>1)
		{
			//echo "hello";
			$totstock=0;
			$specfdt=array();
			for($sp=1;$sp<$speficrow;$sp++)
			{
				$specfid=$this->input->post("specifid_".$i."_".$sp);
				$partscode=$matid;
				$modelname=$model;
				$gdwncode=$wrehousecode;
				$qty=intval($this->input->post("specf_".$i."_".$sp));
			
				if(isset($qty) && !empty($qty))
				{
					//transaction table  insert
					$specdt="$specfid;$qty";
					array_push($specfdt,$specdt);
					 $qtystock=$qty;
					$chechkgdstockexist=$this->stockManage_model->checkstockgdexist($specfid,$gdwncode,$modelname,$partscode);
					if(!empty($chechkgdstockexist))
					{
						//update godown stock 
						foreach($chechkgdstockexist as $gdrow){ $gdqty=intval($gdrow->qty);}
						$openqty=intval($gdqty);
						$cloststock=intval($qty);
						$gstock=intval($openqty)+intval($cloststock);
						$dataaray=array(
							"openqty"=>$openqty,
							"closestock"=>$cloststock,
							"qty"=>$gstock,
							"doe"=>date('Y-m-d'),
							"crted"=>$this->session->userdata('user_name')
						);
						//print_r($dataaray);
						//echo "1<br>";
						$this->stockManage_model->updategdstockbyspecification($dataaray,$specfid,$gdwncode,$modelname,$partscode);
						
						
						
						    
					}else{
						
						//insert  godown stock
						$datainsert=array(
							"partsid"=>$partscode,
							"mnme"=>$modelname,
							"spefcid"=>$specfid,
							"gdownid"=>$gdwncode,
							"openqty"=>0,
							"closestock"=>$qty,
							"qty"=>$qty,
							"doe"=>date('Y-m-d'),
							"crted"=>$this->session->userdata('user_name')
						
						);
						//print_r($datainsert);
						//echo "2<br>";
						$this->stockManage_model->savegdstck($datainsert);
						
					}
				}else{
					$qtystock=0;
				}
				$totstock=intval($totstock)+intval($qtystock);
				
			}
            //###########################   mastyer table stock update  ##################### 
				$specfdtimplode=implode(",",$specfdt);
				$getcurrenstockbymodel=$this->stockManage_model->getcrntstockbymodel($matid);
				if(!empty($getcurrenstockbymodel))
				{
					foreach($getcurrenstockbymodel as $rowstvkmodel)
					{
						$qnty=intval($rowstvkmodel->qnty);
						
					}
					$openqty=intval($qnty);
					$qnt=intval($totstock)+intval($openqty);
					$datamstoc=array(
						"qnty"=>$qnt,
						"openQnty"=>$openqty,
						"lastupdt"=>date('Y-m-d h:i:s A'),
						"crtd"=>$this->session->userdata('user_name')
					);
					//print_r($datamstoc);
					//echo "3<br>";
					$this->stockManage_model->updatestockparts($datamstoc,$matid);
				}
				if($totstock>0){
				$data_trans=array(
					"date"=>date('Y-m-d'),
					"model_id"=>$model,
					"partsId"=>$matid,
					"specifqty"=>$specfdtimplode,
					"openingQty"=>$openqty,
					"newQty"=>$totstock,
					"total"=>$qnt,
					"crtd"=>$this->session->userdata('user_name'),
					"lstupdt"=>date('Y-m-d h:i:s A'),
					
				);
				//print_r($data_trans);
				//echo "4<br>";
				$this->stockManage_model->savetransdata($data_trans);
			}
			
		}else{
			//echo "hello2";
			//$totstock=0;
			$partscode=$matid;
		    $modelname=$model;
			$gdwncode=$wrehousecode;
			//$openstockwrehouse=$this->input->post("openstockwrehouse_$i");
			$currentwrehouse=intval($this->input->post("currentwrehouse_$i"));
			$chechkgdstockexist2=$this->stockManage_model->checkstockgdexist2($gdwncode,$modelname,$partscode);
			//print_r($chechkgdstockexist2);
			if(!empty($chechkgdstockexist2) && isset($chechkgdstockexist2))
			{
				foreach($chechkgdstockexist2 as $gdrow){ $gdqty=intval($gdrow->qty);}
				$openqty=intval($gdqty);
				$cloststock=intval($currentwrehouse);
				$gstock=intval($openqty)+intval($cloststock);
				$dataupdt=array(
					"openqty"=>$openqty,
					"closestock"=>$cloststock,
					"qty"=>$gstock,
					"doe"=>date('Y-m-d'),
					"crted"=>$this->session->userdata('user_name')
				);
				//print_r($dataupdt);
				//echo "5<br>";
				$this->stockManage_model->updategdstockbyspecification2($dataupdt,$gdwncode,$modelname,$partscode);
			}else{
				$datainsert2=array(
					"partsid"=>$partscode,
					"mnme"=>$modelname,
					"gdownid"=>$gdwncode,
					"openqty"=>0,
					"closestock"=>$currentwrehouse,
					"qty"=>$currentwrehouse,
					"doe"=>date('Y-m-d'),
					"crted"=>$this->session->userdata('user_name')
						
				);
				//print_r($datainsert2);;
				//echo "6<br>";
				$this->stockManage_model->savegdstck($datainsert2);
				
				
			}
			//###########################   mastyer table stock update  ##################### 
			$getcurrenstockbymodel=$this->stockManage_model->getcrntstockbymodel($matid);
				if(!empty($getcurrenstockbymodel))
				{
					foreach($getcurrenstockbymodel as $rowstvkmodel)
					{
						$qnty=intval($rowstvkmodel->qnty);
						
					}
					$openqty=intval($qnty);
					$qnt=intval($currentwrehouse)+intval($openqty);
					$datamstoc=array(
						"qnty"=>$qnt,
						"openQnty"=>$openqty,
						"lastupdt"=>date('Y-m-d h:i:s A'),
						"crtd"=>$this->session->userdata('user_name')
					);
					//print_r($datamstoc);
					//echo "7<br>";
					$this->stockManage_model->updatestockparts($datamstoc,$matid);
				}
				if(isset($currentwrehouse) && !empty($currentwrehouse)){
				$data_trans=array(
					"date"=>date('Y-m-d'),
					"model_id"=>$model,
					"partsId"=>$matid,
					"openingQty"=>$openqty,
					"newQty"=>$currentwrehouse,
					"total"=>$qnt,
					"crtd"=>$this->session->userdata('user_name'),
					"lstupdt"=>date('Y-m-d h:i:s A'),
					
				);
				//print_r($data_trans);
				//echo "8<br>";
				$this->stockManage_model->savetransdata($data_trans);
				
				}
			
		}
		
	}
  redirect('StockManage_controller/viewallstock','refresh');
  }
//#########################################  UPdate on 29122016  ###################################
  public function viewmodelstock()
  {
  		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['model']=$this->stockManage_model->getallmodel();
	    foreach($data['model'] as $row)
	    {
	    	$modelnm=$row->productname;
	    	$data['getprts']=$this->stockManage_model->getallprts($modelnm);
			$numparts=$this->stockManage_model->getnoparts($modelnm);
			//echo "<br>==<br>";
			$i=0;
			$mnqty2=0;
			foreach($data['getprts'] as $row2)
			{
				$unit=intval($row2->unit);
				$qnty=intval($row2->qnty);
				$mnqty=$qnty/$unit;
				
					if(($mnqty==$mnqty2))
					{
						
							$i++;
						
						
					}
					$mnqty2=$mnqty;
				
				
			}
			if($i==$numparts)
			{
				//echo $i;
			}else {
				
				//echo $i;
				
				
			}
			echo $i;
			//echo "<br>==<br>";
	    }
		
  }
//############################3  update 07012017##########################3
	public function bxwsestock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['model']=$this->stockManage_model->getallmodel();
		$data['wrehouse']=$this->stockManage_model->getalwarehouse();
		$this->load->view('stockmanage/bxwsstckentry',$data);
		
	}
	public function getallpartsname()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$model=$this->input->post("model");
		$warehouse=$this->input->post("warehouse");
		$getwarehousecode=$this->stockManage_model->getwarehousecode($warehouse);
		$getallparts=$this->stockManage_model->getallparts($model);
		if(!empty($getallparts) && isset($getallparts))
		{
			echo '<div class="col-md-12" style="overflow-y:scroll;"><ul class="list divider-full-bleed">';
			$k=1;
			foreach($getallparts as $row)
			{
				$partsid=$row->id;
				echo '<li class="tile"><a id="" href="" data-toggle="modal" data-target="#simpleModal_'.$k.'">
					     	<div class="tile-content">
										<div class="tile-icon">
											<i class="fa fa-arrows" aria-hidden="true"></i>
										</div>
										<div class="tile-text">'.$row->materialname.'</div>
							</div>
					     	
					     	
								
							  </a>
							  <div class="modal fade" id="simpleModal_'.$k.'" role="dialog">
							    <div class="modal-dialog modal-md">
							      <div class="modal-content">
							        <div class="modal-header">
							          <button type="button" class="close" data-dismiss="modal">&times;</button>
							          <h4 class="modal-title">'.$row->materialname.'</h4>
							        </div>
							        <div class="modal-body">
							        <div class="row">
							          <div class="col-md-6">
							          	<div class="form-group">
							          	  <h4><b>Enter Qty</b></h4>
							          	</div>
							          </div>
							          <div class="col-md-6">
							          	<div class="form-group">
							          	  <input type="text" class="form-control" id="partsqty_'.$k.'"/>
							          	  <input type="hidden" name="modelname_'.$k.'" id="modelname_'.$k.'" value="'.$row->mName.'" />
							          	  <input type="hidden"  name="partsname_'.$k.'" id="partsname_'.$k.'" value="'.$row->materialname.'" />
							          	  <input type="hidden" name="warehouse_'.$k.'" id="warehouse_'.$k.'" value="'.$getwarehousecode.'"/>
							          	  <input type="hidden" name="partsid_'.$k.'" id="partsid_'.$k.'" value="'.$partsid.'"/>
							          	</div>
							          </div>
							          </div>
							        </div>
							        <div class="modal-footer">
							          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="gettotalqty('.$k.')" >Submit</button>
							        </div>
							      </div>
							    </div>
							  </div>
					     </li>';
			$k++;}
			echo '</ul></div>';
		}
	}
	public function saveboxstock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		date_default_timezone_set("Asia/kolkata");
		$tablerow=$this->input->post("tablerow");
		$boxname=$this->input->post("boxname");
		if(isset($boxname) && !empty($boxname)){
			$boxname=$boxname;
		}else
			{
				$boxname="";
			}
		$bxqty=intval($this->input->post("boxqty"));
		if(isset($bxqty)&& !empty($bxqty))
		{
			$bxqty=intval($bxqty);
			$getboxcode=$this->stockManage_model->getlastboxcode();
		}else{
			$bxqty=1;
		}
		for($p=1;$p<intval($tablerow);$p++)
		{
			$modelname=$this->input->post("model_name_".$p);
			$partsname=$this->input->post("partsname_".$p);
			$partsid=$this->input->post("partsid_".$p);
			$partsqty=intval($this->input->post("partsqty_".$p));
			$warehousecode=$this->input->post("warehouse_".$p);
			$getboxcode2=$this->stockManage_model->getlastboxcode();
			$totqty=intval($bxqty)*intval($partsqty);
			//boxsaving purpose only
				if(isset($bxqty)&& !empty($bxqty)&& isset($boxname) && !empty($boxname))
				{
					$bxqty=$bxqty;
					$dataarray=array(
					"boxname"=>$boxname,
					"boxcode"=>$getboxcode,
					"modelname"=>$modelname,
					"partsname"=>$partsname,
					"partsid"=>$partsid,
					"qty"=>$partsqty,
					"boxqty"=>$bxqty,
					"godowncode"=>$warehousecode,
					"doe"=>date('Y-m-d'),
					"crtd"=>$this->session->userdata('user_name')
					
				);
				//print_r($dataarray);
				//echo 1;
			  //  echo "<br>";
			
				$this->stockManage_model->saveboxstock($dataarray);
				
				}else{
					//$bxqty="";
					$dataarray=array(
					"boxname"=>$boxname,
					"boxcode"=>$getboxcode2,
					"modelname"=>$modelname,
					"partsname"=>$partsname,
					"partsid"=>$partsid,
					"qty"=>$partsqty,
					"boxqty"=>$partsqty,
					"godowncode"=>$warehousecode,
					"doe"=>date('Y-m-d'),
					"crtd"=>$this->session->userdata('user_name')
				
			);
			//print_r($dataarray);
			//echo 2;
			//echo "<br>";
			$this->stockManage_model->saveboxstock($dataarray);
			
				}
			/*$dataarray=array(
				"boxname"=>$boxname,
				"modelname"=>$modelname,
				"partsname"=>$partsname,
				"partsid"=>$partsid,
				"qty"=>$partsqty,
				"boxqty"=>$bxqty,
				"godowncode"=>$warehousecode,
				"doe"=>date('Y-m-d'),
				"crtd"=>$this->session->userdata('user_name')
				
			);
			$this->stockManage_model->saveboxstock($dataarray);*/
			//godown saving purpose
			$getpartsidstatus=$this->stockManage_model->getgdstockdetails($partsid,$warehousecode);
			//get parts qty  ==========================
			$getpartsqty=$this->stockManage_model->getcurent_stockdetails($partsid);
			if(!empty($getpartsqty))
			{
				foreach($getpartsqty as $rowq)
				{
					$opqty=intval($rowq->qnty);
					
				}
				$copnqty=$opqty;
				$lqty=intval($totqty)+intval($copnqty);
			}
			if(empty($getpartsidstatus))
			{
				$dataarray=array(
				 "partsid"=>$partsid,
				 "mnme"=>$modelname,
				 "gdownid"=>$warehousecode,
				 "openqty"=>$totqty,
				 "qty"=>$totqty,
				 "doe"=>date('Y-m-d'),
				 "crted"=>$this->session->userdata('user_name')
				
				);
			//	print_r($dataarray);
			//	echo 3;
			  //  echo "<br>";
			
				 $this->stockManage_model->savegdstock($dataarray);
				
			}else
			{
				foreach($getpartsidstatus as $rowst)
				{
					$opqty=intval($rowst->qty);
					
				}
				$qttot=intval($opqty)+intval($totqty);
				
				$dataarray=array(
				 "partsid"=>$partsid,
				 "mnme"=>$modelname,
				 "gdownid"=>$warehousecode,
				 "openqty"=>$opqty,
				 "qty"=>$totqty,
				 "closestock"=>$qttot,
				 "doe"=>date('Y-m-d'),
				 "crted"=>$this->session->userdata('user_name'));
				// print_r($dataarray);
				// echo 4;
			   //   echo "<br>";
			
				 $this->stockManage_model->updategdstock($dataarray,$partsid,$warehousecode);
			}
			//transaction purpose  =======================
			$dataarratrns=array(
				"date"=>date('Y-m-d'),
				"model_id"=>$modelname,
				"partsId"=>$partsid,
				"openingQty"=>$copnqty,
				"newQty"=>$totqty,
				"total"=>$lqty,
				"crtd"=>$this->session->userdata('user_name'),
				"lstupdt"=>date('Y-m-d h:i:s A')
			);
			$this->stockManage_model->savetransactionparts($dataarratrns);
			//print_r($dataarratrns);
			//echo 5;
			//echo "<br>";
			
			//master stock update==================================
			$datamstock=array(
				"qnty"=>$copnqty,
				"openQnty"=>$lqty,
				"stockentryupdt"=>$this->session->userdata('user_name')
						
			);
			//print_r($datamstock);
			//echo 6;
			//echo "<br>";
			
			$this->stockManage_model->getupdatestockmaster($datamstock,$partsid);
			
			
		}
        redirect('StockManage_controller/bxwsestock','refresh');
	}
	public function showallboxstock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['boxstock']=$this->stockManage_model->getallboxstock();
		$this->load->view("stockmanage/viewboxstock",$data);
		//echo "hello";
	}
	/*public function viewboxstockal()
	{
		//$this->authentication->is_loggedin($this->session->userdata('user_name'));
		//$this->load->view("stockManage_controller/boxwisestockall");
		
		
	}*/

    /*public function view_allstock()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['title']="View All Stock";
		$data[]
	}*/





}