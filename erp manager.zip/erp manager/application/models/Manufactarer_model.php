<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manufactarer_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getallmodel()
	{
		$query=$this->db->query("select * from productmaster");
		return $query->result();
	}
	public function getmnthcode($mnth)
	{
		$query=$this->db->query("select * from chasismntcode where mnthno='".trim($mnth)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$code=$row->code;
		}
		return $code;
	}
	public function getallchasisdt($yr,$getmonthcode)
	{
		$query=$this->db->query("select * from manufact where manfYr='".trim($yr)."' and monthcode='".trim($getmonthcode)."' order by id desc limit 1");
		return $query->result();
	}
	public function getrecentorderlist()
   {
   	$query=$this->db->query("select * from manufactre_req order by id  and status='0'desc");
	return $query->result();
   }
   public function get_qntylist($id)
   {
   		$query=$this->db->query("select * from manufactre_req where id='".trim($id)."' and status='0'");
		return $query->result();
   }
   public function getmodelname($model)
   {
   	$query=$this->db->query("select * from productmaster where id='".trim($model)."'");
	$res=$query->result();
	foreach($res as $row)
	{
		$model=$row->productname;
	}
	return $model;
   }
   public function save_manufactred_item($data_array)
   {
   	$this->db->insert("manufact",$data_array);
   }
   public function update_req_manf($data_array_update,$orderno)
   {
   	$this->db->where('orderno',$orderno);
	$this->db->update('manufactre_req',$data_array_update);
   }
   public function updategetpassstatus($data_array_booking_status,$orderno)
   {
   	$this->db->where('bokingid',$orderno);
	
	$this->db->update('bookingorder',$data_array_booking_status);
   }
   public function gettotal_orderdetails($order)
   {
	   	$query=$this->db->query("select * from bookingorder where bokingid='".trim($order)."'");
		return $query->result();
   }
   public function getcustdetails($customercode)
   {
   	$query=$this->db->query("select * from clientmaster where clientid='".trim($customercode)."'");
   	return $query->result();
   }
}
