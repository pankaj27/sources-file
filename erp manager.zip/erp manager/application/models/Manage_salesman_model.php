<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_salesman_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getlastid()
	{
		$query=$this->db->query("select max(id) as id from salesman");
		$res= $query->result();
		foreach($res as $row)
		{
			$id=$row->id;
		}
		return $id;
	}
	public function insert($data_insert)
	{
		$this->db->insert('salesman',$data_insert);
	}
	public function getallsalesman()
	{
		$query=$this->db->query("select * from salesman order by id desc");
		return $query->result();
	}
	public function deletesalesman($sid)
	{
		$query=$this->db->query("delete from salesman where id='".trim($sid)."'");
	}
	public function getdepartments()
	{
		$query=$this->db->query("select * from departments where status='0' order by name asc");
		return $query->result();
	}
	//updae on 31122016========
	public function getallsalesmanindividual($sid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($sid)."' ");
		return $query->result();
	}
	public function updatesalesman($data_insert,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("salesman",$data_insert);
	}
	//########################################  update on 31012017  #################################################
	public function getalldepartsment()
	{
		$query=$this->db->query("select * from departments order by code asc");
		return $query->result();
	}
	public function getlastdpid()
	{
		$query=$this->db->query("select max(id) as id from departments");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $rw)
			{
				$id=$rw->id;
			}
			$qry=$this->db->query("select * from departments where id='".trim($id)."'");
			$res2=$qry->result();
			foreach($res2 as $rew)
			{
				$cod=$rew->code;
			}
		}
		if(isset($cod) && !empty($cod))
		{
			$cod=$cod;
		}else{
			$cod="DP000";
		}
		return $cod;
	}
	public function getalldepartsment_id($id)
	{
		$query=$this->db->query("select * from departments where id='".trim($id)."'");
		return $query->result();
	}
	public function save_departsment_new($data_array)
	{
		$this->db->insert('departments',$data_array);
	}
	public function update_departsment_new($data_array,$dipcid)
	{
		$this->db->where("id",$dipcid);
		$this->db->update("departments",$data_array);
	}
	public function delete_depatsment($id)
	{
		$query=$this->db->query("delete from departments where id='".trim($id)."'");
	}
	
	public function getlastdesignation()
	{
		$query=$this->db->query("select max(id) as id from designation");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $rw)
			{
				$id=$rw->id;
			}
			$qry=$this->db->query("select * from designation where id='".trim($id)."'");
			$res2=$qry->result();
			foreach($res2 as $rew)
			{
				$cod=$rew->desigcode;
			}
		}
		if(isset($cod) && !empty($cod))
		{
			$cod=$cod;
		}else{
			$cod="DSG000";
		}
		return $cod;
	}
	public function getall_desig()
	{
		$query=$this->db->query("select * from designation order by 	desigcode asc");
		return $query->result();
	}
	public function save_designation_new($data_array)
	{
		$this->db->insert('designation',$data_array);
	}
	public function getall_designation($id)
	{
		$query=$this->db->query("select * from designation where id='".trim($id)."'");
		return $query->result();
	}
	public function update_designation_new($data_array,$dipcid)
	{
		$this->db->where('id',$dipcid);
		$this->db->update('designation',$data_array);
	}
	public function delete_designation($id)
	{
		$query=$this->db->query("delete from designation where id='".trim($id)."' ");
	}
	public function update_salaryupdt($data_array,$desigid)
	{
		$this->db->where("id",$desigid);
		$this->db->update("designation",$data_array);
	}
	public function getalldsig($depart)
	{
		$query=$this->db->query("select * from designation where ucase(departments)='".trim(strtoupper($depart))."'");
		return $query->result();
	}
}
	

