<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ColourManage_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function insertColour($data_array)
	{
		$this->db->insert('color_code',$data_array);
		$res=$this->db->query("select * from color_code");
		$res2=$res->result();
		$i=1;
		foreach($res2 as $rw)
		{
			$code=$rw->codeid;
			$this->db->query("update color_code set id='".trim($i)."' where codeid='".trim($code)."'");
			$i++;
		}
	}
	public function fetchcolour()
	{
		$query=$this->db->query("select * from color_code");
	   return $query->result();
	}
	public function deleteColour($id1)
	{
		$this->db->where('codeid', $id1);
		$this->db->delete('color_code');
	}
	public function updatecolorcode($data_array,$code)
	{
		$this->db->where('codeid', $code);
		$this->db->update('color_code', $data_array);
	}
	public function getcolorcodebycode($id)
	{
		$query=$this->db->query("select * from color_code where codeid='".trim($id)."' ");
		return $query->result();
		
	}
}