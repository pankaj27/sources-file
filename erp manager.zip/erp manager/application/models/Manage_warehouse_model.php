<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_warehouse_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getgodowncode($uid)
	{
		$query=$this->db->query("select * from user where id='".trim($uid)."'");
		$res=$query->result();
		foreach($res as $rs)
		{
			$gdwn=$rs->gdown;
		}
		return $gdwn;
		
	}
	public function get_bookingdetails($getgodown)
	{
		$query=$this->db->query("select * from warehousewise_order where wrehsecode='".trim($getgodown)."' order by id desc");
		
		return $query->result();
	}
	public function get_stock_detailsin_warehouse($gdownid)
	{
		$query=$this->db->query("select * from  boxstock where godowncode='".$gdownid."'");
		return $query->result();
	}
	public function getmodeldetails($id)
	{
		$query=$this->db->query("select pm.productname as modelname from productmaster as pm, warehousewise_order as wo where pm.id=wo.modelname and wo.id='".trim($id)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$modelname=$row->modelname;
		}
		return $modelname;
	}
	public function getallspareparts($getmodelname)
	{
		$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($getmodelname))."'order by materialname asc");
		return $query->result();
	}
	public function getqnty($id)
	{
		$query=$this->db->query("select * from warehousewise_order where id='".trim($id)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$qnty=$row->qnty;
			$model=$row->modelname;
		}
		$res=$qnty.";".$model;
		return $res;
	}
	public function getmodelname($id)
	{
		$query=$this->db->query("select * from productmaster where id='".trim($id)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$pname=$row->productname;
		}
		return $pname;
	}
	public function get_godowncode($gdownid)
	{
		$query=$this->db->query("select * from godown where id='".trim($gdownid)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$gdowncode=$row->gdowncode;
		}
		return $gdowncode;
	}
	public function getboswisestock($gdownid,$model)
	{
		$query=$this->db->query("select * from boxstock where modelname='".trim($model)."' and godowncode='".trim($gdownid)."'");
	}
	public function getlastmanufatid()
	{
		$query=$this->db->query("select max(id) as id from manufactre_req ");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $row)
			{
				$rid=$row->id;
			}
			$qryid=$this->db->query("select * from manufactre_req where id='".trim($rid)."'");
			$res2=$qryid->result();
			if(isset($res2)&&!empty($res2)){
			foreach($res2 as $rw)
			{
				$manfactid=$rw->manfactid;
			}
			//if()
			$rwn=intval(substr($manfactid,-5));
			$rwn2=$rwn+1;
			$rwn3=str_pad($rwn2,5,"0", STR_PAD_LEFT);
			$rwn4="MNFC".$rwn3;
			
			}
		}
		if(isset($rwn4)& !empty($rwn4))
		{
			$rwn4=$rwn4;
		}else{
			$rwn4="MNFC00001";
		}
		return $rwn4;
	}
	public function save_manfact($data_manfact)
	{
		$this->db->insert('manufactre_req',$data_manfact);
	}
	public function savetologistic($data_array)
	{
		$this->db->insert('checking_stock',$data_array);
	}
	public function getbookingid($ordername)
	{
		$query=$this->db->query("select wo.bkid as bkid from warehousewise_order as wo ,bookingorder bk where bk.bokingid=wo.bkid and wo.id='".trim($ordername)."'");
		$res=$query->result();
		foreach($res as $row);
		{
			$bkid=$row->bkid;
		}
		return $bkid;
	}
	public function updatestats($data_updte,$ordername1)
	{
		$this->db->where('id',$ordername1);
		$this->db->update('warehousewise_order',$data_updte);
	}
	public function getallwarestockdata()
	{
		$query=$this->db->query("select * from checking_stock  where crtd='".trim($this->session->userdata('user_name'))."' order by id desc");
		return $query->result();
	}
	public function getall_orderdetails($id)
	{
		$query=$this->db->query("select * from checking_stock where orderno='".trim($id)."'");
	  //echo "select * from getpassorder where id='".trim($oid)."'";
	   return $query->result();
	}
	public function saveedit($orderid,$shortage,$tot)
   {
   	$query=$this->db->query("update checking_stock set shortage='".trim($shortage)."',tot='".trim($tot)."' where id='".trim($orderid)."'");
   }
   public function update_checkinggatepass($data_arr,$slid)
   {
   	$this->db->where('id',$slid);
	$this->db->update('checking_stock',$data_arr);
   }
   public function getgodownstock($partsid,$warehouse)
   {
   	$query=$this->db->query("select gs.openqty,gs.closestock ,gd.id from gdownstock as gs ,godown as gd where gd.id=gs.gdownid and gs.partsid='".trim($partsid)."' and gd.gdowncode='".trim($warehouse)."'");
   //	echo "select gs.openqty,gs.closestock  from gdownstock as gs ,godown as gd where gd.id=gs.gdownid and gs.partsid='".trim($partsid)."' and gd.gdowncode='".trim($warehouse)."'";
   	return $query->result();
   }
   public function save_required_qty($data_array)
   {
   	$this->db->insert('requiredparts',$data_array);
   }
   public function upate_godownsock($gwnid,$partsid,$data_ar)
   {
   	$data_arr=array(
   		"partsid"=>$partsid,
   		"gdownid"=>$gwnid
   	);
	$this->db->where($data_arr);
	$this->db->update("gdownstock",$data_ar);
   
   }
   public function getlast_transaction($partsid)
   {
   	$query=$this->db->query("select * from transection_sparesparts where partsId='".trim($partsid)."' order by id desc");
	return $query->result();
   }
   public function savetransactionmasterspareparts($data_array_trns_parts)
   {
   	$this->db->insert('transection_sparesparts',$data_array_trns_parts);
   }
   public function getcurrent_stock($partsid)
   {
   	$query=$this->db->query("select * from materiel_master where id='".trim($partsid)."'");
   	return $query->result();
   }
   public function update_master_transaction($data_array_trns_parts,$partsid)
   {
   	$this->db->where('id',$partsid);
	$this->db->update('materiel_master',$data_array_trns_parts);
   }
   public function update_box_qty($data_array_box,$reqid)
   {
   	$this->db->where('id',$reqid);
	$this->db->update('boxstock',$data_array_box);
   }
   public function getsellqty($reqid)
   {
   	$query=$this->db->query("select * from boxstock where id='".trim($reqid)."'");
	return $query->result();
   }
   
	
}
	

