<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Venders_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_country()
	{
		$query=$this->db->query("select * from countrylist order by name asc");
		return $query->result();
	}
	public function getdat_ex()
	{
		$query=$this->db->query("select max(id) as id from venderslist");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $rowven)
			{
				$id=$rowven->id;
			}
		}
		if(isset($id) && !empty($id))
		{
			$query2=$this->db->query("select * from venderslist where id='".trim($id)."'");
			$resl=$query2->result();
			foreach($resl as $rowvn)
			{
				$venid=$rowvn->vender_id;
			}
			$venid=$venid;
		}else{
			$venid="GKSUP00000";
		}
		return $venid;
		//return $query->result();
	}
	public function check_data_exist($vemail,$vphno)
	{
		$query=$this->db->query("select * from venderslist where vemail='".trim($vemail)."' and vphno='".trim($vphno)."'");
		return $query->result();
	}
	public function insert_venderlist($data_array)
	{
		$this->db->insert('venderslist',$data_array);
	}
	public function getlastid()
	{
		$query=$this->db->query("select max(id) as id from venderslist ");
		 $getlastid=$query->result();
		 foreach($getlastid as $row)
			{
				$vid=$row->id;
			}
		$query=$this->db->query("select * from venderslist where id='".trim($vid)."' ");
		return $query->result();
	}
	//------------------sacve BAnk Info --------------------
	public function savebankinfo($data_array_bankinfo)
	{
		$this->db->insert('vender_bank_info',$data_array_bankinfo);
	}
	/*--------------------get all vendors list-----------------
	 * 
	 */
	 public function getall_vendors_list()
	 {
	 	$query=$this->db->query("select * from venderslist order by id desc");
		return $query->result();
	 }
	 public function getalspareparts()
	 {
	 	$query=$this->db->query("select distinct(materialname) as matnam from materiel_master ");
		return $query->result();
	 }
	 public function getallproducts()
	 {
	 	$query=$this->db->query("select * from productmaster");
		return $query->result();
	 }
	 public function getvendorsdetails($vid)
	 {
	 	$query=$this->db->query("select * from venderslist where id='".trim($vid)."'");
		return $query->result();
	 }
	 public function update_vendors($data_array,$vid)
	 {
	 	$this->db->where('id',$vid);
		$this->db->update('venderslist',$data_array);
		return 1;
	 }
	 public function delete_vendors($vid)
	 {
	 	$query=$this->db->query("delete from venderslist where id='".trim($vid)."'");
		if($query==TRUE)
		{
			return 1;
		}else{
			return 0;
		}
	 }
	public function fetchState()
	{
		$query=$this->db->query("select * from state");
		return $query->result();
	}
	
}