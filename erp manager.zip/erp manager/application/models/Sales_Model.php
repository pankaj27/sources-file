<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_Model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function fetchTerget()
	{
		$query=$this->db->query("select * from salesman where status=1");
		return $query->result();
	}
	public function fetchTerget1()
	{
		$query=$this->db->query("select * from sales_terget");
		return $query->result();
	}
	public function saveinddata($data_array)
	{
		$res=$this->db->insert("sales_terget",$data_array);
		if($res==TRUE)
		{
			$k=1;
		}else{
			$k=0;
		}
		return $k;
	}
	public function updateinddata($data_array,$salesmanid)
	{
		$this->db->where("salesmanid",$salesmanid);
		$this->db->update("sales_terget",$data_array);
	}
	public function getcheckexist($salesmanid,$mnthcode,$yrcode)
	{
		$query=$this->db->query("select * from sales_terget where salesmanid='".trim($salesmanid)."' and monthcode='".trim($mnthcode)."' and yearcode='".trim($yrcode)."'");
		return $query->result();
	}
	//#################################################   update on 10012017   
	public function getallmodellist()
	{
		$query=$this->db->query("select * from productmaster");
		return $query->result();
	}
	public function getallparts($modelname)
	{
		$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($modelname))."'");
		return $query->result();
	}
	public function getallmodedl()
	{
		$query=$this->db->query("select distinct(mName) as model from materiel_master");
		return $query->result();
	}
	/////...............16/01/2016...............///////////////
	
	public function fetchslab()
	{
		$query=$this->db->query("select * from incentive");
		return $query->result();
	}
	public function checkincentive()
	{
		$query=$this->db->query("select * from incentive");
		return $query->result();
	}
	public function updateincentive($data_array,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("incentive",$data_array);
	}
	//update omn 17012017
	public function getsatus($sid)
	{
		$query=$this->db->query("select  * from salesman where id='".trim($sid)."'");
		return $query->result();
	}
	public function update_status($sid,$stnew)
	{
		$query=$this->db->query("update salesman set status='".trim($stnew)."' where id='".trim($sid)."'");
	}
	//19012017
	public function getallmodedlprice()
	{
		$query=$this->db->query("select * from productmaster");
		return $query->result();
	}

 }