<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class StockManage_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function poDetail()
	{
		$query=$this->db->query("select * from finalorder order by id desc");
		return $query->result();
	}
	public function gettallpodetails($pono)
	{
		
		$query=$this->db->query("select * from finalorder where poid='".trim($pono)."'");
		return $query->result();
	}
	public function getallfinalpono()
	{
		$query=$this->db->query("select * from finalorder order by id desc");
		return $query->result();
	}
	public function gettdetails()
	{
		$query=$this->db->query("select * from materiel_master");
		return $query->result();
	}
	public function addStock($data_array,$mnam)
	{
		$this->db->where('mName', $mnam);
		$this->db->update('materiel_master', $data_array);
	}
	public function getallpurchaselist($pono)
	{
		$query=$this->db->query("select * from purchaseorder where poid='".trim($pono)."'");
		return $query->result();
	}
	public function getallspareparts($modelname)
	{
		$query=$this->db->query("select * from materiel_master where mName='".trim($modelname)."'");
		return $query->result();
	}
	public function getpartsdetailsbyprtsid($prtsid)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($prtsid)."'");
		return $query->result();
	}
	public function savetempdatabystockorder($data_array)
	{
		$this->db->insert('temp_table',$data_array);
	}
	public function getalldatatemptable($pono)
	{
		$query=$this->db->query("select * from temp_table where pono='".trim($pono)."' and status=0");
		return $query->result();
	}
	public function getpqtybypono($pono,$prtsid)
	{
		$query=$this->db->query("select * from purchaseorder where poid='".trim($pono)."'");
		$result=$query->result();
		
	}
	public function getalldata($pono)
	{
		$query=$this->db->query("select * from temp_table where pono='".trim($pono)."' and status='0'");
		return $query->result();
	}
	public function getalldatastock()
	{
		$query=$this->db->query("select * from temp_table");
		return $query->result();
	}
	public function getmodel()
	{
		$query=$this->db->query("select * from  productmaster");
		return $query->result();
	}
	public function getspareparts()
	{
		$query=$this->db->query("select * from materiel_master order by materialname asc");
		return $query->result();
	}
	public function getboxwisestock()
	{
		$query=$this->db->query("select * from temp_table where  boxname is not null and boxname!='' ");
		return $query->result();
	}
	public function getallspareparts2($model)
	{
		$query=$this->db->query("select * from materiel_master where mName='".trim($model)."' order by materialname asc ");
		return $query->result();
	
	}
	public function savemodelsorder($data_array)
	{
		$this->db->insert('temporder',$data_array);
	}
	public function getlasttemorderid()
	{
		$query=$this->db->query("select max(temporderid) as tempoid from temporder");
		$res=$query->result();
		foreach($res as $row)
		{
			$tempid=$row->tempoid;
		}
		return $tempid;
	}
	public function getalltemporderdata($model,$qty,$tempoid)
	{
		//$query=$this->db->query("select * from temporder where modelname='".trim($model)."' and qty='".trim($qty)."' and  temporderid='".trim($tempoid)."'");
		$query=$this->db->query("select * from temporder ");
		return $query->result();
	}
	public function getallpono()
	{
		$query=$this->db->query("select * from temp_table");
		return $query->result();
	}
	public function save_data($data_array)
	{
		$this->db->insert('stocktable',$data_array);
	}
	
	public function getgodownstock()
	{
		$query=$this->db->query("select * from godown");
		return $query->result();
	}
	/////////////////////////////by abhishek////////////////////////////  //
	public function getOrderCode()                                        //
	{                                                                     //
		$query=$this->db->query("select max(id) as id from StockTable");  //
		return $query->result();                                          //
	}
	public function fetchgodown()
	{
		$query=$this->db->query("select * from godown");
		return $query->result();
	}
	//////////////////////////////////////////////////////////////////
	public function getspecfstock()
	{
		$query=$this->db->query("select * from spareparts_specification");
		return $query->result();
	}
	public function getallsparepartsstock($mname)
	{
		$query=$this->db->query("select * from materiel_master where mName='".trim($mname)."' order by materialname asc");
		return $query->result();
	}
	public function getallspecification($spareparts)
	{
		$query=$this->db->query("select * from spareparts_specification where productid='".trim($spareparts)."' order by specification asc");
		return $query->result();
	}
	public function getalldatastockgodown($warehouse)
	{
		$query=$this->db->query("select * from gdownstock where gdownid='".trim($warehouse)."'");
		return $query->result();
	}
	public function getallmodeldata($model)
	{
		$query=$this->db->query("select * from gdownstock where mnme='".trim($model)."'");
		return $query->result(); 
	}
	public function getallmodelwrsedata($model,$warehouse)
	{
		$query=$this->db->query("select * from gdownstock where gdownid='".trim($warehouse)."' and mnme='".trim($model)."' ");
		return $query->result();
	}
	public function getallprtsnowrhse($model,$parts)
	{
		$query=$this->db->query("select * from gdownstock where partsid='".trim($parts)."' and mnme='".trim($model)."' ");
		return $query->result();
	}
	public function getallprtsyswrhse($model,$parts,$warehouse)
	{
		$query=$this->db->query("select * from gdownstock where gdownid='".trim($warehouse)."' and partsid='".trim($parts)."' and mnme='".trim($model)."' ");
		return $query->result();
	}
	public function getallspecifiprtsnowrs($model,$parts,$specification)
	{
		$query=$this->db->query("select * from gdownstock where spefcid='".trim($specification)."' and partsid='".trim($parts)."' and mnme='".trim($model)."' ");
		return $query->result();
	}
	public function getallspecifiprtsnowrs2($model,$parts,$specification,$warehouse)
	{
		$query=$this->db->query("select * from gdownstock where gdownid='".trim($warehouse)."' and spefcid='".trim($specification)."' and partsid='".trim($parts)."' and mnme='".trim($model)."' ");
		return $query->result();
	}
	public function getallstockdata()
	{
		$query=$this->db->query("select * from gdownstock order by mnme asc");
		return $query->result();
	}
	public function getallpono_godown($godown)
	{
		$query=$this->db->query("select * from temp_table where warehouse='".trim($godown)."' ");
		return $query->result();
	}
	public function getallpono_godownmodel($godown,$model)
	{
		$query=$this->db->query("select * from temp_table where warehouse='".trim($godown)."' and modelname='".trim($model)."'  ");
		//echo "select * from temp_table where warehouse='".trim($godown)."' and modelname='".trim($model)."' ";
		
		return $query->result();
	}
	public function getstockmodeldis($godown)
	{
		$query=$this->db->query("select distinct(modelname) from temp_table");
		return $query->result();
	}
   public function saveorderdategetpass($data_array)
   {
   	$this->db->insert('getpassorder',$data_array);
   }
   public function getmodelname($prtscode)
   {
   	  $query=$this->db->query("select * from materiel_master where id='".trim($prtscode)."'");
	  $res=$query->result();
	  foreach($res as $row)
	  {
	  	$model=$row->mName;
	  }
	  return $model;
   }
   public function getallorderlist()
   {
   	$query=$this->db->query("select * from getpassorder order by id asc ");
	return $query->result();
   }
   public function getallorderdetails($oid)
   {
   	$query=$this->db->query("select * from getpassorder where orderno='".trim($oid)."'");
	//echo "select * from getpassorder where id='".trim($oid)."'";
	return $query->result();
   }
   public function getallorderlistindi($oid)
   {
   	$query=$this->db->query("select * from getpassorder where id='".trim($oid)."'");
	//echo "select * from getpassorder where id='".trim($oid)."'";
	return $query->result();
   }
   public function saveoidlast($data_array)
   {
   	$this->db->insert('stocktable',$data_array);
   }
   public function getprtsnamebyprtid($partsid)
   {
   	$query=$this->db->query("select * from materiel_master where id='".trim($partsid)."'");
	  $res=$query->result();
	  foreach($res as $row)
	  {
	  	$model=$row->mName;
		$prtsname=$row->materialname;
	  }
	  $resr=$prtsname."(".$model.")";
	  return $resr;
   }
   public function getpartylist()
   {
   	  $query=$this->db->query("select * from clientmaster");
	  return $query->result();
   }
   public function getpartydetails($particode)
   {
   	$query=$this->db->query("select * from clientmaster where clientid='".trim($particode)."'");
	return $query->result();
   }
   public function getsparepartsbymodel($model)
   {
   	$query=$this->db->query("select * from materiel_master where mName='".trim($model)."' order by materialname asc");
   	return $query->result();
   }
   public function saveedit($orderid,$shortage,$tot)
   {
   	$query=$this->db->query("update getpassorder set shortage='".trim($shortage)."',tot='".trim($tot)."' where id='".trim($orderid)."'");
   }
   public function getallpatycode($partyname)
   {
   	$query=$this->db->query("select * from clientmaster where compname like '%".trim($partyname)."%'");
	$res=$query->result();
	foreach($res as $row)
	{
		$prticode=$row->clientid;
		$pariemail=$row->email;
	}
	$resd=$prticode.",".$pariemail;
	return $resd;
   }
   public function getwarehousename($warehouse)
   {
   		$query=$this->db->query("select * from godown where  gdowncode='".trim($warehouse)."'");
		$res=$query->result();
		foreach($res as $row)
		{
			$warehousenme=$row->gdname;
			$godownid=$row->id;
		}
		$godwn=$warehousenme.",".$godownid;
		return $godwn;
   }
   public function getmoddet($modelcode)
   {
   	$query=$this->db->query("select * from materiel_master where id='".trim($modelcode)."'");
	$res=$query->result();
	foreach($res as $row)
	{
		$openqty=$row->openQnty;
		$qnty=$row->qnty;
	}
	$resd=$qnty.";".$openqty;
	return $resd;
   }
   public function updaematerialmaster($data_array,$modelcode)
   {
   		$this->db->where('id',$modelcode);
		$this->db->update('materiel_master',$data_array);
   }
   public function savetransfer_spareparts($data_array)
   {
   	$this->db->insert("transection_sparesparts",$data_array);
   }
   public function getgodownstockdetails($modelcode,$model,$modelspeid,$godownid)
   {
	   
	   $query=$this->db->query("select * from gdownstock where 	partsid='".trim($modelcode)."' and mnme='".trim($model)."' and spefcid='".trim($modelspeid)."' and gdownid='".trim($godownid)."'");
	  // echo "select * from gdownstock where 	partsid='".trim($modelcode)."' and mnme='".trim($model)."' and spefcid='".trim($modelspeid)."' and gdownid='".trim($godownid)."'";
	   $res=$query->result();
	   $resd="";
	   if(!empty($res)){
		   foreach($res as $row)
		   {
			   $qty=$row->qty;
			   $id=$row->id;
			   
		   }
	      $resd=$qty.",".$id;
	   }
	   return $resd;
   }
   public function savegodownstock($data_array_godownnew)
   {
	  $this->db->insert('gdownstock',$data_array_godownnew);
   }
   public function updategownstock($data_array_godownupdate,$godwnstockid)
   {
	   $this->db->where('id',$godwnstockid);
	   $this->db->update('gdownstock',$data_array_godownupdate);
   }
   public function update_tem_table($temid)
   {
		$query=$this->db->query("update temp_table set status='1' where id='".trim($temid)."' ");
   }
   public function getmodelcodebyprt($partcode){
   	  $query=$this->db->query("select * from materiel_master where id='".trim($partcode)."'");
   	  
   	  $res=$query->result();
	  foreach($res as $rowst)
	  {
	  	$mcode=$rowst->mName;
	  }
	  return $mcode;
   }
   //update on 27122016 ==================================================
   public function getwarehouse()
   {
   	 $query=$this->db->query("select * from  godown order by id desc");
	 return $query->result();
   }
   public function getallmodel()
   {
   	$query=$this->db->query("select * from productmaster ");
	return $query->result();
   }
   public function getallpartsbymodel($model)
   {
   	$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($model))."'");
	return $query->result();
   }
   public function getwrehseid($warehouse)
   {
   	$query=$this->db->query("select * from godown where gdname='".trim($warehouse)."' ");
	$gdid="";
	$res=$query->result();
	if(!empty($res)){
	foreach($res as $row)
	{
		$gdid=$row->id;
	}
	}
	return $gdid;
   }
   public function checkstockgdexist($specfid,$gdwncode,$modelname,$partscode)
   {
   	$query=$this->db->query("select * from gdownstock where partsid='".trim($partscode)."' and ucase(mnme)='".trim(strtoupper($modelname))."' and spefcid='".trim($specfid)."' and gdownid='".trim($gdwncode)."'");
	return $query->result();
   }
   public function updategdstockbyspecification($dataaray,$specfid,$gdwncode,$modelname,$partscode)
   {
   	$dataar=array(
		"partsid"=>$partscode,
		"mnme"=>$modelname,
		"spefcid"=>$specfid,
		"gdownid"=>$gdwncode
	);
   	$this->db->where($dataar);
	$this->db->update("gdownstock",$dataaray);
   }
   public function updategdstockbyspecification2($dataaray,$gdwncode,$modelname,$partscode)
   {
   	$dataar=array(
		"partsid"=>$partscode,
		"mnme"=>$modelname,
		"gdownid"=>$gdwncode
	);
   	$this->db->where($dataar);
	$this->db->update("gdownstock",$dataaray);
   }
   public function savegdstck($datainsert)
   {
   	$this->db->insert("gdownstock",$datainsert);
   }
   public function checkstockgdexist2($gdwncode,$modelname,$partscode)
   {
   	$query=$this->db->query("select * from gdownstock where partsid='".trim($partscode)."' and ucase(mnme)='".trim(strtoupper($modelname))."'  and gdownid='".trim($gdwncode)."'");
	return $query->result();
   }
   public function getcrntstockbymodel($matid)
   {
   	$query=$this->db->query("select * from materiel_master where id='".trim($matid)."'");
   	return $query->result();
   }
   public function updatestockparts($datamstoc,$matid)
   {
   	$this->db->where('id',$matid);
	$this->db->update("materiel_master",$datamstoc);
   }
   public function savetransdata($data_trans)
   {
   	$this->db->insert("transection_sparesparts",$data_trans);
   }
   //#########################  Update 29122016 ############################
   public function getallprts($modelnm)
   {
   	$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($modelnm))."'");
	return $query->result();
   }
   public function getnoparts($modelnm)
   {
   	 $query=$this->db->query("select count(*) as no from materiel_master where ucase(mName)='".trim(strtoupper($modelnm))."'");
	 $res=$query->result();
	 foreach($res as $row)
	 {
	 	$not=$row->no;
	 }
	 return $not;
   }
   public function getalwarehouse()
   {
   	 $query=$this->db->query("select  * from godown order by gdname asc");
	 return $query->result();
   }
   public function getallparts($model)
   {
   	$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($model))."' order by materialname asc");
	return $query->result();
   }
   public function getwarehousecode($warehouse)
   {
   	$query=$this->db->query("select * from godown where ucase(gdname)='".trim(strtoupper($warehouse))."'");
	$res=$query->result();
	foreach($res as $row)
	{
		$id=$row->id;
	}
	return $id;
   }
   public function saveboxstock($dataarray)
   {
   	$this->db->insert('boxstock',$dataarray);
   }
   public function getgdstockdetails($partsid,$warehousecode)
   {
   	$query=$this->db->query("select * from gdownstock where partsid='".trim($partsid)."' and gdownid='".trim($warehousecode)."'");
	return $query->result();
   }
   public function updategdstock($dataarray,$partsid,$warehousecode)
   {
   	$datawh=array("partsid"=>$partsid, "gdownid"=>$warehousecode  );
		$this->db->where($datawh);		 
		$this->db->update("gdownstock",$dataarray);
   }
   public function savegdstock($dataarray)
   {
   	$this->db->insert("gdownstock",$dataarray);
   }
   public function getcurent_stockdetails($partsid)
   {
   	  $query=$this->db->query("select * from materiel_master where id='".trim($partsid)."'");
   	  return $query->result();
   }
   public function savetransactionparts($dataarratrns)
   {
   	 $this->db->insert("transection_sparesparts",$dataarratrns);
   }
   public function getupdatestockmaster($datamstock,$partsid)
   {
   	$this->db->where("id",$partsid);
	$this->db->update("materiel_master",$datamstock);
	
   }
   public function getallboxstock()
   {
   	$query=$this->db->query("select * from boxstock where status='0'");
	return $query->result();
   }
   public function getlastboxcode()
   {
   	$query=$this->db->query("select max(id) as id from boxstock");
	$res=$query->result();
	if(!empty($res) && isset($res))
	{
		foreach($res as $rw)
		{
			$id=$rw->id;
		}
		$quer=$this->db->query("select * from boxstock where id='".trim($id)."'");
		$rest=$quer->result();
		if(!empty($rest)){
			foreach($rest as $row)
			{
				$bxcod=$row->boxcode;
			}
		}
	}
	if(isset($bxcod) && !empty($bxcod))
	{
		$bxcod=intval(substr($bxcod,-4));
		$newbxcod=$bxcod+1;
		$newbxcode2=str_pad($newbxcod,4,"0",STR_PAD_LEFT);
		$bxcodnew="BOXCODE".$newbxcode2;
		
	}else{
		$bxcodnew="BOXCODE0001";
	}
	return $bxcodnew;
	
   }
   
   
	
}