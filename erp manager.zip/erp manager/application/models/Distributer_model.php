<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Distributer_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getalldistributer()
	{
		$query=$this->db->query("select * from clientmaster order by id desc");
		return $query->result();
	}
	public function getlastid()
	{
		$query=$this->db->query("select max(id) as id from clientmaster");
		$res=$query->result();
		foreach($res as $row)
		{
			$id=$row->id;
		}
		return $id;
	}
	public function getcountry()
	{
		$query=$this->db->query("select * from countrylist order by name asc");
		return $query->result();
	}
	public function saveclentdetails($data_array)
	{
		$getr=$this->db->insert('clientmaster',$data_array);
		if($getr==TRUE)
		{
			return 1;
		}else{
			return 2;
		}
	}
	public function getstatename($country)
	{
		$query=$this->db->query("select * from state order by statename asc");
		return $query->result();
	}
	public function getditr($id)
	{
		$query=$this->db->query("select * from clientmaster where id='".trim($id)."'");
		return $query->result();
	}
	public function updatedistributer($data_array,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("clientmaster",$data_array);
	}
	public function delete_distr($id)
	{
		$this->db->where("id",$id);
		$this->db->delete("clientmaster");
	}
	public function getcustomertyp()
	{
		$query=$this->db->query("select * from customertype ");
		return $query->result();
	}
	public function get_cnflistmodel($ctyp)
  {
  	$query=$this->db->query("select distinct(compname) as compname from clientmaster where ucase(custtype)='CNF'");
	return $query->result();
	
  }
  public function get_dealer($cnf)
  {
  	$query=$this->db->query("select distinct(compname) as compname from clientmaster where custtype='DEALER' and cnf='".trim(strtoupper($cnf))."' ");
  	//echo"select distinct(compname) as compname from clientmaster where custtype='DEALER' and cnf='".trim(strtoupper($cnf))."' ";
  	return $query->result();
  }
}