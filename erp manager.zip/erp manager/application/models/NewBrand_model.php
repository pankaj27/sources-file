<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class NewBrand_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getModelCode()
	{
		$query=$this->db->query("select max(id) as id from productmaster");
		return $query->result();
	}
	public function save_stock($data_array)
	{
		$this->db->insert('productmaster',$data_array);
	}
	public function fetchmodel()
	{
	   $query=$this->db->query("select * from productmaster order by id desc");
	   return $query->result();
	}
	public function fetchModelEntry($id1)
	{
		$query=$this->db->query("select * from productmaster where id=".trim($id1)."");
	   return $query->result();
	}
	public function updatNewEnrey($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('productmaster', $data_array);
	}
	public function deleteModelEntry($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('productmaster');
	}
	
	                    //////................................................../////
	
	public function getabc()
	{
		$query=$this->db->query("select max(id) as id from materiel_master");
		
	$s= $query->result();
	foreach($s as $row){
		$id=$row->id;
	}
	$query1=$this->db->query("select * from materiel_master where id='".trim($id)."'");
	return $query1->result();
	
	}
	public function getPartsCode()
	{
		$query=$this->db->query("select max(id) as id from materiel_master");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $rowmaterial)
			{
				$id=$rowmaterial->id;
			}
		}
		if(isset($id) && !empty($id))
		{
			$query2=$this->db->query("select * from materiel_master where id='".trim($id)."'");
			$resl=$query2->result();
			foreach($resl as $rowsl)
			{
				$prid=$rowsl->materiel_id;
			}
			$prid=$prid;
		}else{
			$prid="GKPC00000";
		}
		return $prid;
	
	}
	public function saveSpareParts($data_array)
	{
		$this->db->insert('materiel_master',$data_array);
	}
	public function savespecification($data_array2)
	{
		$this->db->insert('spareparts_specification',$data_array2);
	}
	public function fetchSpareParts()
	{
		$query=$this->db->query("select * from materiel_master");
	   return $query->result();
	}
	public function editSpareParts($id1)
	{
		$query=$this->db->query("select * from materiel_master where id=".trim($id1)."");
		
	   return $query->result();
	}
	public function fetchSpecific($id1)
	{
		$query=$this->db->query("select * from spareparts_specification where productid=".trim($id1)."");
	   return $query->result();
	}
	public function updatespecification ($data_array,$partsCode)
	{
		$this->db->where('id',$partsCode);
		$this->db->update('spareparts_specification', $data_array);
	}
	
	public function updateSpareParts($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('materiel_master', $data_array);
	}
	public function deleteSpareParts($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('materiel_master');
	}
	public function deletespec($speid)
	{
		$query=$this->db->query("delete from spareparts_specification where id=".trim($speid)."");
		if($query==true)
		{
			return 1;
		}
		else{
			return 0;
		}
		//echo "delete from spareparts_specification where id='".trim($speid)."'";
		
		//return $res;
	}
	public function fetchallmodel()
	{
		$query=$this->db->query("select distinct(productname) as productname from productmaster");
		return $query->result();
	}
	public function checkmodelexist($mopdel)
	{
		$query=$this->db->query("select * from productmaster where productname ='".trim($mopdel)."'");
		return $query->result();
	}
	public function getlastpartsid($modl)
	{
		$query=$this->db->query("select max(id) as id from materiel_master");
		$res=$query->result();
		foreach($res as $row)
		{
			$id=$row->id;
		}
		if(!empty($id)){
		$query2=$this->db->query("select * from materiel_master where id='".trim($id)."' ");
		$resul=$query2->result();
		foreach($resul as $row2s){
			$partsid=$row2s->materiel_id;
		}
		
		}else{
			$partsid="";
		}
		return $partsid;
	}
	public function fetallcommonparts()
	{
		$query=$this->db->query("select * from allspareparts");
		return $query->result();
	}
	public function getpatsexist($model,$partsname,$partsunit)
	{
		$query=$this->db->query("select * from materiel_master where ucase(materialname)='".trim(strtoupper($partsname))."' and unit='".trim($partsunit)."' and  ucase(mName)='".trim(strtoupper($model))."'");
		return $query->result();
		
	}
	public function savepartscode($dataarray)
	{
		$query=$this->db->insert('materiel_master',$dataarray);
	}
	public function updatepartsrecords($dataarray,$model,$partsname,$partsunit)
	{
		$query=$tis->db->where(array(""));
	}
	public function gellaprtsbymodel($modl)
	{
		$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($modl))."'");
		return $query->result();
	}
	public function saveprtsspef($data_array)
	{
		$this->db->insert("spareparts_specification",$data_array);
	}
	public function updateprtscode($dataarray,$prtsmid)
	{
		$this->db->where("id",$prtsmid);
		$this->db->update("materiel_master",$dataarray);
	}
	public function checkspecf($prtsmid,$partscode,$specf)
	{
		$query=$this->db->query("select * from spareparts_specification where productid='".trim($prtsmid)."' and parts_id='".trim($partscode)."' and specification='".trim($specf)."'");
		return $query->result();
	}
	public function updateprtsspef($data_array,$prtsmid,$partscode,$specf)
	{
		$dataarra=array("productid"=>$prtsmid,"parts_id"=>$partscode,"specification"=>$specf);
		$this->db->where($dataarra);
		$this->db->update("spareparts_specification",$data_array);
	}
	//update on 24012017
	public function getlastModelCode()
	{
		$query=$this->db->query("select max(id) as id from productmaster ");
		$result=$query->result();
		if(!empty($result) && isset($result))
		{
			foreach($result as $row)
			{
				$id=$row->id;
			}
		}
		if(isset($id) && !empty($id))
		{
			$query2=$this->db->query("select * from productmaster where id='".trim($id)."'");
			$respl=$query2->result();
			foreach($respl as $rowpr)
			{
				$resul=$rowpr->productid;
			}
			$resul=$resul;
		}else{
			$resul="GKPR00000";
		}
		return $resul;
	}
}