<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pricing_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getmodel()
	{
		$query=$this->db->query("select * from productmaster");
		return $query->result();
	}
	public function saveprice($data_array,$mName)
	{
		$this->db->where('productname', $mName);
		$this->db->update('productmaster', $data_array);
	}
	
	public function fetchprice1($id1)
	{
		$query=$this->db->query("select * from productmaster where id=".trim($id1)."");
		return $query->result();
	}
	public function updateprice($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('productmaster', $data_array);
	}
	public function deleteprice($data_array,$id1)
	{
		$this->db->where('id', $id1);
		$this->db->update('productmaster', $data_array);
	}
	
	
	public function fetchparts($mName)
	{
		$query=$this->db->query("select * from materiel_master where mName='".trim($mName)."'");
		return $query->result();
	}
	public function savesparepartsprice($data_array,$spareparts)
	{
		$this->db->where('materiel_id', $spareparts);
		$this->db->update('materiel_master', $data_array);
	}
	public function fetchspareparts()
	{
		$query=$this->db->query("select * from materiel_master order by id desc");
		return $query->result();
	}
	public function fetchspareparts1($id1)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($id1)."'");
		return $query->result();
	}
	public function deletespareparts($data_array,$id1)
	{
		$this->db->where('id', $id1);
		$this->db->update('materiel_master', $data_array);
	}
	public function fetchfixprce()
	{
		$query=$this->db->query("select * from finalorder  order by id desc limit 1");
		return $query->result();
	}
//########################################################################################    Manage Price Model   //////////////////////////////
	public function updatepriceingdetails($model,$dataarray)
	{
		$this->db->where("productname",$model);
		$this->db->update("productmaster",$dataarray);
	}
	public function fetchprice()
	{
		$query=$this->db->query("select * from productmaster order by id desc");
		return $query->result();
	}
	public function getmodelpr($id)
	{
		$quwry=$this->db->query("select * from  productmaster where id='".trim($id)."'");
		return $quwry->result();
	}
	public function updatemodelpr($rowid,$dataarray)
	{
		$this->db->where("id",$rowid);
		$this->db->update("productmaster",$dataarray);
	}
	public function getpartsdetails($model)
	{
		$query=$this->db->query("select * from materiel_master where ucase(mName)='".trim(strtoupper($model))."'");
		return $query->result();
	}
//##########################  update on 28122016  #####################

	public function updatesparepartsprice($data_array,$partsid)
	{
		$this->db->where("id",$partsid);
		$this->db->update("materiel_master",$data_array);
		
	}
	public function getallspareprtprice()
	{
		$query=$this->db->query("select * from  materiel_master ");
		return $query->result();
	}
	public function getpartpr($id)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($id)."'");
		return $query->result();
	}
	public function updateprtindi($rowid,$dataarray)
	{
		$this->db->where("id",$rowid);
		$this->db->update("materiel_master",$dataarray);
	}
	
	
	
	
	
	
	
	
	
}