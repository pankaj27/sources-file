<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_hr_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getalldepartments()
	{
		$query=$this->db->query("select * from departments order by name asc");
		return $query->result();
	}
	public function gettemp_empcode()
	{
		$query=$this->db->query("select max(id) as id from ofer_letter ");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $row)
			{
				$id=$row->id;
			}
			$qr=$this->db->query("select * from ofer_letter where id='".trim($id)."' ");
			$rest=$qr->result();
			if(!empty($rest) && isset($rest))
			{
				foreach($rest as $ro)
				{
					$tempcode=$ro->temp_id;
				}
			}
		}
		if(isset($tempcode) && !empty($tempcode))
		{
			$tempcode_2=intval(substr($tempcode,-4));
			$temne=$tempcode_2+1;
			$temn=str_pad($temne,4,"0",STR_PAD_LEFT);
			$newtemid="EMPTEMPID".$temn;
		}
		else {
			$newtemid="EMPTEMPID0001";
		}
	     return $newtemid ;
	}
	public function getoferleter()
	{
		$query=$this->db->query("select * from  ofer_letter order by id desc ");
		return $query->result();
	}
	public function save_offerletter($data_array)
	{
		$this->db->insert('ofer_letter',$data_array);
	}
	public function getdetail_offerletter($id)
	{
		$query=$this->db->query("select * from ofer_letter where id='".trim($id)."'");
		return $query->result();
	}
	public function update_offerletter($data_array,$recordid)
	{
		$this->db->where("id",$recordid);
		$this->db->update('ofer_letter',$data_array);
	}
	public function delete_offerletter($recordid)
	{
		$query=$this->db->query("delete from ofer_letter where id='".trim($recordid)."'");
	}
	public function getdesigname($desg)
	{
		$query=$this->db->query("select * from designation where id='".trim($desg)."'");
		$query1=$query->result();
		if(!empty($query1))
		{
			foreach($query1 as $ro)
			{
				$deshg=$ro->designation;
			}
		}
		return $deshg;
	}
	public function update_mailsentst($data_st,$id)
	{
		$this->db->where('id',$id);
		$this->db->update('ofer_letter',$data_st);
	}
	public function getdesignation()
	{
		$query=$this->db->query("select * from designation order by designation asc");
		return $query->result();
	}
	//-----------------------------------------------------------------------------
	//                         Update on 16022016
	//-----------------------------------------------------------------------------
	public function getallemplist()
	{
		$query=$this->db->query("select * from salesman where ucase(desig)='SALES HEAD'");
		return $query->result();
	}
	public function getalldesig()
	{
		$query=$this->db->query("select * from designation order by designation");
		return $query->result();
	}
	public function getallemp_list($desig)
	{
		$query=$this->db->query("select * from salesman where ucase(desig)='".trim(strtoupper($desig))."'" );
		return $query->result();
	}
	public function getall_salesex($empcod)
	{
		$query=$this->db->query("select * from salesman where hod='".trim($empcod)."' and  ucase(desig)='SALES EXECUTIVE'");
		//echo "select * from salesman where hod='".trim($empcod)."' and  ucase(desig)='SALES EXECUTIVE'";
		
		return $query->result();
	}
	public function get_allsalesex($empcod)
	{
		$query=$this->db->query("select * from salesman where hod='0' and hod!='".trim($empcod)."' and ucase(desig)='SALES EXECUTIVE'");
		return $query->result();
	}
	public function getallsalesexecu($emphd)
	{
		$query=$this->db->query("select * from salesman where hod='".trim($emphd)."' and  ucase(desig)='SALES EXECUTIVE'");
		return $query->result();
		
	}
	public function update_sale_hd($data_arr,$execitive)
	{
		$this->db->where('id',$execitive);
		$this->db->update('salesman',$data_arr);
	}
	public function getallsalesexcu()
	{
		$query=$this->db->query("select * from salesman where ucase(desig)='SALES EXECUTIVE' order by name asc ");
		return $query->result();
	}
	public function getall_emplist()
	{
		$query=$this->db->query("select * from salesman order by name asc");
		return $query->result();
	}
	public function getpaysllepdata($empid,$monthcode,$yr)
	{
		$query=$this->db->query("select * from payslip_generate where empid='".trim($empid)."' and mnthcode='".trim($monthcode)."' and yrcode='".trim($yr)."'");
		return $query->result();
	}
	public function save_paysleep_data($data_array)
	{
		$this->db->insert('payslip_generate',$data_array);
	}
	public function getallpayslip()
	{
		$query=$this->db->query("select distinct(empid) as empid  from payslip_generate order by id desc ");
		return $query->result();
	}
	public function update_payslip($data_array,$empid)
	{
		$this->db->where('id',$empid);
		$this->db->update('payslip_generate',$data_array);
	}
	public function getmonthlist($hr)
	{
		$query=$this->db->query("select distinct(mnthcode) as mnth from payslip_generate where yrcode='".trim($hr)."'");
		//echo "select distinct(mnthcode) as mnth from payslip_generate where yrcode='".trim($hr)."'";
		return $query->result();
	}
	public function getall_data($empid,$month,$year)
	{
		$query=$this->db->query("select * from payslip_generate where id='".trim($empid)."' and mnthcode='".trim($month)."' and yrcode='".trim($year)."' ");
		return $query->result();
	}
	
  
 }