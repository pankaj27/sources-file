<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_report_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getallsalesamn()
	{
		$query=$this->db->query("select * from salesman where ucase(deprts)= 'SALES'");
		return $query->result();
	}
	public function fetchmonth($month)
	{
		$query=$this->db->query("select * from month where month_name='$month'");
		return $query->result();
	}
	public function terget($monthcd,$year)
	{
		$query=$this->db->query("select * from sales_terget where monthcode='$monthcd' and yearcode='$year'");
		return $query->result();
	}
	
 }