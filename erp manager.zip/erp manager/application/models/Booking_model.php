<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Booking_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getmodelmrprice($model)
	{
		$query=$this->db->query("select mainpr from productmaster where ucase(productname)='".trim(strtoupper($model))."'");
		return $query->result();
	}
	public function getexcise()
	{
		$query=$this->db->query("select exciswamnt,vatamnt,cstamnt from taxationdetails");
		return $query->result();
	}
	public function getallbankdetails()
	{
		$query=$this->db->query("select * from banklist order by bank_name asc");
		return $query->result();
	}
	public function savereatsilbooking($data_arraysave)
	{
		$this->db->insert("bookingorder",$data_arraysave);
	}
	public function savecustdata($data_array_custsave)
	{
		$query=$this->db->insert("clientmaster",$data_array_custsave);
	}
	public function savemaintransaction($data_array_transaction)
	{
		$this->db->insert("transection_master_acount",$data_array_transaction);
	}
	public function getdistinctbookinglist($bkid)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($bkid)."'");
		return  $query->result();
	}
	public function getbuyerdetail($cltid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($cltid)."'");
		return $query->result();
	}
	public function getmodelsdetails()
	{
		$query=$this->db->query("select * from productmaster where status='0'");
		return $query->result();
	}
	public function get_material()
	{
		$query=$this->db->query("select materiel_id, qnty,reorderlevel,qnty-reorderlevel as diff,materiel_id,materialname,id from materiel_master order by diff asc ");
		return $query->result();
	}
	public function getall_colorcode()
	{
		$query=$this->db->query("select * from color_code");
		return $query->result();
	}
	public function getallproduct()
	{
		$query=$this->db->query("select * from productmaster where status=0");
		return $query->result();
	}
	public function getcustomername($user)
	{
		$query=$this->db->query("select * from clientmaster where sname='".trim($user)."'");
		return $query->result();
	}
	public function getsearchdata($user,$term)
	{
		$query=$this->db->query("select * from clientmaster where (clientid like '%".trim($term)."%' or name like '%".trim($term)."%' or compname like '%".trim($term)."%' or email like '%".trim($term)."%')and sname='".trim($user)."' ");
		return $query->result();
	}
	public function getexciseduty()
	{
		$query=$this->db->query("select * from productmaster  limit 1");
		$res=$query->result();
		foreach($res as $row)
		{
			$excise=$row->excise;
		}
		return $excise;
	}
	public function getvatpercent($vat)
	{
		$query=$this->db->query("select * from productmaster  limit 1");
		$res=$query->result();
		foreach($res as $row)
		{
			$vatp=$row->vat;
		}
		return $vatp;
		
	}
	public function getcstpercent($vat)
	{
		$query=$this->db->query("select * from productmaster  limit 1");
		$res=$query->result();
		foreach($res as $row)
		{
			$vatp=$row->cst;
		}
		return $vatp;
	}
	public function getallmodel()
	{
		$query=$this->db->query("select * from productmaster");
		return $query->result();
	}
	public function getcustdetails($email)
	{
		
		$query=$this->db->query("select * from clientmaster where (email='".trim($email)."' or clientid ='".trim($email)."' or name='".trim($email)."' or compname='".trim($email)."')");
		//echo "select * from clientmaster where (email='".trim($email)."' or clientid ='".trim($email)."' or name='".trim($email)."' or compname='".trim($email)."')";
		//$query=$this->db->query("select * from clientmaster where clientid ='".trim($email)."'");
		return $query->result();
	}
	public function getspecification($specid)
	{
		$query=$this->db->query("select * from spareparts_specification where id='".trim($specid)."' ");
		return $query->result();
	}
	public function get_alldetails($id)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($id)."' ");
		return $query->result();
	}
	public function getparts_sort_by_modelname($modelname)
	{
		$query=$this->db->query("select materiel_id,qnty,reorderlevel,dispr,qnty-reorderlevel as diff,materiel_id,materialname,id from materiel_master where mName='".trim($modelname)."' order by diff asc ");
		return $query->result();
	}
	public function getspecifbypartsid($partsid)
	{
		$query=$this->db->query("select * from spareparts_specification where parts_id='".trim($partsid)."'");
		return $query->result();
	}
	public function getbookingid()
	{
		$query=$this->db->query("select max(id) as bkid from bookingorder");
		$res=$query->result();
		foreach($res as $row)
		{
			$bkid=$row->bkid;
		}
		$query=$this->db->query("select * from bookingorder where id='".trim($bkid)."'");
		$res2=$query->result();
		foreach($res2 as $row)
		{
			$bkid2=$row->bokingid;
		}
		return $bkid2;
	}
	public function getpartsname($particular)
	{
		$query=$this->db->query("select * from materiel_master where materiel_id='".trim($particular)."'");
		return $query->result();
	}
	public function savebkorder($data_aray)
	{
		$this->db->insert('bookingorder',$data_aray);
	}
	public function getorderlist_all($dat)
	{
		$query=$this->db->query("select * from bookingorder where doe like '%".trim($dat)."%'");
		return $query->result();
	}
	public function getorderlist_pending($dat)
	{
		$query=$this->db->query("select * from bookingorder where doe like '%".trim($dat)."%' and paymentstatus='0'and stockstatus='0' ");
		return $query->result();
	}
	public function getorderlist_approve($dat)
	{
		$query=$this->db->query("select * from bookingorder where doe like '%".trim($dat)."%' and paymentstatus='1'and stockstatus='1' ");
		return $query->result();
	}
	public function getcustnam($custid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($custid)."'");
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			foreach($res as $row1)
			{
				$custnme=$row1->compname;
					$custname=$row1->name;
					$cutyp=$row1->custtype;
					if(strtoupper($cutyp)=="RETAILER")
					{
						$custnme=$custname;
					}else{
						$custnme=$custnme."($custname)";
					}
			}
		}
		if(isset($custnme) && !empty($custnme))
		{
			$custnme=$custnme;
		}else{
			$custnme="";
		}
		return $custnme;
		
	}
	public function getallbookingdeta_ils($bkid)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($bkid)."'");
		return $query->result();
		
	}
	public function getall_modellist()
	{
		$query=$this->db->query("select * from productmaster order by productname asc ");
		return $query->result();
	}
	public function getware_house()
	{
		$query=$this->db->query("select * from godown order by gdname asc");
		return $query->result();
	}
	public function get_update_booking_order($data_array_update_booking_order,$bkid)
	{
		$this->db->where('id',$bkid);
		$this->db->update('bookingorder',$data_array_update_booking_order);
	}
	public function getstovkcode_bookivgid_exist($bkid,$wrhcod)
	{
		$query=$this->db->query("select * from  warehousewise_order where bkid='".trim($bkid)."' and wrehsecode='".trim($wrhcod)."'");
	}
	public function getlaststockcode()
	{
		$query=$this->db->query("select max(id) as id from warehousewise_order");
		$res=$query->result();
		if(!empty($res))
		{
			foreach($res as $row)
			{
				$id=$row->id;
			}
			$qr=$this->db->query("select * from warehousewise_order where id='".trim($id)."'");
			$res2=$qr->result();
			foreach($res2 as $rew)
			{
				$stockid=$rew->stockcode;
			}
		}
		if(isset($stockid) && !empty($stockid))
		{
			$stockcode=intval(substr($rew->stockcode,-4));
			$newstoc=$stockcode+1;
			$new_cod=str_pad($newstoc, 4,"0",STR_PAD_LEFT);
			$newcod="STCODE".$new_cod;
		}else
			{
				$newcod="STCODE0001";	
				
			}
			return $newcod;
	}
	public function save_wareorder_list($data_array_stock_warehousecode)
	{
		$this->db->insert("warehousewise_order",$data_array_stock_warehousecode);
	}
	public function getmodelcode($modelcode)
	{
		$query=$this->db->query("select * from productmaster where productname='".trim($modelcode)."'");
		$res=$query->result();
		foreach($res as $modelcode);
		{
			$cod=$modelcode->id;
		}
		return $cod;
	}
	
 }