<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function gettaxinfo()
	{
		$query=$this->db->query("select distinct(invoiceno) as invoice from invoicegenerate where taxstatus='0' and gtotal>0 ");
		return $query->result();
		
	}
	public function getallbavkdetails()
	{
		$query=$this->db->query("select distinct(bankname) as bankname from  bankinformation");
		return $query->result();
	}
	public function getallaccno($bank)
	{
		$query=$this->db->query("select distinct(accno) as accno from bankinformation where ucase(bankname)='".trim(strtoupper($bank))."' ");
		return $query->result();
	}
	public function getaccdetails($accno)
	{
		$query=$this->db->query("select * from bankinformation where accno='".trim($accno)."'");
		return $query->result();
	}
	public function updateexcisestatus($invoiceno,$datainvoice)
	{
		$this->db->where("invoiceno",$invoiceno);
		$this->db->update("invoicegenerate",$datainvoice);
	}
	public function getexstatus($invoiceno)
	{
		$query=$this->db->query("select * from invoicegenerate where invoiceno='".trim($invoiceno)."'");
		return $query->result();
	}
	public function getinsertstatus($invoiceno)
	{
		$query=$this->db->query("select * from taxandduties where invoiceno='".trim(strtoupper($invoiceno))."'");
		return $query->result();
	}
	public function savetaxandduty($datatacduyinsert)
	{
		$this->db->insert("taxandduties",$datatacduyinsert);
	}
	public function updatetaxandduty($datatacduyinsert,$invoiceno)
	{
		$this->db->where("invoiceno",$invoiceno);
		$this->db->update("taxandduties",$datatacduyinsert);
	}
	public function getallcashinhandlastbalance()
	{
		$query=$this->db->query("select * from cashinhand");
		return $query->result();
	}
	public function updatecashinhand($data_array_cashinhand)
	{
		$this->db->update("cashinhand",$data_array_cashinhand);
	}
	public function getlasttransbalance()
	{
		$query=$this->db->query("select * from cashinhandtransaction order by id desc limit 1");
		return $query->result();
	}
	public function getbalancetransupdate($data_array_trans)
	{
		$this->db->insert("cashinhandtransaction",$data_array_trans);
	}
	public function getallbank($accno)
	{
		$query=$this->db->query("select * from bankinformation where accno='".trim($accno)."'  ");
		return $query->result();
	}
	public function updatecashinbank($data_array_cashinbank,$accno)
	{
		$this->db->where("accno",$accno);
		$this->db->update("bankinformation",$data_array_cashinbank);
	}
	public function getlastbanktransbalance($accno)
	{
		$query=$this->db->query("select * from banktransaction where accno='".trim($accno)."' order by id desc limit 1");
		return $query->result();
	}
	public function getbankbalancetransupdate($data_array_trans)
	{
		$this->db->insert("banktransaction",$data_array_trans);
	}
	public function getpaidtax()
	{
		$query=$this->db->query("select * from taxandduties order by  doe desc");
		return $query->result();
	}
	//update on 22012017
	public function getallcnfcust()
	{
		$query=$this->db->query("select * from clientmaster where ucase(custtype)='CNF' order by compname asc");
		return $query->result();
		
	}
	public function getalldealercust()
	{
		$query=$this->db->query("select * from clientmaster where ucase(custtype)='DEALER' order by compname asc");
		return $query->result();
	}
	public function getallsubdealercust()
	{
		$query=$this->db->query("select * from clientmaster where ucase(custtype)='SUB-DEALER' order by compname asc");
		return $query->result();
	}
	public function getallretailcust()
	{
		$query=$this->db->query("select * from clientmaster where ucase(custtype)='RETAILER' order by compname asc");
		return $query->result();
	}
	public function getalltransactiondetails($id)
	{
		$query=$this->db->query("select * from clientmaster where ucase(clientid)='".trim(strtoupper($id))."'");
		return $query->result();
	}
	//update on 24012017
	public function getalldatasupplier()
	{
		$query=$this->db->query("select * from venderslist order by vcompany asc");
		return $query->result();
	}
	public function getalltransactionsupply($id)
	{
		$query=$this->db->query("select * from venderslist where ucase(vender_id)='".trim(strtoupper($id))."'");
		return $query->result();
	}
    public function getpurpose()
	{
		$query=$this->db->query("select * from paymentpurpose order by purpose asc");
		return $query->result();
	}
	public function getbankdetails()
	{
		$query=$this->db->query("select distinct(bankname) as bankname from bankinformation order by bankname asc");
		return $query->result();
	}
	 public function getacc_no($bankname)
	 {
	 	$query=$this->db->query("select * from bankinformation where ucase(bankname)='".trim(strtoupper($bankname))."'");
		return $query->result();
	 }
	 public function gettdsdetails()
	 {
	 	$query=$this->db->query("select tdsamnt as tds from taxationdetails");
		$res=$query->result();
		foreach($res as $row)
		{
			$tds=$row->tds;
		}
		return $tds;
	 }
	 public function getcashinhand()
	 {
	 	$query=$this->db->query("select * from cashinhand");
		return $query->result();
	 }
	 public function cashinhandupdate($data_array_cash)
	 {
	 	$this->db->update("cashinhand",$data_array_cash);
	 }
	 public function getcashinhandtran()
	 {
	 	$query=$this->db->query("select * from cashinhandtransaction order by id desc limit 1");
	 	return $query->result();
	 }
	 public function cashinhnstraninsert($data_array_cashinhndtransc)
	 {
	 	$this->db->insert("cashinhandtransaction",$data_array_cashinhndtransc);
	 }
	 public function savetransactiontds($data_tdspay)
	 {
	 	$this->db->insert("tdspay",$data_tdspay);
	 }
	 public function savebanktempdata($data_banksave)
	 {
	 	$this->db->insert("pvoucher",$data_banksave);
	 }
	 public function getunpaidtds()
	 {
	 	$query=$this->db->query("select * from tdspay where (status=0 or status=1)  order by doe desc");
		return $query->result();
	 }
	 public function paidtds()
	 {
	 	$query=$this->db->query("select * from tdspay where status=2 order by doe desc");
		return $query->result();
	 }
	 public function totpaidtds()
	 {
	 	$query=$this->db->query("select * from tdspay where status=2");
		$res=$query->result();
		$paidtds=0;
		foreach($res as $rotds)
		{
			$balanc=floatval($rotds->balance);
			$paidtds=floatval($paidtds)+floatval($balanc);
		}
		return $paidtds;
	 }
	 public function totunpaidtds()
	 {
	 	$query=$this->db->query("select * from tdspay where status=0");
		$res=$query->result();
		$paidtds=0;
		foreach($res as $rotds)
		{
			$balanc=floatval($rotds->balance);
			$paidtds=floatval($paidtds)+floatval($balanc);
		}
		return $paidtds;
	 }
	 public function updatetdsamnt($tdsid)
	 {
	 	$query=$this->db->query("update tdspay set status='1' where id='".trim($tdsid)."'");
	 }
	 public function gettemppayment()
	 {
	 	$query=$this->db->query("select * from pvoucher  order by id desc");
		return $query->result();
	 }
	 public function getlastbalance($accno)
	 {
	 	$query=$this->db->query("select * from bankinformation where accno='".trim($accno)."'");
		return $query->result();
	 }
	 public function updatebankmainbalance($data_bankmain,$accno)
	 {
	 	$this->db->where("accno",$accno);
		$this->db->update("bankinformation",$data_bankmain);
	 }
	 public function getlasttransactionbank($accno)
	 {
	 	$query=$this->db->query("select * from banktransaction where accno='".trim($accno)."' order by id desc limit 1 ");
		return $query->result();
	 }
	 public function getlasttrans()
	 {
	 	$query=$this->db->query("select max(id) as id from banktransaction");
		$res=$query->result();
		if(!empty($res) && isset($res))
		{
			foreach($res as $row)
			{
				$id=$row->id;
			}
		}
		if(isset($id) && !empty($id))
		{
			$qry=$this->db->query("select txnno from banktransaction where id='".trim($id)."'");
			$res2=$qry->result();
			foreach($res2 as $rs)
			{
				$txn=$rs->txnno;
			}
			$newtxno=intval(substr($txn,-6));
			$newtxno2=$newtxno+1;
			$newtxno3=str_pad($newtxno2,6,"0", STR_PAD_LEFT);
			$newtx="TXNGK".$newtxno3;
		}else{
			$newtx="TXNGK000001";
		}
		return $newtx;
	 }
	 public function insertbanktransac($data_array_bntran)
	 {
	 	$this->db->insert("banktransaction",$data_array_bntran);
	 }
	 public function updatepvouchertran($data_array_pvoucherupdte,$pvoucherslno)
	 {
	 	$this->db->where('id',$pvoucherslno);
	 	$this->db->update("pvoucher",$data_array_pvoucherupdte);
	 }
	 public function insertapprovevucher($data_pvoucherarray)
	 {
	 	$this->db->insert('pvoucher',$data_pvoucherarray);
	 }
	 public function gettdsserialno($pvoucherslno)
	 {
	 	$query=$this->db->query("select tdsid  from pvoucher where id='".trim($pvoucherslno)."'");
		return $query->result();
		
	 }
	 public function updatetdstab($id)
	 {
	 	$query=$this->db->query("update tdspay set status='2' where id='".trim($id)."'");
	 }
////////////////////////////////////////////////////////////////////  update on 27012017   //////////////////////
    public function purpose_list()
	{
		$query=$this->db->query("select * from payment_purpose order by payment_type asc");
		return $query->result();
	}
	
	public function getcash_hand()
	{	
		$qr=$this->db->query("select * from cashinhand");
		return $qr->result(); /// same as mysql fetch array ///
		
		//$qry=$this->db->query("update cashinhand set closebal= '".trim($amt)."'");
		//return $qry->result();
	}
	
	/*public function updopn($opnbal)
	{
		$query=$this->db->query("update cashinhand set openbal= '".trim($opnbal)."' where id=1" );
		///////////////////////////////////////////////////and openbal= '".trim($opnbal)."'
	}
	
	public function updclos($closbal)
	{
		$query=$this->db->query("update cashinhand set closebal= '".trim($closbal)."' where id=1" );
	}*/
	
	public function updinhand($data_arr)
	{
		$this->db->update("cashinhand",$data_arr);
	}
	
	public function fettrans()
	{
		$lastrow=$this->db->query("select * from cashinhandtransaction order by id desc limit 0,1");
		return $lastrow->result();
	}
	
	public function savetrans($data_array)
	{
		$this->db->insert("cashinhandtransaction",$data_array);
	}
	
	public function insclient($data_set)
	{
		$this->db->insert("clientmaster",$data_set);
	}
	public function savecashreceipt($data_casharray)
	{
		$this->db->insert('transection_master_acount',$data_casharray);
	}
	public function getcashinhad()
	{
		$query=$this->db->query("select * from cashinhand");
		return $query->result();
	}
	public function getalltransaction_day()
	{
		$query=$this->db->query("select distinct(doe) as doe from cashinhandtransaction order by id asc");
		return $query->result();
	}
	public function gettottrans()
	{
		$query=$this->db->query("select * from cashinhandtransaction order by id asc");
		return $query->result();
	}
	public function getminval($d)
	{
		$query=$this->db->query("select min(id) as id from cashinhandtransaction where doe='".trim($d)."'");
		$res=$query->result();
		if(!empty($res)&& isset($res))
		{
			foreach($res as $row)
			{
				$id=$row->id;
			}
			 $id=$id;
		}
		if(isset($id) && !empty($id))
		{
			$id=$id;
		}else{
			$id="";
		}
		return $id;
		
	}
	public function getopenbal($minval)
	{
		$query=$this->db->query("select balance from cashinhandtransaction where id='".trim($minval)."'");
		$res2=$query->result();
		if(!empty($res2))
		{
			foreach($res2 as $row3)
			{
				$openbal=$row3->balance;
			}
		}
		return $openbal;
	}
	public function getclosebal($d)
	{
		$qry2=$this->db->query("select max(id) as id from cashinhandtransaction where doe='".trim($d)."'");
		$res=$qry2->result();
		if(!empty($res)&& isset($res))
		{
			foreach($res as $row)
			{
				$id=$row->id;
			}
			 $id=$id;
		}
		if(isset($id) && !empty($id))
		{
			$id=$id;
		}else{
			$id="";
		}
		return $id;
		
	}
	public function getclose_bal($maxval)
	{
		$query=$this->db->query("select balance from cashinhandtransaction where id='".trim($maxval)."'");
		$res2=$query->result();
		if(!empty($res2))
		{
			foreach($res2 as $row3)
			{
				$openbal=$row3->balance;
			}
		}
		return $openbal;
	}
	public function gettotal_transaction($d)
	{
		$query=$this->db->query("select * from cashinhandtransaction where doe='".trim($d)."' order by id asc");
		return $query->result();
	}
	public function getall_transaction_cashin_hand()
	{
		$query=$this->db->query("select * from cashinhandtransaction order by id asc  ");
		return $query->result();
	}
	public function getall_transaction_cashin_hand_open_close()
	{
		$query=$this->db->query("");
	}
	public function getall_distinctdate()
	{
		$query=$this->db->query("select distinct(doe) as doe from cashinhandtransaction order by id asc");
		return $query->result();
	}
	public function getallaccountno()
	{
		$query=$this->db->query("select distinct(accno) as accno from bankinformation ");
		return $query->result();
	}
	public function gettotalbalance()
	{
		$query=$this->db->query("select distinct(accno) as accno from bankinformation ");
		$res=$query->result();
		$totbal=0;
		if(!empty($res) && isset($res))
		{
			foreach($res as $acc)
			{
				$accno=$acc->accno;
				$gettottalbalnce=$this->db->query("select balance from bankinformation where accno='".trim($accno)."'");
				$gettottalbalnce1=$gettottalbalnce->result();
				foreach($gettottalbalnce1 as $bal)
				{
					$bala=floatval($bal->balance);
					$totbal=floatval($totbal)+floatval($bala);
				}
			}
		}
		return $totbal;
	}
  public function getallbankname()
  {
  	$query=$this->db->query("select distinct(bankname) as bankname from bankinformation ");
	return $query->result();
  }
  public function getalldistinctaccno($bankname)
  {
  	$query=$this->db->query("select distinct(accno) as accno from bankinformation where bankname='".trim($bankname)."' ");
  	//echo "select distinct(accno) as accno from bankinformation where bankname='".trim($bankname)."' ";
  	return $query->result();
  }
  public function getdistinct_date($accno)
  {
  	$query=$this->db->query("select distinct(doe) as doe from banktransaction where accno='".trim($accno)."'");
	return $query->result();
  }
  public function getminbal($accno,$dte)
  {
  	$query=$this->db->query("select min(id) as id from banktransaction where doe='".trim($dte)."' and accno='".trim($accno)."'");
	//echo "select min(id) as id from banktransaction where doe='".trim($dte)."' and accno='".trim($accno)."'";
	$res=$query->result();
	if(!empty($res) && isset($res))
	{
		foreach($res as $rowmin)
		{
			$minid=$rowmin->id;
		}
		
			$getminbl=$this->db->query("select balance from banktransaction where id='".trim($minid)."'");
			//echo "select balance from banktransaction where id='".trim($minid)."'";
			$getminbl=$getminbl->result();
			if(!empty($getminbl) && isset($getminbl))
			{
				foreach($getminbl as $rw)
				{
					$balanc=$rw->balance;
				}
			}
		
	}
	if(isset($balanc) && !empty($balanc))
	{
		$balanc=$balanc;
	}else{
		$balanc="";
	}
	
	/*if(isset($minid) && !empty($minid))
	{
		foreach()
	}*/
	return $balanc;
  }
  public function getmaxbal($accno,$dte)
  {
  	$query=$this->db->query("select max(id) as id from banktransaction where doe='".trim($dte)."' and accno='".trim($accno)."'");
	//echo "select max(id) as id from banktransaction where doe='".trim($dte)."' and accno='".trim($accno)."'";
	$res=$query->result();
	if(!empty($res) && isset($res))
	{
		foreach($res as $rowmin)
		{
			$minid=$rowmin->id;
		}
		
			$getminbl=$this->db->query("select balance from banktransaction where id='".trim($minid)."'");
			$getminbl=$getminbl->result();
			if(!empty($getminbl) && isset($getminbl))
			{
				foreach($getminbl as $rw)
				{
					$balanc=$rw->balance;
				}
			}
	}
	
	if(isset($balanc) && !empty($balanc))
	{
		$balanc=$balanc;
	}else{
		$balanc="";
	}
	return $balanc;
  }
  public function getbank_name($accno)
  {
  	$getbankname=$this->db->query("select * from bankinformation where accno='".trim($accno)."'");
	$getbankname=$getbankname->result();
	//echo "select * from bankinformation where accno='".trim($accno)."'";
     if(!empty($getbankname) && isset($getbankname))
	 {
	 	foreach($getbankname as $rowbnk)
		{
			$bnkname=$rowbnk->bankname;
		}
	 }
	 return $bnkname;
  }
   public function get_transaction_details($accno)
   {
   		$query=$this->db->query("select * from banktransaction where accno='".trim($accno)."' order by id asc");
		return $query->result();
   }
   public function gettotal_transaction_bank($d,$accno)
	{
		$query=$this->db->query("select * from banktransaction where accno='".trim($accno)."' and doe='".trim($d)."' order by id asc");
		return $query->result();
	}
	///31012017
	public function updatecashmanibl($datamainb)
	{
		$this->db->update("cashinhand",$datamainb);
	}
	public function getlast_transaction_cash()
	{
		$query=$this->db->query("select * from cashinhandtransaction order by id desc limit 1");
		return $query->result();
	}
	public function updatecusttran_cash($data_cashtran)
	{
		$this->db->insert("cashinhandtransaction",$data_cashtran);
	}
	public function getoutgoingtax()
	{
		$query=$this->db->query("select * from purchasematerial order by id desc");
		return $query->result();
	}
	public function getaccounthead()
	{
		$query=$this->db->query("select * from accountsgroup order by groupname asc");
		return $query->result();
	}
	public function getallindirectexpence()
	{
		$query=$this->db->query("select * from pvoucher where status='1' order by id desc");
		return $query->result();
		
	}
	public function get_transbyday($d)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1' and doe='".trim($d)."' order by id asc");
		return $query->result();
	}
	public function get_transbyday_direct($d)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1' and doe='".trim($d)."' order by id asc");
		return $query->result();
	}
	public function get_transaction_inderect()
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1'  order by id asc");
		return $query->result();
	}
	public function get_transaction_direct()
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1'  order by id asc");
		return $query->result();
	}
	public function get_transaction_inderect_day($d)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1' and doe='".trim($d)."' order by id asc");
		return $query->result();
	}
	public function get_transaction_direct_day($d)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1' and doe='".trim($d)."' order by id asc");
		return $query->result();
	}
	public function gettrans_dr($indtrns)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1' and purpose like'%".trim($indtrns)."%' order by id asc");
		return $query->result();
	}
	public function gettrans_direct($indtrns)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1' and purpose like'%".trim($indtrns)."%' order by id asc");
		return $query->result();
	}
	public function get_transaction_inderect_individual($prpos)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1' and purpose like'%".trim($prpos)."%'  order by id asc");
		return $query->result();
	}
	public function get_transaction_inderect_day_individual($d,$prpos)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1' and doe='".trim($d)."' and purpose like'%".trim($prpos)."%' order by id asc");
		return $query->result();
	}
	public function get_transbyday_ind($d,$prpos)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='15' and status='1' and doe='".trim($d)."' and purpose like'%".trim($prpos)."%' order by id asc");
		return $query->result();
	}
	public function get_transaction_direct_individual($prpos)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1' and purpose like'%".trim($prpos)."%'  order by id asc");
		return $query->result();
	}
	public function get_transaction_direct_day_individual($d,$prpos)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1' and doe='".trim($d)."' and purpose like'%".trim($prpos)."%' order by id asc");
		return $query->result();
	}
	public function get_transbyday_ind_direct($d,$prpos)
	{
		$query=$this->db->query("select * from pvoucher where ucase(accountgroup)='14' and status='1' and doe='".trim($d)."' and purpose like'%".trim($prpos)."%' order by id asc");
		return $query->result();
	}
################################################################  profit and loss account #######################################
    //indirect expence
    public function getinderctexpenc($date_from,$date_to)
	{
		$query=$this->db->query("select * from pvoucher where doe between '".trim($date_from)."' and '".trim($date_to)."' and accountgroup='15'");
		//print_r("select * from pvoucher where doe between '".trim($date_from)."' and '".trim($date_to)."'");
		return $query->result();
	}
	public function getdistict_indirectexp()
	{
		$query=$this->db->query("select distinct(purpose) as purpos from pvoucher where accountgroup='15'");
		return $query->result();
	}
	public function getdistinct_indirectexpnc($prp)
	{
		$query=$this->db->query("select * from pvoucher where purpose='".trim($prp)."' and accountgroup='15' ");
		$res=$query->result();
		$amnttot=0;
		foreach($res as $rew)
		{
			$amnt=floatval($rew->amnt);
			$amnttot=floatval($amnttot)+floatval($amnt);
		}
		return $amnttot;
	}
	//direct expence  
	public function getderctexpenc($date_from,$date_to)
	{
		$query=$this->db->query("select * from pvoucher where doe between '".trim($date_from)."' and '".trim($date_to)."' and accountgroup='14'");
		//print_r("select * from pvoucher where doe between '".trim($date_from)."' and '".trim($date_to)."'");
		return $query->result();
	}
	public function getdistict_directexp()
	{
		$query=$this->db->query("select distinct(purpose) as purpos from pvoucher where accountgroup='14'");
		return $query->result();
	}
	public function getdistinct_directexpnc($prp)
	{
		$query=$this->db->query("select * from pvoucher where purpose='".trim($prp)."' and accountgroup='14' ");
		$res=$query->result();
		$amnttot=0;
		foreach($res as $rew)
		{
			$amnt=floatval($rew->amnt);
			$amnttot=floatval($amnttot)+floatval($amnt);
		}
		return $amnttot;
	}
	//purchase account details
	public function getcurrent_purchasebillwithouttax($date_from,$date_to)
	{
		$query=$this->db->query("SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and tax1='' and tax2=''");
		//echo "SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and tax1 is null and tax2 is null";
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;$invoic2="";
			foreach($res as $row)
			{
				$invnono=$row->invoiceno;
				
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->gtotal);
					$totam=floatval($totam)+floatval($totamnt);
					$invoic2=$invnono;
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
	}
	public function getcurrent_purchasebillwith_tax($date_from,$date_to)
	{
		$query=$this->db->query("SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and  tax2per='14.5'");
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and ucase(tax2)='VAT' and tax2per='14.5'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;
			foreach($res as $row)
			{
				$invnono=$row->invoiceno;
				$invoic2="";
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->gtotal);
					$totam=floatval($totam)+floatval($totamnt);
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
	}
	public function getcurrent_purchasebillwith_tax_less($date_from,$date_to)
	{
		$query=$this->db->query("SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and  tax2per!='14.5' and tax2per>'0'");
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and ucase(tax2)='VAT' and tax2per='14.5'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;
			foreach($res as $row)
			{
				$invnono=$row->invoiceno;
				$invoic2="";
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->gtotal);
					$totam=floatval($totam)+floatval($totamnt);
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
	}
	//import purcase bill
	public function getcurrent_purchase_import($date_from,$date_to)
	{
		$query=$this->db->query("SELECT *  FROM pi_invoice WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%'");
		//echo "SELECT *  FROM pi_invoice WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%'";
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and ucase(tax2)='VAT' and tax2per='14.5'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;
			foreach($res as $row)
			{
				$invnono=$row->pono;
				$invoic2="";
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->amount);
					$totam=floatval($totam)+floatval($totamnt);
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
	}
	public function getcst_val($date_from,$date_to)
	{
		$query=$this->db->query("SELECT *  FROM invoicegenerate WHERE doissue between '".trim($date_from)."%' and '".trim($date_to)."%' and csttext is not null and ucase(csttext) like '%CST%'");
		//echo "SELECT *  FROM pi_invoice WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%'";
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and ucase(tax2)='VAT' and tax2per='14.5'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;
			foreach($res as $row)
			{
				$invnono=$row->invoiceno;
				$invoic2="";
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->gtotal);
					$totam=floatval($totam)+floatval($totamnt);
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
	}
  public function getvat_sale($date_from,$date_to)
  {
  	$query=$this->db->query("SELECT *  FROM invoicegenerate WHERE doissue between '".trim($date_from)."%' and '".trim($date_to)."%' and csttext is not null and ucase(csttext) like '%VAT%' and csttext like'%14.5%'");
  	//echo "SELECT *  FROM invoicegenerate WHERE doissue between '".trim($date_from)."%' and '".trim($date_to)."%' and csttext is not null and ucase(csttext) like '%VAT%' and csttext like'%14.5%'";
		//echo "SELECT *  FROM pi_invoice WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%'";
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and ucase(tax2)='VAT' and tax2per='14.5'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;
			foreach($res as $row)
			{
				$invnono=$row->invoiceno;
				$invoic2="";
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->gtotal);
					$totam=floatval($totam)+floatval($totamnt);
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
  }
  public function getvat_sale_less($date_from,$date_to)
  {
  	$query=$this->db->query("SELECT *  FROM invoicegenerate WHERE doissue between '".trim($date_from)."%' and '".trim($date_to)."%' and csttext is not null and ucase(csttext) like '%VAT%' and csttext not like'%14.5%'");
  	//echo "SELECT *  FROM invoicegenerate WHERE doissue between '".trim($date_from)."%' and '".trim($date_to)."%' and csttext is not null and ucase(csttext) like '%VAT%' and csttext not like'%14.5%'";
  			//echo "SELECT *  FROM pi_invoice WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%'";
		//echo"SELECT *  FROM purchasematerial WHERE doe between '".trim($date_from)."%' and '".trim($date_to)."%' and status='1' and ucase(tax2)='VAT' and tax2per='14.5'";
		//echo "SELECT *  FROM purchasematerial WHERE CONVERT(DATE, doe, 103) >= '".trim($date_from)."' AND CONVERT(DATE, doe, 103) < '".trim($date_to)."'";
		$res=$query->result();
		if(isset($res) && !empty($res))
		{
			$totam=0;
			foreach($res as $row)
			{
				$invnono=$row->invoiceno;
				$invoic2="";
				if($invnono!=$invoic2)
				{
					$totamnt=floatval($row->gtotal);
					$totam=floatval($totam)+floatval($totamnt);
				}
			}
		}
		if(isset($totam)&& !empty($totam))
		{
			$totam=$totam;
		}else
		{
				$totam="";
		}
		return $totam;
  }
  
 }