<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function gettaxinfo()
	{
		$query=$this->db->query("select distinct(invoiceno) as invoice from invoicegenerate where taxstatus='0' and gtotal>0 ");
		return $query->result();
		
	}
	public function getallbavkdetails()
	{
		$query=$this->db->query("select distinct(bankname) as bankname from  bankinformation");
		return $query->result();
	}
	public function getallaccno($bank)
	{
		$query=$this->db->query("select distinct(accno) as accno from bankinformation where ucase(bankname)='".trim(strtoupper($bank))."' ");
		return $query->result();
	}
	public function getaccdetails($accno)
	{
		$query=$this->db->query("select * from bankinformation where accno='".trim($accno)."'");
		return $query->result();
	}
	public function updateexcisestatus($invoiceno,$datainvoice)
	{
		$this->db->where("invoiceno",$invoiceno);
		$this->db->update("invoicegenerate",$datainvoice);
	}
	public function getexstatus($invoiceno)
	{
		$query=$this->db->query("select * from invoicegenerate where invoiceno='".trim($invoiceno)."'");
		return $query->result();
	}
	public function getinsertstatus($invoiceno)
	{
		$query=$this->db->query("select * from taxandduties where invoiceno='".trim(strtoupper($invoiceno))."'");
		return $query->result();
	}
	public function savetaxandduty($datatacduyinsert)
	{
		$this->db->insert("taxandduties",$datatacduyinsert);
	}
	public function updatetaxandduty($datatacduyinsert,$invoiceno)
	{
		$this->db->where("invoiceno",$invoiceno);
		$this->db->update("taxandduties",$datatacduyinsert);
	}
	public function getallcashinhandlastbalance()
	{
		$query=$this->db->query("select * from cashinhand");
		return $query->result();
	}
	public function updatecashinhand($data_array_cashinhand)
	{
		$this->db->update("cashinhand",$data_array_cashinhand);
	}
	public function getlasttransbalance()
	{
		$query=$this->db->query("select * from cashinhandtransaction order by id desc limit 1");
		return $query->result();
	}
	public function getbalancetransupdate($data_array_trans)
	{
		$this->db->insert("cashinhandtransaction",$data_array_trans);
	}
	public function getallbank($accno)
	{
		$query=$this->db->query("select * from bankinformation where accno='".trim($accno)."'  ");
		return $query->result();
	}
	public function updatecashinbank($data_array_cashinbank,$accno)
	{
		$this->db->where("accno",$accno);
		$this->db->update("bankinformation",$data_array_cashinbank);
	}
	public function getlastbanktransbalance($accno)
	{
		$query=$this->db->query("select * from banktransaction where accno='".trim($accno)."' order by id desc limit 1");
		return $query->result();
	}
	public function getbankbalancetransupdate($data_array_trans)
	{
		$this->db->insert("banktransaction",$data_array_trans);
	}
	public function getpaidtax()
	{
		$query=$this->db->query("select * from taxandduties order by  doe desc");
		return $query->result();
	}
	
 }