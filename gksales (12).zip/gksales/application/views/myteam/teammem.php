<?php //include("connection.php"); ?>
<?php $this->load->view('headercss.php'); ?>

<?php $this->load->view('topnav.php'); ?>
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/starcss/css/style.css">
  
  
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<style>
	h3 {
font-family: Verdana;
color: #2358A0;
}
h2 {
font-family: Verdana;
color: #2D9C1C;
}
	</style>


		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">My Team</a>
							</li>
							<li class="active">View Members</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						
			<div class="row">
						<div class="tab-pane active" id="first1" style="overflow-y: scroll;">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>SL NO</th>
                <th>EMP ID</th>
                <th>EMP NAME</th>
                <th>EMP DESIGNATION</th>
	            <th>AREA</th>
                <th>CONTACT INFO</th>
                <th>JOINED </th>
		        <th>PERPORMANCE</th>
		        <th>ACTION</th>
            </tr>
        </thead>
        <tbody>
			<?php if(isset($getallsaleexe) && !empty($getallsaleexe)){ $sl=1; ?>
				<?php foreach($getallsaleexe as $row){ ?>
		        <tr>
		        	<td><?php echo $sl; ?></td>
		        	<td><?php echo $row->salesmanid; ?></td>
		        	<td><?php echo $row->name; ?></td>
		        	<td><?php echo $row->desig; ?></td>
		        	<td><?php echo $row->area; ?></td>
		        	<td><?php echo $row->phno; ?></td>
		        	<td><?php echo $row->doe; ?></td>
		        	<td></td>
		        	<td>
		        		<a href="<?php echo base_url(); ?>Sales_head/getdetailsinfo/<?php echo $row->id; ?>" target="_blank"><i class="fa fa-eye" aria-hidden="true"></i></a>
		        	</td>
		        </tr>
	        <?php   $sl++; } } ?>
        </tbody>
    </table>
	
	 
		
				</div>
				</div>
					</div>
										

        <?php $this->load->view('footerjs.php'); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquerymodal/js/jquery.modal.js"></script>

		<script>
  $(function(){
    $("#example").dataTable();
  })
  </script> 
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

 <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
 <script src="<?php echo base_url(); ?>assets/starcss/js/starwarsjs.js"></script> 
 <script>
   $( document ).ready(function() {
   	   $(".datepick").datepicker();
            $('.rate_row').starwarsjs({
                stars : 5,
                count : 1
                
            });
			
			

        });
  </script>
     
	
	</body>
</html>
