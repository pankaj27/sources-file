<?php
  include("connection.php");
  include('smtpmail2/smtpmail/mail.php');
	 $email1=explode(",",$email);
	$cmailcount=count($email1);
	for($i=0;$i<$cmailcount;$i++)
	{
		
		$uid=$this->session->userdata('uid');
		$getemail=mysqli_query($con,"select * from clientmaster where id='".trim($email1[$i])."'");
		//echo "select * from salesman where id='".trim($email1[$i])."'";
		
		$re2=mysqli_fetch_array($getemail);
		$email=$re2['email'];
		$sid=$re2['sid'];
		$getsi=mysqli_query($con,"select * from salesman where id='".trim($sid)."'");
		$re=mysqli_fetch_array($getsi);
		$name=$re['name'];
		$image=$re['image'];
		$desig=$re['desig'];
		$phno=$re['phno'];
		
		$email2=$re['email'];
		$imagepath=base_url()."uploads/Salesman/".$image;
		
	
	$card=$card;
	
	$msg='<!DOCTYPE html>
<html>
<head>
<title>Actor Studio</title>
<!-- Custom Theme files -->
<meta content="text/html;charset=utf-8" http-equiv="content-type"><meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
				

					<link href="https://fonts.googleapis.biz/css?family=Roboto:300,400,500,700" rel="stylesheet"><style type="text/css">
        @charset "utf-8";
        /* Responsive */
        
        body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            -webkit-font-smoothing: ;
        }
        
        div,
        p,
        a,
        li,
        td {
            -webkit-text-size-adjust: none;
        }
        
        img {
            border: 0px;
            outline: none;
            text-decoration: none;
        }
        
        a img {
            border: none;
        }
        
        a {
            color: inherit;
            text-decoration: none;
            text-align: inherit;
        }
        
        .ReadMsgBody {
            width: 100%;
            background-color: #ffffff;
        }
        
        .ExternalClass {
            width: 100%;
            background-color: #ffffff;
        }
        
        table {
            border-collapse: collapse;
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }
        
        img {
            border: none;
            outline: none;
            text-decoration: none;
            display: block;
        }
        
        p {
            margin: 0;
            padding: 0;
        }
        
        a:hover,
        a:focus,
        a:visited {
            outline: none;
        }
        
        p {
            padding: 0!important;
            margin-top: 0!important;
            margin-right: 0!important;
            margin-bottom: 0!important;
            margin-left: 0!important;
        }
        
        a {
            color: #3498db;
            text-decoration: none;
        }
        
        html {
            width: 100%;
        }
        
        body {
            -webkit-text-size-adjust: none;
            -ms-text-size-adjust: none;
            margin: 0;
            padding: 0;
        }
        
        table {
            border-spacing: 0;
            table-layout: fixed;
            margin: 0 auto;
        }
        
        table table table {
            table-layout: auto;
        }
        
        img {
            display: block !important;
            overflow: hidden !important;
        }
        
        table td {
            border-collapse: collapse;
        }
        
        img[class="img1"] {
            width: 100% !important;
            height: auto !important;
        }
        
        @media only screen and (max-width: 700px) {
            .reduce_height600 {
                height: 50px;
            }
        }
        
        @media only screen and (max-width: 590px) {
            .unsubscribe a {
                color: #eee;
                text-decoration: none;
            }
            table[class="mazik600"] {
                width: 450px !important;
            }
            table[class="mazik1-1"] {
                width: 100% !important;
            }
            .mazik1-1 {
                width: 100% !important;
            }
            table[class="mazik1-2"] {
                width: 50% !important;
            }
            img[class="img1"] {
                width: 100% !important;
                height: auto !important;
            }
            img[class="img70"] {
                width: 70% !important;
                height: auto !important;
            }
            .mobile_center {
                text-align: center !important;
            }
            .mobile_only {
                height: 20px;
                width: 100%;
            }
            .mobile_full {
                width: 100% !important;
            }
        }
        
        @media only screen and (max-width: 479px) {
            table[class="mazik600"] {
                width: 290px !important;
            }
            table[class="mazik1-1"] {
                width: 100% !important;
            }
            table[class="mazik1-2"] {
                width: 100% !important;
            }
            img[class="img1"] {
                width: 100% !important;
                height: auto !important;
            }
            .mobile_center {
                text-align: center !important;
            }
            .header_title1 {
                font-size: 36px !important;
            }
            .header_title2 {
                font-size: 24px !important;
            }

            /* actorstudio specific */
            .mobile_banner {
                font-size: 40px !important;
            }
            .banner_height {
                height: 20px;
            }
            .height_80 {
                height: 80px;
            }

        }
    </style>
				

					<table data-module="G1" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module1.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color:#1f212d; max-width: 800px;" bgcolor="#1f212d" data-bgcolor="Background">
        <tbody>
            <tr>
                <td mc:edit="section_1">
                    <table class="mazik600" style="width: 100%; max-width: 600px;" align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tbody>
                            <tr>
                                <td height="40">
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                        <tbody>
                                            <tr>
                                                <td align="center">
                                                    <table class="mazik1-1" style="width: 151px;" align="left" border="0" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td class="mobile_center" align="center">
                                                                    <table class="mazik1-1" width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="center">
                                                                                    <a href="#" target="_blank" style="text-decoration:none;">
                                                                                        <img editable="true" mc:edit="logo" alt="logo" align="center" style="display: block;" width="128" height="23" src="http://www.actorstudio.biz/studio/images/Event PlannerW.png">
                                                                                    </a>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>            
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <!-- MENUS -->
                                                    <table class="mazik1-1" width="25" height="25" align="left" border="0" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="25" height="25" align="center">
                                                                    
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                    <table class="mazik1-1" align="right" border="0" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td height="5"></td>
                                                            </tr>
                                                            <tr>
                                                                <td align="center" style="font-family: Roboto, sans-serif;">
                                                                    <singleline><a mc:edit="01" href="#" data-color="menu" data-size="menu" data-min="16" data-max="20" style="font-size: 16px; color:#9d9fa8; text-decoration: none; font-weight:400; ">About</a></singleline>
                                                                </td>
                                                                <td width="25"></td>
                                                                <td align="center" style="font-family: Roboto, sans-serif;">
                                                                    <singleline><a mc:edit="02" href="#" data-color="menu" data-size="menu" data-min="16" data-max="20" style="font-size: 16px; color:#9d9fa8; text-decoration: none; font-weight:400; ">Service</a></singleline>
                                                                </td>
                                                                <td width="25"></td>
                                                                <td align="center" style="font-family: Roboto, sans-serif;">
                                                                    <singleline><a mc:edit="04" href="#" data-color="menu" data-size="menu" data-min="16" data-max="20" style="font-size: 16px; color:#9d9fa8; text-decoration: none; font-weight:400; ">Contact Us</a></singleline>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <!-- END OF MENUS -->
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td height="40">
                </td>
            </tr>
            <tr>
                <td height="3px;" style="background-color:#67b61f;">
                </td>
            </tr>
        </tbody>
    </table><table data-module="G2" data-thumb="http://www.actorstudio.biz/studio/images/imgweb.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-image: url(&quot;http://www.actorstudio.biz/studio/images/imgweb.jpg&quot;); background-size: cover; background-position: center; background-repeat: no-repeat; max-width:800px;" data-bg="banner-img">
        <tbody><tr>
            <td mc:edit="section_2" style="background-color: rgba(31, 33, 45, 0.60);  width: 100%;">
                <table style="width: 100%; max-width: 800px;" align="center" border="0" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td align="center">
                                <table class="mazik600" align="center" border="0" cellpadding="0" cellspacing="0" width="600">
                                    <tbody>
                                        <tr>
                                            <td class="banner_height" height="155">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="center">
                                                <table align="center" border="0" cellpadding="0" cellspacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td height="38">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="mobile_banner" mc:edit="05" style="font-family: Roboto, sans-serif; font-weight: 700; color: #fff; font-size: 60px;text-align: center; line-height: 54px; letter-spacing: 0.1px;" data-color="banner-title" data-size="banner-title" data-min="40" data-max="60">
                                                                <singleline>Actor Studio <br>Event Planner</singleline>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table align="center" border="0" cellpadding="0" cellspacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td height="40">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td mc:edit="06" align="center" style="font-family: Roboto, sans-serif; color: #fff; font-size:16px;font-weight: 400; line-height: 24px;" data-color="content" data-size="content" data-min="12" data-max="16">
                                                                <span>where great things happens
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="35">
                                                            </td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                                <table style="margin: 0; mso-table-lspace: 0; mso-table-rspace: 0; padding: 0; width: 100%;" cellspacing="0" cellpadding="0" border="0" width="100%" class="mazik1-1">
                                                    <tbody><tr>
                                                        <td align="center" valign="top">
                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" width="180">
                                                                <tbody><tr>
                                                                    <td height="48" style="font-family: Roboto, sans-serif; background:#67b61f; border-radius:3px; font-size: 16px; line-height: 48px; color: #ffffff; text-align:center; font-weight:400; padding: 0 30px;" align="center" data-color="Button" data-size="Button" data-min="16" data-max="32" data-bgcolor="button-bg">

                                                                        <a href="http://www.actorstudio.biz/holiday/services.php" style=" color: #ffffff; display: block;" mc:edit="07">
                                                                            <singleline>Learn More</singleline>
                                                                        </a>

                                                                    </td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr>
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td class="height_80" height="185">
                            </td>
                        </tr>
                        <tr>
                            <td height="3px;" style="background-color:#67b61f;"></td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody></table><table data-module="G3" data-thumb="http://www.actorstudio.biz/images/course/Acting.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-image: url(&quot;http://www.actorstudio.biz/images/course/Acting.jpg&quot;); background-size: cover; background-position: center top; background-repeat: no-repeat; max-width: 800px;" data-bg="banner2-img">
        <tbody><tr>
            <td mc:edit="section_3" style="background-color: rgba(31, 33, 45, 0.60);">
                <table style="width: 100%; max-width: 800px;" align="center" border="0" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td align="center">
                                <table class="mazik600" align="center" border="0" cellpadding="0" cellspacing="0" width="600">
                                    <tbody>
                                        <tr>
                                            <td class="height_80" height="185">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="center">
                                                <table align="center" border="0" cellpadding="0" cellspacing="0">
                                                    <tbody>

                                                        <tr>
                                                            <td mc:edit="08" class="mobile_banner" style="font-family: Roboto, sans-serif; font-weight: 700; color: #fff; font-size: 50px;text-align: left; line-height: 70px; letter-spacing: 0.1px;" data-color="banner-title" data-size="banner-title" data-min="40" data-max="70">
                                                                <singleline> About Us</singleline>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="50px" align="left">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table style="margin: 0; mso-table-lspace: 0; mso-table-rspace: 0; padding: 0; width: 100%;" cellspacing="0" cellpadding="0" border="0" width="100%" class="mazik1-1">
                                                    <tbody><tr>
                                                        <td align="left" valign="top">
                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="180">
                                                                <tbody><tr>
                                                                    <td height="48" style="font-family: Roboto, sans-serif; background:#67b61f; border-radius:3px; font-size: 16px; line-height: 48px; color: #ffffff; text-align:center; font-weight:400; padding: 0 30px;" align="center" data-bgcolor="button-bg" data-size="Button" data-min="16" data-max="32">

                                                                        <a mc:edit="09" href="http://www.actorstudio.biz/holiday/services.php" style=" color: #ffffff; display: block;">
                                                                            <singleline>Learn More</singleline>
                                                                        </a>

                                                                    </td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr>
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td class="height_80" height="185">
                            </td>
                        </tr>
                        <tr>
                            <td height="3px;" style="background-color:#67b61f;"></td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>

    </tbody></table><table data-module="G4" data-thumb="http://www.actorstudio.biz/images/course/event1.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-image: url(&quot;http://www.actorstudio.biz/images/course/event1.jpg&quot;); background-size: cover; background-position: center top; background-repeat: no-repeat; max-width: 800px;" data-bg="banner3-img">
        <tbody><tr>
            <td mc:edit="section_4" style="background-color: rgba(31, 33, 45, 0.60);">
                <table style="width: 100%; max-width: 800px;" align="center" border="0" cellpadding="0" cellspacing="0">
                    <tbody>

                        <tr>

                            <td align="center">
                                <table class="mazik600" align="center" border="0" cellpadding="0" cellspacing="0" width="600">
                                    <tbody>
                                        <tr>
                                            <td class="height_80" height="155">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="center">
                                                <table align="center" border="0" cellpadding="0" cellspacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td mc:edit="10" style="font-family: Roboto, sans-serif; font-weight: 300; color: #fff; font-size: 24px; text-align: center; line-height: 30px;" data-size="top-text" data-min="24" data-max="34">
                                                                <singleline> Our Services</singleline>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="3">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td mc:edit="11" class="" style="font-family: Roboto, sans-serif; font-weight: 700; color: #67b61f; font-size: 50px; text-align: center; line-height: 70px;" data-size="Heading" data-min="50" data-max="60">
                                                                <!--<singleline>This is The Green Lab</singleline>-->
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table align="center" border="0" cellpadding="0" cellspacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td height="50">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td mc:edit="12" align="center" style="font-family: Roboto, sans-serif; color: #fff; font-size:16px; line-height: 24px; font-weight: 400; line-height: 22px;" data-color="content" data-size="content" data-min="12" data-max="16">
                                                                <span><multiline>At Actor Studio’s Event Planner we provide solution to our clients for Branding, Media production, Promotion, Model and Celebrity Contract, Revenue Consultancy, International and National events, TVC, copy write, Giggle, Short Films, Line production etc. Keeping in mind our international consulting background we are committed to deliver world class consulting to our clients in terms of Branding and promotion.</multiline>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="50">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table style="margin: 0; mso-table-lspace: 0; mso-table-rspace: 0; padding: 0; width: 100%;" cellspacing="0" cellpadding="0" border="0" width="100%" class="mazik1-1">
                                                    <tbody><tr>
                                                        <td align="center" valign="top">
                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" width="180">
                                                                <tbody><tr>
                                                                    <td height="45" style="font-family: Roboto, sans-serif; background:#67b61f; border-radius:3px; font-size: 16px; line-height: 20px; color: #ffffff; text-align:center; font-weight:400; padding: 0 30px;" align="center" data-size="Button" data-min="16" data-max="32" data-bgcolor="button-bg">

                                                                        <a mc:edit="13" href="http://www.actorstudio.biz/holiday/services.php" style=" color: #ffffff; display: block;">
                                                                            <singleline>Learn More</singleline>
                                                                        </a>

                                                                    </td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr>
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td class="height_80" height="185">
                            </td>
                        </tr>
                        <tr>
                            <td height="3px;" style="background-color:#67b61f;"></td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>

    </tbody></table>
	<table data-module="G5" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module5.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #fff; max-width:800px;" data-bgcolor="BG-color">
        <tbody>

            <tr>
                <td mc:edit="section_5">
                    <table class="mazik600" cellpadding="0" cellspacing="0" align="center" width="600">
                        <tbody>
                            <tr>
                                <td height="60">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="left" width="180">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="center" width="180" style="background-color: #fff;">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center">
                                                                    <img editable="true" mc:edit="14" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/service-icon.png" width="64" alt="service">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="15" align="center" style="color: #2c3e50; font-size: 16px; font-weight: 700; font-family: Roboto, sans-serif; text-align: center; line-height: 24px;" data-size="title" data-min="16" data-max="32">
                                                                    <singleline>EVENT CONCEPTS & MANAGEMENT</singleline>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="12">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="16" style="font-size: 14px; font-family: Roboto, sans-serif; color: #8c91b0; line-height: 24px; font-weight:400; text-align: center;" data-size="Text" data-min="14" data-max="32">
                                                                    <multiline></multiline>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table width="30" cellspacing="0" cellpadding="0" align="left">
                                        <tbody>
                                            <tr>
                                                <td height="5">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="left" width="180">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="left" width="180" style="background-color: #fff;">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center">
                                                                    <img editable="true" mc:edit="17" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/service-icon2.png" width="64" alt="service">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="18" align="center" style="color: #2c3e50; font-size: 16px; font-weight: bold; font-family: Roboto, sans-serif; text-align: center; line-height:  24px;" data-size="title" data-min="16" data-max="32">
                                                                    <singleline>BUDGET DEVELOPMENT</singleline>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="12">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="19" style="font-size: 14px; font-family: Roboto, sans-serif; color: #8c91b0; line-height: 24px; text-align: center;" data-size="Text" data-min="14" data-max="32">
                                                                    <multiline></multiline>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table width="30" cellspacing="0" cellpadding="0" align="left">
                                        <tbody>
                                            <tr>
                                                <td height="5">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="right" width="180">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table cellpadding="0" cellspacing="0" align="center" width="180" style="background-color: #fff;">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center">
                                                                    <img editable="true" mc:edit="20" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/service-icon3.png" width="64" alt="service 3">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="21" align="center" style="color: #2c3e50; font-size: 16px; font-weight: bold; font-family: Roboto, sans-serif; text-align: center;line-height: 24px;" data-size="title" data-min="16" data-max="32">
                                                                    <singleline>EVENT DESIGN & TECHNICAL PRODUCTION</singleline>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="12">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="22" style="font-size: 14px; font-family: Roboto, sans-serif; color: #8c91b0; line-height: 26px; text-align: center;" data-size="Text" data-min="14" data-max="32">
                                                                    <multiline></multiline>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
							<tr>
                                <td>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="left" width="180">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="center" width="180" style="background-color: #fff;">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center">
                                                                    <img editable="true" mc:edit="14" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/service-icon.png" width="64" alt="service">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="15" align="center" style="color: #2c3e50; font-size: 16px; font-weight: 700; font-family: Roboto, sans-serif; text-align: center; line-height: 24px;" data-size="title" data-min="16" data-max="32">
                                                                    <singleline>PRESS EVENTS</singleline>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="12">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="16" style="font-size: 14px; font-family: Roboto, sans-serif; color: #8c91b0; line-height: 24px; font-weight:400; text-align: center;" data-size="Text" data-min="14" data-max="32">
                                                                    <multiline></multiline>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table width="30" cellspacing="0" cellpadding="0" align="left">
                                        <tbody>
                                            <tr>
                                                <td height="5">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="left" width="180">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="left" width="180" style="background-color: #fff;">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center">
                                                                    <img editable="true" mc:edit="17" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/service-icon2.png" width="64" alt="service">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="18" align="center" style="color: #2c3e50; font-size: 16px; font-weight: bold; font-family: Roboto, sans-serif; text-align: center; line-height:  24px;" data-size="title" data-min="16" data-max="32">
                                                                    <singleline>AWARD CEREMONIES</singleline>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="12">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="19" style="font-size: 14px; font-family: Roboto, sans-serif; color: #8c91b0; line-height: 24px; text-align: center;" data-size="Text" data-min="14" data-max="32">
                                                                    <multiline></multiline>
																	<br>
																	<a mc:edit="68" href="#" style=" color: green; display: block; ">
                                                                         <singleline>More.....</singleline>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table width="30" cellspacing="0" cellpadding="0" align="left">
                                        <tbody>
                                            <tr>
                                                <td height="5">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="right" width="180">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table cellpadding="0" cellspacing="0" align="center" width="180" style="background-color: #fff;">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center">
                                                                    <img editable="true" mc:edit="20" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/service-icon3.png" width="64" alt="service 3">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="21" align="center" style="color: #2c3e50; font-size: 16px; font-weight: bold; font-family: Roboto, sans-serif; text-align: center;line-height: 24px;" data-size="title" data-min="16" data-max="32">
                                                                    <singleline>CONFERENCES</singleline>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="12">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td mc:edit="22" style="font-size: 14px; font-family: Roboto, sans-serif; color: #8c91b0; line-height: 26px; text-align: center;" data-size="Text" data-min="14" data-max="32">
                                                                    <multiline></multiline>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td height="60">
                </td>
            </tr>
            <tr>
                <td height="3px;" style="background-color:#67b61f;"></td>
            </tr>
        </tbody>
    </table><table data-module="G6" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module6.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #1f212d; max-width:800px;" data-bgcolor="bg-color" bgcolor="#1f212d">

        <tbody><tr>
            <td mc:edit="section_6">
                <table class="mazik600" align="center" cellpadding="0" cellspacing="0" width="600">
                    <tbody>
                        <tr>
                            <td height="60">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellpadding="0" cellspacing="0" align="left" width="285" style="font-family: Roboto, sans-serif;">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <table>
                                                    <tbody>
                                                        <tr>
                                                            <td height="9">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td mc:edit="23" style="color: #ffffff; font-size: 24px; line-height:24px; font-weight: 500; font-family: Roboto, sans-serif;" data-color="Main-heading" data-size="Main-heading" data-min="24" data-max="32">
                                                                <singleline> About Actor Studio Event Planner</singleline>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="28">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td mc:edit="24" style="color: #ffffff; font-size: 14px; font-family: Roboto, sans-serif; font-weight:400; line-height: 24px;" data-color="content2" data-size="content2" data-min="14" data-max="34">
                                                                <multiline>WE ARE A CARING, LEARNING, ACHIEVING, SHARING AND SOCIALLY RESPONSIBLE ORGANIZATION (CLASS).</multiline>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="10">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table cellpadding="0" cellspacing="0" align="right" width="285">
                                    <tbody>
                                        <tr>
                                            <td align="right">
                                                <img editable="true" mc:edit="25" src="http://www.actorstudio.biz/images/events/RushHour.jpg" alt="img" width="286" height="200">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td height="60">
            </td>
        </tr>
    </tbody></table><table data-module="G7" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module7.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #ffffff; max-width:800px;" bgcolor="#ffffff" data-bgcolor="BG-color">

        <tbody><tr>
            <td mc:edit="section_7">
                <table class="mazik600" align="center" cellpadding="0" cellspacing="0" width="600">
                    <tbody><tr>
                        <td height="55">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table align="center" cellspacing="0" cellpadding="0">
                                <tbody><tr>
                                    <td mc:edit="26" style="color: #797d96; font-size: 14px; font-family: Roboto, sans-serif; font-weight:400; line-height: 24px;" data-color="text2" data-size="text2" data-min="14" data-max="32">
                                        <multiline>At Actor Studio’s Event Planner we provide solution to our clients for Branding, Media production, Promotion, Model and Celebrity Contract, Revenue Consultancy, International and National events, TVC, copy write, Giggle, Short Films, Line production etc. Keeping in mind our international consulting background we are committed to deliver world class consulting to our clients in terms of Branding and promotion.</multiline>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="30">
                                    </td>
                                </tr>
                            </tbody></table>
                            <table align="left" cellpadding="0" cellspacing="0" width="290">
                                <tbody><tr>
                                    <td mc:edit="27" style="color: #797d96; font-size: 14px; font-family: Roboto, sans-serif; font-weight:400; line-height: 24px;" data-color="left-text" data-size="left-text" data-min="14" data-max="32">
                                        <multiline>We are living in an age of unprecedented human progress. What seems impossible one minute is a reality the next. Technology revolutionizes the way we interact with the world, and culture is constantly rewriting the story we tell ourselves. But no matter how drastically the world changes or how fast we progress, we are always human at our very core. We are still essentially emotional creatures who thrive on connection.</multiline>
                                    </td>
                                </tr>
                            </tbody></table>
                            <table align="right" cellpadding="0" cellspacing="0" width="290">
                                <tbody><tr>
                                    <td mc:edit="28" style="color: #797d96; font-size: 14px; font-family: Roboto, sans-serif; font-weight:400; line-height: 24px;" data-color="right-text" data-size="right-text" data-min="14" data-max="32">
                                        <multiline>That’s why we put people at the center of all we do. Of course we’re informed by data, strategic insights, and platform possibilities, but what truly inspires us are the common experiences that bind us all. We let it show. We take our three core practices—strategy and intelligence, marketing and advertising, and platforms and experiences—and harness them to build meaningful human connections in the name of a brand.</multiline>
                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                    </tr>
                </tbody></table>
            </td>
        </tr>
        <tr>
            <td height="55">
            </td>
        </tr>
    </tbody></table>
	<table data-module="G8" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module8.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-image: url(&quot;http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/img29.jpg&quot;); background-size: cover; background-position: center top; background-repeat: no-repeat; max-width: 800px;" bgcolor="#ffffff" data-bg="left-img">
    </table>
	<table data-module="G9" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module9.jpg" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #ffffff; mso-table-lspace: 0; mso-table-rspace: 0; max-width: 800px;" bgcolor="#fff" data-bgcolor="BG-color">
        <tbody><tr>
            <td height="60">
            </td>
        </tr>
        
        <tr>
            <td height="60">
            </td>
        </tr>
        <tr>
            <td height="3px;" style="background-color:#67b61f;"></td>
        </tr>
    </tbody></table>
	
<!----##############################################################  -->
                                        
                                        <table width="30" align="left" border="0" cellpadding="0" cellspacing="0">
                                            <tbody><tr>
                                                <td width="30" height="30"></td>
                                            </tr>
                                        </tbody></table>

                                        
                                    </td>
                                </tr>
                                <!-- links-1 -->
                            </tbody></table>
                        </td>
                        <!-- section -->
                    </tr>
                </tbody></table>
            </td>
        </tr>
        <tr>
            <td height="60">

            </td>
        </tr>
    </tbody></table><table data-module="G29" data-thumb="http://www.actorstudio.biz/studio/images/Event%20Planner.png" align="center" border="0 " cellpadding="0 " cellspacing="0 " width="100% " style="margin:0 auto; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; border: 0px; max-width:800px;" bgcolor="#f1f2f9" data-bgcolor="footer-bg">
        <tbody><tr>
            <td mc:edit="section_29">
                <table width="600" align="center" class="mazik600" border="0 " cellpadding="0 " cellspacing="0 " style="width:600px; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; border: 0px; ">
                    <tbody><tr>
                        <td height="60 ">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table class="mazik1-1" width="285" align="left" border="0" cellpadding="0" cellspacing="0">
                                <tbody><tr>
                                    <td align="left">
                                        <table class="mazik1-1" align="left" border="0" cellpadding="0" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td class="mobile_center " align="left ">
                                                        <a href="# " target="_blank " style="text-decoration:none; ">
                                                            <img editable="true" mc:edit="199" align="left " style="display: block; " width="128 " height="23 " src="http://www.actorstudio.biz/studio/images/Event%20Planner.png" alt="logo2">
                                                        </a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="35 ">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td mc:edit="200" align="left " style="font-family: Roboto, sans-serif; font-size:16px; line-height: 24px; text-decoration: none; color: #83879e; font-weight:400;" data-color="text5" data-size="text5" data-min="16" data-max="32">
                                                        <multiline>AE-37, SALT LAKE CITY, 
SECTOR 1, NEAR TANK NO. 4,
KOLKATA-700064, WEST BENGAL,INDIA</multiline>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody></table>
                            <table width="30" align="left" border="0" cellpadding="0" cellspacing="0">
                                <tbody><tr>
                                    <td width="30" height="30"></td>
                                </tr>
                            </tbody></table>
                            <table class="mazik1-1 " width="185 " align="right " border="0 " cellpadding="0 " cellspacing="0 ">
                                <!-- icons -->
                                <tbody><tr>
                                    <td align="left ">
                                        <table style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;border: 0px; " align="left " border="0 " cellpadding="0 " cellspacing="0 ">
                                            <tbody><tr>
                                                <td>
                                                    <a href="# "><img editable="true" mc:edit="201" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/f-icon.png" width="30 " height="30 " alt="# " style="display:block; vertical-align:left; "></a>
                                                </td>
                                                <!-- margin -->
                                                <td align="center " height="1 " width="10 " style="font-size: 1px; line-height: 1px; width:10px; ">
                                                </td>
                                                <!-- margin -->
                                                <td>
                                                    <a href="# "><img editable="true" mc:edit="202" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/t-icon.png" width="30 " height="30 " alt="# " style="display:block; vertical-align:left; "></a>
                                                </td>
                                                <!-- margin -->
                                                <td align="center " height="1 " width="10 " style="font-size: 1px; line-height: 1px; width:10px; ">
                                                </td>
                                                <!-- margin -->
                                                <td>
                                                    <a href="# "><img editable="true" mc:edit="203" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/g-icon.png" width="30 " height="30 " alt="# " style="display:block; vertical-align:left; "></a>
                                                </td>
                                                <!-- margin -->
                                                <td align="center " height="1 " width="10 " style="font-size: 1px; line-height: 1px; width:10px; ">
                                                </td>
                                                <!-- margin -->
                                                <td>
                                                    <a href="# "><img editable="true" mc:edit="204" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/l-icon.png" width="30 " height="30 " alt="# " style="display:block; vertical-align:left; "></a>
                                                </td>
                                                <!-- margin -->
                                                <td align="center " height="1 " width="10 " style="font-size: 1px; line-height: 1px; width:10px; ">
                                                </td>
                                                <!-- margin -->
                                                <td>
                                                    <a href="# "><img editable="true" mc:edit="205" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/images/y-icon.png" width="30 " height="30 " alt="# " style="display:block; vertical-align:left; "></a>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                                <!-- icons -->
                                <tr>
                                    <td mc:edit="207" style="vertical-align:top; text-align:left; font-family: Roboto, sans-serif; font-size:16px; line-height: 24px; text-decoration: none; color: #a7a9bb; font-weight: 400; " data-color="text5" data-size="text5" data-min="16" data-max="32">
                                        <multiline>
                                            www.actorstudio.biz support@actorstudio.biz
                                        </multiline>
                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                    </tr>
                    <tr>
                        <td height="60 ">
                        </td>
                    </tr>
                </tbody></table>
            </td>
        </tr>
    </tbody></table><table data-module="G30" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/03/20/C1m6tjKGSPvgfpyHU4rlJcN2/html/thumbnails/module30.jpg" width="100%" align="center" cellspacing="0" cellpadding="0" style="background-color: #1f212d; max-width:800px;" data-bgcolor="bgColors">
        <tbody>
            <tr>
                <td mc:edit="section_30">
                    <table class="mazik600" cellspacing="0" cellpadding="0" border="0 " width="600" align="center">
                        <tbody>
                            <tr>
                                <td height="20 "></td>
                            </tr>
                            <tr>
                                <td>
                                    <table class="mazik1-1" cellpadding="0 " cellspacing="0 " width="350" align="left">
                                        <tbody>
                                            <tr>
                                                <td mc:edit="207" style="color:#fff;font-family: Roboto, sans-serif; font-size: 16px; line-height:30px; font-weight:400;" data-color="copyryt" data-size="copyryt" data-min="16" data-max="32">
                                                    <multiline> Copyright © 2017 actorstudio</multiline>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mazik1-1" cellpadding="0" cellspacing="0" align="right" width="200">
                                        <tbody>
                                            <tr>
                                                <td mc:edit="208" style="color:#fff;font-family: Roboto, sans-serif; font-size: 16px; line-height:30px; font-weight:400;" data-color="copyryt" data-size="copyryt" data-min="16" data-max="32">
                                                    <singleline>unsubscribe</singleline>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height="20"></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
';
	$name=$this->session->userdata('uname');
	$sub="EMAIL TEMPLATE";
	echo send_mail1($sub,$email,$msg,$name,$card);
	}
?>