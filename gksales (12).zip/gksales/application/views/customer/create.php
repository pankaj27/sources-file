<?php $this->load->view('headercss.php'); ?>
<?php $this->load->view('topnav.php'); ?>
<?php if(isset($custdata) && !empty($custdata)) {
	foreach($custdata as $rowinfo)	
	{
		$custname=$rowinfo->name;
		$lastid=$rowinfo->clientid;
		$compname=$rowinfo->compname;
		$custtype=strtoupper($rowinfo->custtype);
		$image=$rowinfo->image;
		$pass=$rowinfo->pass;
		$agvalidity=$rowinfo->agreement_validity;
		$agunit=$rowinfo->agvalunit;
		$openbal=$rowinfo->openbal;
		$ph=$rowinfo->phone;
		$interest=$rowinfo->interest;
		$email=$rowinfo->email;
		$add1=$rowinfo->add1;
		$add2=$rowinfo->add2;
		$country=$rowinfo->country;
		$state=$rowinfo->state;
		$district=$rowinfo->district;
		$area=$rowinfo->area;
		$pin=$rowinfo->pin;
		$pan=$rowinfo->pan;
		$tin_vat=$rowinfo->tin_vat;
		//$vat=$this->input->post('vat');
		$excise=$rowinfo->excise;
		$cst=$rowinfo->cst;
		$acno1=$rowinfo->acno1;
		$bank1=$rowinfo->bank1;
		$branch1=$rowinfo->branch1;
		$ifsc1=$rowinfo->ifsc1;
		$acno2=$rowinfo->acno2;
		$bank2=$rowinfo->bank2;
		$branch2=$rowinfo->branch2;
		$ifsc2=$rowinfo->ifsc2;
		$fact1=$rowinfo->factory1;
		$fact2=$rowinfo->factory2;
		$fact3=$rowinfo->factory3;
		$shr1=$rowinfo->showroom1;
		$shr2=$rowinfo->showroom2;
		$shr3=$rowinfo->showroom3;
		$id=$rowinfo->id;
	}
	
}

?>

		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Manage Customers</a>
							</li>
							<li class="active">Create Customer</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="page-header">
							<h1>
								Create Customer
								
							</h1>
						</div><!-- /.page-header -->
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<form class="form-horizontal" role="form" <?php if(isset($id) && !empty($id)){ ?> action="<?php echo base_url(); ?>Manage_customer/updatecustomer"  <?php   }else{?> action="<?php echo base_url(); ?>Manage_customer/savecustomer" <?php  } ?> method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">COMPANY NAME</label>

										<div class="col-sm-9">
											<input type="hidden" name="cld" value="<?php if(isset($id)  && !empty($id)){ echo $id ; } ?>"/>
											<input type="text" id="form-field-1" placeholder="Company Name" name="compname" class="col-xs-10 col-sm-5" value="<?php if(isset($compname) && !empty($compname)){ echo $compname; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CUSTOMER  NAME</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Customer Name" name="custname" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($custname) && !empty($custname)){ echo $custname; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CUSTOMER ID</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="" name="custid" class="col-xs-10 col-sm-5" readonly value="<?php if(isset($lastid)){ echo $lastid; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CUSTOMER TYPE</label>

										<div class="col-sm-9">
											<select name="custtype" id="custtype" class="col-xs-10 col-sm-5" onchange="customertype();" required="required" >
												  <?php if(isset($custtype) && !empty($custtype)){ ?>
												  	<option value="<?php echo $custtype; ?>" selected><?php echo $custtype;  ?></option>
												  	<option value="">--Select Customer Type--</option>
														<?php if(isset($customertype) && !empty($customertype))
														{ ?>
															<?php foreach($customertype as $row3) {  ?>
																<option value="<?php echo $row3->custtyp; ?>"><?php echo $row3->custtyp;  ?></option>
																
																
														<?php 	}?>
															
															
													    <?php  	} ?>
												  	
												 <?php  }else{ ?>
														 <option value="">--Select Customer Type--</option>
														<?php if(isset($customertype) && !empty($customertype))
														{ ?>
															<?php foreach($customertype as $row3) {  ?>
																<option value="<?php echo $row3->custtyp; ?>"><?php echo $row3->custtyp;  ?></option>
																
																
														<?php 	}?>
															
															
													    <?php  	} ?>
												   <?php } ?>
											</select>
										</div>
									</div>
									<!--<div class="form-group" id="cnflist">
										
									</div>
									<div class="form-group" id="dealerlist">
										
									</div>
									-->
									<!--<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CUSTOMER PASSWORD</label>

										<div class="col-sm-9">
											<input type="password" id="form-field-1" placeholder="CREATE PASSWORD" name="password" class="col-xs-10 col-sm-5" required value="<?php if(isset($pass) && !empty($pass)){ echo $pass; } ?>"  />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">AGREEMENT VALIDITY  TIME</label>

										<div class="col-sm-9">
											<input type="number" id="form-field-1" placeholder="AGREEMENT VALIDITY TIME" name="agval" class="col-xs-10 col-sm-5"  value="<?php if(isset($agvalidity) && !empty($agvalidity)){ echo $agvalidity; } ?>"/>
											&nbsp;&nbsp;
											<select name="agunit" required>
											<?php  if(isset($agunit) && !empty($agunit)){  ?>
												 <option value=".<?php echo $agunit; ?>." selected>"<?php echo $agunit; ?></option>
												<option value="">--select--</option> <option value="year">Year</option><option value="monthh">Month</option><option value="days">Days</option>
										<?php	} else
												{ ?>
													<option value="year">Year</option><option value="monthh">Month</option><option value="days">Days</option>
											<?php 	} ?>
											</select>
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">SECURITY DEPOSIT AMOUNT</label>

										<div class="col-sm-9">
											<input type="number" id="form-field-1" placeholder="SECURITY DEPOSIT AMOUNT" name="securiyu" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($openbal) && !empty($openbal)){ echo $openbal; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">YEARLY RATE OF INTEREST(%) </label>

										<div class="col-sm-9">
											<input type="number" id="form-field-1" placeholder="INTEREST AMOUNT(%)" name="interest" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($interest) && !empty($interest)){ echo $interest; } ?>" />
										</div>
									</div>-->
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">PHONE NUMBER</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Phone Number" name="ph" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($ph) && !empty($ph)){ echo $ph; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">EMAIL</label>

										<div class="col-sm-9">
											<input type="email" id="form-field-1" placeholder="Email1" name="email" class="col-xs-10 col-sm-5" value="<?php if(isset($email) && !empty($email)){ echo $email; } ?>" />&nbsp;&nbsp;
									    </div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">ADDRESS 1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Address 1" name="add1" class="col-xs-10 col-sm-5" value="<?php if(isset($add1) && !empty($add1)){ echo $add1; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">ADDRESS 2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Address 2 " name="add2" class="col-xs-10 col-sm-5" value="<?php if(isset($add2) && !empty($add2)){ echo $add2; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">COUNTRY</label>

										<div class="col-sm-9">
											<select name="country" id="country" class="col-xs-10 col-sm-5" onchange="getstate();">
											<?php if(isset($country) && !empty($country)){ ?>
												
												<option value="<?php echo $country; ?>" selected><?php echo $country; ?></option>
												<option value="">--Select Country--</option>
											<?php if(isset($country2) && !empty($country2))
											{
												foreach($country2 as $row)
												{
													?>
													<option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
											<?php 	}
											}
											
											
											 ?>
											<?php  }else{ ?>
												<option value="">--Select Country--</option>
											<?php if(isset($country2) && !empty($country2))
											{
												foreach($country2 as $row)
												{
													?>
													<option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
											<?php 	}
											}
											
											
											 ?>
											 <?php } ?>
											 </select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">STATE</label>

										<div class="col-sm-9" id="state">
											<?php  if(isset($state) && !empty($state)){
												echo "<select id='state2' name='state'>";
														
													  	echo "<option value='".$state."' selected>".$state."</option>";
														
												 if(isset($state1) && !empty($state1))
												 {
												 	echo "<option value=''>--select--</option>";
												 	foreach($state1 as $rowst)
													{
														echo "<option value='".$rowst->statename."'>".$rowst->statename."</option>";
													}
												 }
												
												echo "</select>"; 
												
											} ?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">DISTRICT</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="District" name="district" class="col-xs-10 col-sm-5" value="<?php if(isset($district) && !empty($district)){ echo $district; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">AREA</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Area" name="area" class="col-xs-10 col-sm-5" value="<?php if(isset($area) && !empty($area)){ echo $area; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">PIN</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="PIN code" name="pin" class="col-xs-10 col-sm-5" required value="<?php if(isset($pin) && !empty($pin)){ echo $pin; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">PAN NO</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Pan No" name="pan" class="col-xs-10 col-sm-5" value="<?php if(isset($pan) && !empty($pan)){ echo $pan; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">TIN NO / VAT NO</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="TIN No / VAT No" name="tin_vat" class="col-xs-10 col-sm-5" value="<?php if(isset($tin_vat) && !empty($tin_vat)){ echo $tin_vat; } ?>" />
										</div>
									</div>

									<!--<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">VAT NO</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="VAT No" name="vat" class="col-xs-10 col-sm-5" />
										</div>
									</div>-->
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">EXCISE NO</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="EXCISE No" name="excise" class="col-xs-10 col-sm-5" value="<?php if(isset($excise) && !empty($excise)){ echo $excise; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">CST NO</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="CST NO" name="cst" class="col-xs-10 col-sm-5" value="<?php if(isset($cst) && !empty($cst)){ echo $cst; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BANK NAME 1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="BANK NAME" name="bank1" class="col-xs-10 col-sm-5" value="<?php if(isset($bank1) && !empty($bank1)){ echo $bank1; } ?>"  />
										</div>
										
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BANK ACCOUNT NO 1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="BANK ACCNO" name="acno1" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($acno1) && !empty($acno1)){ echo $acno1; } ?>" />
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BRANCH NAME 1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="BRANCH NAME" name="branch1" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($branch1) && !empty($branch1)){ echo $branch1; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">IFSC CODE 1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="IFSC CODE" name="ifsc1" class="col-xs-10 col-sm-5" required="required"  value="<?php if(isset($ifsc1) && !empty($ifsc1)){ echo $ifsc1; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BANK ACCOUNT NO 2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="BANK ACCNO" name="acno2" class="col-xs-10 col-sm-5" value="<?php if(isset($acno2) && !empty($acno2)){ echo $acno2; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BANK NAME 2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="BANK NAME" name="bank2" class="col-xs-10 col-sm-5" value="<?php if(isset($bank2) && !empty($bank2)){ echo $bank2; } ?>" />
										</div>
										
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BRANCH NAME 2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="BRANCH NAME" name="branch2" class="col-xs-10 col-sm-5" value="<?php if(isset($branch2) && !empty($branch2)){ echo $branch2; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">IFSC CODE 2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="IFSC CODE" name="ifsc2" class="col-xs-10 col-sm-5" value="<?php if(isset($ifsc2) && !empty($ifsc2)){ echo $ifsc2; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">WAREHOUSE 1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Factory 1" name="fact1" class="col-xs-10 col-sm-5"  value="<?php if(isset($fact1) && !empty($fact1)){ echo $fact1; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">WAREHOUSE 2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Factory 2" name="fact2" class="col-xs-10 col-sm-5" value="<?php if(isset($fact2) && !empty($fact2)){ echo $fact2; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">WAREHOUSE 3</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Factory 3" name="fact3" class="col-xs-10 col-sm-5" value="<?php if(isset($fact3) && !empty($fact3)){ echo $fact3; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">SHOWROOM1</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Showroom 1" name="shr1" class="col-xs-10 col-sm-5" value="<?php if(isset($shr1) && !empty($shr1)){ echo $shr1; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right"  for="form-field-1">SHOWROOM2</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Showroom 2" name="shr2" class="col-xs-10 col-sm-5" value="<?php if(isset($shr2) && !empty($shr2)){ echo $shr2; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">SHOWROOM3</label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Showroom 3" name="shr3" class="col-xs-10 col-sm-5" value="<?php if(isset($shr3) && !empty($shr3)){ echo $shr3; } ?>" />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BUSINESS TYPE</label>

										<div class="col-sm-9">
											<select name="shr3" class="col-xs-10 col-sm-5" name="busnesstyp">
												<option value="">--select--</option>
												<option value="partnership">Partnership</option>
												<option value="proprieter">Proprietership</option>
												<option value="pvtltd">PVT LTD.</option>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BUSINESS TYPE</label>

										<div class="col-sm-9">
											<select name="shr3" class="col-xs-10 col-sm-5" name="busnesstyp">
												<option value="">--select--</option>
												<option value="partnership">Partnership</option>
												<option value="proprieter">Proprietership</option>
												<option value="pvtltd">PVT LTD.</option>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">IMAGE</label>

										<div class="col-sm-6">
											<input type="hidden" name="file1" "value="<?php if(isset($image) && !empty($image)){ echo $image; } ?>" />
											<input type="file" id="imgInp" placeholder="Showroom 3" class="col-xs-10 col-sm-5" name="image1" >
										</div>
										<br>
										<img id="blah"  <?php if(isset($image) && !empty($image)){ ?> src="<?php echo base_url(); ?>uploads/clientpics/<?php echo $image; ?>"   <?php }else{ ?> src="<?php echo base_url(); ?>assets/favicon/anonymous-man.png" <?php } ?> alt="your image" width="150" height="150" name="image1"/>
									</div>




									

									

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<button class="btn btn-info" type="submit">
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
											</button>

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
								</form>
									
							</div>
						
			</div><!-- /.main-content -->

        <?php $this->load->view('footerjs.php'); ?>

		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
				$('#id-disable-check').on('click', function() {
					var inp = $('#form-input-readonly').get(0);
					if(inp.hasAttribute('disabled')) {
						inp.setAttribute('readonly' , 'true');
						inp.removeAttribute('disabled');
						inp.value="This text field is readonly!";
					}
					else {
						inp.setAttribute('disabled' , 'disabled');
						inp.removeAttribute('readonly');
						inp.value="This text field is disabled!";
					}
				});
			
			
				if(!ace.vars['touch']) {
					$('.chosen-select').chosen({allow_single_deselect:true}); 
					//resize the chosen on window resize
			
					$(window)
					.off('resize.chosen')
					.on('resize.chosen', function() {
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					}).trigger('resize.chosen');
					//resize chosen on sidebar collapse/expand
					$(document).on('settings.ace.chosen', function(e, event_name, event_val) {
						if(event_name != 'sidebar_collapsed') return;
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					});
			
			
					$('#chosen-multiple-style .btn').on('click', function(e){
						var target = $(this).find('input[type=radio]');
						var which = parseInt(target.val());
						if(which == 2) $('#form-field-select-4').addClass('tag-input-style');
						 else $('#form-field-select-4').removeClass('tag-input-style');
					});
				}
			
			
				$('[data-rel=tooltip]').tooltip({container:'body'});
				$('[data-rel=popover]').popover({container:'body'});
			
				autosize($('textarea[class*=autosize]'));
				
				$('textarea.limited').inputlimiter({
					remText: '%n character%s remaining...',
					limitText: 'max allowed : %n.'
				});
			
				$.mask.definitions['~']='[+-]';
				$('.input-mask-date').mask('99/99/9999');
				$('.input-mask-phone').mask('(999) 999-9999');
				$('.input-mask-eyescript').mask('~9.99 ~9.99 999');
				$(".input-mask-product").mask("a*-999-a999",{placeholder:" ",completed:function(){alert("You typed the following: "+this.val());}});
			
			
			
				$( "#input-size-slider" ).css('width','200px').slider({
					value:1,
					range: "min",
					min: 1,
					max: 8,
					step: 1,
					slide: function( event, ui ) {
						var sizing = ['', 'input-sm', 'input-lg', 'input-mini', 'input-small', 'input-medium', 'input-large', 'input-xlarge', 'input-xxlarge'];
						var val = parseInt(ui.value);
						$('#form-field-4').attr('class', sizing[val]).attr('placeholder', '.'+sizing[val]);
					}
				});
			
				$( "#input-span-slider" ).slider({
					value:1,
					range: "min",
					min: 1,
					max: 12,
					step: 1,
					slide: function( event, ui ) {
						var val = parseInt(ui.value);
						$('#form-field-5').attr('class', 'col-xs-'+val).val('.col-xs-'+val);
					}
				});
			
			
				
				//"jQuery UI Slider"
				//range slider tooltip example
				$( "#slider-range" ).css('height','200px').slider({
					orientation: "vertical",
					range: true,
					min: 0,
					max: 100,
					values: [ 17, 67 ],
					slide: function( event, ui ) {
						var val = ui.values[$(ui.handle).index()-1] + "";
			
						if( !ui.handle.firstChild ) {
							$("<div class='tooltip right in' style='display:none;left:16px;top:-6px;'><div class='tooltip-arrow'></div><div class='tooltip-inner'></div></div>")
							.prependTo(ui.handle);
						}
						$(ui.handle.firstChild).show().children().eq(1).text(val);
					}
				}).find('span.ui-slider-handle').on('blur', function(){
					$(this.firstChild).hide();
				});
				
				
				$( "#slider-range-max" ).slider({
					range: "max",
					min: 1,
					max: 10,
					value: 2
				});
				
				$( "#slider-eq > span" ).css({width:'90%', 'float':'left', margin:'15px'}).each(function() {
					// read initial values from markup and remove that
					var value = parseInt( $( this ).text(), 10 );
					$( this ).empty().slider({
						value: value,
						range: "min",
						animate: true
						
					});
				});
				
				$("#slider-eq > span.ui-slider-purple").slider('disable');//disable third item
			
				
				$('#id-input-file-1 , #id-input-file-2').ace_file_input({
					no_file:'No File ...',
					btn_choose:'Choose',
					btn_change:'Change',
					droppable:false,
					onchange:null,
					thumbnail:false //| true | large
					//whitelist:'gif|png|jpg|jpeg'
					//blacklist:'exe|php'
					//onchange:''
					//
				});
				//pre-show a file name, for example a previously selected file
				//$('#id-input-file-1').ace_file_input('show_file_list', ['myfile.txt'])
			
			
				$('#id-input-file-3').ace_file_input({
					style: 'well',
					btn_choose: 'Drop files here or click to choose',
					btn_change: null,
					no_icon: 'ace-icon fa fa-cloud-upload',
					droppable: true,
					thumbnail: 'small'//large | fit
					//,icon_remove:null//set null, to hide remove/reset button
					/**,before_change:function(files, dropped) {
						//Check an example below
						//or examples/file-upload.html
						return true;
					}*/
					/**,before_remove : function() {
						return true;
					}*/
					,
					preview_error : function(filename, error_code) {
						//name of the file that failed
						//error_code values
						//1 = 'FILE_LOAD_FAILED',
						//2 = 'IMAGE_LOAD_FAILED',
						//3 = 'THUMBNAIL_FAILED'
						//alert(error_code);
					}
			
				}).on('change', function(){
					//console.log($(this).data('ace_input_files'));
					//console.log($(this).data('ace_input_method'));
				});
				
				
				//$('#id-input-file-3')
				//.ace_file_input('show_file_list', [
					//{type: 'image', name: 'name of image', path: 'http://path/to/image/for/preview'},
					//{type: 'file', name: 'hello.txt'}
				//]);
			
				
				
			
				//dynamically change allowed formats by changing allowExt && allowMime function
				$('#id-file-format').removeAttr('checked').on('change', function() {
					var whitelist_ext, whitelist_mime;
					var btn_choose
					var no_icon
					if(this.checked) {
						btn_choose = "Drop images here or click to choose";
						no_icon = "ace-icon fa fa-picture-o";
			
						whitelist_ext = ["jpeg", "jpg", "png", "gif" , "bmp"];
						whitelist_mime = ["image/jpg", "image/jpeg", "image/png", "image/gif", "image/bmp"];
					}
					else {
						btn_choose = "Drop files here or click to choose";
						no_icon = "ace-icon fa fa-cloud-upload";
						
						whitelist_ext = null;//all extensions are acceptable
						whitelist_mime = null;//all mimes are acceptable
					}
					var file_input = $('#id-input-file-3');
					file_input
					.ace_file_input('update_settings',
					{
						'btn_choose': btn_choose,
						'no_icon': no_icon,
						'allowExt': whitelist_ext,
						'allowMime': whitelist_mime
					})
					file_input.ace_file_input('reset_input');
					
					file_input
					.off('file.error.ace')
					.on('file.error.ace', function(e, info) {
						//console.log(info.file_count);//number of selected files
						//console.log(info.invalid_count);//number of invalid files
						//console.log(info.error_list);//a list of errors in the following format
						
						//info.error_count['ext']
						//info.error_count['mime']
						//info.error_count['size']
						
						//info.error_list['ext']  = [list of file names with invalid extension]
						//info.error_list['mime'] = [list of file names with invalid mimetype]
						//info.error_list['size'] = [list of file names with invalid size]
						
						
						/**
						if( !info.dropped ) {
							//perhapse reset file field if files have been selected, and there are invalid files among them
							//when files are dropped, only valid files will be added to our file array
							e.preventDefault();//it will rest input
						}
						*/
						
						
						//if files have been selected (not dropped), you can choose to reset input
						//because browser keeps all selected files anyway and this cannot be changed
						//we can only reset file field to become empty again
						//on any case you still should check files with your server side script
						//because any arbitrary file can be uploaded by user and it's not safe to rely on browser-side measures
					});
					
					
					/**
					file_input
					.off('file.preview.ace')
					.on('file.preview.ace', function(e, info) {
						console.log(info.file.width);
						console.log(info.file.height);
						e.preventDefault();//to prevent preview
					});
					*/
				
				});
			
				$('#spinner1').ace_spinner({value:0,min:0,max:200,step:10, btn_up_class:'btn-info' , btn_down_class:'btn-info'})
				.closest('.ace-spinner')
				.on('changed.fu.spinbox', function(){
					//console.log($('#spinner1').val())
				}); 
				$('#spinner2').ace_spinner({value:0,min:0,max:10000,step:100, touch_spinner: true, icon_up:'ace-icon fa fa-caret-up bigger-110', icon_down:'ace-icon fa fa-caret-down bigger-110'});
				$('#spinner3').ace_spinner({value:0,min:-100,max:100,step:10, on_sides: true, icon_up:'ace-icon fa fa-plus bigger-110', icon_down:'ace-icon fa fa-minus bigger-110', btn_up_class:'btn-success' , btn_down_class:'btn-danger'});
				$('#spinner4').ace_spinner({value:0,min:-100,max:100,step:10, on_sides: true, icon_up:'ace-icon fa fa-plus', icon_down:'ace-icon fa fa-minus', btn_up_class:'btn-purple' , btn_down_class:'btn-purple'});
			
				//$('#spinner1').ace_spinner('disable').ace_spinner('value', 11);
				//or
				//$('#spinner1').closest('.ace-spinner').spinner('disable').spinner('enable').spinner('value', 11);//disable, enable or change value
				//$('#spinner1').closest('.ace-spinner').spinner('value', 0);//reset to 0
			
			
				//datepicker plugin
				//link
				$('.date-picker').datepicker({
					autoclose: true,
					todayHighlight: true
				})
				//show datepicker when clicking on the icon
				.next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
			
				//or change it into a date range picker
				$('.input-daterange').datepicker({autoclose:true});
			
			
				//to translate the daterange picker, please copy the "examples/daterange-fr.js" contents here before initialization
				$('input[name=date-range-picker]').daterangepicker({
					'applyClass' : 'btn-sm btn-success',
					'cancelClass' : 'btn-sm btn-default',
					locale: {
						applyLabel: 'Apply',
						cancelLabel: 'Cancel',
					}
				})
				.prev().on(ace.click_event, function(){
					$(this).next().focus();
				});
			
			
				$('#timepicker1').timepicker({
					minuteStep: 1,
					showSeconds: true,
					showMeridian: false,
					disableFocus: true,
					icons: {
						up: 'fa fa-chevron-up',
						down: 'fa fa-chevron-down'
					}
				}).on('focus', function() {
					$('#timepicker1').timepicker('showWidget');
				}).next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
				
				
			
				
				if(!ace.vars['old_ie']) $('#date-timepicker1').datetimepicker({
				 //format: 'MM/DD/YYYY h:mm:ss A',//use this option to display seconds
				 icons: {
					time: 'fa fa-clock-o',
					date: 'fa fa-calendar',
					up: 'fa fa-chevron-up',
					down: 'fa fa-chevron-down',
					previous: 'fa fa-chevron-left',
					next: 'fa fa-chevron-right',
					today: 'fa fa-arrows ',
					clear: 'fa fa-trash',
					close: 'fa fa-times'
				 }
				}).next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
				
			
				$('#colorpicker1').colorpicker();
				//$('.colorpicker').last().css('z-index', 2000);//if colorpicker is inside a modal, its z-index should be higher than modal'safe
			
				$('#simple-colorpicker-1').ace_colorpicker();
				//$('#simple-colorpicker-1').ace_colorpicker('pick', 2);//select 2nd color
				//$('#simple-colorpicker-1').ace_colorpicker('pick', '#fbe983');//select #fbe983 color
				//var picker = $('#simple-colorpicker-1').data('ace_colorpicker')
				//picker.pick('red', true);//insert the color if it doesn't exist
			
			
				$(".knob").knob();
				
				
				var tag_input = $('#form-field-tags');
				try{
					tag_input.tag(
					  {
						placeholder:tag_input.attr('placeholder'),
						//enable typeahead by specifying the source array
						source: ace.vars['US_STATES'],//defined in ace.js >> ace.enable_search_ahead
						/**
						//or fetch data from database, fetch those that match "query"
						source: function(query, process) {
						  $.ajax({url: 'remote_source.php?q='+encodeURIComponent(query)})
						  .done(function(result_items){
							process(result_items);
						  });
						}
						*/
					  }
					)
			
					//programmatically add/remove a tag
					var $tag_obj = $('#form-field-tags').data('tag');
					$tag_obj.add('Programmatically Added');
					
					var index = $tag_obj.inValues('some tag');
					$tag_obj.remove(index);
				}
				catch(e) {
					//display a textarea for old IE, because it doesn't support this plugin or another one I tried!
					tag_input.after('<textarea id="'+tag_input.attr('id')+'" name="'+tag_input.attr('name')+'" rows="3">'+tag_input.val()+'</textarea>').remove();
					//autosize($('#form-field-tags'));
				}
				
				
				/////////
				$('#modal-form input[type=file]').ace_file_input({
					style:'well',
					btn_choose:'Drop files here or click to choose',
					btn_change:null,
					no_icon:'ace-icon fa fa-cloud-upload',
					droppable:true,
					thumbnail:'large'
				})
				
				//chosen plugin inside a modal will have a zero width because the select element is originally hidden
				//and its width cannot be determined.
				//so we set the width after modal is show
				$('#modal-form').on('shown.bs.modal', function () {
					if(!ace.vars['touch']) {
						$(this).find('.chosen-container').each(function(){
							$(this).find('a:first-child').css('width' , '210px');
							$(this).find('.chosen-drop').css('width' , '210px');
							$(this).find('.chosen-search input').css('width' , '200px');
						});
					}
				})
				/**
				//or you can activate the chosen plugin after modal is shown
				//this way select element becomes visible with dimensions and chosen works as expected
				$('#modal-form').on('shown', function () {
					$(this).find('.modal-chosen').chosen();
				})
				*/
			
				
				
				$(document).one('ajaxloadstart.page', function(e) {
					autosize.destroy('textarea[class*=autosize]')
					
					$('.limiterBox,.autosizejs').remove();
					$('.daterangepicker.dropdown-menu,.colorpicker.dropdown-menu,.bootstrap-datetimepicker-widget.dropdown-menu').remove();
				});
			
			});
		</script>
		<script>
			function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#imgInp").change(function(){
        readURL(this);
    });
    function getstate()
    {
    	var country=$("#country").val();
    	if(country=="")
    	{
    		alert('please select country');
    		//$("#state").hide();
    		$("#state2").remove();
    	}else
    	{
    		if(country=="India")
    		{
	    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_customer/getstate",
	  			data :{'country':country},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				$("#state").html(data);
	  			  
	              }  
                });
    		}else
    		{
    			//alert('hello');
    			$("#state").html("<input type='text' name='state' class='col-xs-10 col-sm-5' placeholder='State' required />");
    		}
    	}
    }
    function customertype()
    {
    	//alert('hello');
    	var custype=$("#custtype").val();
    	alert(custype);
    	if(custype=="DEALER")
    	{
    		//alert('hello');
    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_customer/get_cnflist",
	  			data :{'custype':custype},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				$("#cnflist").html(data);
	  			  
	              }  
                });
    		
    	}
    	
    	 if(custype=="SUB-DEALER")
    	{
    		//alert('hello2');
    		//$("#cnflist").hide();
    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_customer/get_cnflist",
	  			data :{'custype':custype},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				$("#cnflist").html(data);
	  			  
	              }  
              });
             
    	}
    	 if(custype=="RETAILER/DIRECT")
    	{
    		
    	}
    	
    	
    }
    function getdealer()
    {
    	var cnf=$("#cnf").val();
    	  alert(cnf);
    	
    		$.ajax({			
	 			type :"POST",
	  			url : "<?php echo base_url();  ?>Manage_customer/getdelaerlist",
	  			data :{'cnf':cnf},
	  			success : function(data){
	  				 				 
	  				//alert(data);
	  				console.log(data);
	  				$("#dealerlist").html(data);
	  			  
	              }  
                });
    }
		</script>
	</body>
</html>
