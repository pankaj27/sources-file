<?php $this->load->view('headercss.php'); ?>
<?php $this->load->view('topnav.php'); ?>

<style>
.squaredOne {
  width: 28px;
  height: 28px;
  position: relative;
  margin: 20px auto;
  background: #fcfff4;
  background: linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
  box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0,0,0,0.5);
  label {
    width: 20px;
    height: 20px;
    position: absolute;
    top: 4px;
    left: 4px;
    cursor: pointer;
    background: linear-gradient(top, #222 0%, #45484d 100%);
    box-shadow: inset 0px 1px 1px rgba(0,0,0,0.5), 0px 1px 0px rgba(255,255,255,1);
    &:after {
      content: '';
      width: 16px;
      height: 16px;
      position: absolute;
      top: 2px;
      left: 2px;
      background: $activeColor;
      background: linear-gradient(top, $activeColor 0%, $darkenColor 100%);
      box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0,0,0,0.5);
      opacity: 0;
    }
    &:hover::after {
      opacity: 0.3;
    }
  }
  input[type=checkbox] {
    visibility: hidden;
    &:checked + label:after {
      opacity: 1;
    }   
  } 
}
</style>


<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
	
		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			
  <?php $this->load->view('navmenu.php'); ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Manage Customer</a>
							</li>
							<li class="active">Registered Client Details</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="page-header">
							<h1>
								Customer Deatils
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									
								</small>
							</h1>
						</div><!-- /.page-header -->
									<form action="<?php echo base_url(); ?>Manage_customer/mail_sales" method="POST">
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">CHOOSE YOUR CATEGORY</label>

										<div class="col-sm-9">
											&nbsp;&nbsp;<!--<input type="checkbox"   id="card_1" name="card[]" value="1" onclick="getcard(this.id)" /> E-CARD FOR <?php  echo strtoupper($this->session->userdata('uname')); ?><br>-->
											
											&nbsp;&nbsp;<input type="checkbox" id="card_2" name="card[]" value="3" onclick="getcard(this.id)" /> MODEL DETAILS<br>
											&nbsp;&nbsp;&nbsp;<input type="checkbox" id="card_3" name="card[]" value="4" onclick="getcard(this.id)"/> DISTRIBUTORSHIP FORM<br>
											&nbsp;&nbsp;<!--<input type="checkbox" id="card_4" name="card[]" value="5" onclick="getcard(this.id)" /> DISTRIBUTORSHIP RULES & REGULATION<br>-->
											&nbsp;&nbsp;<input type="checkbox" id="card_5" name="card[]" value="6" onclick="getcard(this.id)" /> SPAREPARTS RATE<br>
											<input type="hidden" name="emailcust" value="" id="custid" >
										</div>
									</div>
									<center><div class="mail" id="mail">
											<button class="btn btn-info" type="submit" id="sb">
												<i class="ace-icon fa fa-check bigger-110"></i>
												Send Mail
											</button>
									</div></center>
									 </form>
								<div class="row">
									<div class="col-xs-12" style="overflow-y: scroll;">
										<!--<h3 class="header smaller lighter blue">jQuery dataTables</h3>-->

										<div class="clearfix">
											<div class="pull-right tableTools-container"></div>
										</div>
										<!--<div class="table-header">
											Results for "Latest Registered Clients "
										</div>-->

										<!-- div.table-responsive -->

										<!-- div.dataTables_borderWrap -->
										<div>
											<table id="simple" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														<th>SL NO.</th>
														<th class="center">
															<label class="pos-rel">
																<!--<input type="checkbox" class="ace" />
																<span class="lbl"></span>-->
															</label>
														</th>
														
														<th>CUST ID</th>
														<th>CUST COMPNAME</th>
														<th>CONTACT DETAILS</th>
														<th>LOCATION</th>
														<th>
															<i class="ace-icon fa fa-clock-o bigger-110 hidden-480"></i>
															FACTORY/SHOROOM
														</th>
														<!--<th>IMAGE</th>-->
														<th>STATUS</th>

														<th>ACTION</th>
													</tr>
												</thead>

												<tbody>
													<?php if(isset($getcust) && !empty($getcust)){$t=1; ?>
														<?php foreach($getcust as $row){ ?>
														
													
													<tr>
														<td><?php  echo $t; ?></td>
														<td class="center">
															<label class="pos-rel">
																<input type="checkbox" onclick="Showbt(this.id)" id="checkbox_<?php echo $t; ?>" name="checkbox" value="<?php echo $row->id; ?>" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td><?php echo $row->clientid;  ?></td>
														<td><?php echo $row->compname;  ?></td>
														<td><?php echo $row->email;  ?></td>
														<td>
															<button type="button" class="btn btn-link" data-toggle="modal" href="#modal-form_<?php echo $t; ?>"><i class="fa fa-map-marker" aria-hidden="true"></i></button>
															
															<div id="modal-form_<?php echo $t; ?>" class="modal" tabindex="-1">
																	<div class="modal-dialog">
																		<div class="modal-content">
																			<div class="modal-header">
																				<button type="button" class="close" data-dismiss="modal">&times;</button>
																				<h4 class="blue bigger">Location For <?php echo $row->compname;  ?></h4>
																			</div>
								
																			<div class="modal-body">
																				<div class="row">
																					<div class="col-xs-12 col-sm-5">
																						<div class="space"></div>
								
																						
																					</div>
								
																					<div class="col-xs-12 col-sm-7">
																						<div class="form-group">
																							<label for="form-field-select-3"><b>Address</b></label>
								
																							<div>
																								<?php echo $row->add1.",".$row->add2.",".$row->district.",".$row->state.",".$row->country.",".$row->pin;
																								
																								
																								 ?>
																							</div>
																						</div>
								
																						<div class="space-4"></div>
								
																						<div class="form-group">
																							<label for="form-field-username"><b>Area</b></label>
								
																							<div>
																								<?php echo $row->area; ?>
																							</div>
																						</div>
								
																						<div class="space-4"></div>
								
																						
																					</div>
																				</div>
																			</div>
								
																			<div class="modal-footer">
																				<button class="btn btn-sm" data-dismiss="modal">
																					<i class="ace-icon fa fa-times"></i>
																					Cancel
																				</button>
								
																				
																			</div>
																		</div>
																	</div>
								</div><!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->

															
														</td>
														<td><?php echo $row->showroom1;  ?></td>
														<!--<td class="hidden-480"><img src="<?php//  echo base_url();?>uploads/clientpics/<?php// echo $row->image; ?>" width="100" height="100""/></td>-->
														<td>ACTIVE</td>
													<td>
													   <form action="<?php echo base_url(); ?>Manage_customer/mail_ind" method="post">
															<input type="hidden" name="cardview" id="cardview_<?php echo $t; ?>"/>
															<input type="hidden" name="email" value="<?php echo $row->email; ?>"/><button type="submit" class="btn btn-link"><i class="fa fa-envelope" aria-hidden="true"></i></button>
													  </form>
														<a href="<?php echo base_url();?>Paymentcontroller/boookbycust/<?php echo $row->clientid; ?>"><button type="button" class="btn btn-link" title="New Booking"><i class="fa fa-book" aria-hidden="true"></i></button></a>
														<a href="<?php echo base_url();?>Manage_customer/editcustomer/<?php echo $row->clientid; ?>"><button type="button" class="btn btn-link" title="New Booking"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
													</td>
													</tr>
													<?php $t++; }} ?>
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
								
								
								<div id="modal-table" class="modal fade" tabindex="-1">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header no-padding">
												<div class="table-header">
													<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
														<span class="white">&times;</span>
													</button>
													Results for "Latest Registered Domains
												</div>
											</div>

											<div class="modal-body no-padding">
												<table class="table table-striped table-bordered table-hover no-margin-bottom no-border-top">
													<thead>
														<tr>
															<th>Domain</th>
															<th>Price</th>
															<th>Clicks</th>

															<th>
																<i class="ace-icon fa fa-clock-o bigger-110"></i>
																Update
															</th>
														</tr>
													</thead>

													<tbody>
														<tr>
															<td>
																<a href="#">ace.com</a>
															</td>
															<td>$45</td>
															<td>3,330</td>
															<td>Feb 12</td>
														</tr>

														<tr>
															<td>
																<a href="#">base.com</a>
															</td>
															<td>$35</td>
															<td>2,595</td>
															<td>Feb 18</td>
														</tr>

														<tr>
															<td>
																<a href="#">max.com</a>
															</td>
															<td>$60</td>
															<td>4,400</td>
															<td>Mar 11</td>
														</tr>

														<tr>
															<td>
																<a href="#">best.com</a>
															</td>
															<td>$75</td>
															<td>6,500</td>
															<td>Apr 03</td>
														</tr>

														<tr>
															<td>
																<a href="#">pro.com</a>
															</td>
															<td>$55</td>
															<td>4,250</td>
															<td>Jan 21</td>
														</tr>
													</tbody>
												</table>
											</div>

											<div class="modal-footer no-margin-top">
												<button class="btn btn-sm btn-danger pull-left" data-dismiss="modal">
													<i class="ace-icon fa fa-times"></i>
													Close
												</button>

												<ul class="pagination pull-right no-margin">
													<li class="prev disabled">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-left"></i>
														</a>
													</li>

													<li class="active">
														<a href="#">1</a>
													</li>

													<li>
														<a href="#">2</a>
													</li>

													<li>
														<a href="#">3</a>
													</li>

													<li class="next">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-right"></i>
														</a>
													</li>
												</ul>
											</div>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div>

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			  <?php $this->load->view('footerjs.php'); ?>
		<!-- inline scripts related to this page -->
	
<script>

$(document).ready(function(){
  $("#sb").hide();
});
function Showbt(id)
   {
   	var idsplit=id.split("_");
   	var tr=$("#simple tr").length;
   //	alert(tr);
   	var tr1=tr-1;
   //	alert(tr1);
   	var cust="";
   ///	var t=0;
   	  for(var t=1;t<=parseInt(tr1);t++)
   	  {
   	  	 if ($("#checkbox_"+t).prop('checked') == true) {
                cust +=$("#checkbox_"+t).val()+ ",";
                //alert('2');
             // t++;  
		 }
   	  	
   	  }
   	  
	   //alert(cust);
	   $("#custid").val(cust);
	   if(cust=="")
   	  {
   	  	$("#sb").hide();
   	  }else
   	  {
   	  	$("#sb").show();
   	  }
   }
   function getcard(id)
   {
   		var idsplit=id.split("_");
   		var card="";
   		var t1=$("#simple tr").length;
   		for(var tr=1;tr<6;tr++)
   		{
   			if ($("#card_"+tr).prop('checked') == true) {
                card +=$("#card_"+tr).val()+ ",";
                //alert('2');
             // t++;  
		 }
   		}
   		for(var t=1;t<=parseInt(t1);t++)
   	     {
   	  	     $("#cardview_"+t).val(card);
   	  	
   	      }
   		
   }

</script>	
		
		<script>
  $(function(){
    $("#simple").dataTable();
  })
  </script> 
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

		
		
		<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var myTable = 
				$('#dynamic-table')
				//.wrap("<div class='dataTables_borderWrap' />")   //if you are applying horizontal scrolling (sScrollX)
				.DataTable( {
					bAutoWidth: false,
					"aoColumns": [
					  { "bSortable": false },
					  null, null,null, null, null,
					  { "bSortable": false }
					],
					"aaSorting": [],
					
					
					//"bProcessing": true,
			        //"bServerSide": true,
			        //"sAjaxSource": "http://127.0.0.1/table.php"	,
			
					//,
					//"sScrollY": "200px",
					//"bPaginate": false,
			
					//"sScrollX": "100%",
					//"sScrollXInner": "120%",
					//"bScrollCollapse": true,
					//Note: if you are applying horizontal scrolling (sScrollX) on a ".table-bordered"
					//you may want to wrap the table inside a "div.dataTables_borderWrap" element
			
					//"iDisplayLength": 50
			
			
					select: {
						style: 'multi'
					}
			    } );
			
				
				
				$.fn.dataTable.Buttons.defaults.dom.container.className = 'dt-buttons btn-overlap btn-group btn-overlap';
				
				new $.fn.dataTable.Buttons( myTable, {
					buttons: [
					  {
						"extend": "colvis",
						"text": "<i class='fa fa-search bigger-110 blue'></i> <span class='hidden'>Show/hide columns</span>",
						"className": "btn btn-white btn-primary btn-bold",
						columns: ':not(:first):not(:last)'
					  },
					  {
						"extend": "copy",
						"text": "<i class='fa fa-copy bigger-110 pink'></i> <span class='hidden'>Copy to clipboard</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "csv",
						"text": "<i class='fa fa-database bigger-110 orange'></i> <span class='hidden'>Export to CSV</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "excel",
						"text": "<i class='fa fa-file-excel-o bigger-110 green'></i> <span class='hidden'>Export to Excel</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "pdf",
						"text": "<i class='fa fa-file-pdf-o bigger-110 red'></i> <span class='hidden'>Export to PDF</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "print",
						"text": "<i class='fa fa-print bigger-110 grey'></i> <span class='hidden'>Print</span>",
						"className": "btn btn-white btn-primary btn-bold",
						autoPrint: false,
						message: 'This print was produced using the Print button for DataTables'
					  }		  
					]
				} );
				myTable.buttons().container().appendTo( $('.tableTools-container') );
				
				//style the message box
				var defaultCopyAction = myTable.button(1).action();
				myTable.button(1).action(function (e, dt, button, config) {
					defaultCopyAction(e, dt, button, config);
					$('.dt-button-info').addClass('gritter-item-wrapper gritter-info gritter-center white');
				});
				
				
				var defaultColvisAction = myTable.button(0).action();
				myTable.button(0).action(function (e, dt, button, config) {
					
					defaultColvisAction(e, dt, button, config);
					
					
					if($('.dt-button-collection > .dropdown-menu').length == 0) {
						$('.dt-button-collection')
						.wrapInner('<ul class="dropdown-menu dropdown-light dropdown-caret dropdown-caret" />')
						.find('a').attr('href', '#').wrap("<li />")
					}
					$('.dt-button-collection').appendTo('.tableTools-container .dt-buttons')
				});
			
				////
			
				setTimeout(function() {
					$($('.tableTools-container')).find('a.dt-button').each(function() {
						var div = $(this).find(' > div').first();
						if(div.length == 1) div.tooltip({container: 'body', title: div.parent().text()});
						else $(this).tooltip({container: 'body', title: $(this).text()});
					});
				}, 500);
				
				
				
				
				
				myTable.on( 'select', function ( e, dt, type, index ) {
					if ( type === 'row' ) {
						$( myTable.row( index ).node() ).find('input:checkbox').prop('checked', true);
					}
				} );
				myTable.on( 'deselect', function ( e, dt, type, index ) {
					if ( type === 'row' ) {
						$( myTable.row( index ).node() ).find('input:checkbox').prop('checked', false);
					}
				} );
			
			
			
			
				/////////////////////////////////
				//table checkboxes
				$('th input[type=checkbox], td input[type=checkbox]').prop('checked', false);
				
				//select/deselect all rows according to table header checkbox
				$('#dynamic-table > thead > tr > th input[type=checkbox], #dynamic-table_wrapper input[type=checkbox]').eq(0).on('click', function(){
					var th_checked = this.checked;//checkbox inside "TH" table header
					
					$('#dynamic-table').find('tbody > tr').each(function(){
						var row = this;
						if(th_checked) myTable.row(row).select();
						else  myTable.row(row).deselect();
					});
				});
				
				//select/deselect a row when the checkbox is checked/unchecked
				$('#dynamic-table').on('click', 'td input[type=checkbox]' , function(){
					var row = $(this).closest('tr').get(0);
					if(this.checked) myTable.row(row).deselect();
					else myTable.row(row).select();
				});
			
			
			
				$(document).on('click', '#dynamic-table .dropdown-toggle', function(e) {
					e.stopImmediatePropagation();
					e.stopPropagation();
					e.preventDefault();
				});
				
				
				
				//And for the first simple table, which doesn't have TableTools or dataTables
				//select/deselect all rows according to table header checkbox
				var active_class = 'active';
				$('#simple-table > thead > tr > th input[type=checkbox]').eq(0).on('click', function(){
					var th_checked = this.checked;//checkbox inside "TH" table header
					
					$(this).closest('table').find('tbody > tr').each(function(){
						var row = this;
						if(th_checked) $(row).addClass(active_class).find('input[type=checkbox]').eq(0).prop('checked', true);
						else $(row).removeClass(active_class).find('input[type=checkbox]').eq(0).prop('checked', false);
					});
				});
				
				//select/deselect a row when the checkbox is checked/unchecked
				$('#simple-table').on('click', 'td input[type=checkbox]' , function(){
					var $row = $(this).closest('tr');
					if($row.is('.detail-row ')) return;
					if(this.checked) $row.addClass(active_class);
					else $row.removeClass(active_class);
				});
			
				
			
				/********************************/
				//add tooltip for small view action buttons in dropdown menu
				$('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});
				
				//tooltip placement on right or left
				function tooltip_placement(context, source) {
					var $source = $(source);
					var $parent = $source.closest('table')
					var off1 = $parent.offset();
					var w1 = $parent.width();
			
					var off2 = $source.offset();
					//var w2 = $source.width();
			
					if( parseInt(off2.left) < parseInt(off1.left) + parseInt(w1 / 2) ) return 'right';
					return 'left';
				}
				
				
				
				
				/***************/
				$('.show-details-btn').on('click', function(e) {
					e.preventDefault();
					$(this).closest('tr').next().toggleClass('open');
					$(this).find(ace.vars['.icon']).toggleClass('fa-angle-double-down').toggleClass('fa-angle-double-up');
				});
				/***************/
				
				
				
				
				
				/**
				//add horizontal scrollbars to a simple table
				$('#simple-table').css({'width':'2000px', 'max-width': 'none'}).wrap('<div style="width: 1000px;" />').parent().ace_scroll(
				  {
					horizontal: true,
					styleClass: 'scroll-top scroll-dark scroll-visible',//show the scrollbars on top(default is bottom)
					size: 2000,
					mouseWheelLock: true
				  }
				).css('padding-top', '12px');
				*/
			
			
			})
		</script>
	</body>
</html>
