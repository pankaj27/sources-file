<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Authentication {
    function is_loggedin($session_param)
    {
		if(empty($session_param)){
			redirect(base_url().'login/chk_login');
			return false;
		}
	}
	
	
}

?>