<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_head_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getsaleexe($user)
	{
		$query=$this->db->query("select * from salesman where hod='".trim($user)."' and ucase(desig)='SALES EXECUTIVE'");
		return $query->result();
	}
}
