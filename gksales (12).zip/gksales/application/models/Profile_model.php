<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function fetchterget()
	{
		$query=$this->db->query("select * from set_terget");
		return $query->result();
	}
	public function delete_trgt($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('set_terget');
	}
	public function getsalesmandetails($uid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($uid)."'");
		return $query->result();
	}
	public function getcheckexist($dte,$uid,$yrcode,$formloc,$totloc,$custn,$contactinfo)
	{
		$query=$this->db->query("select * from tour_plan where userid='".trim($uid)."' and dte='".trim($dte)."' and yrcode='".trim($yrcode)."' and ucase(formloc)='".trim(strtoupper($formloc))."' and ucase(toloca)='".trim(strtoupper($totloc))."' and ucase(custname)='".trim(strtoupper($custn))."' and contactinfo='".trim(strtoupper($contactinfo))."'");
		return $query->result();
	}
	public function updatetourplan($data_array,$dte)
	{
		$this->db->where("dte",$dte);
		$this->db->update("tour_plan",$data_array);
	}
	public function savetoupplan($data_array)
	{
		$this->db->insert("tour_plan",$data_array);
	}
	public function getplandetails($d2,$uid)
	{
		$query=$this->db->query("select * from tour_plan where dte='".trim($d2)."' and userid='".$uid."' ");
		return $query->result();
	}
	public function getallplantour($dt)
	{
		$query=$this->db->query("SELECT * FROM `daybydayplan` where dte < '".trim($dt)."' order by dte asc");
		return $query->result();
	}
	public function checkdaybydayexist($dte,$uid,$fromloc,$toloc,$yrcode,$customer,$contact)
	{
		$query=$this->db->query("select * from daybydayplan where userid='".trim($uid)."' and dte='".trim($dte)."' and formloc='".trim($fromloc)."' and toloca='".trim($toloc)."' and yrcode='".trim($yrcode)."' and custname='".trim($customer)."' and contactinfo='".trim($contact)."'");
		return $query->result();
	}
	public function updatedaybydayplan($data_array,$dte)
	{
		$this->db->where("dte",$dte);
		$this->db->update("daybydayplan",$data_array);
	}
	public function savedaybydayplan($data_array)
	{
		$this->db->insert("daybydayplan",$data_array);
	}
///  profile   model details  ###################################################

	public function fetchslsmandtails($uid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($uid)."'");
		return $query->result();
	}
	public function cmplttrgt($uid)
	{
		$uid=$this->session->userdata('uid');
		$query=$this->db->query("select count(*) as nor from invoicegenerate where sid='".trim($uid)."' and mnthcd='".trim(date('m'))."' and yrcode='".trim(date('Y'))."'");
		return $query->result();
	}
	public function fetchtrgt($uid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($uid)."'");
		return $query->result();
	}
	public function ftchtrgt1($sid,$month,$year)
	{
		$query=$this->db->query("select * from sales_terget where salesmanid='".trim($sid)."' and monthcode like '%$month%' and yearcode like '%$year%'");
		return $query->result();
	}
	public function ftchtrgt2($sid)
	{
		$uid=$this->session->userdata('uid');
		$query=$this->db->query("select count(*) as nor from invoicegenerate where sid='".trim($uid)."' ");
		return $query->result();
	}
	/*public function ftchtrgt3($sid,$month,$year)
	{
		$query=$this->db->query("select * from sales_terget where (salesmanid!='".trim($sid)."' and monthcode like '%$month%' and yearcode like '%$year%'");
		return $query->result();
	}*/
	public function ftchtrgt3($sid,$month,$year)
	{
		$uid=$this->session->userdata('uid');
		$query=$this->db->query("select * from invoicegenerate where (sid<>null or sid<>'".trim($uid)."') and monthcode like '%".$month."%' and yearcode like '%".$year."%'");
		return $query->result();
	}
	public function ftchtrgt4($fetchid)
	{
		
		$query=$this->db->query("select * from salesman where salesmanid='".trim($fetchid)."'");
		return $query->result();
	}
	public function ftchtrgt5($slsid)
	{
		$query=$this->db->query("select * from clientmaster where sid='".trim($slsid)."'");
		return $query->result();
	}
	public function updateprofile($data_array,$username)
	{
		$this->db->where("salesmanid",$username);
		$this->db->update("salesman",$data_array);
	}
	
	//###################  end of profile model  ######################
	public function getallplanningdetails()
	{
		$mntcode=date('m');
		$yrcode=date('Y');
		$query=$this->db->query("select * from tour_plan where mnthcode='".trim($mntcode)."' and yrcode='".trim($yrcode)."' order by dte asc");
		return $query->result();
	}
	
	public function totlleads($uid)
	{
		$query=$this->db->query("select * from enquiry where user_id='".trim($uid)."'");
		return $query->result();
	}
	public function clientdetails($uid)
	{
		$query=$this->db->query("select * from  clientmaster where sid='".trim($uid)."'");
		return $query->result();
	}
	//update on 11012017
	public function fetchslab()
	{
		$query=$this->db->query("select * from incentive");
		return $query->result();
	}
	public function fetchperform()
	{
		$uid=$this->session->userdata('uid');
		$query=$this->db->query("select distinct(sid) as sid from invoicegenerate where (sid<>'".trim($uid)."' and sid!='') and mnthcd='".date('m')."' and yrcode='".trim(date('Y'))."'");
		//echo "select distinct(sid) as sid from invoicegenerate where (sid<>'".trim($uid)."' or sid!='') and mnthcd='".date('m')."' and yrcode='".trim(date('Y'))."'";
		//echo "select distinct(sid) as sid from invoicegenerate where (sid<>'".trim($uid)."' or sid<>null) and mnthcd='".date('m')."' and yrcode='".trim(date('m'))."'";
		return $query->result();
	}
	public function cmplttperfrgt($sid)
	{
		$query=$this->db->query("select count(*) as nor from invoicegenerate where sid='".trim($sid)."' and mnthcd='".trim(date('m'))."' and yrcode='".trim(date('Y'))."'");
	  //"select count(*) as nor from invoicegenerate where sid='".trim($sid)."' and mnthcd='".trim(date('m'))."' and yrcode='".trim(date('Y'))."'";
		return $query->result();
	}
	///////////////////////17012017
	public function updateaboutme($data_array,$uid)
	{
		$this->db->where("id",$uid);
		$this->db->update("salesman",$data_array);
		
	}
	public function getaboutme($id)
	{
		$query=$this->db->query("select * from salesman where id='".trim($id)."' ");
		return $query->result();
	}
	public function getallsiddetails($uid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($uid)."' ");
		return $query->result();
	}
	//180102017
	public function dleteedit($rowid)
	{
		$query=$this->db->query("delete from tour_plan where id='".trim($rowid)."'");
	}
	
}
