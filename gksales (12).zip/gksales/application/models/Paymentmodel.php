<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paymentmodel extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getmodelsdetails()
	{
		$query=$this->db->query("select * from productmaster where status='0' order by id desc");
		return $query->result();
	}
	public function getall_colorcode()
	{
		$query=$this->db->query("select * from color_code");
		return $query->result();
	}
	public function getallproduct()
	{
		$query=$this->db->query("select * from productmaster where status=0");
		return $query->result();
	}
	public function get_material()
	{
		$query=$this->db->query("select materiel_id, qnty,reorderlevel,qnty-reorderlevel as diff,materiel_id,materialname,id from materiel_master order by diff asc ");
		return $query->result();
	}
	public function getparts_sort_by_modelname($modelname)
	{
		$query=$this->db->query("select materiel_id,qnty,reorderlevel,dispr,qnty-reorderlevel as diff,materiel_id,materialname,id from materiel_master where mName='".trim($modelname)."' order by diff asc ");
		return $query->result();
	}
	public function getspecifbypartsid($partsid)
	{
		$query=$this->db->query("select * from spareparts_specification where parts_id='".trim($partsid)."'");
		return $query->result();
	}
	public function get_alldetails($id)
	{
		$query=$this->db->query("select * from materiel_master where id='".trim($id)."' ");
		return $query->result();
	}
	public function getspecification($specid)
	{
		$query=$this->db->query("select * from spareparts_specification where id='".trim($specid)."' ");
		return $query->result();
	}
	public function getcustdetails($email)
	{
		$query=$this->db->query("select * from clientmaster where (email='".trim($email)."' or clientid ='".trim($email)."' or name='".trim($email)."' or compname='".trim($email)."')");
		return $query->result();
	}
	public function getcustomername($user)
	{
		$query=$this->db->query("select * from clientmaster where sid='".trim($user)."'");
		return $query->result();
	}
	public function savebkorder($data_aray)
	{
		$this->db->insert('bookingorder',$data_aray);
	}
	public function getbookingid()
	{
		$query=$this->db->query("select max(id) as bkid from bookingorder");
		$res=$query->result();
		foreach($res as $row)
		{
			$bkid=$row->bkid;
		}
		$query=$this->db->query("select * from bookingorder where id='".trim($bkid)."'");
		$res2=$query->result();
		foreach($res2 as $row)
		{
			$bkid2=$row->bokingid;
		}
		return $bkid2;
	}
	public function getpartsname($particular)
	{
		$query=$this->db->query("select * from materiel_master where materiel_id='".trim($particular)."'");
		return $query->result();
	}
	public function getallbookinglist($user)
	{
		$query=$this->db->query("select * from bookingorder where sname='".trim($user)."' order by id desc");
		return $query->result();
	}
	public function setstatus($bkid)
	{
		$query=$this->db->query("update bookingorder set status='1' where bokingid='".$bkid."'");
	}
	public function getdistinctbookinglist($bkid)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($bkid)."'");
		return  $query->result();
	}
	public function getclientmail($cltid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($cltid)."'");
		$res= $query->result();
		foreach($res as $row){
			$mail=$row->email;
		}
		return $mail;
	}
	public function getcomplist($uname)
	{
		$query=$this->db->query("select distinct(custid) as cid  from bookingorder where sname='".trim($uname)."'");
		return $query->result();
	}
	public function getcstpercent($vat)
	{
		$query=$this->db->query("select cstamnt as cst from taxationdetails ");
		$res=$query->result();
		foreach($res as $row)
		{
			$vatp=$row->cst;
		}
		return $vatp;
	}
	public function getvatpercent($vat)
	{
		$query=$this->db->query("select vatamnt as vat from taxationdetails ");
		$res=$query->result();
		foreach($res as $row)
		{
			$vatp=$row->vat;
		}
		return $vatp;
		
	}
	public function getexciseduty()
	{
		$query=$this->db->query("select * from productmaster  limit 1");
		$res=$query->result();
		foreach($res as $row)
		{
			$excise=$row->excise;
		}
		return $excise;
	}
	public function getbuyerdetail($cltid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($cltid)."'");
		return $query->result();
	}
	public function getbookingd($clientid)
	{
		$query=$this->db->query("select distinct(bokingid) as bkid from bookingorder where custid='".trim($clientid)."' and status<>5 order by id desc");
		return $query->result();
	}
	public function getbill($bkid)
	{
		$query=$this->db->query("select * from bookingorder where bokingid='".trim($bkid)."'");
		return $query->result();
	}
	public function saverecepttransaction($data_array)
	{
		$this->db->insert('vouchertransaction',$data_array);
	}
	public function getallreceiptvoucher($uname)
	{
		$query=$this->db->query("select * from vouchertransaction where sname='".trim($uname)."' order by id desc ");
		return $query->result();
	}
	public function getalldetailpayment($bkid)
	{
		$query=$this->db->query("select * from vouchertransaction where bookingid='".trim($bkid)."'");
		return $query->result();
	}
	public function getallmodel()
	{
		$query=$this->db->query("select * from productmaster order by id desc");
		return $query->result();
	}
	public function getsearchdata($user,$term)
	{
		$query=$this->db->query("select * from clientmaster where (clientid like '%".trim($term)."%' or name like '%".trim($term)."%' or compname like '%".trim($term)."%' or email like '%".trim($term)."%')and sname='".trim($user)."' ");
		return $query->result();
	}
	public function getcustdetailsbyid($clientid)
	{
		$query=$this->db->query("select * from clientmaster where clientid='".trim($clientid)."' ");
		return $query->result();
	}
	//update on 11012017
	public function savetransactionprts($data_tran)
	{
		$this->db->insert("transection_master_acount",$data_tran);
	}
	public function getlastid()
	{
		$query=$this->db->query("select max(id) as id from vouchertransaction");
		$res=$query->result();
		foreach($res as $row)
		{
			$id=$row->id;
		}
		return $id;
	}
	//update on 23012017
	public function getexcisetx()
	
	{
		$query=$this->db->query("select * from taxationdetails");
		return $query->result();
	}
}