<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	
	public function fetch_user_data($username,$password)
	{
	$query=$this->db->query("select * from  salesman where email = '".$username."' and passwod = '".$password."' and status='1' ");
	return $query->result();
	}
	public function get_pass($user)
	{
	$query=$this->db->query("select password from  salesman where id = '".$user."'");
	return $query->result();
	}
	public function update_pass($where,$data)
	{
	$this->db->where($where);
	$this->db->update("user",$data);
	return;
	}
	
}
