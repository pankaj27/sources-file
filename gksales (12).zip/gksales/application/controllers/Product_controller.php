<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		$this->load->model('Product_model');
			//$this->load->model('Notify_model');
	}
		public function viewdemo()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/choosedemo',$data);
		}
		public function product_rotate()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/viewdemo',$data);
		}
		//########################  update on 09012017   ########################
		
		public function viewdemo1()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/demo1',$data);
		}
		//update on 16012017
		public function product_rotate_green()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/viewdemogreen',$data);
		}
      public function product_rotate_yellow()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/viewdemoyellow',$data);
		}
		public function product_rotate_violet()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/viewdemoviolet',$data);
		}
	  
	
	
}
