<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_customer extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		$this->load->library('fpdf_gen');
		$this->load->model('Manage_customer_model');
			//$this->load->model('Notify_model');
	}
public function createcustomer()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$data['title']='Dashboard';
	$data['country2']=$this->Manage_customer_model->getcountry();
	$data['customertype']=$this->Manage_customer_model->getcustomertyp();
	$lastid=$this->Manage_customer_model->getlastid();
	if(empty($lastid))
	{
		$lastid=1;
	}else{
		$lastid=intval($lastid)+1;
	}
	$data['lastid']="GKCLNT".date('y').str_pad($lastid, 5 , '0', STR_PAD_LEFT);
	$this->load->view('customer/create',$data);
}
	public function getstate()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
	  $country=$this->input->post("country");
	  $getstate=$this->Manage_customer_model->getstatename($country);
	  if(!empty($getstate) && isset($getstate))
	  {
	  	echo "<select id='state2' name='state'>";
		echo "<option value=''></option>";
	  	foreach($getstate as $row )
		{
			echo "<option value='".$row->statename."'>".$row->statename."</option>";
		}
		echo "</select>";
	  }
	}
	public function savecustomer()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$path="uploads/clientpics/";
		date_default_timezone_set("asia/Kolkata");
		$custname=$this->input->post('custname');
		$custid=$this->input->post('custid');
		$compname=$this->input->post('compname');
		$custtype=strtoupper($this->input->post("custtype"));
		if($custtype=="CNF")
		{
			$custid="C$custid";
		}
		if($custtype=="DEALER")
		{
			$custid="D$custid";
		}
		if($custtype=="SUB-DEALER")
		{
			$custid="SD$custid";
		}
		if($custtype=="RETAILER")
		{
			$custid="T$custid";
		}
		$pass=$this->input->post("password");
		$agvalidity=$this->input->post("agval");
		$agunit=$this->input->post("agunit");
		$openbal=$this->input->post("securiyu");
		$ph=$this->input->post('ph');
		$interest=$this->input->post("interest");
		$email=$this->input->post('email');
		$add1=$this->input->post('add1');
		$add2=$this->input->post('add2');
		$country=$this->input->post('country');
		$state=$this->input->post('state');
		$district=$this->input->post('district');
		$area=$this->input->post('area');
		$pin=$this->input->post('pin');
		$pan=$this->input->post('pan');
		$tin_vat=$this->input->post('tin_vat');
		//$vat=$this->input->post('vat');
		$excise=$this->input->post('excise');
		$cst=$this->input->post('cst');
		$acno1=$this->input->post("acno1");
		$bank1=$this->input->post("bank1");
		$branch1=$this->input->post("branch1");
		$ifsc1=$this->input->post("ifsc1");
		$acno2=$this->input->post("acno2");
		$bank2=$this->input->post("bank2");
		$branch2=$this->input->post("branch2");
		$ifsc2=$this->input->post("ifsc2");	
		$fact1=$this->input->post('fact1');
		$fact2=$this->input->post('fact2');
		$fact3=$this->input->post('fact3');
		$shr1=$this->input->post('shr1');
		$shr2=$this->input->post('shr2');
		$shr3=$this->input->post('shr3');
		$file1=$_FILES['image1']['name'];
		$image1=$this->imageupload($file1,"image1",$path);
		//$image1=$this->input->post('image1');
		$data_array=array(
			"clientid"=>$custid,
			"name"=>$custname,
			"image"=>$image1,
			"compname"=>$compname,
			"custtype"=>$custtype,
			"openbal"=>$openbal,
			"pass"=>$pass,
			"interest"=>$interest,
			"phone"=>$ph,
			"email"=>$email,
			"add1"=>$add1,
			"add2"=>$add2,
			"country"=>$country,
			"state"=>$state,
			"district"=>$district,
			"area"=>$area,
			"pin"=>$pin,
			"agreement_validity"=>$agvalidity,
			"agvalunit"=>$agunit,
			"pan"=>$pan,
			"tin_vat"=>$tin_vat,
			//"vat"=>$vat,
			"cst"=>$cst,
			"excise"=>$excise,
			
			"acno1"=>$acno1,
			"bank1"=>$bank1,
			"branch1"=>$branch1,
			"ifsc1"=>$ifsc1,
			"acno2"=>$acno2,
			"bank2"=>$bank2,
			"branch2"=>$branch2,
			"ifsc2"=>$ifsc2,
			
			"factory1"=>$fact1,
			"factory2"=>$fact2,
			"factory3"=>$fact3,
			"showroom1"=>$shr1,
			"showroom2"=>$shr2,
			"showroom3"=>$shr3,
			
			"doe"=>date('Y-m-d h:i:s A'),
			"sid"=>$this->session->userdata('uid'),
			"sname"=>$this->session->userdata('uname')
		);
		$uname=$this->session->userdata('uname');
		$data_array2=array(
			"uniid"=>"Customer Open",
			"title"=>"One user wants to  Registered for $custtype by $uname",
			"link"=>"Manage_distributer",
			"date"=>date('Y-m-d h:i:s A')
		
		);
		$checkdupliicate=$this->Manage_customer_model->checkduplicate($compname,$custtype,$email,$ph,$acno1);
		if(empty($checkdupliicate))
		{
		//if($image1!="")
		//{
			$this->Manage_customer_model->saveclentdetails($data_array);
			$this->Manage_customer_model->savenitification($data_array2);
			redirect('Manage_customer/viewclientlist','refresh');
		//}else
		//{
				//r//edirect('Manage_customer/createcustomer','refresh');
		//}
		}else
		{
				redirect('Manage_customer/createcustomer','refresh');
		}
		
	}
	public function imageupload($file,$name,$path)
	{
		$image=$file;
		if($image != '')
		{
			$allowedtype = "jpg|gif|png|jpeg|JPEG";
			$max_size = '';
			$max_width = '0';
			$max_height = '0';
			$upload_path = $path;
			$config['upload_path'] = $upload_path;
			$config['allowed_types'] = $allowedtype;
			$config['max_size']	= $max_size;
			$config['max_width'] = $max_width;
			$config['max_height'] = $max_height;
			$config['overwrite'] = FALSE;
			//$file_name = $file['prod_image']['name'];
			$file_name = $file;
			$file_name = preg_replace('/[\s,$#&\+\-()\[\];\'~`]/','_',$file_name);
			$f_name=time()."_".$file_name;
			$config['file_name'] = $f_name;
			//$config['orig_name'] = $file['prod_image']['name'];
			$config['orig_name'] = $file;
			$this->upload->initialize($config);
			if($this->upload->do_upload($name))
			{
				$data = array('upload_data' => $this->upload->data());
				$latest_filename_rtr = $data['upload_data']['file_name'];
				//generate the thumb image from the main image 
				$config['image_library'] = 'gd2'; 
				$config['source_image'] = "uploads/clientpics/".$latest_filename_rtr; 
				//$config['new_image'] = "uploads/thumb_images/"; 
				$config['thumb_marker'] = ''; 
				$config['create_thumb'] = TRUE; 
				$config['maintain_ratio'] = TRUE; 
				$config['width'] = 185; 
				$config['height'] = 185; 
				$this->image_lib->initialize($config); 
				if (!$this->image_lib->resize())
				{ 

				} 
				return $latest_filename_rtr;
			}
			else
			{
				print($this->upload->display_errors());
				return '';  
				
			}
			
		}
		else
			return '';   
				  
		
	}
 public function viewclientlist()
 {
 		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']="View Customer List";
		$data['getcust']=$this->Manage_customer_model->getallcustomer($this->session->userdata('uid'));
		$this->load->view('customer/view',$data);
 	
 }
  public function sndmail()
  {
  		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']="Send Company Brouchere";
		//$data['getcust']=$this->Manage_customer_model->getallcustomer($this->session->userdata('uid'));
		$this->load->view('customer/sendmail',$data);
  }
  public function sendmail()
  {
  	   
  		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$to_email=$this->input->post('email');
		$card=$this->input->post("card");
		
		if(empty($card) && !isset($card))
		{
			$card="8,2";
		}else{
			$card=implode(",",$card);
		}
		$data['card']=$card;
		$data['email']= $to_email;
		if(empty($to_email) && !isset($to_email)){
			$message='Please Provide Valid Email';
		     $this->session->set_flashdata('message',$message);
			redirect('Manage_customer/sndmail','refresh');
		}else{
			$this->load->view('send_mail/sendmail',$data);
			$message='Mail Sent successfully';
		     $this->session->set_flashdata('message',$message);
		     redirect('Manage_customer/sndmail','refresh');
		}
			
  }
  public function mail_sales()
  {
  	   
  		$this->authentication->is_loggedin($this->session->userdata('uname'));
		 $to_email=$this->input->post('emailcust');
		$card=$this->input->post("card");
		
		if(empty($card) && !isset($card))
		{
			$card="8,2";
		}else{
			$card=implode(",",$card);
		}
		$data['card']=$card;
		$data['email']= $to_email;
		if(empty($to_email) && !isset($to_email)){
			 $message='Please Provide Valid Email';
		     $this->session->set_flashdata('message',$message);
			redirect('Manage_customer/viewclientlist','refresh');
		}else{
			$this->load->view('send_mail/sendmail',$data);
			 $message='Mail Sent successfully';
		     $this->session->set_flashdata('message',$message);
		     redirect('Manage_customer/viewclientlist','refresh');
		}
  }
  public function mail_ind()
  {
	  $this->authentication->is_loggedin($this->session->userdata('uname'));
		 $to_email=$this->input->post('email');
		 $card=$this->input->post("cardview");
		
		if(empty($card) && !isset($card))
		{
			$card="8,2";
		}else{
			$card=$card;
		}
		$data['card']=$card;
		$data['email']= $to_email;
		if(empty($to_email) && !isset($to_email)){
			$message='Please Provide Valid Email';
		     $this->session->set_flashdata('message',$message);
			redirect('Manage_customer/viewclientlist','refresh');
		}else{
			$this->load->view('send_mail/sendmailsingle',$data);
			$message='Mail Sent successfully';
		     $this->session->set_flashdata('message',$message);
		   redirect('Manage_customer/viewclientlist','refresh');
		}
  }
  /*public function send_mail() { 
         $from_email = "your@example.com"; 
         $to_email = $this->input->post('email'); 
   
         //Load email library 
         $this->load->library('email'); 
   
         $this->email->from($from_email, 'Your Name'); 
         $this->email->to($to_email);
         $this->email->subject('Email Test'); 
         $this->email->message('Testing the email class.'); 
   
         //Send mail 
         if($this->email->send()) 
         $this->session->set_flashdata("email_sent","Email sent successfully."); 
         else 
         $this->session->set_flashdata("email_sent","Error in sending Email."); 
         $this->load->view('email_form'); 
      } 
	*/
public function get_cnflist()
  {
  	//  $this->authentication->is_loggedin($this->session->userdata('user_name'));
	  $ctyp=$this->input->post("custype");
	  $getcnflist=$this->Manage_customer_model->get_cnflistmodel($ctyp);
	  if(!empty($getcnflist) && isset($getcnflist))
	  {
	  	
		echo '<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CNF LIST</label>

										
					<div class="col-sm-9">
					<select name="custtype" id="custtype" class="col-xs-10 col-sm-5" onchange="customertype();" >
						<option value="">--Select CNF--</option>
										';
							foreach($getcnflist as $row3)
		          {
										
											echo '<option value="'. $row3->compname.'">'. $row3->compname.'</option>';
										
																
																
																
											
															
			       } 
										echo '</select>
											
										</div>';
	  	
			
		
	  }else{
	  	
	  }
  }
  public function getdelaerlist()
  {
  	$cnf=$this->input->post("cnf");
	  $getdealer=$this->Manage_customer_model->get_dealer($cnf);
	  if(!empty($getdealer) && isset($getdealer))
	  {
	  	
		echo '<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CNF LIST</label>

										
					<div class="col-sm-9">
					<select name="custtype" id="custtype" class="col-xs-10 col-sm-5" onchange="customertype();" >
						<option value="">--SELECT DEALER--</option>
				';
							foreach($getdealer as $row3)
		          {
										
											echo '<option value="'. $row3->compname.'">'. $row3->compname.'</option>';
																
																
											
															
			       } 
										echo '</select>
											
										</div>';
	  	
			
		
	  }else{
	  	
	  }
  }
  public function editcustomer($id)
  {
  	
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$data['title']='Dashboard';
	$custid=$id;
	$data['custdata']=$this->Manage_customer_model->getallcustomerdetails($custid);
	$data['country2']=$this->Manage_customer_model->getcountry();
	$data['customertype']=$this->Manage_customer_model->getcustomertyp();
	$countr="India";
	$data['state1']=$this->Manage_customer_model->getstatename($countr);
	/*$lastid=$this->Manage_customer_model->getlastid();
	if(empty($lastid))
	{
		$lastid=1;
	}else{
		$lastid=intval($lastid)+1;
	}
	$data['lastid']="GKCLNT".date('y').str_pad($lastid, 5 , '0', STR_PAD_LEFT);*/
	$this->load->view('customer/create',$data);
  }
  public function updatecustomer()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
		$path="uploads/clientpics/";
		date_default_timezone_set("asia/Kolkata");
		$custname=$this->input->post('custname');
		$id=$this->input->post('cld');
		//$custid=$this->input->post('custid');
		$compname=$this->input->post('compname');
		$custtype=strtoupper($this->input->post("custtype"));
		/*if($custtype=="CNF")
		{
			$custid="C$custid";
		}
		if($custtype=="DEALER")
		{
			$custid="D$custid";
		}
		if($custtype=="SUB-DEALER")
		{
			$custid="SD$custid";
		}
		if($custtype=="RETAILER")
		{
			$custid="T$custid";
		}*/
		$pass=$this->input->post("password");
		$agvalidity=$this->input->post("agval");
		$agunit=$this->input->post("agunit");
		$openbal=$this->input->post("securiyu");
		$ph=$this->input->post('ph');
		$interest=$this->input->post("interest");
		$email=$this->input->post('email');
		$add1=$this->input->post('add1');
		$add2=$this->input->post('add2');
		$country=$this->input->post('country');
		$state=$this->input->post('state');
		$district=$this->input->post('district');
		$area=$this->input->post('area');
		$pin=$this->input->post('pin');
		$pan=$this->input->post('pan');
		$tin_vat=$this->input->post('tin_vat');
		//$vat=$this->input->post('vat');
		$excise=$this->input->post('excise');
		$cst=$this->input->post('cst');
		$acno1=$this->input->post("acno1");
		$bank1=$this->input->post("bank1");
		$branch1=$this->input->post("branch1");
		$ifsc1=$this->input->post("ifsc1");
		$acno2=$this->input->post("acno2");
		$bank2=$this->input->post("bank2");
		$branch2=$this->input->post("branch2");
		$ifsc2=$this->input->post("ifsc2");	
		$fact1=$this->input->post('fact1');
		$fact2=$this->input->post('fact2');
		$fact3=$this->input->post('fact3');
		$shr1=$this->input->post('shr1');
		$shr2=$this->input->post('shr2');
		$shr3=$this->input->post('shr3');
		if(!empty($_FILES['image1']['name']) && isset($_FILES['image1']['name']))
		{
			$file1=$_FILES['image1']['name'];
		    $image1=$this->imageupload($file1,"image1",$path);
		}else{
			$image1=$this->input->post("file1");
		}
		
		//$image1=$this->input->post('image1');
		$data_array=array(
			"name"=>$custname,
			"image"=>$image1,
			"compname"=>$compname,
			"custtype"=>$custtype,
			"openbal"=>$openbal,
			"pass"=>$pass,
			"interest"=>$interest,
			"phone"=>$ph,
			"email"=>$email,
			"add1"=>$add1,
			"add2"=>$add2,
			"country"=>$country,
			"state"=>$state,
			"district"=>$district,
			"area"=>$area,
			"pin"=>$pin,
			"agreement_validity"=>$agvalidity,
			"agvalunit"=>$agunit,
			"pan"=>$pan,
			"tin_vat"=>$tin_vat,
			//"vat"=>$vat,
			"cst"=>$cst,
			"excise"=>$excise,
			
			"acno1"=>$acno1,
			"bank1"=>$bank1,
			"branch1"=>$branch1,
			"ifsc1"=>$ifsc1,
			"acno2"=>$acno2,
			"bank2"=>$bank2,
			"branch2"=>$branch2,
			"ifsc2"=>$ifsc2,
			
			"factory1"=>$fact1,
			"factory2"=>$fact2,
			"factory3"=>$fact3,
			"showroom1"=>$shr1,
			"showroom2"=>$shr2,
			"showroom3"=>$shr3,
			
			"doe"=>date('Y-m-d h:i:s A'),
			"sid"=>$this->session->userdata('uid'),
			"sname"=>$this->session->userdata('uname')
		);
		$uname=$this->session->userdata('uname');
		$data_array2=array(
			"uniid"=>"Customer Open",
			"title"=>"One user wants to  Registered for $custtype by $uname",
			"link"=>"Manage_distributer",
			"date"=>date('Y-m-d h:i:s A')
		
		);
		//$checkdupliicate=$this->Manage_customer_model->checkduplicate($compname,$custtype,$email,$ph,$acno1);
		//if(empty($checkdupliicate))
		//{
		//if($image1!="")
		//{
			$this->Manage_customer_model->updateclentdetails($data_array,$id);
			//$this->Manage_customer_model->savenitification($data_array2);
			//redirect('Manage_customer/viewclientlist','refresh');
		//}else
		//{
				//r//edirect('Manage_customer/createcustomer','refresh');
		//}
		//}else
		//{
				redirect('Manage_customer/viewclientlist','refresh');
		//}
  }
	
	
}
