<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication'));
		$this->load->model('login_model');
			//$this->load->model('Notify_model');
	}
	
	public function index()
	{
		
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$data['title']='Dashboard';
	//$data['getallnotice']=$this->Notify_model->getallnotice();
	//$this->load->view('');
	$this->load->view('index_view',$data);
	}
	public function chk_login()
	{
		//$r=$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$this->load->view('login_view');
	}
	public function signin()
	{
		 $username=$this->input->post('user_name');
		 $password=$this->input->post('password');

		$data['user_details']=$this->login_model->fetch_user_data($username,$password);
		//print_r($data['user_details']);
		if(!empty($data['user_details']))
		{
		  foreach($data['user_details'] as $ud)
		  {
		   $user_id=$ud->id;
		   $user_name=$ud->name;
		   $pic=$ud->image;
		   $udesig=$ud->desig;
		   $user=array(
		    "uid" => $user_id,
			"uname" => $user_name,
			"uimage"=>$pic,
			"desig"=>$udesig
		   );
		   $this->session->set_userdata($user);
		   
		  }
		  //exit;
		  $message='Login Successfully.....';
		  $this->session->set_flashdata('message',$message);
		  redirect('login','refresh');
		}
		else
		{
			$message='Invalid Credential or your account has been deactivated';
		  $this->session->set_flashdata('message',$message);
		  redirect('login/chk_login','refresh');
		}
	}
	public function signout()
	{	
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$this->session->sess_destroy();
		 redirect('login/chk_login/logout','refresh');
	}
	public function change_password()
	{
		$this->authentication->is_loggedin($this->session->userdata('user_name'));
		$data['password']=$this->login_model->get_pass($this->session->userdata('user_id'));
		$data['title']="Change Password";
		$this->load->view('change_password',$data);
	}
	
	public function update_password()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$password=base64_encode($this->input->post('new_password'));
		$where=array("id" => $this->session->userdata('user_id'));
		$data=array("password" => $password);
		$this->login_model->update_pass($where,$data);
		$message='Password Updated Successfully.';
		$this->session->set_flashdata('message',$message);
		redirect('login/index/','refresh');
	}
	public function chanpassword()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
	}
	
	
	
}
