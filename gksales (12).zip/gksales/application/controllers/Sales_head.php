<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_head extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		//$this->load->library('fpdf_gen');
		$this->load->library('fpdf_gen2');
		$this->load->library('numbertowords');
		$this->load->model('Sales_head_model');
		$this->load->model('profile_model');
		
		
		//$this->load->model('Purchase_model');
			//$this->load->model('Notify_model');
	}
	public function myteam_mem()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']="All Teammember ";
		$user=$this->session->userdata('uid');
		$data['getallsaleexe']=$this->Sales_head_model->getsaleexe($user);
		$this->load->view('myteam/teammem',$data);
		
	}
	public function getdetailsinfo($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']="Details Information";
		$data['slsmandtails']=$this->profile_model->fetchslsmandtails($id);
		$data['totlleads']=$this->profile_model->totlleads($id);
		$data['cmplttrgt']=$this->profile_model->cmplttrgt($id);
		$data['aboutme']=$this->profile_model->getaboutme($id);
		$trgt=$this->profile_model->fetchtrgt($id);
		
		//print_r($trgt);exit;
		$a=array();
		$data['percent']=$a;
		foreach($trgt as $row)
		{
			$sid=$row->salesmanid;
			$snam=$row->name;
		}
		$month=date('M');
		$year=date('Y');
		
		$data['trgt1']=$this->profile_model->ftchtrgt1($sid,$month,$year);
		$data['trgt2']=$this->profile_model->ftchtrgt2($sid);
		//$trgt3=$this->profile_model->ftchtrgt3($sid,$month,$year);
		foreach($data['trgt2'] as $row104){
			 $terget=intval($row104->nor);
	   }
		//get incentive slot
		$getinsentvslt=$this->profile_model->fetchslab();
		$data['fetchslb']=$getinsentvslt;
		$getperformance=$this->profile_model->fetchperform();
		$totper=array();
		$getperformance=array_filter($getperformance);
		//print_r($getperformance);
		if(!empty($getperformance) && isset($getperformance))
		{
			foreach($getperformance as $rowper)
			{
			 $sid=$rowper->sid;
				$getresperf=$this->profile_model->cmplttperfrgt($sid);
				
				foreach($getresperf as $sidper)
				{
					$getp=intval($sidper->nor);
					$sid1=$sid;
					$cont="$getp;$sid1";
					array_push($totper,$cont);
				}
				
			}
		}
		
		rsort($totper);
		$data['sortdta']=$totper;
		$uid=$id;
		$getsid=$this->profile_model->getallsiddetails($uid);
		foreach($getsid as $rosid)
		{
			$sidor=$rosid->salesmanid;
		}
		$data['sidoriginal']=$sidor;
		//print_r($totper);
		/*foreach($trgt3 as $row3)
		{

			$ftchterget=$row3->terget;
			$fetchid=$row3->salesmanid;
			$trgt4=$this->profile_model->ftchtrgt4($fetchid);
			foreach($trgt4 as $row4){
				 $slsid=$row4->id;
				 $trgt5=$this->profile_model->ftchtrgt5($slsid);
				 if(isset($trgt5)){$p=0;
				 foreach($trgt5 as $row5){
					 
				 $p++;}}
				 if(isset($p) && !empty($p)){
					 $ratio=$ftchterget/$p;
				 }else{
					 $ratio=0;
				 }
				// echo $p;exit;
				 
				 $formatted_number = round($ratio,2);
				// echo $formatted_number;echo "<br>";
				
				array_push($data['percent'],$formatted_number);	
			}
		}
		
		arsort($data['percent']);*/
		$data['id']=$id;
		$data['clientdetails']=$this->profile_model->clientdetails($id);
		$this->load->view('myteam/individualinfo',$data);
		
	}
  public function performance()
  {
  	    $this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']="Details Information";
		$this->load->view('myteam/performance',$data);
		
  }
}