<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Enquery_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		//$this->load->library('fpdf_gen');
		$this->load->library('fpdf_gen2');
		$this->load->library('numbertowords');
		$this->load->model('enquiry_model');
		
		
		//$this->load->model('Purchase_model');
			//$this->load->model('Notify_model');
	}
	public function add()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['state']=$this->enquiry_model->getstate();
		$this->load->view('Enquery/add',$data);	
	}
	public function saveenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$name=$this->input->post("name");
		$ph=$this->input->post("ph");
		$email=$this->input->post("email");
		$add=$this->input->post("add");
		$state=$this->input->post("state");
		$dist=$this->input->post("dist");
		$location=$this->input->post("location");
		$date=$this->input->post("date");
		$nxtdt=$this->input->post("date2");
		//echo $date;exit;
		$rm1=$this->input->post("rm1");
		$rating=$this->input->post("rating");
		//$rm2=$this->input->post("rm2");
		$data_array=array(
			'name'=>$name,
			'phone'=>$ph,
			'email'=>$email,
			'address'=>$add,
			'state'=>$state,
			'dist'=>$dist,
			'location'=>$location,
			'dat'=>$date,
			'remark1'=>$rm1,
			'date2'=>$nxtdt,
			'rating'=>$rating,
			"user"=>$this->session->userdata('uname')
			//'remark2'=>$rm2
		);
		$this->enquiry_model->saveenq($data_array);
		redirect('Enquery_controller/viewenq');
	}
	public function viewenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['enq']=$this->enquiry_model->fetchenq($this->session->userdata('uname'));
		$this->load->view('Enquery/view',$data);
	}
	public function edit($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['state']=$this->enquiry_model->getstate();
		$id1=$id;
		$data['enq']=$this->enquiry_model->fetchenq1($id);
		$this->load->view('Enquery/edit',$data);
	}
	public function follow($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id1=$id;
		$data['enq']=$this->enquiry_model->fetchenq1($id);
		$this->load->view('Enquery/follow',$data);
	}
	public function updateenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id	=$this->input->post('id');
		$name=$this->input->post("name");
		$ph=$this->input->post("ph");
		$email=$this->input->post("email");
		$add=$this->input->post("add");
		$state=$this->input->post("state");
		$dist=$this->input->post("dist");
		$location=$this->input->post("location");
		$rm1=$this->input->post("rm1");
		//$rating=$this->input->post("rating");
		//$rm2=$this->input->post("rm2");
		$data_array=array(
			'name'=>$name,
			'phone'=>$ph,
			'email'=>$email,
			'address'=>$add,
			'state'=>$state,
			'dist'=>$dist,
			'location'=>$location,
			'remark1'=>$rm1,
			//'rating'=>$rating
			//'remark2'=>$rm2
		);
		$this->enquiry_model->updateenq($data_array,$id);
		redirect('Enquery_controller/viewenq');
	}
	public function deleteenq($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id1=$id;
		$this->enquiry_model->deleteenq($id1);
		redirect('Enquery_controller/viewenq');
	}
	public function updatefollow()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id	=$this->input->post('id');
		//echo $id;exit;
		$date2=$this->input->post('date2');
		$rm2=$this->input->post('rm2');
		 $date3=$this->input->post('date3');
		 $rm3=$this->input->post('rm3');
		 $nextfollow=$this->input->post('nextfolow');
		 $rating=$this->input->post("rating");
		if(isset($nextfollow))
		{
			if(isset($rating) && !empty($rating)){
					
			$data_array=array(
			'remark2'=>$rm2,
			'date3'=>$nextfollow,
			'rating'=>$rating,
			
		    );
			}else{
				
			$data_array=array(
			'remark2'=>$rm2,
			'date3'=>$nextfollow,
						
		    );
		}
			
		}else{
			
			$data_array=array(
			'remark3'=>$rm3,
			'rating'=>$rating,
			
		    );
		}
		
		
		
		
		$this->enquiry_model->updatefollow($data_array,$id);
		redirect('Enquery_controller/viewenq');
		
	}
	public function sendmailfromenquery()
	  {
	  	   
	  		$this->authentication->is_loggedin($this->session->userdata('uname'));
			$to_email=$this->input->post('email');
			$card=$this->input->post("card");
			
			if(empty($card) && !isset($card))
			{
				$card="8,2";
			}else{
				$card=implode(",",$card);
			}
			$data['card']=$card;
			$data['email']= $to_email;
			if(empty($to_email) && !isset($to_email)){
				$message='Please Provide Valid Email';
			     $this->session->set_flashdata('message',$message);
				redirect('Enquery_controller/viewenq','refresh');
			}else{
				$this->load->view('send_mail/sendmail',$data);
				$message='Mail Sent successfully';
			     $this->session->set_flashdata('message',$message);
			     redirect('Enquery_controller/viewenq','refresh');
			}
				
	  }
	  public function savefolloeups()
	  {
	  	$remarks=$this->input->post("remark");
		$dat=$this->input->post("dat");
		$id=$this->input->post("id");
		$rate=$this->input->post("rating");
		if(isset($rate) && !empty($rate))
		{
			$data_array=array(
				"remark1"=>$remarks,
				"rating"=>$rate,
				"dat"=>$dat
			);
			
		}else{
			
		
			$data_array=array(
				"remark1"=>$remarks,
				"dat"=>$dat
			);
		}
		$this->enquiry_model->getsaverating($data_array,$id);
	  }
//update on 19012016
	  public function recepitv($id)
     {
          $this->authentication->is_loggedin($this->session->userdata('uname'));
		$bkid=$id;
		$uname=strtoupper($this->session->userdata('uname'));
		$path="assets/logo/logo1.png";
		$path2="assets/logo/gklogo12.png";
		$getall_voucher=$this->enquiry_model->getallvouchertransaction($bkid);
		foreach($getall_voucher as $rowvoucher)
		{
			$clientid=$rowvoucher->clientid;
			$bookingid=$rowvoucher->bookingid;
			$type=strtoupper($rowvoucher->type);
			$purpose=strtoupper($rowvoucher->purpose);
			$vamnt=$rowvoucher->vamnt;
			$chq=$rowvoucher->chqno;
			$branch=$rowvoucher->branch;
			$bank=$rowvoucher->bankname;
			$dte=$rowvoucher->doe;
			
		}
		$getclientname=$this->enquiry_model->getclientdetails($clientid);
		foreach($getclientname as $clntnme)
		{
			$clienttyp=strtoupper($clntnme->custtype);
			$compname=$clntnme->compname;
			$name=$clntnme->name;
			$contct=$clntnme->phone;
		}
		if($clienttyp=="RETAILER")
		{
			$name=$name;
		}else{
			$name=$compname;
		}
		$red=$this->numbertowords->convert_number($vamnt);
		$receivetxt=" we have  received Rs $vamnt/- ($red Rupees) from you for $purpose deposit .In case of any query feel free to contact us any time. ";
		$x=$this->fpdf->GetX();
		$y=$this->fpdf->GetY();
		$this->fpdf->Image("$path2",10,20,300,200,'png');
		$this->fpdf->Image("$path",11,7,40,40,'png');
		
		$this->fpdf->SetFont('Arial','B',40);
		$this->fpdf->text(60,30,"GK RICKSHOW PVT LTD ");
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text($x+229,$y+5,"Office Address. ");
		  $y=$y+5;
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+229,$y+5,"30(33/1) N.T Road,Padmabati ");
		$y=$y+5;
		$this->fpdf->text($x+229,$y+5,"Colony, Baidyabati, Hooghly, ");
		
		$y=$y+5;
		$this->fpdf->text($x+229,$y+5,"West Bengal-712222, India ");
		$y=$y+5;
		 $this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text($x+229,$y+5,"TIN NO: 19731597605 ");
		$y=$y+5;
		$this->fpdf->text($x+229,$y+5,"Phone: 033-64517771 ");
		$y=$y+5;
		//$this->fpdf->text($x+229,$y+5,"E-mail: accounts@gkrickshow.com ");
		$y=$y+5;
		$this->fpdf->line(296,$y+5,"-----------------------","50");
		 $this->fpdf->SetFont('Arial','B',19);
		 $this->fpdf->ln(45);
		$this->fpdf->cell(1);
		$this->fpdf->setFillColor(160,160,160);
		$this->fpdf->cell(150,15,"RECEIPT VOUCHER",1,0,'C','1');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(10);
		//$this->fpdf->cell(40,8,"INVOICE NO : ",1,0,'');
		//$this->fpdf->cell(76,8,"",1,0,'');
		$this->fpdf->ln(8);
		$this->fpdf->cell(161);
		$this->fpdf->cell(40,8,"CLIENT ID : ",1,0,'');
		$this->fpdf->cell(76,8,"$clientid",1,0,'');
		$this->fpdf->ln(15);
		$this->fpdf->cell(1);
		$this->fpdf->cell(50,9,"Date : ",1,0,'');
		$this->fpdf->cell(100,9,"$dte",1,0,'');
		$this->fpdf->cell(10);
		$this->fpdf->SetFont('Arial','B',20);
		$this->fpdf->cell(117,18,"Amount :  $vamnt/-",1,0,'C');
		$this->fpdf->ln(9);
		$this->fpdf->cell(1);
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(50,9,"Client's Name : ",1,0,'');
		$this->fpdf->cell(100,9,"$name",1,0,'');
		
		$this->fpdf->ln(9);
		$this->fpdf->cell(1);
		$this->fpdf->cell(50,9,"Client's Contact Number : ",1,0,'');
		$this->fpdf->cell(100,9,"$contct",1,0,'');
		$this->fpdf->cell(10);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(117,9,"Payment Type :  $type",1,0,'');
		
		$this->fpdf->ln(9);
		$this->fpdf->cell(1);
		$this->fpdf->cell(50,9,"Payment Purpose : ",1,0,'');
		$this->fpdf->cell(100,9,"$purpose Deposit",1,0,'');
		$this->fpdf->cell(10);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->cell(117,9,"Cheque No :  $chq",1,0,'');
		
		//$this->fpdf->text(172,112,"Cash: ");
		$this->fpdf->ln(2);
		$this->fpdf->cell(175);
		//$this->fpdf->cell(10,8,"",1,0,'');
		//$this->fpdf->text(201,112,"Cheque: ");
		$this->fpdf->ln(0);
		$this->fpdf->cell(210);
		//$this->fpdf->cell(10,8,"",1,0,'');
		//$this->fpdf->text(240,112,"RTGS/NEFT: ");
		$this->fpdf->ln(0);
		//$this->fpdf->cell(260);
		//$this->fpdf->cell(10,8,"",1,0,'');
		$this->fpdf->ln(12);
		$this->fpdf->cell(1);
		$this->fpdf->setFillColor(160,160,160);
		$this->fpdf->cell(277,9,"Amount (In words) ",1,0,'','1');
		$this->fpdf->ln(9);
		$this->fpdf->cell(1);
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(277,9,"INR. $red Rs. Only",1,0,'');
		$this->fpdf->ln(15);
		$this->fpdf->cell(1);
		
		$this->fpdf->setFillColor(160,160,160);
		$this->fpdf->cell(277,9,"Acknowledgement ",1,0,'','1');
		$this->fpdf->ln(9);
		$this->fpdf->cell(1);
		$this->fpdf->Multicell(277,5,"$receivetxt",1);
		$this->fpdf->ln(10);
		$this->fpdf->cell(1);
		$this->fpdf->cell(139,9,"Receiver's Name : $uname ",1,0,'');
		$this->fpdf->cell(139,9,"Receiver's Signature : ",1,0,'');
	
        $this->fpdf->Output();
       }
}