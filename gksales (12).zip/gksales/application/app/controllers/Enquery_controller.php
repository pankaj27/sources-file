<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Enquery_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		//$this->load->library('fpdf_gen');
		$this->load->model('enquiry_model');
		//$this->load->model('Purchase_model');
			//$this->load->model('Notify_model');
	}
	public function add()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['state']=$this->enquiry_model->getstate();
		$this->load->view('Enquery/add',$data);	
	}
	public function saveenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$name=$this->input->post("name");
		$ph=$this->input->post("ph");
		$email=$this->input->post("email");
		$add=$this->input->post("add");
		$state=$this->input->post("state");
		$dist=$this->input->post("dist");
		$location=$this->input->post("location");
		$date=$this->input->post("date");
		$nxtdt=$this->input->post("date2");
		//echo $date;exit;
		$rm1=$this->input->post("rm1");
		$rating=$this->input->post("rating");
		//$rm2=$this->input->post("rm2");
		$data_array=array(
			'name'=>$name,
			'phone'=>$ph,
			'email'=>$email,
			'address'=>$add,
			'state'=>$state,
			'dist'=>$dist,
			'location'=>$location,
			'dat'=>$date,
			'remark1'=>$rm1,
			'date2'=>$nxtdt,
			'rating'=>$rating,
			"user"=>$this->session->userdata('uname')
			//'remark2'=>$rm2
		);
		$this->enquiry_model->saveenq($data_array);
		redirect('Enquery_controller/viewenq');
	}
	public function viewenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['enq']=$this->enquiry_model->fetchenq($this->session->userdata('uname'));
		$this->load->view('Enquery/view',$data);
	}
	public function edit($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['state']=$this->enquiry_model->getstate();
		$id1=$id;
		$data['enq']=$this->enquiry_model->fetchenq1($id);
		$this->load->view('Enquery/edit',$data);
	}
	public function follow($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id1=$id;
		$data['enq']=$this->enquiry_model->fetchenq1($id);
		$this->load->view('Enquery/follow',$data);
	}
	public function updateenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id	=$this->input->post('id');
		$name=$this->input->post("name");
		$ph=$this->input->post("ph");
		$email=$this->input->post("email");
		$add=$this->input->post("add");
		$state=$this->input->post("state");
		$dist=$this->input->post("dist");
		$location=$this->input->post("location");
		$rm1=$this->input->post("rm1");
		//$rating=$this->input->post("rating");
		//$rm2=$this->input->post("rm2");
		$data_array=array(
			'name'=>$name,
			'phone'=>$ph,
			'email'=>$email,
			'address'=>$add,
			'state'=>$state,
			'dist'=>$dist,
			'location'=>$location,
			'remark1'=>$rm1,
			//'rating'=>$rating
			//'remark2'=>$rm2
		);
		$this->enquiry_model->updateenq($data_array,$id);
		redirect('Enquery_controller/viewenq');
	}
	public function deleteenq($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id1=$id;
		$this->enquiry_model->deleteenq($id1);
		redirect('Enquery_controller/viewenq');
	}
	public function updatefollow()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id	=$this->input->post('id');
		//echo $id;exit;
		$date2=$this->input->post('date2');
		$rm2=$this->input->post('rm2');
		 $date3=$this->input->post('date3');
		 $rm3=$this->input->post('rm3');
		 $nextfollow=$this->input->post('nextfolow');
		 $rating=$this->input->post("rating");
		if(isset($nextfollow))
		{
			if(isset($rating) && !empty($rating)){
					
			$data_array=array(
			'remark2'=>$rm2,
			'date3'=>$nextfollow,
			'rating'=>$rating,
			
		    );
			}else{
				
			$data_array=array(
			'remark2'=>$rm2,
			'date3'=>$nextfollow,
						
		    );
		}
			
		}else{
			
			$data_array=array(
			'remark3'=>$rm3,
			'rating'=>$rating,
			
		    );
		}
		
		
		
		
		$this->enquiry_model->updatefollow($data_array,$id);
		redirect('Enquery_controller/viewenq');
		
	}
	public function sendmailfromenquery()
	  {
	  	   
	  		$this->authentication->is_loggedin($this->session->userdata('uname'));
			$to_email=$this->input->post('email');
			$card=$this->input->post("card");
			
			if(empty($card) && !isset($card))
			{
				$card="8,2";
			}else{
				$card=implode(",",$card);
			}
			$data['card']=$card;
			$data['email']= $to_email;
			if(empty($to_email) && !isset($to_email)){
				$message='Please Provide Valid Email';
			     $this->session->set_flashdata('message',$message);
				redirect('Enquery_controller/viewenq','refresh');
			}else{
				$this->load->view('send_mail/sendmail',$data);
				$message='Mail Sent successfully';
			     $this->session->set_flashdata('message',$message);
			     redirect('Enquery_controller/viewenq','refresh');
			}
				
	  }
	  public function savefolloeups()
	  {
	  	$remarks=$this->input->post("remark");
		$dat=$this->input->post("dat");
		$id=$this->input->post("id");
		$rate=$this->input->post("rating");
		if(isset($rate) && !empty($rate))
		{
			$data_array=array(
				"remark1"=>$remarks,
				"rating"=>$rate,
				"dat"=>$dat
			);
			
		}else{
			
		
			$data_array=array(
				"remark1"=>$remarks,
				"dat"=>$dat
			);
		}
		$this->enquiry_model->getsaverating($data_array,$id);
	  }
}