<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Enquery_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		//$this->load->library('fpdf_gen');
		$this->load->model('enquiry_model');
		//$this->load->model('Purchase_model');
			//$this->load->model('Notify_model');
	}
	public function add()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$this->load->view('Enquery/add');	
	}
	public function saveenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$name=$this->input->post("name");
		$ph=$this->input->post("ph");
		$email=$this->input->post("email");
		$add=$this->input->post("add");
		$rm1=$this->input->post("rm1");
		$rm2=$this->input->post("rm2");
		$data_array=array(
			'name'=>$name,
			'phone'=>$ph,
			'email'=>$email,
			'address'=>$add,
			'remark1'=>$rm1,
			'remark2'=>$rm2
		);
		$this->enquiry_model->saveenq($data_array);
		redirect('Enquery_controller/viewenq');
	}
	public function viewenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['enq']=$this->enquiry_model->fetchenq();
		$this->load->view('Enquery/view',$data);
	}
	public function edit($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id1=$id;
		$data['enq']=$this->enquiry_model->fetchenq1($id);
		$this->load->view('Enquery/edit',$data);
	}
	public function updateenq()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id	=$this->input->post('id');
		$name=$this->input->post("name");
		$ph=$this->input->post("ph");
		$email=$this->input->post("email");
		$add=$this->input->post("add");
		$rm1=$this->input->post("rm1");
		$rm2=$this->input->post("rm2");
		$data_array=array(
			'name'=>$name,
			'phone'=>$ph,
			'email'=>$email,
			'address'=>$add,
			'remark1'=>$rm1,
			'remark2'=>$rm2
		);
		$this->enquiry_model->updateenq($data_array,$id);
		redirect('Enquery_controller/viewenq');
	}
	public function deleteenq($id)
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id1=$id;
		$this->enquiry_model->deleteenq($id1);
		redirect('Enquery_controller/viewenq');
	}
}