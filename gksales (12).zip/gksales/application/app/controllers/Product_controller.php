<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		$this->load->model('Product_model');
			//$this->load->model('Notify_model');
	}
		public function viewdemo()
		{
			$this->authentication->is_loggedin($this->session->userdata('uname'));
	        $data['title']='Dashboard';
			$this->load->view('models/viewdemo',$data);
		}

	
	
}
