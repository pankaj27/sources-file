<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paymentcontroller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		$this->load->library('fpdf_gen');
		$this->load->model('paymentmodel');
		//$this->load->model('Purchase_model');
			//$this->load->model('Notify_model');
	}
	public function createorder()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']='Create Order';
		$user=$this->session->userdata('uname');
		$data['models']=$this->paymentmodel->getmodelsdetails();
		$data['allmaterial']=$this->paymentmodel->get_material();
		$data['getcolorcode']=$this->paymentmodel->getall_colorcode();
		$data['getallproduct']=$this->paymentmodel->getallproduct();
		$data['customer']=$this->paymentmodel->getcustomername($user);
		//$data['spareparts']=$this->paymentmodel->getspareparts();
		$this->load->view('payments/createbooking',$data);
	
		
		
	}
	public function getallspare_parts_sort_by_modelname()
	{
	   $modelid=$this->input->post("modcode");
		$modelname=$this->input->post("modnam");
		$getparts=$this->paymentmodel->getparts_sort_by_modelname($modelname);
		echo '<ol   id="allspareparts">';
						//echo '<li><small>Spare Parts list</small></li>';
						if(!empty($getparts)){
							 $i=1; 
							 foreach($getparts as $row){ 
								$diff=$row->diff;
								$reoder=$row->reorderlevel; 
								$partsid=$row->materiel_id;
								$prtsamnt=$row->dispr;
								$getspecifi=$this->paymentmodel->getspecifbypartsid($partsid);
								if($diff<$reoder){
									//echo '<li  class="btn btn-block ink-reaction btn-danger"  title="'. $row->materialname.'('.$row->qnty.')" ><a  id="item_$i" href="javascript:anchor_test('.$row->id.')" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small>'. $row->materialname.'('. $row->qnty.')</small></a></li>';
									echo '<li   title="'. $row->materialname.'"("'.$row->qnty.'")">';
							 	//echo '<a  id="item_ $i" href="javascript:anchor_test('. $row->id.' )" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
								echo '<a  id="item_ $i" href="javascript:void(0);" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
							 	 echo '<div class="tile-content">';
										
										echo '<div class="tile-text" style="font-weight: bold;"><small>'.$row->materialname.'('. $row->qnty.')</small></div>';
									echo '</div>';
							   echo '</a>' ;
							 	echo '</li>';
								echo '<div class="modal fade" id="myModal_'.$row->id.'" role="dialog">
								    <div class="modal-dialog modal-md">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">'. $row->materialname.'</h4>
								        </div>
								        <div class="modal-body">
								        <div class="row">
								          <div class="col-md-12">
								        	 <form class="form-horizontal">';
								        	 if(isset($getspecifi) && !empty($getspecifi)){
								        	 	
											   echo ' <div class="form-group">
											    <div class="col-md-2"></div>
											    <div class="col-md-3">
											      <h4>Select Specification:  </h4>
											      </div>
											      
											      <div class="col-md-6">
											      <select name="specifi" class="form-control" id="speci_'.$row->id.'">';
												  
											      	foreach($getspecifi as $spe)
													{
														echo '<option value="'.$spe->id.'">'.$spe->specification.'</option>';
													}
											      	
											      
											      echo '</select>
											        
											      </div>
											    </div>';
											 }else{
											 	echo '<input type="hidden" value="9999
											 	"class="form-control" id="speci_'.$row->id.'" placeholder="No of parts">';
											 }
											    echo '<div class="form-group">
											      
											    </div>
											    
											    <div class="form-group">
											     <div class="col-md-2"></div>
											      <div class="col-md-3">
											        <h4>Enter No Of Parts:</h4>
											      </div>
											      
											      <div class="col-md-6">
											        <input type="text" class="form-control" id="noprts_'.$row->id.'" placeholder="No of parts">
											        <input type="hidden" value="'.$prtsamnt.'" id="prtsamnt_'.$row->id.'">
											      </div>
											    </div>
											    
											  </form>
										  </div>
										</div>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" onclick="anchor_test('. $row->id.' )">Submit</button>
								        </div>
								      </div>
								    </div>
							 </div>';
									$i++;
								}else
									{
											//echo '<li    title="'. $row->materialname.'('.$row->qnty.')" ><a  id="item_$i" href="javascript:anchor_test('.$row->id.')" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small>'. $row->materialname.'('. $row->qnty.')</small></a></li>';
											echo '<li   class="tile" title="'. $row->materialname.'"("'.$row->qnty.'")"">';
							 	//echo '<a  id="item_ $i" href="javascript:anchor_test('. $row->id.' )" >';
							 	echo '<a  id="item_ $i" href="javascript:void(0);" data-toggle="modal" data-target="#myModal_'.$row->id.'" >';
							 	 echo '<div class="tile-content">';
										
										echo '<div class="tile-text" style="font-weight: bold;"><small>'.$row->materialname.'('. $row->qnty.')</small></div>';
									echo '</div>';
							   echo '</a>' ;
							 	echo '</li>';
								echo '<div class="modal fade" id="myModal_'.$row->id.'" role="dialog">
								    <div class="modal-dialog modal-md">
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">'. $row->materialname.'</h4>
								        </div>
								        <div class="modal-body">
								        <div class="row">
								          <div class="col-md-12">
								        	 <form class="form-horizontal">';
											    if(isset($getspecifi) && !empty($getspecifi)){
								        	 	
											   echo ' <div class="form-group">
											    <div class="col-md-2"></div>
											    <div class="col-md-3">
											      <h4>Select Specification:  </h4>
											      </div>
											      
											      <div class="col-md-6">
											      <select name="specifi" class="form-control" id="speci_'.$row->id.'">';
												  
											      	foreach($getspecifi as $spe)
													{
														echo '<option value="'.$spe->id.'">'.$spe->specification.'</option>';
													}
											      	
											      
											      echo '</select>
											        
											      </div>
											    </div>';
											 }else{
											 	echo '<input type="hidden" value="9999
											 	"class="form-control" id="speci_'.$row->id.'" placeholder="No of parts">';
											 }
											    echo '<div class="form-group">
											    </div>
											    <div class="form-group">
											      
											    </div>
											    
											    <div class="form-group">
											     <div class="col-md-2"></div>
											      <div class="col-md-3">
											       <h4> Enter No Of Parts:</h4>
											      </div>
											      
											      <div class="col-md-6">
											        <input type="text" class="form-control" id="noprts_'.$row->id.'" placeholder="No of parts">
											         <input type="hidden" value="'.$prtsamnt.'" id="prtsamnt_'.$row->id.'">
											      </div>
											    </div>
											    
											  </form>
										  </div>
										</div>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								          <button type="button" class="btn ink-reaction btn-raised btn-primary" data-dismiss="modal" onclick="anchor_test('. $row->id.' )">Submit</button>
								        </div>
								      </div>
								    </div>
							 </div>';
								
									$i++;	
								}
								//echo  ' <li style="border:1px solid #c2c2c2;"></li>';
							
								
							
						   } 
					echo '</ol>';
					
					}else{
						echo "<h5 style='color:red;'>No Spare Parts Available</h5>";
					}
		//print_r($getparts);
		
		
		
		
		
	}
	public function getdetails_purchase()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$id=$this->input->post('id');
		$specid=$this->input->post("specid");
		$result=$this->paymentmodel->get_alldetails($id);
		foreach($result as $row)
		{
			$materialid=$row->materiel_id;
			$materialnam=$row->materialname;
			$unit=$row->unit;
		}
		$getspecid=$this->paymentmodel->getspecification($specid);
		foreach($getspecid as $rowspe)
		{
			$spectit=$rowspe->specification;
		}
		$result=array("matid"=>"$materialid","matname"=>"$materialnam","specif"=>"$spectit","unit"=>"$unit");
		echo json_encode($result);
	}
  public function getcustmer()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
  	 $email=$this->input->post("custmail");
	$getcustdetails=$this->paymentmodel->getcustdetails($email);
    if(!empty($getcustdetails) && isset($getcustdetails))
	{
		foreach($getcustdetails as $row)
		{
			$comp=$row->compname;
			$name=$row->name;
			$image=$row->image;
			$custid=$row->clientid;
			$email=$row->email;
		}
		$result=array("comp"=>"$comp","name"=>"$name","image"=>"$image","custid"=>$custid,"email"=>"$email");
		echo json_encode($result);
	}
  	
  }
  public function savepiorder_customer()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
	//$custid=$this->input->post('pono');
	//echo $custmailid=$this->input->post('dte')."<br>";
	echo $custname=$this->input->post('custname')."<br>";
	echo $compname=$this->input->post('compname')."<br>";
	echo $notr=$this->input->post('numofrows')."<br>";
	$item=array();$model1=array();
		for($i=1;$i<=$notr;$i++)
		{
			$matid=$this->input->post("matid_$i");
			$modelname=$this->input->post("modelname_$i");
			$matqty=$this->input->post("prqty1_$i");
			$modelid=$this->input->post("modelid1_$i");
			$prtspec=$this->input->post("prtspecif_$i");
			echo $specificat=$this->input->post("specification_$i");
			echo "<br>";
			$colorspeci=$this->input->post("colorspe_$i");
			if(isset($matid) && !empty($matid) && isset($matqty) && !empty($matqty))
			{
				$item1=$matid.";".$modelname.";".$matqty.";".$prtspec;
			
			   array_push($item,$item1);
			}
			if(isset($modelid) && !empty($modelid) && isset($matqty) && !empty($matqty))
			{
				$specificatexplode=explode("||",$specificat);
				foreach($specificatexplode as $row)
				{
				   $prtex=explode("_",$row);
				   print_r($prtex);
				   echo "<br>";
				   
				}
				print_r($specificatexplode);
				$mode2=$modelid.";".$modelname.";".$matqty.";".$specificat.";".$colorspeci;
				array_push($model1,$mode2);
			}
			
		}
		echo "<br>";
		print_r($model1);
		echo "<br>";
		print_r($item1);
		
	
  }
  public function bookingsave()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$custid=$this->input->post("compid");
	$notr=$this->input->post('numofrows');
	date_default_timezone_set("Asia/kolkata");
	$getbookingid=$this->paymentmodel->getbookingid();
	if(empty($getbookingid))
	{
		$getbookingid=1;
		$bkid="GKSLSBK".str_pad($getbookingid, 5 , '0', STR_PAD_LEFT);
	}else{
		$getbookingid=intval(substr($getbookingid, -5))+1;
		$bkid="GKSLSBK".str_pad($getbookingid, 5 , '0', STR_PAD_LEFT);
	}
	for($i=1;$i<=$notr;$i++)
	{
		$particular=$this->input->post("particular_$i");
		$getprtsname=$this->paymentmodel->getpartsname($particular);
		$vatcst=$this->input->post("vatcst");
		if(isset($vatcst)){  $vatcst=$vatcst ; }else{ $vatcst=""; }
		$vatcstpercent=$this->input->post("vatcstpercent");
		if(isset($vatcstpercent)){  $vatcstpercent=$vatcstpercent ; }else{ $vatcstpercent=""; }
		$vatamnt=$this->input->post("vat_amnt");
		if(isset($vatamnt)){  $vatamnt=$vatamnt ; }else{ $vatamnt=""; }
		$excise=$this->input->post("excise");
		if(isset($excise)){  $excise=$excise ; }else{ $excise=""; }
		$exciseamnt=$this->input->post("excise_amnt");
		if(isset($exciseamnt)){  $exciseamnt=$exciseamnt ; }else{ $exciseamnt=""; }
		$grandtot=$this->input->post("grandtotal");
		if(isset($grandtot)){  $grandtot=$grandtot ; }else{ $grandtot=""; }
		if(!empty($getprtsname))
		{
			foreach($getprtsname as $row)
			{
				$particual=$row->materialname;
			}
		}else
			{
				$particual=$particular;
			}
		$cate=$this->input->post("specfic_$i");
		$qnty=$this->input->post("prqty1_$i");
		$unit=$this->input->post("unitpr_$i");
		$tot=$this->input->post("tot_$i");
		$color=$this->input->post("colorspe_$i");
		if(isset($color)){
			$color=$color;
		}else{
			$color="";
		}
			
		if(isset($cate) && !empty($cate))
		{
			
			$data_aray=array(
				"custid"=>$custid,
				"bokingid"=>$bkid,
				"doe"=>date('Y-m-d h:i:s A'),
				"particulars"=>$particual,
				"cate"=>$cate,
				"qnty"=>$qnty,
				"unitpr"=>$unit,
				"total"=>$tot,
				"color"=>$color,
				"tax"=>$vatcst,
				"taxpercent"=>$vatcstpercent,
				"taxamount"=>$vatamnt,
				"excise1"=>$excise,
				"exciseamount"=>$exciseamnt,
				"grand"=>$grandtot,
				"sid"=>$this->session->userdata('uid'),
				"sname"=>$this->session->userdata('uname')
			
			);
			$this->paymentmodel->savebkorder($data_aray);
		}
		else {
			$data_aray=array(
				"custid"=>$custid,
				"bokingid"=>$bkid,
				"doe"=>date('Y-m-d h:i:s A'),
				"particulars"=>$particual,
				"qnty"=>$qnty,
				"unitpr"=>$unit,
				"total"=>$tot,
				"tax"=>$vatcst,
				"taxpercent"=>$vatcstpercent,
				"taxamount"=>$vatamnt,
				"excise1"=>$excise,
				"exciseamount"=>$exciseamnt,
				"grand"=>$grandtot,
				
				"sid"=>$this->session->userdata('uid'),
				"sname"=>$this->session->userdata('uname')
			
			);
			$this->paymentmodel->savebkorder($data_aray);
		}
		//echo "<br>";
	}
	redirect('Paymentcontroller/viewbokkinglist','refresh');
	
  }
 public function viewbokkinglist()
 {
 	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$user=$this->session->userdata('uname');
	$data['getbookinglist']=$this->paymentmodel->getallbookinglist($user);
		$this->load->view('payments/bookinglist',$data);
 }
 public function sentoaccounts($bkid)
 {
 	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$bkid;
	$updtest=$this->paymentmodel->setstatus($bkid);
	
	redirect('Paymentcontroller/viewbokkinglist','refresh');
 }
 public function sendpiinvoicecopy($bkid)
 {
 	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$bkid;
	$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$text1="Dear Sir,";
		$text2="    We are pleased to inform you that your  booking is successfully done and  look forward to your Interest. Please review the information carefully and contact our respetive accounts department/sales executive immediately of any changes call 24X7 helpline number (033)-64517771: ";
		$getdata=$this->paymentmodel->getdistinctbookinglist($bkid);
		foreach($getdata as $row)
		{
			$dte=$row->doe;
			$sls=$row->sname;
			$cltid=$row->custid;
		}
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(7);
		$this->fpdf->MultiCell(180,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(180,5,"Performa Invoice",0,0,'C');
		$this->fpdf->ln(7);
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(25,5,"Booking ID ",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $bkid",0,0,'L');
		$this->fpdf->cell(30,5," ",0,0,'L');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(45,5,"Sales Exec.",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $sls ",0,1,'L');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(25,5,"Date ",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $dte ",0,1,'L');
		
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(20,5,'Sl.No',1,0,'L');
		$this->fpdf->Cell(50,5,'Prticulars',1,0,'L');
		$this->fpdf->Cell(20,5,'Qnty',1,0,'L');
		$this->fpdf->Cell(40,5,'Unit Price.',1,0,'L');
		$this->fpdf->Cell(50,5,'Total',1,1,'L');
		//$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',10);
		$i=1;$tot1=0;
		foreach($getdata as $row){
		$this->fpdf->SetWidths(array(20,50,20,40,50));
		$particular=$row->particulars;
		$atg=$row->cate;
		if(!empty($atg) &&  isset($atg))
		{
			$particular=$particular."(".$atg.")";
		}else{
			$particular=$particular;
		}
		$qty=$row->qnty;
		$unitpr=number_format($row->unitpr,2);
		$tot=$row->total;
		$tot3=number_format($row->total,2);
		$tot1=$tot1+floatval($tot);
		//$tot1=number_format($tot1,2);
		$this->fpdf->Row(array("$i","$particular","$qty","$unitpr","$tot3"));
		$i++;
		}
		$tot1=number_format($tot1,2);
		$this->fpdf->Cell(130,5,'Net Total',1,0,'R');
		$this->fpdf->Cell(50,5,"$tot1",1,1,'L');
		$filename="Fpdfoutput/pi_invoice.pdf";
					//echo $vendidemailimplode;
        $this->fpdf->Output($filename,'F');
		$data['bkid']=$bkid;
		$getmail=$this->paymentmodel->getclientmail($cltid);
		$data['cstml']=$getmail;
		$this->load->view("send_mail/sendpi",$data);
		$message='Mail with Attachment send succesfully.....';
		 $this->session->set_flashdata('message',$message);
		 //redirect('login','refresh');
		 redirect('Paymentcontroller/viewbokkinglist','refresh');
       //	$this->fpdf->Output();
					 
		
 }
public function sendpiinvoice($bkid)
 {
 	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$bkid;
	$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$image1="assets/logo/bank_small.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$text1="Dear Sir,";
		$text2="    We are pleased to inform you that your  booking is successfully done and  look forward to your Interest. Please review the information carefully and contact our respetive accounts department/sales executive immediately of any changes call 24X7 helpline number (033)-64517771: ";
		$text3="All Payments must be made by DD,RTGS,NEFT or A/C Payee cheque only Our resplonsibility ceases as sonn as goods leave our permises. Disputes if any are subject to Serampore Hooghly Jurisdiction inly Failure to send C-Form as applicable within 90 day will invoice additional tax as per central/local sales tax,vat act. Over due interest @21% will be charged if payment is not received within 30days from date of invoice.Goods once sold will not be taken back or return";
		$getdata=$this->paymentmodel->getdistinctbookinglist($bkid);
		foreach($getdata as $row)
		{
			$dte=$row->doe;
			$sls=$row->sname;
			$cltid=$row->custid;
		}
		$buyerdet=$this->paymentmodel->getbuyerdetail($cltid);
		foreach($buyerdet as $rowc)
		{
			$comname=$rowc->compname;
			$add1=$rowc->add1;
			$add2=$rowc->add2;
			$countrymname=$rowc->country;
			$state=$rowc->state;
			$pin=$rowc->pin;
			$district=$rowc->district;
			$phno=$rowc->phone;
			$tin=$rowc->tin;
		}
		$this->fpdf->Image("$path",9,10,195,280,'png');
		$this->fpdf->ln(40);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(20,5,"NO.",1,0,'C');
		$this->fpdf->cell(35,5,"$bkid",1,0,'C');
		$this->fpdf->cell(74);
		$this->fpdf->cell(25,5,"DATE:",1,0,'C');
		$this->fpdf->cell(35,5,"08/12/2016",1,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->cell(55,5,"BUYER'S ADDRESS",1,0,'C');
		//company name------
		$this->fpdf->text(12,70," $comname");
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		if(isset($add1)){
			$this->fpdf->text(12,$y+15," $add1");
			 $y=$y+20;
		}
		if(isset($add2))
		{
			
			$this->fpdf->text(12,$y," $add2");
			$y=$y+5;
		}
		if(isset($district))
		{
			$this->fpdf->text(12,$y," $district");
			$y=$y+5;
		}
		if(isset($state))
		{
			$this->fpdf->text(12,$y," $state");
			$y=$y+5;
		}
		if(isset($countrymname))
		{
			$this->fpdf->text(12,$y," $countrymname");
			$y=$y+5;
		}
		if(isset($pin))
		{
			$this->fpdf->text(12,$y,"PIN: $pin");
			$y=$y+5;
		}
		if(isset($phno))
		{
			$this->fpdf->text(12,$y,"Mob: $phno");
		}
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',10);
		  $this->fpdf->text($x+78,$y+10,"GK RICKSHAW PVT LTD. ");
		  $y=$y+10;
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+78,$y+5,"30(33/1) N.T Road,Padmabati ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Colony, Baidyabati, Hooghly, ");
		
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"West Bengal-712222, India ");
		$y=$y+5;
		 $this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text($x+78,$y+5,"TIN NO: 19731597605 ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Phone: 033-64517771 ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Mob: +919903197821 ");
		$this->fpdf->cell(74);
		 $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(60,5,"OFFICE ADDRESS",1,1,'C');
		$this->fpdf->cell(55,45,"",1,0,'C');
		$this->fpdf->cell(74);
		$this->fpdf->cell(60,45,"",1,1,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(35,5,"Buyer's TIN NO",1,0,'C');
		$this->fpdf->cell(40,5,"$tin",1,0,'C');
		$this->fpdf->cell(39);
		$this->fpdf->cell(35,5,"Delivery Date",1,0,'C');
		$this->fpdf->cell(40,5,"",1,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetWidths(array(35,50,20,40,44));
		$this->fpdf->SetAligns(array("C","C","C","C","R"));
		
		$this->fpdf->Row(array("Parts Code","Particulars","Qty(pcs)","Rate(INR)","Value(INR)"));
		$i=1;$tot1=0;
		foreach($getdata as $row){
		
		$particular=$row->particulars;
		$atg=$row->cate;
		if(!empty($atg) &&  isset($atg))
		{
			$particular=$particular."(".$atg.")";
		}else{
			$particular=$particular;
		}
		$qty=$row->qnty;
		$unitpr=number_format($row->unitpr,2);
		$tot=$row->total;
		$vat=$row->tax;
		$vat=strtoupper($vat);
		$taxper=$row->taxpercent;
		$taxamount=$row->taxamount;
		$excise1=$row->excise1;
		$exciseamount=$row->exciseamount;
		$grand=$row->grand;
		$grand=number_format($grand,2);
		$tot3=number_format($row->total,2);
		$tot1=$tot1+floatval($tot);
		//$tot1=number_format($tot1,2);
		
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->SetWidths(array(35,50,20,40,44));
		$this->fpdf->SetAligns(array("C","C","C","C","R"));
		$this->fpdf->Row(array("","$particular","$qty","$unitpr","$tot3"));
		$i++;
		}
		//$tot1=number_format($tot1,2);
		//$this->fpdf->Cell(130,5,'Net Total',1,0,'R');
		//$this->fpdf->Cell(50,5,"$tot1",1,1,'L');
		if(isset($vat) && isset($taxper) && isset($taxamount)){
			$this->fpdf->SetWidths(array(145,44));
			$this->fpdf->SetAligns(array("C","R"));
			
			$this->fpdf->Row(array(" $vat @ $taxper","$taxamount"));
		}
		if($excise1==1 && floatval($exciseamount)>0)
		{
			$this->fpdf->SetWidths(array(145,44));
			$this->fpdf->SetAligns(array("C","R"));
			
			$this->fpdf->Row(array("Excise duty @ 6.00%","$exciseamount"));
		
		}
		$this->fpdf->SetWidths(array(145,44));
		$this->fpdf->SetAligns(array("R","R"));
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Row(array("Grand Total(INR)","$grand"));
		
		$this->fpdf->SetWidths(array(189));
		$this->fpdf->SetAligns(array("C"));
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->Row(array("Excluding Transporation Cost"));
		$this->fpdf->SetWidths(array(80,109));
		$this->fpdf->SetAligns(array("L","L"));
		$this->fpdf->SetFont('Arial','',11);
		$this->fpdf->Row2(array($this->fpdf->Image($image1, $this->fpdf->GetX()+2, $this->fpdf->GetY()+2,50,50,'png'),"$text3"));
		$this->fpdf->cell(30,20,"Customer Signature:",0,0,'L');
		$this->fpdf->cell(119);
		$this->fpdf->cell(30,20,"Authorized Signature",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->cell(20,30,$this->fpdf->Image($img2, $this->fpdf->GetX()+140, $this->fpdf->GetY()+1,40,40,'png'),0,0,'C');
		$this->fpdf->ln(5);
		$filename="Fpdfoutput/pi_invoice.pdf";
					//echo $vendidemailimplode;
        $this->fpdf->Output($filename,'F');
		$data['bkid']=$bkid;
		$getmail=$this->paymentmodel->getclientmail($cltid);
		$data['cstml']=$getmail;
		$this->load->view("send_mail/sendpi",$data);
		$message='Mail with Attachment send succesfully.....';
		 $this->session->set_flashdata('message',$message);
		 //redirect('login','refresh');
		 redirect('Paymentcontroller/viewbokkinglist','refresh');
       //	$this->fpdf->Output();
					 
		
 }
public function receiptvoucher()
{
	 $this->authentication->is_loggedin($this->session->userdata('uname'));
	 $data['title']="Receipt Voucher";
	 $data['customer']=$this->paymentmodel->getcomplist($this->session->userdata('uname'));
	 $this->load->view('payments/receiptvoucher',$data);
	 
}
public function savereceiptvoucher()
{
	 $this->authentication->is_loggedin($this->session->userdata('uname'));
	 $clintid=$this->input->post("clientid");
	 $bookingid=$this->input->post("bookingid");
	 $billamnt=$this->input->post("billamnt");
	 $paidamnt=$this->input->post("receiptamnt");
	 $typ=$this->input->post('typ');
	 $chqno=$this->input->post("chqno");
	 $dte=$this->input->post("date");
	 $bnknm=$this->input->post("bank");
	 $brnch=$this->input->post("brnch");
	 $data_array=array(
	 	"clientid"=>$clintid,
	 	"bookingid"=>$bookingid,
	 	"type"=>$typ,
	 	"billtot"=>$billamnt,
	 	"vamnt"=>$paidamnt,
	 	"bankname"=>$bnknm,
	 	"chqno"=>$chqno,
	 	"branch"=>$brnch,
	 	"doe"=>$dte,
	 	"sid"=>$this->session->userdata('uid'),
	 	"sname"=>$this->session->userdata('uname')
	 
	 );
	
	 $this->paymentmodel->saverecepttransaction($data_array);
	 redirect('Paymentcontroller/viewreceiptvoucher','refresh');
	// $data['title']="Receipt Vouc";
	 
}
public function viewreceiptvoucher()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$data['getreceiptvc']=$this->paymentmodel->getallreceiptvoucher($this->session->userdata('uname'));
	$this->load->view('payments/viewreceiptvch',$data);
}
public function getvatdetails()
{
	 $this->authentication->is_loggedin($this->session->userdata('uname'));
	 $vat=$this->input->post("vatcst");
	$nettot= $this->input->post("nettot");
	 if($vat=="cst"){
	 	$getvat=$this->paymentmodel->getcstpercent($vat);
	 }
	 if($vat=="vat")
	 {
	 	$getvat=$this->paymentmodel->getvatpercent($vat);
	 }
	// $nettot=$this->input->post("nettot");
	 $vatto=((floatval($nettot)*floatval($getvat))/100);
	 $netr=floatval($nettot)+floatval($vatto);
	 $result=array("vat"=>"$getvat","vatamnt"=>"$vatto","grandtot"=>"$netr");
	 echo json_encode($result);
	
}
public function getexcisedetails()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	 //$excise=$this->input->post("vatcst");
	$grandtot= $this->input->post("grandtot");
	$excise=$this->paymentmodel->getexciseduty();
	// $nettot=$this->input->post("nettot");
	 $exciseamnt=((floatval($grandtot)*floatval($excise))/100);
	 $netr=floatval($grandtot)+floatval($exciseamnt);
	 $result=array("excise"=>"$excise","exciseamnt"=>"$exciseamnt","grandtot"=>"$netr");
	 echo json_encode($result);
}
public function viewpiinvoice($id)
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$id;
	$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$image1="assets/logo/bank_small.png";
		$img2="assets/logo/Stam3.png";
		$path="assets/logo/gklogo1.png";
		$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$text1="Dear Sir,";
		$text2="    We are pleased to inform you that your  booking is successfully done and  look forward to your Interest. Please review the information carefully and contact our respetive accounts department/sales executive immediately of any changes call 24X7 helpline number (033)-64517771: ";
		$text3="All Payments must be made by DD,RTGS,NEFT or A/C Payee cheque only Our resplonsibility ceases as sonn as goods leave our permises. Disputes if any are subject to Serampore Hooghly Jurisdiction inly Failure to send C-Form as applicable within 90 day will invoice additional tax as per central/local sales tax,vat act. Over due interest @21% will be charged if payment is not received within 30days from date of invoice.Goods once sold will not be taken back or return";
		$getdata=$this->paymentmodel->getdistinctbookinglist($bkid);
		foreach($getdata as $row)
		{
			$dte=$row->doe;
			$sls=$row->sname;
			$cltid=$row->custid;
		}
		$buyerdet=$this->paymentmodel->getbuyerdetail($cltid);
		foreach($buyerdet as $rowc)
		{
			$comname=$rowc->compname;
			$add1=$rowc->add1;
			$add2=$rowc->add2;
			$countrymname=$rowc->country;
			$state=$rowc->state;
			$pin=$rowc->pin;
			$district=$rowc->district;
			$phno=$rowc->phone;
			//$tin=$rowc->tin;
		}
		$this->fpdf->Image("$path",9,10,195,280,'png');
		$this->fpdf->ln(40);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(20,5,"NO.",1,0,'C');
		$this->fpdf->cell(35,5,"$bkid",1,0,'C');
		$this->fpdf->cell(74);
		$this->fpdf->cell(25,5,"DATE:",1,0,'C');
		$this->fpdf->cell(35,5,"08/12/2016",1,0,'C');
		$this->fpdf->ln(10);
		$this->fpdf->cell(55,5,"BUYER'S ADDRESS",1,0,'C');
		//company name------
		$this->fpdf->text(12,70," $comname");
		$x=$this->fpdf->GetX();
		 $y=$this->fpdf->GetY();
		
		//company address--
		if(isset($add1)){
			$this->fpdf->text(12,$y+15," $add1");
			 $y=$y+20;
		}
		if(isset($add2))
		{
			
			$this->fpdf->text(12,$y," $add2");
			$y=$y+5;
		}
		if(isset($district))
		{
			$this->fpdf->text(12,$y," $district");
			$y=$y+5;
		}
		if(isset($state))
		{
			$this->fpdf->text(12,$y," $state");
			$y=$y+5;
		}
		if(isset($countrymname))
		{
			$this->fpdf->text(12,$y," $countrymname");
			$y=$y+5;
		}
		if(isset($pin))
		{
			$this->fpdf->text(12,$y,"PIN: $pin");
			$y=$y+5;
		}
		if(isset($phno))
		{
			$this->fpdf->text(12,$y,"Mob: $phno");
		}
		 $x=$this->fpdf->GetX();
		  $y=$this->fpdf->GetY();
		  $this->fpdf->SetFont('Arial','B',10);
		  $this->fpdf->text($x+78,$y+10,"GK RICKSHAW PVT LTD. ");
		  $y=$y+10;
		   $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->text($x+78,$y+5,"30(33/1) N.T Road,Padmabati ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Colony, Baidyabati, Hooghly, ");
		
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"West Bengal-712222, India ");
		$y=$y+5;
		 $this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->text($x+78,$y+5,"TIN NO: 19731597605 ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Phone: 033-64517771 ");
		$y=$y+5;
		$this->fpdf->text($x+78,$y+5,"Mob: +919903197821 ");
		$this->fpdf->cell(74);
		 $this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(60,5,"OFFICE ADDRESS",1,1,'C');
		$this->fpdf->cell(55,45,"",1,0,'C');
		$this->fpdf->cell(74);
		$this->fpdf->cell(60,45,"",1,1,'C');
		$this->fpdf->ln(10);
		$this->fpdf->SetFont('Arial','',9);
		$this->fpdf->cell(35,5,"Buyer's TIN NO",1,0,'C');
		$this->fpdf->cell(40,5,"",1,0,'C');
		$this->fpdf->cell(39);
		$this->fpdf->cell(35,5,"Delivery Date",1,0,'C');
		$this->fpdf->cell(40,5,"",1,0,'C');
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetWidths(array(35,50,20,40,44));
		$this->fpdf->SetAligns(array("C","C","C","C","R"));
		
		$this->fpdf->Row(array("Parts Code","Particulars","Qty(pcs)","Rate(INR)","Value(INR)"));
		$i=1;$tot1=0;
		foreach($getdata as $row){
		
		$particular=$row->particulars;
		$atg=$row->cate;
		if(!empty($atg) &&  isset($atg))
		{
			$particular=$particular."(".$atg.")";
		}else{
			$particular=$particular;
		}
		$qty=$row->qnty;
		$unitpr=number_format($row->unitpr,2);
		$tot=$row->total;
		$vat=$row->tax;
		$vat=strtoupper($vat);
		$taxper=$row->taxpercent;
		$taxamount=$row->taxamount;
		$excise1=$row->excise1;
		$exciseamount=$row->exciseamount;
		$grand=$row->grand;
		$grand=number_format($grand,2);
		$tot3=number_format($row->total,2);
		$tot1=$tot1+floatval($tot);
		//$tot1=number_format($tot1,2);
		
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->SetWidths(array(35,50,20,40,44));
		$this->fpdf->SetAligns(array("C","C","C","C","R"));
		$this->fpdf->Row(array("","$particular","$qty","$unitpr","$tot3"));
		$i++;
		}
		//$tot1=number_format($tot1,2);
		//$this->fpdf->Cell(130,5,'Net Total',1,0,'R');
		//$this->fpdf->Cell(50,5,"$tot1",1,1,'L');
		if(isset($vat) && isset($taxper) && isset($taxamount)){
			$this->fpdf->SetWidths(array(145,44));
			$this->fpdf->SetAligns(array("C","R"));
			
			$this->fpdf->Row(array(" $vat @ $taxper","$taxamount"));
		}
		if($excise1==1 && floatval($exciseamount)>0)
		{
			$this->fpdf->SetWidths(array(145,44));
			$this->fpdf->SetAligns(array("C","R"));
			
			$this->fpdf->Row(array("Excise duty @ 6.00%","$exciseamount"));
		
		}
		$this->fpdf->SetWidths(array(145,44));
		$this->fpdf->SetAligns(array("R","R"));
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Row(array("Grand Total(INR)","$grand"));
		
		$this->fpdf->SetWidths(array(189));
		$this->fpdf->SetAligns(array("C"));
		$this->fpdf->SetFont('Arial','B',11);
		$this->fpdf->Row(array("Excluding Transporation Cost"));
		$this->fpdf->SetWidths(array(80,109));
		$this->fpdf->SetAligns(array("L","L"));
		$this->fpdf->SetFont('Arial','',11);
		$this->fpdf->Row2(array($this->fpdf->Image($image1, $this->fpdf->GetX()+2, $this->fpdf->GetY()+2,50,50,'png'),"$text3"));
		$this->fpdf->cell(30,20,"Customer Signature:",0,0,'L');
		$this->fpdf->cell(110);
		$this->fpdf->cell(30,20,"Authorized Signature",0,0,'L');
		$this->fpdf->ln(10);
		$this->fpdf->cell(20,30,$this->fpdf->Image($img2, $this->fpdf->GetX()+140, $this->fpdf->GetY()+1,40,40,'png'),0,0,'C');
		$this->fpdf->ln(5);
		
		
		
		
		/*$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(7);
		$this->fpdf->MultiCell(180,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(180,5,"Proforma Invoice",0,0,'C');
		$this->fpdf->ln(7);
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(25,5,"Booking ID ",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $bkid",0,0,'L');
		$this->fpdf->cell(30,5," ",0,0,'L');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(45,5,"Sales Exec.",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $sls ",0,1,'L');
		$this->fpdf->SetFont('Arial','',12);
		$this->fpdf->cell(25,5,"Date ",0,0,'L');
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->cell(30,5,": $dte ",0,1,'L');
		
		$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(20,5,'Sl.No',1,0,'L');
		$this->fpdf->Cell(50,5,'Prticulars',1,0,'L');
		$this->fpdf->Cell(20,5,'Qnty',1,0,'L');
		$this->fpdf->Cell(40,5,'Unit Price.',1,0,'L');
		$this->fpdf->Cell(50,5,'Total',1,1,'L');
		//$this->fpdf->ln(5);
		$this->fpdf->SetFont('Arial','',10);
		$i=1;$tot1=0;
		foreach($getdata as $row){
		$this->fpdf->SetWidths(array(20,50,20,40,50));
		$particular=$row->particulars;
		$atg=$row->cate;
		if(!empty($atg) &&  isset($atg))
		{
			$particular=$particular."(".$atg.")";
		}else{
			$particular=$particular;
		}
		$qty=$row->qnty;
		$unitpr=number_format($row->unitpr,2);
		$tot=$row->total;
		$tot3=number_format($row->total,2);
		$tot1=$tot1+floatval($tot);
		//$tot1=number_format($tot1,2);
		$this->fpdf->Row(array("$i","$particular","$qty","$unitpr","$tot3"));
		$i++;
		}
		$tot1=number_format($tot1,2);
		$this->fpdf->Cell(130,5,'Net Total',1,0,'R');
		$this->fpdf->Cell(50,5,"$tot1",1,1,'L');
		//$filename="Fpdfoutput/pi_invoice.pdf";
					//echo $vendidemailimplode;
        //$this->fpdf->Output($filename,'F');*/
        $this->fpdf->Output();
		//$data['bkid']=$bkid;
		//$getmail=$this->paymentmodel->getclientmail($cltid);
		//$data['cstml']=$getmail;
		//$this->load->view("send_mail/sendpi",$data);
		//$message='Mail with Attachment send succesfully.....';
		// $this->session->set_flashdata('message',$message);
		 //redirect('login','refresh');
		//redirect('Paymentcontroller/viewbokkinglist','refresh');
	
}
public function getbookingid()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	 $clientid=$this->input->post("clientid");
	$getbookingdetails=$this->paymentmodel->getbookingd($clientid);
	//print_r($getbookingdetails);
	if(isset($getbookingdetails) && !empty($getbookingdetails))
	{
		
		echo '<div class="col-xs-12">
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1">BOOKING ID</label>
							
						<div class="col-sm-9">
						<select name="bookingid" id="bookingid" onchange="getbilldetails();" required>
						<option value="">--select--</option>
						';
							foreach($getbookingdetails as $row)
							{
								//print_r($row);
								echo '<option value="'.$row->bkid.'">'.$row->bkid.'</option>';
							}
						echo '</select></div>
			</div>
															 	
		</div>';
							
	}
}
public function getbilldetail()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$this->input->post("bkid");
	$getbilldetails=$this->paymentmodel->getbill($bkid);
	$tot=0;
	foreach($getbilldetails as $row)
	{
		$tot=floatval($tot)+floatval($row->total);
	}
	echo $tot;
}
public function sendvouchere($id)
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$id;
	$gettvoucher=$this->paymentmodel->getalldetailpayment($bkid);
	$tot=0;
	foreach($gettvoucher as $row)
	{
		$tot=$tot+floatval($row->vamnt);
	}
	$tot=number_format($tot,2);
	$text2="Please send us the required quotation for the given list of products";
		$this->fpdf->SetFont('Arial','B',16);
		$path4="login_assets/logo/logogk3.png";
		$path="assets/logo/gklogo.png";$path1="login_assets/icon/phone.png";$path2="login_assets/icon/whatsapp.png";$path1="login_assets/icon/email.png";
		//$this->fpdf->Image("$path4",10,10,-300);
		$text1="Dear Sir,";
		$text2="    We are pleased to inform you that your  booking is successfully done and  look forward to your Interest. Please review the information carefully and contact our respetive accounts department/sales executive immediately of any changes call 24X7 helpline number (033)-64517771: ";
		
		$this->fpdf->Image("$path",10,10,-300);
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Text(130,20,"Office Address");
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Text(130,25,"30(33/1) N.T Road, Padmabati Colony ,");
		$this->fpdf->Text(130,30,"Baidyabati, Hooghly,West Bengal-712222, India");
		$this->fpdf->Text(130,35,"Phone No: 033-64517771");
		$this->fpdf->Text(130,40,"Whatsapp No: 9804267746");
		$this->fpdf->SetFont('Arial','B',12);
		$this->fpdf->Line(10,45,200,45);
		$this->fpdf->SetFont('Arial','',10);
		$this->fpdf->Line(10,46,200,46);
		$x=$this->fpdf->GetX(); 
		$y=$this->fpdf->GetY();
		$this->fpdf->Ln($y);
		$this->fpdf->Ln(30);
		$this->fpdf->MultiCell(150,5,"$text1");
		$this->fpdf->ln(7);
		$this->fpdf->MultiCell(180,5,"$text2");
		$this->fpdf->SetFont('Arial','B',15);
		$this->fpdf->cell(180,5,"Receipt Voucher",0,0,'C');
		$this->fpdf->ln(7);
		$this->fpdf->SetWidths(array(30,25,30,30,30,25));
		$this->fpdf->SetFont('Arial','B',10);
		
		$this->fpdf->Row(array("Date","Booking ID","Paid By","Bill(INR.)","Paid(INR.)","DUE(INR)"));
		$i=1;
		$this->fpdf->SetFont('Arial','',10);
		foreach($gettvoucher as $row)
		{
			$this->fpdf->SetWidths(array(30,25,30,30,30,25));
			//$this->fpdf->cell(25);
			$dt=$row->doe;
			$bkid=$row->bookingid;
			$ty=$row->type;
			$ckkno=$row->chqno;
			$bank=$row->bankname;
			if(isset($ckkno) && isset($bank))
			{
				$ty=$ty."($ckkno), (n$bank)";
			}else{
				$ty=$ty;
			}
			$paid=$row->vamnt;
			$billam=$row->billtot;
			$billam2=number_format($billam,2);
			$due=floatval($billam)-floatval($paid);
			$due2=number_format($due,2);
			$vm=number_format($row->vamnt,2);
			$this->fpdf->Row(array("$dt","$bkid","$ty","$billam2","$vm","$due2"));
			$i++;
			
		}
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->SetWidths(array(145,25));
		$this->fpdf->Row(array("Net Due Balance ","$due2"));
		$this->fpdf->Output();
		
    }

  public function boookbycust($id)
  {
  		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$data['title']='Create Order';
		//$user=$this->session->userdata('uname');
		//$user=$id;
		$data['models']=$this->paymentmodel->getmodelsdetails();
		$data['allmaterial']=$this->paymentmodel->get_material();
		$data['getcolorcode']=$this->paymentmodel->getall_colorcode();
		$data['getallproduct']=$this->paymentmodel->getallproduct();
		$getcustomerdetails=$this->paymentmodel->getbuyerdetail($id);
		foreach($getcustomerdetails as $row)
		{
			$email=$row->email;
			$name=$row->compname;
			$custname=$row->name;
			$custid=$row->clientid;
		}
		$data['email']=$email;
		$data['compname']=$name;
		$data['custnam']=$custname;
		$data['clientid']=$custid;
		//$data['spareparts']=$this->paymentmodel->getspareparts();
		$this->load->view('payments/bookingbycustomer',$data);
  	
  }
  public function getmodeldet()
  {
  	$model=$this->input->post("cattyp");
	$getallmodel=$this->paymentmodel->getallmodel();
	if(isset($getallmodel) && !empty($getallmodel))
	{
		
			echo '
					<label class="col-sm-3 control-label no-padding-right" for="form-field-1">SELECT MODEL</label>
							<div class="col-sm-9">
								<select name="modeltype" id="modeltype" onchange="getmodeltype()" required>
									<option value="">--select type--</option>';
									$i=1;
									foreach($getallmodel as $row)
		                             {
		                             	echo '<option value="'.$row->productname.'_'.$i.'">'.$row->productname .'</option>';
									$i++; }
																			
			echo '</select>
							</div>
			
			
			
			
			';
		
	}
  }
public function getmodelprice()
{
	echo "hello";
}
public function getmodellistbyparts()
{
	$model=$this->input->post("cattyp");
	$getallmodel=$this->paymentmodel->getallmodel();
	if(isset($getallmodel) && !empty($getallmodel))
	{
		
			echo '
					<label class="col-sm-3 control-label no-padding-right" for="form-field-1">SELECT MODEL</label>
							<div class="col-sm-9">
								<select name="modeltype" id="modeltype" onchange="getmodeltypebyparts()" required>
									<option value="">--select type--</option>';
									$i=1;
									foreach($getallmodel as $row)
		                             {
		                             	echo '<option value="'.$row->productname.'_'.$i.'">'.$row->productname .'</option>';
									$i++; }
																			
			echo '</select>
							</div>
			
			
			
			
			';
		
	}
	
	
}
public function autocomplete()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$user=$this->session->userdata('uname');
	$term=$this->input->get('term');
	$getdata=$this->paymentmodel->getsearchdata($user,$term);
	foreach($getdata as $row)
	{
		$data[]=strtoupper($row->name);
		
	}
	foreach($getdata as $row)
	{
		$data[]=($row->email);
		
	}
	foreach($getdata as $row)
	{
		$data[]=strtoupper($row->compname);
		
	}
	foreach($getdata as $row)
	{
		$data[]=strtoupper($row->clientid);
		
	}
	echo json_encode($data);
	
}
public function pay_amount($id)
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$bkid=$id;
	$getbilldetails=$this->paymentmodel->getbill($bkid);
	$tot=0;
	foreach($getbilldetails as $row)
	{
		$tot=floatval($tot)+floatval($row->total);
		$clientid=$row->custid;
	}
	$data['getcustdetailsbyis']=$this->paymentmodel->getcustdetailsbyid($clientid);
	$data['tot']= $tot;
	$data['bkid']=$id;
	$this->load->view('payments/receiptvoucherbybookinglist',$data);
}
public function savevoucher()
{
	$this->authentication->is_loggedin($this->session->userdata('uname'));
	 $clintid=$this->input->post("clientid");
	 $bookingid=$this->input->post("bookingid");
	 $billamnt=$this->input->post("billamnt");
	 $paidamnt=$this->input->post("receiptamnt");
	 $typ=$this->input->post('typ');
	 $chqno=$this->input->post("chqno");
	 $dte=$this->input->post("date");
	 $bnknm=$this->input->post("bank");
	 $brnch=$this->input->post("brnch");
	 $data_array=array(
	 	"clientid"=>$clintid,
	 	"bookingid"=>$bookingid,
	 	"type"=>$typ,
	 	"billtot"=>$billamnt,
	 	"vamnt"=>$paidamnt,
	 	"bankname"=>$bnknm,
	 	"chqno"=>$chqno,
	 	"branch"=>$brnch,
	 	"doe"=>$dte,
	 	"sid"=>$this->session->userdata('uid'),
	 	"sname"=>$this->session->userdata('uname')
	 
	 );
	
	 $this->paymentmodel->saverecepttransaction($data_array);
	 redirect('Paymentcontroller/viewreceiptvoucher','refresh');
}
 

}