<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile_controller extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('url','form','html'));
        $this->load->library(array('session','authentication','upload','image_lib'));
		//$this->load->library('fpdf_gen');
		$this->load->model('profile_model');
		//$this->load->model('Purchase_model');
			//$this->load->model('Notify_model');
	}
	public function achv_trgt()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$this->load->view('Profile/achv_trgt');	
	}
	public function myprofile()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$this->load->view('Profile/profile');	
	}
	public function creat_planning()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$this->load->view('Profile/creat_planning');
	}
	public function get_table1()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$no_days=$this->input->post("no_days");
		//$strtd_date=$this->input->post("strtd_date");
		//$end_date=$this->input->post("end_date");
		
        // Specify the start date. This date can be any English textual format  
		$date_from = $this->input->post("strtd_date");  
		 $date_from = strtotime($date_from); // Convert date to a UNIX timestamp  
        //  echo "<br>";
		// Specify the end date. This date can be any English textual format  
		$date_to = $this->input->post("end_date");  
		$date_to = strtotime($date_to); // Convert date to a UNIX timestamp  
	
		// Loop from the start date to end date and output all dates inbetween
		
		//echo $no_days;
		//echo $strtd_date;
		//exit;
		echo '<form action="'.base_url().'Profile_controller/saveplanning" method="POST">';
		echo '<table id="example" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th style="width: 40px;">Date</th>
													<th style="width: 40px;">From</th>
													<th style="width: 40px;">To</th>
													<th style="width: 40px;">Name of Customer</th>
													<th style="width: 40px;">Contact Info</th>
													<th style="width: 40px;">Remarks</th>
													
													<th style="width: 40px;">Action</th>
												</tr>
											</thead>
											
											<tbody>';
											//for($i= $strtd_date; $i<=$end_date; $i++)
											//{                     
										   $k=1;
                                           for ($i=$date_from; $i<=$date_to; $i+=86400)
											   {
											   	  $d2=date('Y-m-d', $i);
												  $getplan=$this->profile_model->getplandetails($d2,$this->session->userdata('uid'));
												  if(empty($getplan)){
												  	echo '<tr>
												<td>'.$d=date('Y-m-d', $i).'<input type="hidden" id="dte_'.$k.'" name="dte_'.$k.'" value="'.date('Y-m-d', $i).'" /></td>
												
												<td ><input type="text"  id="fromloc_'.$k.'" name="formloc_'.$k.'"> </td>
												<td ><input type="text"  id="toloc_'.$k.'" name="toloc_'.$k.'"  > </td>
												<td ><input type="text"  id="customer_'.$k.'" name="customer_'.$k.'"  > </td>
												<td ><input type="number"  id="contact_'.$k.'" name="contact_'.$k.'"> </td>
												<td ><textarea name="rmrk_'.$k.'" id="rmrk_'.$k.'"></textarea></td>
												
											    <td >
												
														<button type="button" id="savesing_'.$k.'" class="btn btn-link" onclick="saveindividualdata(this.id);"><i class="fa fa-save"></i></button>
														<button type="button" id="delete_'.$k.'" class="btn btn-link" onclick="deletesingle(this.id);"><i class="fa fa-trash-o"></i></button>&nbsp;
														
														
												</td>
											</tr>';
											$k++;
													
													
													
												  }else{
												  	foreach($getplan as $row2){
												  		$dte=$row2->dte;
												  		if(isset($dte)&& !empty($dte)){ $dte=$dte; }else{ $dte=""; }
												  		 $forml=$row2->formloc;
												  		if(isset($forml)&& !empty($forml)){ $forml=$forml; }else{ $forml="";  }
														$toloca=$row2->toloca;
														if(isset($toloca)&& !empty($toloca)){ $toloca=$toloca; }else{ $toloca=""; }
														$custo=$row2->custname;
														if(isset($custo) && !empty($custo)){ $custo=$custo;}else{ $custo="" ;}
														$custinfo=$row2->contactinfo;
														if(isset($custinfo)& !empty($custinfo)){ $custinfo=$custinfo; }else{ $custinfo=""; }
														$rmk=$row2->remarks;
														if(isset($rmk)&& !empty($rmk)){$rmk=$rmk; }else{ $rmk=""; }
														$dailyex=$row2->dailyexpen;
														if(isset($dailyex) && !empty($dailyex)){ $dailyex=$dailyex; }else{ $dailyex="";}
												  	}
										echo '<tr>
												<td>'.$d=date('Y-m-d', $i).'<input type="hidden" id="dte_'.$k.'" name="dte_'.$k.'" value="'.date('Y-m-d', $i).'"  /></td>
												
												<td ><input type="text"  id="fromloc_'.$k.'" name="formloc_'.$k.'" value="'.$forml.'"> </td>
												<td ><input type="text"  id="toloc_'.$k.'" name="toloc_'.$k.'" value="'.$toloca.'"  > </td>
												<td ><input type="text"  id="customer_'.$k.'" name="customer_'.$k.'" value="'.$custo.'"  > </td>
												<td ><input type="number"  id="contact_'.$k.'" name="contact_'.$k.'" value="'.$custinfo.'"> </td>
												<td ><textarea name="rmrk_'.$k.'" id="rmrk_'.$k.'">'.$rmk.'</textarea></td>
												
											    <td >
												
														<button type="button" id="savesing_'.$k.'" class="btn btn-link" onclick="saveindividualdata(this.id);"><i class="fa fa-save"></i></button>
														<button type="button" id="delete_'.$k.'" class="btn btn-link" onclick="deletesingle(this.id);"><i class="fa fa-trash-o"></i></button>&nbsp;
														
														
												</td>
											</tr>';
											$k++;
														
												  	
													
												  		
												  	
												  }
										
																//if($i>=5){
																//	break;
																//}
											}

											echo '</tbody>
						</table>';
						echo '<center>
						<input type="hidden" value="'.$k.'" name="totalrow">
					<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						</center>';
						echo '</form>';
	}
	public function saveplanning()
	{
		
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$getsalesmandetails=$this->profile_model->getsalesmandetails($this->session->userdata('uid'));
		foreach($getsalesmandetails as $row)
		{
			$sid=$row->salesmanid;
			$snam=$row->name;
		}
	     $snam;
		$totrow=$this->input->post('totalrow');
		for($i=1;$i<intval($totrow);$i++)
		{
			$dte=$this->input->post("dte_$i");
			$dte1=explode("-",$dte);
			
			$formloc=$this->input->post("formloc_$i");
			$totloc=$this->input->post("toloc_$i");
			$mnthcode=$dte1[1];
			$yrcode=$dte1[0];
			$custn=$this->input->post("customer_$i");
			$contactinfo=$this->input->post("contact_$i");
			$rmrk=$this->input->post("rmrk_$i");
			$dailyexpen=$this->input->post("expnce_$i");
			//$crtdby=$this->input->post("$snam");
			//$userid=$this->input->post("");
			
			
			$data_array=array(
				"salesmanid"=>$sid,
				"dte"=>$dte,
				"formloc"=>$formloc,
				"toloca"=>$totloc,
				"mnthcode"=>$mnthcode,
				"yrcode"=>$yrcode,
				"custname"=>$custn,
				"contactinfo"=>$contactinfo,
				"remarks"=>$rmrk,
				
				"crtdby"=>$snam,
				"userid"=>$this->session->userdata('uid')
			);
			$checkdataexist=$this->profile_model->getcheckexist($dte,$this->session->userdata('uid'),$yrcode);
			if(empty($checkdataexist))
			{
				$this->profile_model->savetoupplan($data_array);
			}else
			{
				$this->profile_model->updatetourplan($data_array,$dte);
			}
			
		}
     $this->load->view("Profile/viewcalender");
		
	}
	public function savesingledate()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$getsalesmandetails=$this->profile_model->getsalesmandetails($this->session->userdata('uid'));
		foreach($getsalesmandetails as $row)
		{
			$sid=$row->salesmanid;
			$snam=$row->name;
		}
		$dte=$this->input->post("dte");
		$dte1=explode("-",$dte);
		$mnthcode=$dte1[1];
		$yrcode=$dte1[0];
		$fromloc=$this->input->post("fromloc");
		$toloc=$this->input->post("toloc");
		$customer=$this->input->post("customer");
		$contact=$this->input->post("contact");
		$rmrk=$this->input->post("rmrk");
		$expnce=$this->input->post("expnce");
		$data_array=array(
				"salesmanid"=>$sid,
				"dte"=>$dte,
				"formloc"=>$fromloc,
				"toloca"=>$toloc,
				"mnthcode"=>$mnthcode,
				"yrcode"=>$yrcode,
				"custname"=>$customer,
				"contactinfo"=>$contact,
				"remarks"=>$rmrk,
				
				"crtdby"=>$snam,
				"userid"=>$this->session->userdata('uid')
		);
		//print_r($data_array);
		$checkdataexist=$this->profile_model->getcheckexist($dte,$this->session->userdata('uid'),$yrcode);
		if(empty($checkdataexist))
		{
				$this->profile_model->savetoupplan($data_array);
		}else
		{
				$this->profile_model->updatetourplan($data_array,$dte);
		}
		
		
	     //$snam;
		
		
		
	}
  public function monthtourplan()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
	 $this->load->view("Profile/viewcalender");
	
  }
  public function tourplan()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
	$data['Title']="Salesman Dashboard";
	$dt=date('Y-m-d');
	$data['getdatadetails']=$this->profile_model->getallplantour($dt);
	$this->load->view("Profile/tourplan",$data);
  }
  public function get_table12()
  {
  	$this->authentication->is_loggedin($this->session->userdata('uname'));
  	$data['Title']="Salesman Dashboard";
	//echo '<form action="'.base_url().'Profile_controller/saveplanning" method="POST">';
	
	
	$strtdte=$this->input->post("strtd_date");
	$k=1;
		echo '<table id="example" class="table  table-bordered table-hover">
				<thead>
					<tr>
						<th style="width: 40px;">Date</th>
						<th style="width: 40px;">From</th>
						<th style="width: 40px;">To</th>
						<th style="width: 40px;">Name of Customer</th>
						<th style="width: 40px;">Contact Info</th>
						<th style="width: 40px;">Remarks</th>
						<th style="width: 40px;">Expences</th>
						<th style="width: 40px;">Action</th>
					</tr>
				</thead>
											
				<tbody>';
				echo '<tr>
							<td>'.$d=$strtdte.'<input type="hidden" id="dte_'.$k.'" name="dte_'.$k.'" value="'.$strtdte.'" /></td>
												
							<td ><input type="text"  id="fromloc_'.$k.'" name="formloc_'.$k.'"> </td>
							<td ><input type="text"  id="toloc_'.$k.'" name="toloc_'.$k.'"  > </td>
							<td ><input type="text"  id="customer_'.$k.'" name="customer_'.$k.'"  > </td>
							<td ><input type="number"  id="contact_'.$k.'" name="contact_'.$k.'"> </td>
							<td ><textarea name="rmrk_'.$k.'" id="rmrk_'.$k.'"></textarea></td>
							<td ><input type="number"  id="expnce_'.$k.'" name="expnce_'.$k.'" style="width:60px;"> </td>
							 <td >
												
							<button type="button" id="savesing_'.$k.'" class="btn btn-link" onclick="saveindividualdata(this.id);"><i class="fa fa-save"></i></button>
							<button type="button" id="delete_'.$k.'" class="btn btn-link" onclick="deletesingle(this.id);"><i class="fa fa-trash-o"></i></button>&nbsp;
							<button type="button" id="delete_'.$k.'" class="btn btn-link" onclick="addtabletr(this.id);"><i class="fa fa-plus" aria-hidden="true"></i></button>
														
							</td>
					</tr>';
					echo '</tbody>
						</table>';
	
  }
	public function savedaybydayreport()
	{
		$this->authentication->is_loggedin($this->session->userdata('uname'));
		$getsalesmandetails=$this->profile_model->getsalesmandetails($this->session->userdata('uid'));
		foreach($getsalesmandetails as $row)
		{
			$sid=$row->salesmanid;
			$snam=$row->name;
		}
		$dte=$this->input->post("dte");
		$dte1=explode("-",$dte);
		$mnthcode=$dte1[1];
		$yrcode=$dte1[0];
		$fromloc=$this->input->post("fromloc");
		$toloc=$this->input->post("toloc");
		$customer=$this->input->post("customer");
		$contact=$this->input->post("contact");
		$rmrk=$this->input->post("rmrk");
		$expnce=$this->input->post("expnce");
		$data_array=array(
				"salesmanid"=>$sid,
				"dte"=>$dte,
				"formloc"=>$fromloc,
				"toloca"=>$toloc,
				"mnthcode"=>$mnthcode,
				"yrcode"=>$yrcode,
				"custname"=>$customer,
				"contactinfo"=>$contact,
				"remarks"=>$rmrk,
				"dailyexpen"=>$expnce,
				"crtdby"=>$snam,
				"userid"=>$this->session->userdata('uid')
		);
		//print_r($data_array);
		$checkdataexist=$this->profile_model->checkdaybydayexist($dte,$this->session->userdata('uid'),$fromloc,$toloc,$yrcode);
		if(empty($checkdataexist))
		{
				$this->profile_model->savedaybydayplan($data_array);
				$result=array("status"=>"Data Inserted Succesfully");
				
		}else
		{
				//$this->profile_model->updatedaybydayplan($data_array,$dte);
				$result=array("status"=>"Data Already Exist");
		}
		echo json_encode($result);
		
		
	}
	
}