
<?php  include('connection.php');  ?>
<?php $this->load->view('headercss.php'); ?>
<?php $this->load->view('topnav.php'); ?>
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />

<style>
	.list-type1,{
width:100px;
margin:0 auto;
}

.list-type1 ol{
counter-reset: li;
list-style: none;
*list-style: decimal;
font-size: 15px;
font-family: 'Raleway', sans-serif;
padding: 0;
margin-bottom: 4em;
}
.list-type1 ol ol{
margin: 0 0 0 2em;
}

.list-type1 a{
position: relative;
display: block;
padding: .4em .4em .4em 2em;
*padding: .4em;
margin: .5em 0;
background: #93C775;
color: #fff;
text-decoration: none;
-moz-border-radius: .3em;
-webkit-border-radius: .3em;
border-radius: 10em;
transition: all .2s ease-in-out;
}

.list-type1 a:hover{
background: #d6d4d4;
color:black;
text-decoration:none;
transform: scale(1.1);
}

.list-type1 a:before{
content: counter(li);
counter-increment: li;
position: absolute;
left: -1.3em;
top: 50%;
margin-top: -1.3em;
background:#93C775;
color:white;
height: 2em;
width: 2em;
line-height: 2em;
border: .3em solid #fff;
text-align: center;
font-weight: bold;
-moz-border-radius: 2em;
-webkit-border-radius: 2em;
border-radius: 2em;
color:#FFF;
}
/*SPAREPARTS*/
.prts{
width:215px;
margin:0 auto;
height:250px;
overflow-y: scroll;
}

.prts ol{
counter-reset: li;
list-style: none;
*list-style: decimal;
font-size: 15px;
font-family: 'Raleway', sans-serif;
padding: 0;
margin-bottom: 4em;
}
.prts ol ol{
margin: 0 0 0 2em;
}

.prts a{
position: relative;
display: block;
padding: .4em .4em .4em 2em;
*padding: .4em;
margin: .5em 0;
background: #93C775;
color: #fff;
text-decoration: none;
-moz-border-radius: .3em;
-webkit-border-radius: .3em;
border-radius: 10em;
transition: all .2s ease-in-out;
}

.prts a:hover{
background: #d6d4d4;
color:black;
text-decoration:none;
transform: scale(1.1);
}

.prts a:before{
content: counter(li);
counter-increment: li;
position: absolute;
left: -1.3em;
top: 50%;
margin-top: -1.3em;
background:#93C775;
color:white;
height: 2em;
width: 2em;
line-height: 2em;
border: .3em solid #fff;
text-align: center;
font-weight: bold;
-moz-border-radius: 2em;
-webkit-border-radius: 2em;
border-radius: 2em;
color:#FFF;
}
li {
	list-style-type: none;
}
/*  table design  */
table { 
    width: 750px; 
    border-collapse: collapse; 
    margin:50px auto;
    }
/* Zebra striping */
tr:nth-of-type(odd) { 
    background: #eee; 
    }
th { 
    background: #3498db; 
    color: white; 
    font-weight: bold; 
    }
td, th { 
    padding: 10px; 
    border: 1px solid #ccc; 
    text-align: left; 
    font-size: 10px;
    }
    @media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {
    table { 
          width: 100%; 
    }
    /* Force table to not be like tables anymore */
    table, thead, tbody, th, td, tr { 
        display: block; 
    }
    
    /* Hide table headers (but not display: none;, for accessibility) */
    thead tr { 
        position: absolute;
        top: -9999px;
        left: -9999px;
    }
    
    tr { border: 1px solid #ccc; }
    
    td { 
        /* Behave  like a "row" */
        border: none;
        border-bottom: 1px solid #eee; 
        position: relative;
        padding-left: 50%; 
    }
    
    td:before { 
        /* Now like a table header */
        position: absolute;
        /* Top/left values mimic padding */
        top: 6px;
        left: 6px;
        width: 45%; 
        padding-right: 10px; 
        white-space: nowrap;
        /* Label the data */
        content: attr(data-column);
        color: #3498db;
    }
}

</style>

		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Manage Booking</a>
							</li>
							<li class="active"> Booking</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="page-header">
							<h1>
								Create Booking
								
							</h1>
						</div><!-- /.page-header -->
						<div class="row">
								<div class="col-xs-12 col-sm-12">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Booking Summery</h4>

																	</div>

												<div class="widget-body">
													<div class="widget-main">
														<div class="row">
															<div class="col-xs-12">
																
															<form class="form-horizontal" role="form" action="<?php echo base_url(); ?>Paymentcontroller/bookingsave" method="post" >
																<!--<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"></label>
							
																	<div class="col-sm-3">
																		
																	</div>
																 <div class="col-sm-3" id="img">
																	<img id="blah" src="<?php echo base_url(); ?>assets/favicon/anonymous-man.png" alt="your image" width="150" height="150" name="image1"/>
																</div>
																</div>-->
																<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1">COMPANYNAME</label>
							
																	<div class="col-sm-9">
																		<input type="text" id="custid" placeholder="Customer Email/Phone No" name="compn"  class="col-xs-10 col-sm-5" value="<?php if(isset($compname)){ echo $compname; } ?>" readonly />
																		
																	</div>
																</div>
																
																<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> </label>
							
																	<div class="col-sm-9">
																		<div class="inputr"></div>
																	</div>
																</div>

																<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> COMPANY ID</label>
							
																	<div class="col-sm-9">
																		<input type="text" id="comp" placeholder="" name="compid" class="col-xs-10 col-sm-5" readonly value="<?php if(isset($clientid)){ echo $clientid; } ?>" />
																	</div>
																</div>
																
																<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> CUSTOMER NAME</label>
							
																	<div class="col-sm-9">
																		<input type="text" id="custname" placeholder="" name="custname" class="col-xs-10 col-sm-5" readonly value="<?php if(isset($custnam)){ echo $custnam; } ?>" />
																	</div>
																</div>
																<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1">DATE</label>
							
																	<div class="col-sm-9">
																		<input type="text" id="form-field-1" placeholder="" name="custid" class="col-xs-10 col-sm-5" readonly value="<?php echo date('Y-m-d'); ?>" />
																	</div>
																</div>
																<div class="form-group">
																	<label class="col-sm-3 control-label no-padding-right" for="form-field-1">SELECT TYPE</label>
							
																	<div class="col-sm-9">
																		<select name="type" id="cattyp" onchange="gettypedetails()" >
																			<option value="">--select type--</option>
																			<option value="product">Model</option>
																			<option value="parts">Spare Parts</option>
																			
																		</select>
																	</div>
																</div>
																<div class="form-group" id="model">
																	
																</div>
															
															</div>
														</div>
														<div class="row">
														    <div class="col-xs-12">
														    	<table class="col-xs-12" id="example">
														    		<tr>
														    			<td>SL NO</td>
														    			<td>PARTICULARS</td>
														    			<td>QNTY</td>
														    			<td>UNITPRICE</td>
														    			<td>TOTAL </td>
														    			<td>ACTION</td>
														    		</tr>
														    		
														    	</table>
															</div>
															<hr>
															
														   <hr>
															<div class="row">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-3">
																		NET TOTAL
																	</div>
																	<div class="col-sm-3">
																		
																	</div>
																	<div class="col-sm-3">
																		
																	</div>
																	<div class="col-sm-3" id="nettot" style="font-size: 15px;text-align: right;font-weight: bold;">
																	  
																	</div>
																</div>
															    	
															    </div>
														   </div>
														   <div class="row" id="exciseduty">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-9">
																		EXCISETAX @2.00%
																	</div>
																	
																	
																		<input type="hidden" id="excisetax" style="width:70px;" name="excise">
																	
																	<div class="col-sm-3" id="examnt" style="font-size: 15px;text-align: right;font-weight: bold;">
																		
																	</div>
																	<input type="hidden" name="excise_amnt" id="excise_amnt"/>
																</div>
															    	
															    </div>
														   </div>
														  
														   <div class="row">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-3">
																		VAT/CST
																	</div>
																	<div class="col-sm-3">
																		<select id="vatcst" name="vatcst" onchange="getvatamount();">
																			<option value="">--select VAT/CST--</option>
																			<option value="cst">CST</option>
																			<option value="vat">VAT</option>
																		</select>
																	</div>
																	<div class="col-sm-3">
																		<input type="text" id="vatcs" name="vatcstpercent" style="width:70px;">
																	</div>
																	<div class="col-sm-3" id="vatamnt" name="vatamnt" style="font-size: 15px;text-align: right;font-weight: bold;">
																		
																	</div>
																	<input type="hidden" name="vat_amnt" id="vat_amnt"/>
																</div>
															    	
															    </div>
														   </div>
														  
														   
														   <div class="row">
															    <div class="col-xs-12" >
															    	<div class="form-group" style="border-top: 1px solid black;padding: 2px;">
																	
							
																	<div class="col-sm-3">
																		
																	</div>
																	<div class="col-sm-6">
																		
																	
																	
																		<b><h2>GRAND TOTAL</h2></b>
																	</div>
																	<div class="col-sm-3" id="grandtot" style="font-size: 15px;text-align: right;font-weight: bold;">
																		
																	</div>
																	<input type="hidden" name="grandtotal" id="grandtotal"/>
																</div>
															    	
															    </div>
														   </div>
															<div class="row">
															    <div class="col-xs-12">
															    	 <div class="clearfix form-actions">
																		<div class="col-md-offset-3 col-md-9">
																			<button class="btn btn-info" type="submit" id="submit">
																				<i class="ace-icon fa fa-check bigger-110"></i>
																				Submit
																			</button>
								
																			&nbsp; &nbsp; &nbsp;
																			
																		</div>
																	</div>
															    </div>
														   </div>
															<input type="hidden" name="numofrows" id="tbalerow"/>
   					 										<input type="hidden" name="vendorid[]" id="vendorid">
   					 										<input type="hidden" name="dupven" id="dupven" />
													    </div>
													    </form>
													</div>
												</div><!-- /.span -->
												<?php if(isset($models) && !empty($models)){ $x=1;;
																		    foreach($models as $row){
																			  $productid=$row->id;
																				$withbatr=$row->dis_excld;
																				$withoutbatr=$row->dis_incld;
																				//$withcrg=$row->
																			 ?>
																	     
																	    <!-- <li>
																	     	<!--<a id="product__<?php echo $x; ?>" href="javascript:product_test(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#simpleModal_<?php echo $x; ?>">
																	     	<div class="tile-content">
																						
																						<div class="tile-text"><?php echo $row->productname; ?></div>
																			</div>
																			
																	     	
																	     	</a>->
																	     </li>
																	    																
																	     <!-- BEGIN SIMPLE MODAL MARKUP -->
																			<div class="modal fade" id="simpleModal_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
																				<div class="modal-dialog modal-lg">
																					<div class="modal-content">
																						<div class="modal-header">
																								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																									<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
																										<?php //$res=new Purchase_controller();
																			
																												$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
																			
																												<!--<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																												<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
																			
																												<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
																												-->
																						</div>
																						<div class="modal-body">
																							<div class="row">
																								<div class="col-md-9"><div class="col-md-3"><h4>Total Qty:-</h4></div><div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqty_<?php echo $x; ?>" name="productqty"  placeholder="Required No Of Quantity" onblur="getmodelqty(this.id);" ></div></div></div>
																								<div class="col-md-9"><div class="col-md-3"><h4>Choose :</h4></div>
																								<div class="col-md-6">
																									<div class="form-group floating-label">
																									 <input type="checkbox" name="choose[]" value="2000" id="erickshaw_<?php echo $x; ?>_1" onclick="getericksakwval(this.id)" >E-Rickshaw &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="100" id="erickshaw_<?php echo $x; ?>_2" onclick="getericksakwval(this.id)">Batery &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="50" id="erickshaw_<?php echo $x; ?>_3" onclick="getericksakwval(this.id)">Charger &nbsp;&nbsp;
																									<input type="hidden" id="cat_<?php echo $x; ?>" >
																									<input type="hidden" id="cate2_<?php echo $x; ?>" >
																									  </div>
																								    </div>
																								</div>
																									<table id="example8" style="width:80%;"><thead><tr><th colspan="10">Specify Quantity for Different Color</th></tr></thead>
																										<tr>
																											<?php if(isset($getcolorcode)){ $colorcode=1;
																														foreach($getcolorcode as $rowcolor)
																											{ ?>
																												<td data-column="<?php echo $rowcolor->color_name; ?>"><input type="text" id="colorqty_<?php echo $x; ?>_<?php echo $colorcode;  ?>" style="text-align:center;width:85px;background-color: <?php echo $rowcolor->code_hex; ?>;color:white;font-weight:bold;" onkeyup="getcolorquantity(this.id)"/></td>
																											<?php $colorcode++;  }
																											}   ?>
																											
																										</tr>
																									</table>
																								<div class="col-md-9">
																									<div class="col-md-3"><h4>Rest Of Quantity:-</h4></div>
																									<div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqtycolor_<?php echo $x; ?>" name="productqty"  readonly></div></div>
																								</div>
																						  </div>
																						     <input type="hidden" value="<?php echo $colorcode; ?>" id="colorcode">
																							<input type="hidden" name="modelid" value="<?php echo $row->productid; ?>" id="modid_<?php echo $x ;  ?>"/>
																							<input type="hidden" name="modelnme" value="<?php echo $row->productname; ?>" id="modname_<?php echo $x;  ?>"/>
																			
																							<br>
																								
																			
																		</div>
																		<div class="modal-footer">
																			<input type="hidden" id="notr" value=""/>
																			<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																			<button type="button"  class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetails(this.id,<?php echo $x; ?>)">SUBMIT</button>
																		</div>
																	</div><!-- /.modal-content -->
																</div><!-- /.modal-dialog -->
															</div><!-- /.modal -->
															<!-- END SIMPLE MODAL MARKUP -->
												
							                  <?php $x++;  } } ?>
							                  <?php  
							                    if(isset($models)&& !empty($models))
												{  $x=1; ?>
													 <?php foreach($models as $row){ 
													 	  $mname=$row->productname;
													 	?>
															<div class="modal fade" id="modalparts_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
																						<div class="modal-dialog modal-lg">
																							<div class="modal-content">
																								<div class="modal-header">
																										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																											<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
																												<?php //$res=new Purchase_controller();
																					
																														$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
																					
																														<!--<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																														<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
																					
																														<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
																														-->
																								</div>
																								<div class="modal-body">
																									<div class="row">
																										<center>REQUIRED QTY: <input type="text" name="noqty" id="noqty_<?php echo $x; ?>" onkeyup="gettotallist(this.id)" ></center>
																									</div>
																									<div class="row">
																										<div class="col-md-12">
																											<table class="table">
																												<thead>
																													<tr>
																														<td>SL NO.</td>
																														<td><input type="checkbox" id="checkAll"></td>
																														<td>PARTSCODE</td>
																														<td>PARTSNAME</td>
																														<td>PARTSUNIT</td>
																														<td>TOTALQNTY</td>
																														<td>UNITPRICE</td>
																														<td>AMOUNT</td>
																													</tr>
																												</thead>
																												<tbody>
																													<?php    $queryparts2=mysqli_query($con,"select * from materiel_master where mName='".trim($mname)."'"); 
																													       $re=1;
																														  while($rowparts=mysqli_fetch_array($queryparts2)){
																													    ?>
																													<tr>
																														<td><?php echo $re; ?></td>
																														<td><input type="checkbox" id="checked_<?php echo $x."_".$re ; ?>" class="spr" ></td>
																														<td><?php echo $rowparts['materiel_id'] ; ?></td>
																														<td><?php echo $rowparts['materialname'];  ?><input type="hidden" name="matname" value="<?php echo $rowparts['materialname']."($mname)";  ?>" id="matnam_<?php echo $x."_".$re; ?>">
																															<input type="hidden" name="matid" id="matid_<?php echo $x."_".$re; ?>" value="<?php echo $rowparts['materiel_id']; ?>"/>
																															
																														</td>
																														<td><?php echo $rowparts['unit'];  ?><input type="hidden" name="" id="unitpartsd_<?php echo  $x."_".$re; ?>" value="<?php echo $rowparts['unit']; ?>"></td>
																														<td><input type="text" style="width:50px;" id="totqnty_<?php echo $x."_".$re; ?>"></td>
																														<td><?php echo $rowparts['dispr'];  ?><input type="hidden" name="partamnt" id="partsamnt_<?php echo $x."_".$re; ?>" value="<?php echo $rowparts['dispr']; ?>"/></td>
																														<td><input type="text" style="width:80px;" id="totvalue_<?php echo $x."_".$re; ?>" readonly><input type="hidden" name="totval" id="totval_<?php echo $x."_".$re; ?>" /></td>
																														
																													</tr>
																													<?php $re++; }  ?>
																												</tbody>
																											</table>
																											<input type="hidden" value="<?php echo $re; ?>"  id="tottable_<?php echo $x; ?>">
																										</div>
																										
																									</div>
																								     
																					
																				                </div>
																				<div class="modal-footer">
																					<input type="hidden" id="notr" value=""/>
																					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																					<button type="button"  class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetltsbymodal(this.id)">SUBMIT</button>
																				</div>
																			</div><!-- /.modal-content -->
																		</div><!-- /.modal-dialog -->
																	</div><!-- /.modal -->
													
											<?php	} }
							                  
							                  ?>
											</div>
										</div>
										
										<div class="col-xs-12 col-sm-3" style="display:none;">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Model List</h4>

													
												</div>

												<div class="widget-body">
													<div class="widget-main">
														<!-- ############################################################## ######################################################################-->
														<div class="list-type1">
															
														<ol>
																				
																<?php if(isset($models) && !empty($models)){ $x=1;;
																		    foreach($models as $row){
																			  $productid=$row->id;
																				$withbatr=$row->dis_excld;
																				$withoutbatr=$row->dis_incld;
																				//$withcrg=$row->
																			 ?>
																	     
																	     <li>
																	     	<a id="product__<?php echo $x; ?>" href="javascript:product_test(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#simpleModal_<?php echo $x; ?>">
																	     	<div class="tile-content">
																						
																						<div class="tile-text"><?php echo $row->productname; ?></div>
																			</div>
																			
																	     	
																	     	</a>
																	     </li>
																	    																
																	     <!-- BEGIN SIMPLE MODAL MARKUP -->
																			<div class="modal fade" id="simpleModal_<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="simpleModalLabel" aria-hidden="true">
																				<div class="modal-dialog modal-lg">
																					<div class="modal-content">
																						<div class="modal-header">
																								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																									<h4 class="modal-title" id="simpleModalLabel"><?php echo $row->productname;  ?></h4>
																										<?php //$res=new Purchase_controller();
																			
																												$query=mysqli_query($con,"select * from product_specification where productid='".trim($productid)."'"); ?>
																			
																												<!--<h5><i>Model Code:-<?php echo $row->productid; ?></i></h5>
																												<h5><i>Current Stock Available:-<?php  echo $row->productqty ; ?></i></h5>
																			
																												<h5><i>Details Spare Parts with Specification of this Product are Following..........................</i></h5>
																												-->
																						</div>
																						<div class="modal-body">
																							<div class="row">
																								<div class="col-md-9"><div class="col-md-3"><h4>Total Qty:-</h4></div><div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqty_<?php echo $x; ?>" name="productqty"  placeholder="Required No Of Quantity" onblur="getmodelqty(this.id);" ></div></div></div>
																								<div class="col-md-9"><div class="col-md-3"><h4>Choose :</h4></div>
																								<div class="col-md-6">
																									<div class="form-group floating-label">
																									 <input type="checkbox" name="choose[]" value="2000" id="erickshaw_<?php echo $x; ?>_1" onclick="getericksakwval(this.id)" >E-Rickshaw &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="100" id="erickshaw_<?php echo $x; ?>_2" onclick="getericksakwval(this.id)">Batery &nbsp;&nbsp;
																									 <input type="checkbox" name="choose[]" value="50" id="erickshaw_<?php echo $x; ?>_3" onclick="getericksakwval(this.id)">Charger &nbsp;&nbsp;
																									<input type="text" id="cat_<?php echo $x; ?>" >
																									<input type="text" id="cate2_<?php echo $x; ?>" >
																									  </div>
																								    </div>
																								</div>
																									<table id="example8" style="width:80%;"><thead><tr><th colspan="10">Specify Quantity for Different Color</th></tr></thead>
																										<tr>
																											<?php if(isset($getcolorcode)){ $colorcode=1;
																														foreach($getcolorcode as $rowcolor)
																											{ ?>
																												<td data-column="<?php echo $rowcolor->color_name; ?>"><input type="text" id="colorqty_<?php echo $x; ?>_<?php echo $colorcode;  ?>" style="text-align:center;width:85px;background-color: <?php echo $rowcolor->code_hex; ?>;color:white;font-weight:bold;" onkeyup="getcolorquantity(this.id)"/></td>
																											<?php $colorcode++;  }
																											}   ?>
																											
																										</tr>
																									</table>
																								<div class="col-md-9">
																									<div class="col-md-3"><h4>Rest Of Quantity:-</h4></div>
																									<div class="col-md-6"><div class="form-group floating-label"><input type="text" class="form-control" id="productqtycolor_<?php echo $x; ?>" name="productqty"  readonly></div></div>
																								</div>
																						  </div>
																						     <input type="hidden" value="<?php echo $colorcode; ?>" id="colorcode">
																							<input type="hidden" name="modelid" value="<?php echo $row->productid; ?>" id="modid_<?php echo $x ;  ?>"/>
																							<input type="hidden" name="modelnme" value="<?php echo $row->productname; ?>" id="modname_<?php echo $x;  ?>"/>
																			
																							<br>
																								
																			
																		</div>
																		<div class="modal-footer">
																			<input type="hidden" id="notr" value=""/>
																			<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																			<button type="button"  class="btn btn-primary" id="modallist_<?php echo $x; ?>"  onclick="getpartsdetails(this.id,<?php echo $x; ?>)">SUBMIT</button>
																		</div>
																	</div><!-- /.modal-content -->
																</div><!-- /.modal-dialog -->
															</div><!-- /.modal -->
															<!-- END SIMPLE MODAL MARKUP -->
												
																	 <?php $x++;  } } ?>
														</ol>
														</div>
														
<!-- #################################################################################################################################### -->
	
													</div>
												</div>
											</div>
										</div><!-- /.span -->

										

										<div class="col-xs-12 col-sm-3" style="display:none;">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Spare Parts</h4>

													
												</div>

												<div class="widget-body">
													<div class="widget-main">
														<div class="">
															<ul class="list divider-full-bleed">
																<li>
																	
																		<div class="tile-text">
																			<?php if(isset($getallproduct)){ ?>
													 								<select name="modelname" id="modelname" class="form-control select2-list" onchange="getallspareparts();"><option value="">--select model--</option><?php foreach($getallproduct as $row){ ?><option value="<?php echo $row->productid."_".$row->productname ; ?>"><?php echo $row->productname; ?></option> <?php } ?></select>
													 						<?php } ?></div>
																	
																	
																</li>
														    </ul>
														</div>
														<div class="prts">
																<ol>
																<?php if(isset($allmaterial)){ $i=1; ?>
															<?php foreach($allmaterial as $row){ 
																$diff=$row->diff;
																$reoder=$row->reorderlevel; ?>
																
															 <li   class="tile" title="<?php  echo $row->materialname."(".$row->qnty.")";  ?>">
															 	<a  id="item_<?php echo $i; ?>" href="javascript:anchor_test(<?php echo $row->id; ?>)"  >
															 	 <div class="tile-content">
																		
																		<div class="tile-text" <?php if($diff<$reoder){ ?> style="font-weight: bold;"  <?php } ?>><small><?php  echo $row->materialname;  ?> (<?php echo $row->qnty;  ?>)</small></div>
																	</div>
															   </a>
															 	</li>
															 	<!--<li <?php if($diff<$reoder){?> class="btn btn-block ink-reaction btn-danger" <?php } ?> title="<?php  echo $row->materialname."(".$row->qnty.")";  ?>"><a  id="item_<?php echo $i; ?>" href="#" data-toggle="modal" data-target="#myModal_<?php echo $i;  ?>" ><i class="fa fa-crosshairs" aria-hidden="true"></i><small><?php  echo $row->materialname;  ?> (<?php echo $row->qnty;  ?>)</small></a></li>-->
															   				
															
														<?php  $i++; } } ?>
																
															</ol>
														</div>
												    </div>
												</div>
											</div>
										</div><!-- /.span -->
									</div><!-- /.row -->
									<!--<div class="row">
								<div class="col-xs-12 col-sm-12">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Billing Summary</h4>

												</div>

												<div class="widget-body">
													<div class="widget-main">
													</div>
												</div>
											</div>
							 </div>
							 </div>-->
												
								

        <?php $this->load->view('footerjs.php'); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquerymodal/js/jquery.modal.js"></script>

		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
				$("#submit").hide();
				$("#exciseduty").hide();
			     $("#checkAll").change(function () {
                   $("input:checkbox[class='spr']").prop('checked', $(this).prop("checked"));
             });

			
				if(!ace.vars['touch']) {
					$('.chosen-select').chosen({allow_single_deselect:true}); 
					//resize the chosen on window resize
			
					$(window)
					.off('resize.chosen')
					.on('resize.chosen', function() {
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					}).trigger('resize.chosen');
					//resize chosen on sidebar collapse/expand
					$(document).on('settings.ace.chosen', function(e, event_name, event_val) {
						if(event_name != 'sidebar_collapsed') return;
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					});
			
			
					$('#chosen-multiple-style .btn').on('click', function(e){
						var target = $(this).find('input[type=radio]');
						var which = parseInt(target.val());
						if(which == 2) $('#form-field-select-4').addClass('tag-input-style');
						 else $('#form-field-select-4').removeClass('tag-input-style');
					});
				}
			
			
				$('[data-rel=tooltip]').tooltip({container:'body'});
				$('[data-rel=popover]').popover({container:'body'});
			
				autosize($('textarea[class*=autosize]'));
				
				$('textarea.limited').inputlimiter({
					remText: '%n character%s remaining...',
					limitText: 'max allowed : %n.'
				});
			
				$.mask.definitions['~']='[+-]';
				$('.input-mask-date').mask('99/99/9999');
				$('.input-mask-phone').mask('(999) 999-9999');
				$('.input-mask-eyescript').mask('~9.99 ~9.99 999');
				$(".input-mask-product").mask("a*-999-a999",{placeholder:" ",completed:function(){alert("You typed the following: "+this.val());}});
			
			
			
				$( "#input-size-slider" ).css('width','200px').slider({
					value:1,
					range: "min",
					min: 1,
					max: 8,
					step: 1,
					slide: function( event, ui ) {
						var sizing = ['', 'input-sm', 'input-lg', 'input-mini', 'input-small', 'input-medium', 'input-large', 'input-xlarge', 'input-xxlarge'];
						var val = parseInt(ui.value);
						$('#form-field-4').attr('class', sizing[val]).attr('placeholder', '.'+sizing[val]);
					}
				});
			
				$( "#input-span-slider" ).slider({
					value:1,
					range: "min",
					min: 1,
					max: 12,
					step: 1,
					slide: function( event, ui ) {
						var val = parseInt(ui.value);
						$('#form-field-5').attr('class', 'col-xs-'+val).val('.col-xs-'+val);
					}
				});
			
			
				
				//"jQuery UI Slider"
				//range slider tooltip example
				$( "#slider-range" ).css('height','200px').slider({
					orientation: "vertical",
					range: true,
					min: 0,
					max: 100,
					values: [ 17, 67 ],
					slide: function( event, ui ) {
						var val = ui.values[$(ui.handle).index()-1] + "";
			
						if( !ui.handle.firstChild ) {
							$("<div class='tooltip right in' style='display:none;left:16px;top:-6px;'><div class='tooltip-arrow'></div><div class='tooltip-inner'></div></div>")
							.prependTo(ui.handle);
						}
						$(ui.handle.firstChild).show().children().eq(1).text(val);
					}
				}).find('span.ui-slider-handle').on('blur', function(){
					$(this.firstChild).hide();
				});
				
				
				$( "#slider-range-max" ).slider({
					range: "max",
					min: 1,
					max: 10,
					value: 2
				});
				
				$( "#slider-eq > span" ).css({width:'90%', 'float':'left', margin:'15px'}).each(function() {
					// read initial values from markup and remove that
					var value = parseInt( $( this ).text(), 10 );
					$( this ).empty().slider({
						value: value,
						range: "min",
						animate: true
						
					});
				});
				
				$("#slider-eq > span.ui-slider-purple").slider('disable');//disable third item
			
				
				$('#id-input-file-1 , #id-input-file-2').ace_file_input({
					no_file:'No File ...',
					btn_choose:'Choose',
					btn_change:'Change',
					droppable:false,
					onchange:null,
					thumbnail:false //| true | large
					//whitelist:'gif|png|jpg|jpeg'
					//blacklist:'exe|php'
					//onchange:''
					//
				});
				//pre-show a file name, for example a previously selected file
				//$('#id-input-file-1').ace_file_input('show_file_list', ['myfile.txt'])
			
			
				$('#id-input-file-3').ace_file_input({
					style: 'well',
					btn_choose: 'Drop files here or click to choose',
					btn_change: null,
					no_icon: 'ace-icon fa fa-cloud-upload',
					droppable: true,
					thumbnail: 'small'//large | fit
					//,icon_remove:null//set null, to hide remove/reset button
					/**,before_change:function(files, dropped) {
						//Check an example below
						//or examples/file-upload.html
						return true;
					}*/
					/**,before_remove : function() {
						return true;
					}*/
					,
					preview_error : function(filename, error_code) {
						//name of the file that failed
						//error_code values
						//1 = 'FILE_LOAD_FAILED',
						//2 = 'IMAGE_LOAD_FAILED',
						//3 = 'THUMBNAIL_FAILED'
						//alert(error_code);
					}
			
				}).on('change', function(){
					//console.log($(this).data('ace_input_files'));
					//console.log($(this).data('ace_input_method'));
				});
				
				
				//$('#id-input-file-3')
				//.ace_file_input('show_file_list', [
					//{type: 'image', name: 'name of image', path: 'http://path/to/image/for/preview'},
					//{type: 'file', name: 'hello.txt'}
				//]);
			
				
				
			
				//dynamically change allowed formats by changing allowExt && allowMime function
				$('#id-file-format').removeAttr('checked').on('change', function() {
					var whitelist_ext, whitelist_mime;
					var btn_choose
					var no_icon
					if(this.checked) {
						btn_choose = "Drop images here or click to choose";
						no_icon = "ace-icon fa fa-picture-o";
			
						whitelist_ext = ["jpeg", "jpg", "png", "gif" , "bmp"];
						whitelist_mime = ["image/jpg", "image/jpeg", "image/png", "image/gif", "image/bmp"];
					}
					else {
						btn_choose = "Drop files here or click to choose";
						no_icon = "ace-icon fa fa-cloud-upload";
						
						whitelist_ext = null;//all extensions are acceptable
						whitelist_mime = null;//all mimes are acceptable
					}
					var file_input = $('#id-input-file-3');
					file_input
					.ace_file_input('update_settings',
					{
						'btn_choose': btn_choose,
						'no_icon': no_icon,
						'allowExt': whitelist_ext,
						'allowMime': whitelist_mime
					})
					file_input.ace_file_input('reset_input');
					
					file_input
					.off('file.error.ace')
					.on('file.error.ace', function(e, info) {
						//console.log(info.file_count);//number of selected files
						//console.log(info.invalid_count);//number of invalid files
						//console.log(info.error_list);//a list of errors in the following format
						
						//info.error_count['ext']
						//info.error_count['mime']
						//info.error_count['size']
						
						//info.error_list['ext']  = [list of file names with invalid extension]
						//info.error_list['mime'] = [list of file names with invalid mimetype]
						//info.error_list['size'] = [list of file names with invalid size]
						
						
						/**
						if( !info.dropped ) {
							//perhapse reset file field if files have been selected, and there are invalid files among them
							//when files are dropped, only valid files will be added to our file array
							e.preventDefault();//it will rest input
						}
						*/
						
						
						//if files have been selected (not dropped), you can choose to reset input
						//because browser keeps all selected files anyway and this cannot be changed
						//we can only reset file field to become empty again
						//on any case you still should check files with your server side script
						//because any arbitrary file can be uploaded by user and it's not safe to rely on browser-side measures
					});
					
					
					/**
					file_input
					.off('file.preview.ace')
					.on('file.preview.ace', function(e, info) {
						console.log(info.file.width);
						console.log(info.file.height);
						e.preventDefault();//to prevent preview
					});
					*/
				
				});
			
				$('#spinner1').ace_spinner({value:0,min:0,max:200,step:10, btn_up_class:'btn-info' , btn_down_class:'btn-info'})
				.closest('.ace-spinner')
				.on('changed.fu.spinbox', function(){
					//console.log($('#spinner1').val())
				}); 
				$('#spinner2').ace_spinner({value:0,min:0,max:10000,step:100, touch_spinner: true, icon_up:'ace-icon fa fa-caret-up bigger-110', icon_down:'ace-icon fa fa-caret-down bigger-110'});
				$('#spinner3').ace_spinner({value:0,min:-100,max:100,step:10, on_sides: true, icon_up:'ace-icon fa fa-plus bigger-110', icon_down:'ace-icon fa fa-minus bigger-110', btn_up_class:'btn-success' , btn_down_class:'btn-danger'});
				$('#spinner4').ace_spinner({value:0,min:-100,max:100,step:10, on_sides: true, icon_up:'ace-icon fa fa-plus', icon_down:'ace-icon fa fa-minus', btn_up_class:'btn-purple' , btn_down_class:'btn-purple'});
			
				//$('#spinner1').ace_spinner('disable').ace_spinner('value', 11);
				//or
				//$('#spinner1').closest('.ace-spinner').spinner('disable').spinner('enable').spinner('value', 11);//disable, enable or change value
				//$('#spinner1').closest('.ace-spinner').spinner('value', 0);//reset to 0
			
			
				//datepicker plugin
				//link
				$('.date-picker').datepicker({
					autoclose: true,
					todayHighlight: true
				})
				//show datepicker when clicking on the icon
				.next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
			
				//or change it into a date range picker
				$('.input-daterange').datepicker({autoclose:true});
			
			
				//to translate the daterange picker, please copy the "examples/daterange-fr.js" contents here before initialization
				$('input[name=date-range-picker]').daterangepicker({
					'applyClass' : 'btn-sm btn-success',
					'cancelClass' : 'btn-sm btn-default',
					locale: {
						applyLabel: 'Apply',
						cancelLabel: 'Cancel',
					}
				})
				.prev().on(ace.click_event, function(){
					$(this).next().focus();
				});
			
			
				$('#timepicker1').timepicker({
					minuteStep: 1,
					showSeconds: true,
					showMeridian: false,
					disableFocus: true,
					icons: {
						up: 'fa fa-chevron-up',
						down: 'fa fa-chevron-down'
					}
				}).on('focus', function() {
					$('#timepicker1').timepicker('showWidget');
				}).next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
				
				
			
				
				if(!ace.vars['old_ie']) $('#date-timepicker1').datetimepicker({
				 //format: 'MM/DD/YYYY h:mm:ss A',//use this option to display seconds
				 icons: {
					time: 'fa fa-clock-o',
					date: 'fa fa-calendar',
					up: 'fa fa-chevron-up',
					down: 'fa fa-chevron-down',
					previous: 'fa fa-chevron-left',
					next: 'fa fa-chevron-right',
					today: 'fa fa-arrows ',
					clear: 'fa fa-trash',
					close: 'fa fa-times'
				 }
				}).next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
				
			
				$('#colorpicker1').colorpicker();
				//$('.colorpicker').last().css('z-index', 2000);//if colorpicker is inside a modal, its z-index should be higher than modal'safe
			
				$('#simple-colorpicker-1').ace_colorpicker();
				//$('#simple-colorpicker-1').ace_colorpicker('pick', 2);//select 2nd color
				//$('#simple-colorpicker-1').ace_colorpicker('pick', '#fbe983');//select #fbe983 color
				//var picker = $('#simple-colorpicker-1').data('ace_colorpicker')
				//picker.pick('red', true);//insert the color if it doesn't exist
			
			
				$(".knob").knob();
				
				
				var tag_input = $('#form-field-tags');
				try{
					tag_input.tag(
					  {
						placeholder:tag_input.attr('placeholder'),
						//enable typeahead by specifying the source array
						source: ace.vars['US_STATES'],//defined in ace.js >> ace.enable_search_ahead
						/**
						//or fetch data from database, fetch those that match "query"
						source: function(query, process) {
						  $.ajax({url: 'remote_source.php?q='+encodeURIComponent(query)})
						  .done(function(result_items){
							process(result_items);
						  });
						}
						*/
					  }
					)
			
					//programmatically add/remove a tag
					var $tag_obj = $('#form-field-tags').data('tag');
					$tag_obj.add('Programmatically Added');
					
					var index = $tag_obj.inValues('some tag');
					$tag_obj.remove(index);
				}
				catch(e) {
					//display a textarea for old IE, because it doesn't support this plugin or another one I tried!
					tag_input.after('<textarea id="'+tag_input.attr('id')+'" name="'+tag_input.attr('name')+'" rows="3">'+tag_input.val()+'</textarea>').remove();
					//autosize($('#form-field-tags'));
				}
				
				
				/////////
				$('#modal-form input[type=file]').ace_file_input({
					style:'well',
					btn_choose:'Drop files here or click to choose',
					btn_change:null,
					no_icon:'ace-icon fa fa-cloud-upload',
					droppable:true,
					thumbnail:'large'
				})
				
				//chosen plugin inside a modal will have a zero width because the select element is originally hidden
				//and its width cannot be determined.
				//so we set the width after modal is show
				$('#modal-form').on('shown.bs.modal', function () {
					if(!ace.vars['touch']) {
						$(this).find('.chosen-container').each(function(){
							$(this).find('a:first-child').css('width' , '210px');
							$(this).find('.chosen-drop').css('width' , '210px');
							$(this).find('.chosen-search input').css('width' , '200px');
						});
					}
				})
				/**
				//or you can activate the chosen plugin after modal is shown
				//this way select element becomes visible with dimensions and chosen works as expected
				$('#modal-form').on('shown', function () {
					$(this).find('.modal-chosen').chosen();
				})
				*/
			
				
				
				$(document).one('ajaxloadstart.page', function(e) {
					autosize.destroy('textarea[class*=autosize]')
					
					$('.limiterBox,.autosizejs').remove();
					$('.daterangepicker.dropdown-menu,.colorpicker.dropdown-menu,.bootstrap-datetimepicker-widget.dropdown-menu').remove();
				});
			
			});
		</script>
		<script>
			function getcolorquantity(id)
{
	var idsplit=id.split("_");
	var divmodalid=idsplit[1];
	var tot=0;var gettot;
	var colorcdno=$("#colorcode").val();
	for( var n=1;n<colorcdno;n++)
	{
		
		gettot=$("#colorqty_"+divmodalid+"_"+n).val();
		if(gettot=="")
		{
			gettot=0;
			
		}
		tot=tot+parseInt(gettot);
		//alert(tot);
	}
	var existtot=$("#productqty_"+divmodalid).val();
	if(existtot==""){existtot=0;}
	var resttot=parseInt(existtot)-parseInt(tot);
	if(resttot==0){resttot="";}
	if(resttot<0)
	{
		alert('please type right number of quantity');
		
	}else{
		
		$("#productqtycolor_"+divmodalid).val(resttot);
	}
	
	
}
function getallspareparts()
{
	//alert('hello');
	var modelname=$("#modelname").val();
	//alert(modelname);
	var idsplit=modelname.split("_");
	var modcode=idsplit[0];
	var modnam=idsplit[1];
	//alert(modnam);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getallspare_parts_sort_by_modelname",
  			data :{'modcode':modcode,'modnam':modnam},
  			success : function(data){
  				 				 
  				//alert(data);
  				$(".prts").html(data);
  			  
              }  
           });
}
function getmodelqty(id)
{
	var idsplit=id.split("_");
	var idx=idsplit[1];
	var noqty=$("#productqty_"+idsplit[1]).val();
	var partssp=parseInt($("#partssp_"+idsplit[1]).val());
	for(var c=1;c<partssp;c++)
	{
		var ptaqty=$("#ptsap_"+idx+"_"+c).val();
		var hidpty=$("#ptsaphidden_"+idx+"_"+c).val();
		 if(noqty=="")
		 {
		 	$("#ptsap_"+idx+"_"+c).val(hidpty);
		 }else
		 {
		 	var noqty1=parseInt(noqty)*parseInt(ptaqty);
		    $("#ptsap_"+idx+"_"+c).val(noqty1);
		 }
		
		//alert(ptaqty);
	}
	//alert(idx);
	//alert(noqty);
	
}
function getpartsdetails(id,divid)
{
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var ds=divid;
	var notr=$("#notr").val();
	//alert(notr);
	//var notr1=notr-1;
	var colorcode23=parseInt($("#colorcode").val());
	var req="";
	var valid=0;
	var nettot=0;
	for(var c=1;c<notr;c++)
	{
		var prtsqty=$("#ptsap_"+ds+"_"+c).val();
		//alert(prtsqty);
		
		if(($("#req_"+ds+"_"+c).prop('checked') == true) && ($("#specification_"+ds+"_"+c).val()!="9999")){
			req +=$("#req_"+ds+"_"+c).val()+"@"+prtsqty+"||";
    
         }else
         { 
         	if($("#req_"+ds+"_"+c).prop('checked') == true){
         		valid++;
         	}else
         	{
         		
         	}
         	
         }
		
	}
	//alert(valid);
	
	var color="";
	for(var d=1;d<colorcode23;d++)
	{
		gettot=$("#colorqty_"+ds+"_"+d).val();
		if(gettot=="")
		{
			
		}else
		{
			color +=$("#colorqty_"+ds+"_"+d).val()+"->"+d+"#";
		}
	}
   //  alert(color);
	var modelid=$("#modid_"+idsplit[1]).val();
	var modelname=$("#modname_"+idsplit[1]).val();
	var prqty=$("#productqty_"+idsplit[1]).val();
	if(prqty=="")
	{
		prqty=0;
	}
	//alert(prqty);
	
	var modelnm=$("#cate2_"+idsplit[1]).val();
	//alert(modelnm);
	if(modelnm=="")
	{
		ctr="0";
	}
	//modelnmsp=modelnm.split("_");
	
	var amount=parseFloat($("#cat_"+idsplit[1]).val());
	//alert(amount);
	var ctr=modelnm;
	//alert(ctr);
	if(ctr=="1,")
	{
		var catr="without battery & charger";
	}
	if(ctr=="1,2,")
	{
		var catr="with Battery";
	}
	if(ctr=="1,2,3,")
	{
		var catr="with Battery & Charger";
	}
	amount=parseFloat(amount).toFixed(2);
	//alert(amount);
	var amnyt=parseFloat(amount)*parseInt(prqty);
	var amnt=amnyt.toFixed(2);
	//alert(amnt);
	//$('.inputr').append("<input type='text'");
  			    
     //$('.inputr').append("<input type='text' name='modelname_"+tr2+"' value='"+modelname+"'/>");
    // $('.inputr').append("<input type='text' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prqty+"' />");
    // $('.inputr').append("<input type='text'/>");
	//alert(modelid);
	//alert(modelname);;
	//alert(color);
	
	var rowCount = $('#example tr').length;
	var tr=rowCount-1;
	var tr2=tr+1;
	$("#tbalerow").val(tr2);
	//var rew=$("#product_spec").val(req);
	//alert(req);
	if(valid<1 && parseInt(prqty)>0 && ctr!="" ){
	$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+modelname+'<br>('+catr+')<input type="hidden" value="'+modelname+'" id="modelname_'+tr2+'"/></td><td>'+prqty+'</td><td>'+amount+'</td><td>'+amnt+'<input type="hidden" id="tot1_'+tr2+'" value="'+amnt+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
	$('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='modelid1_"+tr2+"' value='"+modelid+"'/>");
  			    
  $('.inputr').append("<input type='hidden' name='particular_"+tr2+"' value='"+modelname+"'/>");
  $('.inputr').append("<input type='hidden' name='specfic_"+tr2+"' value='"+catr+"'/>");
   $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' value='"+prqty+"' />");
    $('.inputr').append("<input type='hidden' name='unitpr_"+tr2+"' id='unitpr_"+tr2+"' value='"+amount+"'  />");
    $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+amnt+"'  />");
    $('.inputr').append("<input type='hidden' name='colorspe_"+tr2+"' value='"+color+"' />");
   //$('.inputr').append("<input type='hidden' name='specification_"+tr2+"' value='"+req+"' />");
  // $('.inputr').append("<input type='hidden' name='colorspe_"+tr2+"' value='"+color+"' />");
   
  for(var tre=1;tre<=parseInt(tr2);tre++)
    {
           var tt=$("#tot_"+tre).val();
           nettot=parseFloat(nettot)+parseFloat(tt);
           nettot=nettot.toFixed(2);
    }
                   $("#nettot").text(nettot);
                  // $("#grandtot").text(nettot);
                   var grandtot=parseFloat(nettot);
	                var excise=2;
	                var exciseamnt=(parseFloat(grandtot)*parseFloat(2))/100;
	                var grtot=parseFloat(grandtot)+parseFloat(exciseamnt);
	                $("#excisetax").val(excise);
  				 	$("#examnt").text(exciseamnt.toFixed(2));
  				 	$("#excise_amnt").val(exciseamnt.toFixed(2));
  				 	$("#grandtot").text(grtot.toFixed(2));	
  				 	$("#grandtotal").val(grtot.toFixed(2));		 
  				  
             
                  // $(nettoinput).
                  	$("#submit").show();
   	                  $("#exciseduty").show();
   	             $("#simpleModal_"+idsplit[1]).modal('hide');
   
  }else
  {
  	alert('Please Fill required Filled');
  }
  
   
   
   
	// $('.inputr').append("<input type='text'/>");
	//$('.inputr').append("<input type='text'");
}
function anchor_test(id)
{
	//var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var id1=id;
	var matid1="matid";
	var specid=$("#speci_"+id1).val();
	var prtsqt=parseInt($("#noprts_"+id1).val());
	var model=$("#modelname").val();
	if(model==""){
		 //alert("Please Select Model Name");
		 modal({
				type: 'warning',
				title: 'Message!',
				text: '<h4><b>Please Select Model Name</b></h4>',
			});
			
			
	}else{
		//alert(specid);
	var rowCount = $('#example tr').length;
	var modelsplit=model.split("_");
	var modelid=modelsplit[0];
	var modelname=modelsplit[1];
	var tr=rowCount-1;
	var tr2=tr+1;
	var prtsamnt=$("#prtsamnt_"+id).val();
	$("#tbalerow").val(tr2);
	var nettot=0;
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getdetails_purchase",
  			data :{'id':id1,'specid':specid},
  			success : function(data){
  				//alert('hello');
  				var json=JSON.parse(data);
  				
  				var matid=json.matid;
  				//alert(matid);
  				var unit=parseInt(json.unit);
  				var matname=json.matname;
  				var specif=json.specif;
  				var prtd=parseInt(prtsqt*unit);
  					var tot=parseFloat(prtsamnt)*parseInt(prtd);
  					tot=tot.toFixed(2);
  				//$("#matid").val(matid);
  				$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+ matname +'<br><i>('+specif+')</i><input type="hidden" name="matname_'+tr2+'" value="'+matname+'"/></td><td>'+prtd+'<br><i>('+prtsqt+'X'+unit+')</i></td><td>'+prtsamnt+'</td><td>'+tot+'<input type="hidden" id="tot1_'+tr2+'" value="'+tot+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='particular_"+tr2+"' value='"+matid+"'/>");
  			    $('.inputr').append("<input type='hidden' id='specfic_"+tr2+"' name='specfic_"+tr2+"' value='"+specif+"'/>");
  			      $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			      $('.inputr').append("<input type='hidden' name='unitpr_"+tr2+"' id='unitpr_"+tr2+"' value='"+prtsamnt+"'  />");
  			     $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			    /*$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			     $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			     $('.inputr').append("<input type='hidden' name='prtspecif_"+tr2+"' id='prtspecif_"+tr2+"' value='"+specid+"'  />");*/
  			    // $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			     for(var tre=1;tre<=parseInt(tr2);tre++)
                 {
           	      var tt=$("#tot_"+tre).val();
           	           nettot=parseFloat(nettot)+parseFloat(tt);
           	           nettot=nettot.toFixed(2);
                 }
                   $("#nettot").text(nettot);
              }  
           });
           
         
          
     //alert(matid);
     
   	   $("#submit").show();
   
	
	}
	//alert('hello');
	//alert(id);
	//$('#example tr:last').after('<tr><td>'+ tr2 +'</td><td>'+ matid1+'</td><td>'+ matname1 +'</td><td><input type="text" name="matqty" /> </td><td><button>Delete</button></td></tr>');
}
 function deletetrrow(id)
{
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var rowCount = $('#example tr').length;
	var result=confirm("Want to delete?");
	//alert(result);
	if(result==true)
	{
		//alert(this);
		//$(this).closest('tr').remove();
		$(".getrow_"+idsplit[1]).css("background-color","#a94442");

		$(".getrow_"+idsplit[1]).fadeOut(400, function(){
			$(".getrow_"+idsplit[1]).remove();
		});
	}
	rowCount=rowCount-1;
	if( rowCount<2)
	{
		$("#submit").hide();
	}
	
	
	
	// alert('hello');
}
function getcstdtls()
{
	//alert('hello');
	var custmail=$("#custid").val();
	alert(custmail);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getcustmer",
  			data :{'custmail':custmail},
  			success : function(data){
  				 				 
  				//alert(data);
  				
  				var json=JSON.parse(data);
  				
  				var cmpnme=json.comp;
  				var name=json.name;
  				var img=json.image;
  				var custid=json.custid;
  				$("#comp").val(custid);
  				$("#custname").val(name);
  				$("#img").html('<img id="blah" src="<?php echo base_url(); ?>uploads/clientpics/'+img+'" alt="your image" width="150" height="150" name="image1"/>');
  				
  				//$(".prts").html(data);
  			  
              }  
       });
}
function addspecification(id,spd)
{
	var idsplit=id.split("_");
	var divis=spd;
	var specification=$("#specification_"+divis+"_"+idsplit[2]).val();
	//alert(specification);
	if(specification=="0")
	{
		specification=9999;
	}
	var req=$("#req_"+divis+"_"+idsplit[2]).val();
	var chr=req.indexOf("9999");
	if(chr>-1)
	{
		req=req.slice(0,-5);
	}else
	{
		req=req.slice(0,-2);
	}
	//alert(req);
	req += '_'+specification;

//str += ' ' + 'and some more blah';
$("#req_"+divis+"_"+idsplit[2]).val(req);
	//alert(req);
}
function getvatamount()
{
	var nettot=parseFloat($("#grandtot").text());
	var vatcst=$("#vatcst").val();
	if(vatcst==""){
		alert("please select VAT/CST");
		$("#vatcs").val('');
  	    $("#vatamnt").text("");
  		$("#grandtot").text(nettot.toFixed(2));
  		$("#grandtotal").val(nettot.toFixed(2));
  		$("#vat_amnt").val('');
	}else
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getvatdetails",
  			data :{'vatcst':vatcst,'nettot':nettot},
  			success : function(data){
  				//console.log(data);
  				 	var json=JSON.parse(data);
  				 	var vatamnt=parseFloat(json.vat);
  				 	vatamnt=vatamnt.toFixed(2)+"%";
  				 	var vatamnt2=parseFloat(json.vatamnt);
  				 	vatamnt2=vatamnt2.toFixed(2);
  				 	var grtot=parseFloat(json.grandtot);
  				 	$("#vatcs").val(vatamnt);
  				 	$("#vatamnt").text(vatamnt2);
  				 	$("#vat_amnt").val(vatamnt2);
  				 	$("#grandtot").text(grtot.toFixed(2));
  				 	$("#grandtotal").val(grtot.toFixed(2));			 
  				  
              }  
       });
	}
	//alert(vatcst);
}
function getcstamount()
{
	
	var nettot=parseFloat($("#nettot").text());
	var vatamnt=parseFloat($("#vatamnt").text());
	var grandtot=parseFloat($("#grandtot").text());
	var excise=$("#excise").val();
	if(excise==3){
		var grandtot2=parseFloat(nettot)+parseFloat(vatamnt);
		alert("please select Excise tax");
		$("#excisetax").val('');
  	   $("#examnt").text("");
  	   $("#excise_amnt").val('');
  	   	$("#grandtot").text(grandtot2.toFixed(2));
  	   	$("#grandtotal").val(grandtot2.toFixed(2));
	}else
	{
		if(excise==1){
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getexcisedetails",
  			data :{'excise':excise,'grandtot':grandtot},
  			success : function(data){
  				console.log(data);
  				 	var json=JSON.parse(data);
  				 	var excise=parseFloat(json.excise);
  				 	excise=excise.toFixed(2)+"%";
  				 	var exciseamnt=parseFloat(json.exciseamnt);
  				 	exciseamnt=exciseamnt.toFixed(2);
  				 	var grtot=parseFloat(json.grandtot);
  				 	$("#excisetax").val(excise);
  				 	$("#examnt").text(exciseamnt);
  				 	$("#excise_amnt").val(exciseamnt);
  				 	$("#grandtot").text(grtot.toFixed(2));	
  				 	$("#grandtotal").val(grtot.toFixed(2));		 
  				  
              }  
       });
       
      }
      else
      {
      	var grandtot2=parseFloat(nettot)+parseFloat(vatamnt);
		//alert("please select Excise tax");
		$("#excisetax").val('');
  	   $("#examnt").text("");
  	   $("#excise_amnt").val('');
  	   	$("#grandtot").text(grandtot2.toFixed(2));
  	   	$("#grandtotal").val(randtot2.toFixed(2));		 
      }
	}
}
function gettypedetails()
{
	var cattyp=$("#cattyp").val(); 
	//alert(cattyp);
	//console.log(cattyp);
	if(cattyp=="product")
	{
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getmodeldet",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					$("#model").show();
  				  $("#model").html(data);
              }  
       });
	}else
	{
		//$("#model").hide();
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getmodellistbyparts",
  			data :{'cattyp':cattyp},
  			success : function(data){
  					//alert(data) ;
  					$("#model").show();
  				  $("#model").html(data);
              }  
       });
		
		//if(cattyp=="parts")
		//{
			
		//}else
		//{
			
		//}
	}
}
function getmodeltype()
{
	var type1=$("#modeltype").val();
	var typesplit=type1.split("_");
	var type=typesplit[0];
	var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getmodelprice",
  			data :{'type':type},
  			success : function(data){
  					
  				  $("#simpleModal_"+id).modal('show');
              }  
       });
	
}
function getmodeltypebyparts()
{
	var type1=$("#modeltype").val();
	var typesplit=type1.split("_");
	var type=typesplit[0];
	var id=typesplit[1];
	//alert(typesplit);
	//if(type=="")
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getmodelprice",
  			data :{'type':type},
  			success : function(data){
  					
  				  $("#modalparts_"+id).modal('show');
              }  
       });
	
	
}
function getericksakwval(id)
{
	var idsplit=id.split("_");
	var catval=0;
	var cate2="";
	for(var d=1;d<4;d++){
	    var eric=$("#erickshaw_"+idsplit[1]+"_"+d).val();
	    
		if($("#erickshaw_"+idsplit[1]+"_"+d).prop('checked') == true)
		{
			//alert(eric);
			catval=parseFloat(catval)+parseFloat(eric);
			cate2 += d +",";
			
		}
	
	}
	//console.log(cate2);
	$("#cate2_"+idsplit[1]).val(cate2);
	$("#cat_"+idsplit[1]).val(catval);
	
}
function getpartsdetltsbymodal(id)
{
	
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	//var id1=id;
	//var matid1="matid";
	//var specid=$("#speci_"+id1).val();
	//var prtsqt=parseInt($("#noprts_"+id1).val());
	//var model=$("#modelname").val();
	var retoto=$("#noqty_"+idsplit[1]).val();
	if(retoto==""){
		 //alert("Please Select Model Name");
		 modal({
				type: 'warning',
				title: 'Message!',
				text: '<h4><b>Please Enter Required No Qty</b></h4>',
			});
			
	}else{		
	
		//alert(specid);
	var tottable=parseInt($("#tottable_"+idsplit[1]).val());
	var totqnty1=parseInt($("#noqty_"+idsplit[1]).val());
	
	//alert(tottable);
	var rest=0;
	var grandtot=0;
	for(var i=1;i<tottable;i++)
	{
		 var prtd=$("#totqnty_"+idsplit[1]+"_"+i).val();
	  //var totval= $("#totval_"+idsplit[1]+"_"+i).val(totval);
	    var tot= $("#totvalue_"+idsplit[1]+"_"+i).val();
	    //tot=tot.toFixed(2);
		var matname=$("#matnam_"+idsplit[1]+"_"+i).val();
		var matid=$("#matid_"+idsplit[1]+"_"+i).val();
		var partsamnt=$("#partsamnt_"+idsplit[1]+"_"+i).val();
		//console.log("#partsamnt_"+idsplit[1]+i);
		if($("#checked_"+idsplit[1]+"_"+i).prop('checked') == true)
		{
			grandtot=grandtot+parseInt(tot);
			var rowCount = $('#example tr').length;
			var specif="";
			var tr=rowCount-1;
	   	 	var tr2=tr+1;
	   	 	$("#tbalerow").val(tr2);
	   	 	$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+ matname +'<br><i>('+specif+')</i><input type="hidden" name="matname_'+tr2+'" value="'+matname+'"/></td><td>'+prtd+'<br><i></i></td><td>'+partsamnt+'</td><td>'+tot+'<input type="hidden" id="tot1_'+tr2+'" value="'+tot+'"/></td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
	   	 	
	   	 	$('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='particular_"+tr2+"' value='"+matid+"'/>");
  			$('.inputr').append("<input type='hidden' id='specfic_"+tr2+"' name='specfic_"+tr2+"' value='"+specif+"'/>");
  			$('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			$('.inputr').append("<input type='hidden' name='unitpr_"+tr2+"' id='unitpr_"+tr2+"' value='"+partsamnt+"'  />");
  			$('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			    /*$('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			     $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			     $('.inputr').append("<input type='hidden' name='prtspecif_"+tr2+"' id='prtspecif_"+tr2+"' value='"+specid+"'  />");*/
  			    // $('.inputr').append("<input type='hidden' name='tot_"+tr2+"' id='tot_"+tr2+"' value='"+tot+"'  />");
  			    
	   	 	
	   	 	
	   	 	
	   	 	
	   	 	
	   }else
	   {
	   	 rest++;
	   }
	}
	   alert(rest);
	     $("#nettot").text(parseInt(grandtot).toFixed(2));
	  	$("#grandtot").text(parseInt(grandtot).toFixed(2));
  	   	$("#grandtotal").val(parseInt(grandtot).toFixed(2));	
	
	
     //alert(matid);
     
   	   $("#submit").show();
   
	}
	
	//alert('hello');
	//alert(id);
	//$('#example tr:last').after('<tr><td>'+ tr2 +'</td><td>'+ matid1+'</td><td>'+ matname1 +'</td><td><input type="text" name="matqty" /> </td><td><button>Delete</button></td></tr>');
 
}
function gettotallist(id)
{
	var idsplit=id.split("_");
	//alert(idsplit);
	var tottable=parseInt($("#tottable_"+idsplit[1]).val());
	var totqnty1=parseInt($("#noqty_"+idsplit[1]).val());
	if(totqnty1=="" || isNaN(totqnty1))
	{
		totqnty1=1;
	}
	//alert(tottable);
	
	for(var i=1;i<tottable;i++)
	{
		var unit=$("#unitpartsd_"+idsplit[1]+"_"+i).val();
		//alert(unit);
		//alert(totqnty1);
		
		var prtsamnt=parseFloat($("#partsamnt_"+idsplit[1]+"_"+i).val());
		var totqnt=parseInt(totqnty1) * parseInt(unit);
		var totval=parseFloat(prtsamnt) * totqnt;
		//$().val();
		$("#totqnty_"+idsplit[1]+"_"+i).val(totqnt);
	   $("#totval_"+idsplit[1]+"_"+i).val(totval);
	    $("#totvalue_"+idsplit[1]+"_"+i).val(totval.toFixed(2));
		
	}
	
	
}

		</script>
	</body>
</html>
