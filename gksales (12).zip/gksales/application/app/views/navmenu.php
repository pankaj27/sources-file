<div id="sidebar" class="sidebar                  responsive                    ace-save-state">
				<script type="text/javascript">
					try{ace.settings.loadState('sidebar')}catch(e){}
				</script>

				<div class="sidebar-shortcuts" id="sidebar-shortcuts">
					<div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
						<button class="btn btn-success">
							<i class="ace-icon fa fa-signal"></i>
						</button>

						<button class="btn btn-info">
							<i class="ace-icon fa fa-pencil"></i>
						</button>

						<button class="btn btn-warning">
							<i class="ace-icon fa fa-users"></i>
						</button>

						<button class="btn btn-danger">
							<i class="ace-icon fa fa-cogs"></i>
						</button>
					</div>

					<div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
						<span class="btn btn-success"></span>

						<span class="btn btn-info"></span>

						<span class="btn btn-warning"></span>

						<span class="btn btn-danger"></span>
					</div>
				</div><!-- /.sidebar-shortcuts -->

				<ul class="nav nav-list" id="box">
					<li>
						<a href="<?php echo base_url(); ?>">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>
					<li>
						<a href="#" class="dropdown-toggle">
							<i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
							<span class="menu-text"> Enquiry </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>
						<ul class="submenu">
							<li>
								<a href="<?php echo base_url(); ?>enquery_controller/add" >
									<i class="menu-icon fa fa-caret-right"></i>
									Add Enquiry
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url(); ?>enquery_controller/viewenq">
									<i class="menu-icon fa fa-caret-right"></i>
									View Enquiry
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li class="">
						<a href="" class="dropdown-toggle">
							<i class="ace-icon fa fa-users"></i>
							<span class="menu-text">
								Manage Customers
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							

							<li class="">
								<a href="<?php echo base_url();?>manage_customer/createcustomer">
									<i class="menu-icon fa fa-caret-right"></i>
									Create Customer
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>manage_customer/viewclientlist">
									<i class="menu-icon fa fa-caret-right"></i>
									View Customer
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>manage_customer/sndmail">
									<i class="menu-icon fa fa-caret-right"></i>
									Send Email
								</a>

								<b class="arrow"></b>
							</li>

							
							</ul>
							</li>
						

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
							<span class="menu-text"> Products </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url(); ?>product_controller/viewdemo">
									<i class="menu-icon fa fa-caret-right"></i>
									View Demo
								</a>

								<b class="arrow"></b>
							</li>

							
						</ul>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="fa fa-money" aria-hidden="true"></i>
							<span class="menu-text"> Booking </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url();?>Paymentcontroller/createorder">
									<i class="menu-icon fa fa-caret-right"></i>
									Create  Booking
								</a>

								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url();?>Paymentcontroller/viewbokkinglist">
									<i class="menu-icon fa fa-caret-right"></i>
									 Booking List
								</a>

								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url();?>Paymentcontroller/receiptvoucher">
									<i class="menu-icon fa fa-caret-right"></i>
									Receipt Voucher
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url();?>Paymentcontroller/viewreceiptvoucher">
									<i class="menu-icon fa fa-caret-right"></i>
									view Receipt Voucher
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="fa fa-user" aria-hidden="true"></i>
							<span class="menu-text"> My Profile  </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url(); ?>Profile_controller/myprofile">
									<i class="menu-icon fa fa-caret-right"></i>
									View Profile 
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url(); ?>Profile_controller/tourplan">
									<i class="menu-icon fa fa-caret-right"></i>
								    Day by Day Visit Report 
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url(); ?>Profile_controller/creat_planning">
									<i class="menu-icon fa fa-caret-right"></i>
								    Monthwise Tour Plan
								</a>

								<b class="arrow"></b>
							</li>

							<!--<li class="">
								<a href="#">
									<i class="menu-icon fa fa-caret-right"></i>
									View Target(Current Month) 
								</a>

								<b class="arrow"></b>
							</li>-->
							<!--<li class="">
								<a href="#">
									<i class="menu-icon fa fa-caret-right"></i>
									Customer Followups
								</a>

								<b class="arrow"></b>
							</li>-->
							<!--<li class="">
								<a href="<?php echo base_url(); ?>Profile_controller/achv_trgt">
									<i class="menu-icon fa fa-caret-right"></i>
									Achieve Target
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="#">
									<i class="menu-icon fa fa-caret-right"></i>
									Daily Expenses
								</a>

								<b class="arrow"></b>
							</li>-->

							
						</ul>
					</li>

					
					<!--<li class="">
						<a href="#">
							<i class="fa fa-comments" aria-hidden="true"></i>
							<span class="menu-text"> Customer Feedback </span>
						</a>

						<b class="arrow"></b>
					</li>
				-->

                  <li class="">
						<a href="<?php  echo base_url();?>login/signout">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
							<span class="menu-text"> Exit/Logout </span>
						</a>

						<b class="arrow"></b>
					</li>
					

					
				</ul><!-- /.nav-list -->

				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>