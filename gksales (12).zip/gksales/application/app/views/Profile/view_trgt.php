<?php $this->load->view('headercss.php'); ?>
<?php $this->load->view('topnav.php'); ?>
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />


<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">


		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Profile</a>
							</li>
							<li class="active">View Target List</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="page-header">
							<h1>
								<!--<button type="button" data-toggle="modal" data-target="#myModal">Enquiry</button>-->
								
							</h1>
						</div><!-- /.page-header -->
						<div class="row">
										
						<table id="example" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th>Salesman Id</th>
													<th>Terget By Company</th>
													<th>Terget By Salesman</th>
													<th>Achieve Terget</th>
													<th>Terget Date</th>
													<th>Achieve Date</th>
													<th>Action</th>
												</tr>
											</thead>
											
											<tbody>
											<?php  if(isset($prfl) && !empty($prfl)){?>
											<?php foreach($prfl as $row){ ?>
											<tr>
												<td><?php echo $row->salesmanid; ?> </td>
												<td><?php echo $row->set_trgt; ?> </td>
												<td><?php echo $row->set_trgt_bySlsman; ?> </td>
												<td><?php echo $row->achv_terget; ?> </td>
												<td><?php echo $row->trgt_date; ?> </td>
												<td><?php echo $row->achive_date; ?> </td>
											    <td>
												<!--<a href="<?php //echo base_url();?>admin/manage_event/editevent/<?php// echo $row->id;  ?>" class="tooltip-success">
												
														<button type="button" class="btn btn-sm btn-success"><i class="ace-icon fa fa-check"></i> Edit</button></a>-->
														
														<a href="<?php echo base_url(); ?>Profile_controller/delete_trgt/<?php echo $row->id; ?> " class="tooltip-success">
														<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-sm btn-denger"><i class="ace-icon fa fa-times bigger-125"></i>Delete</button></a>
														
												</td>
											</tr>
											<?php }} ?>
											</tbody>
						</table>
										

										
									</div><!-- /.row -->
									</div>

        <?php $this->load->view('footerjs.php'); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquerymodal/js/jquery.modal.js"></script>
<script>
  $(function(){
    $("#example").dataTable();
  })
  </script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

		<!-- inline scripts related to this page -->
		
	</body>
</html>
