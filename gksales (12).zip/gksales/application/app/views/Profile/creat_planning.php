<?php $this->load->view('headercss.php'); ?>
<?php $this->load->view('topnav.php'); ?>

	<!--/////////////////////////////////////////////////////////////////////////////////MANISH/////////////////////////////////////////////////////////////////////////////////////////////-->
	<?php
	$strt=$this->input->post("strtd_date");
	$end=$this->input->post("end_date");
	$exp=explode('/',$strt);
	
	?>
	<!--/////////////////////////////////////////////////////////////////////////////////MANISH////////////////////////////////////////////////////////////////-->
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />


<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">


		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Profile</a>
							</li>
							<li class="active">Creat Planning</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="page-header">
							<h2>
								<!--<button type="button" data-toggle="modal" data-target="#myModal">Enquiry</button>-->
								<center><u>Tour Planning</u></center>
								
							</h2>
						</div><!-- /.page-header -->
						<?php
						$strt=$this->input->post("strtd_date");
		                $end=$this->input->post("end_date");
						//echo $strt; 
						//exit;
		?>
						<div class="row">
										<div class="col-md-2">
											<div class="form-group">
												Start  Date :<input type="text"  id="strtd_date" name="strtd_date" >
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												End Date :<input type="text"  id="end_date" name="end_date"  >
											</div>
										</div>
										<br>
										<div class="col-md-4">
											<div class="form-group">
												<button  type="button" onclick="creatTable()" class="btn btn-sm btn-primary"> GO</button>
											</div>
										</div>
										
						</div>
						<div id="table1">

						
						</div>
						
					</div>

        <?php $this->load->view('footerjs.php'); ?>
		<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
		
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquerymodal/js/jquery.modal.js"></script>	
		
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script>
 // $(document).ready(function(){
  //  $("#strtd_date").datepicker();
 // });
  </script>
  
  <script>
 // $(document).ready(function(){
 //   $("#end_date").datepicker();
 // });
  </script>
  
<script type="text/javascript">
$(document).ready(function() {
$("table1").hide();
});
</script>

<script>
function creatTable(){
	 var no_days=$("#no_days").val();
	 var strtd_date=$("#strtd_date").val();
	 var end_date=$("#end_date").val();
	 //alert(strtd_date);
	 if(strtd_date=="" || end_date=="" ){
		 
		 alert('Please Enter Start Date And End date');
		 
	 }else{
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Profile_controller/get_table1",
  			data :{'no_days':no_days,'strtd_date':strtd_date,'end_date':end_date},
  			success : function(data){
  				 				 
  				//alert(data);
				//console.log(data);
  				$("#table1").html(data);
  			  
              }  
           });
	 }		   
   }
   function saveindividualdata(id)
   {
	   var idsplit=id.split("_");
	   var dte=$("#dte_"+idsplit[1]).val();
	   var fromloc=$("#fromloc_"+idsplit[1]).val();
	   var toloc=$("#toloc_"+idsplit[1]).val();
	   var customer=$("#customer_"+idsplit[1]).val();
	   var contact=$("#contact_"+idsplit[1]).val();
	   var rmrk=$("#rmrk_"+idsplit[1]).val();
	   var expnce=$("#expnce_"+idsplit[1]).val();
	   //alert(fromloc);
	   $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Profile_controller/savesingledate",
  			data :{'dte':dte,'fromloc':fromloc,'toloc':toloc,'customer':customer,'contact':contact,'rmrk':rmrk,'expnce':expnce},
  			success : function(data){
  				 				 
  				alert('Data Inserted Successful');
				
              }  
           });
	 	
   }
</script>
  
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js" type="text/javascript"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js" type="text/javascript"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="Stylesheet"type="text/css"/>
<script type="text/javascript">
$(function () {
    $("#strtd_date").datepicker({
        numberOfMonths: 1,
		dateFormat:'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $("#end_date").datepicker("option", "minDate", dt);
        }
    });
    $("#end_date").datepicker({
        numberOfMonths: 1,
		dateFormat:'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() - 1);
            $("#strtd_date").datepicker("option", "maxDate", dt);
        }
    });
});
</script>

<script>
/*function creatTable(){
	document.getElementById('example').style.display="block";
}*/
</script>

<script>

</script>
	</body>
</html>
