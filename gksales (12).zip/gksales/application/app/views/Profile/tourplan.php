<?php $this->load->view('headercss.php'); ?>
<?php $this->load->view('topnav.php'); ?>

	<!--/////////////////////////////////////////////////////////////////////////////////MANISH/////////////////////////////////////////////////////////////////////////////////////////////-->
	<?php
	$strt=$this->input->post("strtd_date");
	$end=$this->input->post("end_date");
	$exp=explode('/',$strt);
	
	?>
	<!--/////////////////////////////////////////////////////////////////////////////////MANISH////////////////////////////////////////////////////////////////-->
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />


<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">


		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Profile</a>
							</li>
							<li class="active">Creat Planning</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="page-header">
							<h2>
								<!--<button type="button" data-toggle="modal" data-target="#myModal">Enquiry</button>-->
								<center><u>Day by Day Report Entry </u></center>
								
							</h2>
						</div><!-- /.page-header -->
						<?php
						//$strt=$this->input->post("strtd_date");
		                //$end=$this->input->post("end_date");
						//echo $strt; 
						//exit;
		?>
						<div class="row">
										<div class="col-md-2">
											<div class="form-group">
												Start  Date :<input type="text"  id="strtd_date" name="strtd_date" value="<?php echo date('Y-m-d'); ?>" >
											</div>
										</div>
										
										<br>
										<div class="col-md-4">
											<div class="form-group">
												<button  type="submit" onclick="creatTable2()" class="btn btn-sm btn-primary">GO</button>
											</div>
										</div>
										
						</div>
						<div id="table1">
							<?php 
							
							$k=1;
								echo '<table id="example3" class="table  table-bordered table-hover">
				<thead>
					<tr>
						<th style="width: 40px;">Date</th>
						<th style="width: 40px;">From</th>
						<th style="width: 40px;">To</th>
						<th style="width: 40px;">Name of Customer</th>
						<th style="width: 40px;">Contact Info</th>
						<th style="width: 40px;">Remarks</th>
						<th style="width: 40px;">Expences</th>
						<th style="width: 40px;">Action</th>
					</tr>
				</thead>
											
				<tbody>';
				echo '<tr>
							<td>'.$d=date('Y-m-d').'<input type="hidden" id="dte_'.$k.'" name="dte_'.$k.'" value="'.date('Y-m-d').'" /></td>
												
							<td ><input type="text"  id="fromloc_'.$k.'" name="formloc_'.$k.'"> </td>
							<td ><input type="text"  id="toloc_'.$k.'" name="toloc_'.$k.'"  > </td>
							<td ><input type="text"  id="customer_'.$k.'" name="customer_'.$k.'"  > </td>
							<td ><input type="number"  id="contact_'.$k.'" name="contact_'.$k.'"> </td>
							<td ><textarea name="rmrk_'.$k.'" id="rmrk_'.$k.'"></textarea></td>
							<td ><input type="number"  id="expnce_'.$k.'" name="expnce_'.$k.'" style="width:60px;"> </td>
							 <td >
												
							<button type="button" id="savesing_'.$k.'" class="btn btn-link" onclick="saveindividualdata(this.id);"><i class="fa fa-save"></i></button>
							<button type="button" id="addtr_'.$k.'" class="btn btn-link" onclick="addtable(this.id);"><i class="fa fa-plus" aria-hidden="true"></i></button>							
														
							</td>
					</tr>';
					echo '</tbody>
						</table>';
							
							
							 ?>
						
						</div>
						<div id="example5">
							<?php  
								if(isset($getdatadetails) && !empty($getdatadetails)){ ?>
									<center><u><h2>Previous Visit Report</h2></u></center>
									<?php // print_r($getdatadetails); ?>
									<table id="example2" class="table  table-bordered table-hover">
									<thead>
										<tr>
											<th style="width: 40px;">Date</th>
											<th style="width: 40px;">From</th>
											<th style="width: 40px;">To</th>
											<th style="width: 40px;">Name of Customer</th>
											<th style="width: 40px;">Contact Info</th>
											<th style="width: 40px;">Remarks</th>
											<th style="width: 40px;">Expences</th>
											<th style="width: 40px;">Action</th>
										</tr>
									</thead>
																
									<tbody>	
									
									<?php    foreach($getdatadetails as $rowdata){
											
										 ?>
											  
									
										 <tr>
										 	<td><?php echo $rowdata->dte; ?></td>
										 	<td><?php echo $rowdata->formloc; ?></td>
										 	<td><?php echo $rowdata->toloca; ?></td>
										 	<td><?php echo $rowdata->custname; ?></td>
										 	<td><?php echo $rowdata->contactinfo; ?></td>
										 	<td><?php echo $rowdata->remarks; ?></td>
										 	<td><?php echo $rowdata->dailyexpen; ?></td>
										 	<td></td>
										 	
										 </tr>
									
										
										
									<?php } ?>
									
									</tbody>
									</table>
										
									
									
							<?php 	}
							 
							
							?>
							
							
						</div>
						
					</div>

        <?php $this->load->view('footerjs.php'); ?>
		<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
		
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquerymodal/js/jquery.modal.js"></script>	
		
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script>
 // $(document).ready(function(){
  //  $("#strtd_date").datepicker();
 // });
  </script>
  
  <script>
 // $(document).ready(function(){
 //   $("#end_date").datepicker();
 // });
  </script>
  
<script type="text/javascript">
$(document).ready(function() {
$("table1").hide();
});
</script>

<script>
function creatTable2(){
	//$("#example2").remove();
	 var no_days=$("#no_days").val();
	 var strtd_date=$("#strtd_date").val();
	// var end_date=$("#end_date").val();
	 //alert(strtd_date);
	 if(strtd_date==""){
		 
		 alert('Please Enter  Date');
		 
	 }else{
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Profile_controller/get_table12",
  			data :{'no_days':no_days,'strtd_date':strtd_date},
  			success : function(data){
  				 				 
  				//alert(data);
				//console.log(data);
  				$("#table1").html(data);
  			  
              }  
           });
	 }		   
   }
   function saveindividualdata(id)
   {
	   var idsplit=id.split("_");
	   var dte=$("#dte_"+idsplit[1]).val();
	   var fromloc=$("#fromloc_"+idsplit[1]).val();
	   var toloc=$("#toloc_"+idsplit[1]).val();
	   var customer=$("#customer_"+idsplit[1]).val();
	   var contact=$("#contact_"+idsplit[1]).val();
	   var rmrk=$("#rmrk_"+idsplit[1]).val();
	   var expnce=$("#expnce_"+idsplit[1]).val();
	   //alert(fromloc);
	   
	   $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Profile_controller/savedaybydayreport",
  			data :{'dte':dte,'fromloc':fromloc,'toloc':toloc,'customer':customer,'contact':contact,'rmrk':rmrk,'expnce':expnce},
  			success : function(data){
  				var json=JSON.parse(data);	
  				var st=json.status;			 
  				alert(st);
				
              }  
           });
           
      
	 	
   }
   function addtable(id)
   {
   	    var idsplit=id.split("_");
   	    //gf gbv alert(idsplit);
   	    //alert(idsplit);
   	    var dt=$("#dte_"+idsplit[1]).val();
   	    //alert(dt);
   	    var rowCount = $('#example3 tr').length;
   	   // alert(rowCount);
	    var tr=rowCount-1;
	    var tr2=tr+1;
	
   	    $('#example3 tr:last').after('<tr><td>'+dt+'<input type="hidden" id="dte_'+tr2+'"  value="'+dt+'" /></td><td><input type="text"  id="formloc_'+tr2+'" name=""></td><td ><input type="text"  id="toloc_'+tr2+'" name=""  > </td><td ><input type="text"  id="customer_'+tr2+'" name=""  > </td><td ><input type="number"  id="contact_'+tr2+'" name=""> </td>	<td ><textarea name="" id="rmrk_'+tr2+'"></textarea></td><td ><input type="number"  id="expnce_+tr2+" name="" style="width:60px;"> </td><td ><button type="button" id="" class="btn btn-link" onclick="saveindividualdata(this.id);"><i class="fa fa-save"></i></button><button type="button" id="" class="btn btn-link" onclick="deletesingle(this.id);"><i class="fa fa-trash-o"></i></button>&nbsp;<button type="button" id="addtr_'+tr2+'" class="btn btn-link" onclick="addtable(this.id);"><i class="fa fa-plus" aria-hidden="true"></i></button></td></tr>');
   }
</script>
  
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js" type="text/javascript"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js" type="text/javascript"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="Stylesheet"type="text/css"/>
<script type="text/javascript">
$(function () {
    $("#strtd_date").datepicker({
        numberOfMonths: 1,
		dateFormat:'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $("#end_date").datepicker("option", "minDate", dt);
        }
    });
    $("#end_date").datepicker({
        numberOfMonths: 1,
		dateFormat:'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() - 1);
            $("#strtd_date").datepicker("option", "maxDate", dt);
        }
    });
});
</script>

<script>
/*function creatTable(){
	document.getElementById('example').style.display="block";
}*/
</script>

<script>

</script>
	</body>
</html>
