<?php
require 'PHPMailerAutoload.php';

function send_mail1($sub,$to,$msg,$name,$card)
{
    $cardex=explode(",",$card);
    $mail = new PHPMailer;


    $mail->isSMTP();                                            // Set mailer to use SMTP
    //$mail->Host = "ssl://smtp.gmail.com";
    $mail->Host = 'smtp.gmail.com';                            // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                                   // Enable SMTP authentication
    $mail->SMTPDebug = 1;
    //$mail->Username = 'cantata@contratorapido.com.br';    // SMTP username
    //$mail->Password = 'cr2014';                          // SMTP password

    $mail->Username = 'purchase.gkrickshaw@gmail.com'; 
	             // SMTP username
    $mail->Password = 'pkp@9800743629'; 
    //$mail->Username = 'bibadi.pal@gmail.com'; 
	//$mail->Password = 'bibadi9119';                              // SMTP password (new and active pass)
    //$mail->Password = 'Raj123123';                                // SMTP password (old and inactive pass)
    $mail->SMTPSecure = 'tls';                                       // Enable encryption, 'ssl' also accepted
    
    $mail->From = "info@letwex.com";
    ///$mail->FromName = 'Billing Details';
    $mail->FromName = $name;
    //$mail->addAddress('subir.saha@esolzmail.com', 'Joe User');             // Add a recipient
    $mail->addAddress($to);                                                 // Name is optional(mail to)
    //$mail->addReplyTo('contato@contratorapido.com.br', 'Information');
    //$mail->addReplyTo('bibadi.pal@gmail.com');
    //$mail->addCC('patrapankaj36@gmail.com');
    //$mail->addBCC('info@bongentrepreneurs.com');
    
    $mail->WordWrap = 50;
	if(in_array("1",$cardex)){
	    $mail->addAttachment('emailtemplate/greetings/greetingscard.jpg','E-CARD.jpg');
	}
	if(in_array("3",$cardex))                                                      // Set word wrap to 50 characters
	{
		$mail->addAttachment('emailtemplate/dealership/avalon_ebrochure.pdf','Model.pdf');                           // Add attachments
	}
	if(in_array("4",$cardex))
	{
		$mail->addAttachment('emailtemplate/dealership/application_dealership_form.pdf','Dealership Form.pdf');
	}
	if(in_array("5",$cardex))
	{
		$mail->addAttachment('emailtemplate/dealership/Rules & Regulations for the Agents.pdf','Rules & Regulation.pdf');                           // Add attachments
	}
	if(in_array("6",$cardex))
	{
		$mail->addAttachment('emailtemplate/dealership/catagoryPICLISTPAQ.pdf','sparepart & price List');                           // Add attachments
	}
    
	 
    
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');                     // Optional name
    $mail->isHTML(true);                                                    // Set email format to HTML
    
    $mail->Subject = $sub;
    $mail->Body    = $msg;
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
    if(!$mail->send()) {
    //    echo 'Message could not be sent.';
    //    echo 'Mailer Error: ' . $mail->ErrorInfo;
    return '0';
    } else {
        //echo 'Message has been sent';
        //return true;
        return '1';
    }
}
?>