<?php
require 'PHPMailerAutoload1.php';

function send_mail2($sub,$to,$msg,$name)
{
    
    $mail = new PHPMailer;


    $mail->isSMTP();                                            // Set mailer to use SMTP
    //$mail->Host = "ssl://smtp.gmail.com";
    $mail->Host = 'smtp.gmail.com';                            // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                                   // Enable SMTP authentication
    $mail->SMTPDebug = 1;
    //$mail->Username = 'cantata@contratorapido.com.br';    // SMTP username
    //$mail->Password = 'cr2014';                          // SMTP password

    $mail->Username = 'purchase.gkrickshaw@gmail.com'; 
	$mail->Password = 'pkp@9800743629';     
    //$mail->Username = 'patrapankaj36@gmail.com'; 
	 // $mail->Password = 'pkp@9933663838';                              // SMTP password (new and active pass)
    //$mail->Password = 'Raj123123';                                // SMTP password (old and inactive pass)
    $mail->SMTPSecure = 'tls';                                       // Enable encryption, 'ssl' also accepted
    
    $mail->From = "info.gkrikshow.com";
    ///$mail->FromName = 'Billing Details';
    $mail->FromName = $name;
    //$mail->addAddress('subir.saha@esolzmail.com', 'Joe User');             // Add a recipient
    $mail->addAddress($to);                                                 // Name is optional(mail to)
    //$mail->addReplyTo('contato@contratorapido.com.br', 'Information');
    //$mail->addReplyTo('bibadi.pal@gmail.com');
    //$mail->addCC('patrapankaj36@gmail.com');
    //$mail->addBCC('info@bongentrepreneurs.com');
    
    $mail->WordWrap = 50;                                                      // Set word wrap to 50 characters
    $mail->addAttachment('C:\xampp\htdocs\erp_Managerbkup\Fpdfoutput\finalpi2.pdf');                           // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');                     // Optional name
    $mail->isHTML(true);                                                    // Set email format to HTML
    
    $mail->Subject = $sub;
    $mail->Body    = $msg;
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
    if(!$mail->send()) {
    //    echo 'Message could not be sent.';
       echo 'Mailer Error: ' . $mail->ErrorInfo;
    return '0';
    } else {
        //echo 'Message has been sent';
        //return true;
        return '1';
    }
}
?>