<?php
  include("connection.php");
  include('smtpmail2/smtpmail/mail.php');
	 $email1=explode(",",$email);
	$cmailcount=count($email1);
	for($i=0;$i<$cmailcount;$i++)
	{
		$email=$email1[$i];
		$uid=$this->session->userdata('uid');
		$getemail=mysqli_query($con,"select * from salesman where id='".trim($uid)."'");
		$re=mysqli_fetch_array($getemail);
		$name=$re['name'];
		$image=$re['image'];
		$desig=$re['desig'];
		$phno=$re['phno'];
		$email2=$re['email'];
		$imagepath=base_url()."uploads/Salesman/".$image;
		
	
	$card=$card;
	
	$msg='<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta content="width=mobile-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no" name="viewport"><meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;"><meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE"><meta content="#EEEEEE" name="sr bgcolor">					
				
					
					<style type="text/css">
          html, body{width:100%; margin:0; font-family: Lato, Aria , Calibri, sans-serif;}
          .ExternalClass{width:100%;}
          .ReadMsgBody{width:100%;}
          .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .    ExternalClass div {line-height: 100%;}
           table, td{ border-collapse: collapse; margin: 0; mso-table-lspace: 0; mso-table-rspace: 0; padding: 0;}
          a{color:#0CB4CE;text-decoration:none;}
          a:hover{text-decoration:underline; opacity:0.7; transition:all .25s ease-in-out}
           
          @media only screen and (max-width: 800px){
               table[class=container800]{width:100% !important;}
               table[class=container800_img]{width:50% !important;}
               table[class=half-container800]{width:50% !important;}
               table[class=preheader]{width:90% !important;}
               td[class=hide800]{ display:none!important}
           }
     
          @media only screen and (max-width: 640px){
               table[class=full], table[class=container800]{width:100%!important;}
               table[class=container800], table[class=container600], table[class=container590], table[class=  container500]{width:370px !important;}
               table[class=container186], table[class=container290], table[class=container200]{width:320px !important   ;}
               table[class=container800_img], table[class=half-container800]{width:100% !important;}
               table[class=half-container600], table[class=container120], td[class=container120]{width:49% !important   ;}
               table[class=about180]{width:250px !important;}
               table[class=container340]{width:370px !important;}
                 td[class=center]{text-align:center!important;vertical-align:middle!important}
               img[class=img_scale], td[class=img_scale]{width:100%!important;height:auto!important}
               td[class=hide], br[class=hide]{ display:none!important}
               td[class=show]{display:block!important}
               td[class=padding_10]{padding: 0 10px!important}
               td[class=padding_20],td[class=padding_20_show]{padding: 0 20px!important; height: auto !important}
               img[class=divider]{width:100%!important;height:1px!important}
               td[class=mobile-width]{padding:0 25% !important}
               td[class=main-section-header], div[class=main-section-header]{font-size:30px!important; line-height:     38px!important}
               td[class=mobile_para]{font-size:14px!important; line-height: 26px!important}
           } 
     
          @media only screen and (max-width:480px){
               table[class=container800], table[class=full], table[class=container600], table[class=container590],      table[class=container500]{width:100% !important; height: auto !important}
               table[class=container186], table[class=container290], table[class=container200]{width:200px !important   ;}
               table[class=container800_img], table[class=half-container800], table[class=container120], td[class= container120]{width:100% !important;}
               table[class=half-container600], table[class=container120], td[class=container120]{width:49% !important   ;}
               table[class=container340]{width:260px !important;}
               table[class=about180]{width:140px !important;}
               td[class=center], td[class=align-center]{text-align:center!important;vertical-align:middle!important}
               img[class=img_scale], td[class=img_scale]{width:100%!important;height:auto!important}
               td[class=hide], br[class=hide]{ display:none!important}
               td[class=show]{display:block!important}
               td[class=padding_20], td[class=padding_20_show]{padding:0 20px!important}
               img[class=divider]{width:100%!important;height:1px!important}
               td[class=main-section-header], div[class=main-section-header]{font-size:26px!important;}
               td[class=mobile_para],div[class=mobile_para]{font-size:14px!important;}
               }
     </style>
</head>
<body>	 
				
					
					<table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#EEEEEE" data-module="module1" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module1.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
               
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#EEEEEE" data-module="module2" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module2.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr>
              <td align="center">
                <table border="0" align="center" width="100%" style="width: 100%; max-width: 800px; background-color: rgb(42, 120, 149); background-size: cover; background-position: 50% 0%; background-repeat: no-repeat;" cellpadding="0" cellspacing="0" bgcolor="#0CB4CE" background="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/bg1.JPG" data-bg="Background1" data-bgcolor="Background1">
                    <tbody>

                      <!-- Header Nav -->
                      <tr>
                        <td align="center" data-bgcolor="Nav Background" style="width: 100%; max-width: 800px; background-size: cover; background-position: 50% 0%;" cellpadding="0" cellspacing="0" background="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/headerbg.png">
                          <table border="0" align="center" width="600" style="" cellpadding="0" cellspacing="0" class="container600">
                            <tbody>
                              
                              <tr><td height="30" style="font-size: 30px; line-height: 30px;">&nbsp;</td></tr>
                              <tr>
                                  <td align="center">
                                      <table border="0" align="left" width="380" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                          <tbody><tr>
                                              <td align="center">
                                                  <table border="0" cellpadding="0" cellspacing="0" align="left" class="container600">
                                                      <tbody><tr>
                                                          <!-- ======= logo ======= -->
                                                          <td align="center">
                                                              <a href="#" target="_blank" style="display: block; border-style: none !important; border: 0 !important;" class="editable_img"><img editable="true" mc:edit="logo" width="100" border="0" style="display: block; width: 100px;" src="http://letxweb.com/assets/logo.png" alt="logo"></a>
                                                          </td>           
                                                      </tr>
                                                  </tbody></table> 
                                                  
                                                  <table border="0" align="right" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                                    <tbody><tr>
                                                        <td align="center">
                                                            <table align="center" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                                <tbody>
                                                                <tr><td height="10" class="hide" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                                                <tr> 
                                                                    <td align="center" class="hide" mc:edit="navigation" style="color: #F9F9F9; font-size: 12px; font-family:  Lato ,  Calibri , sans-serif; line-height: 20px; font-weight:500; text-transform: uppercase;" data-size="Nav menu" data-min="12" data-max="24">
                                                                      <!-- data-link-color, data-link-size & data-link-style -->
                                                                        <div class="editable_text" style="line-height: 20px;">
                                                                            <span class="text_container">
                                                                            <multiline>
                                                                                <a href="#" target="_blank" style="color:#F9F9F9; text-decoration: none;" data-color="Nav menu"></a>
                                                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                                                <a href="#" target="_blank" style="color:#F9F9F9; text-decoration: none;" data-color="Nav menu"></a>
                                                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                                               <!-- <a href="#" target="_blank" style="color:#F9F9F9; text-decoration: none;" data-color="Nav menu">SHOP</a>-->
                                                                            </multiline>
                                                                            </span>
                                                                        </div>  
                                                                    </td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr>
                                                  </tbody><tbody></tbody></table>       
                                              </td>
                                          </tr>
                                      </tbody></table>
                                      
                                      <table border="0" align="left" width="5" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                          <tbody><tr><td height="20" width="5" style="font-size: 20px; line-height: 20px;">&nbsp;</td></tr>
                                      </tbody></table>
                                      
                                      <table border="0" align="right" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                        <tbody><tr>
                                            <td align="center">
                                                <table class="center" border="0" cellpadding="0" cellspacing="0">
                                                <tbody><tr><td height="6" class="hide" style="font-size: 6px;line-height: 6px;">&nbsp;</td></tr>
                                                <tr>
                                                  <td>
                                                    <a style="display: block; border-style: none !important; border: 0 !important;" href="#" target="_blank" class="editable_img"><img editable="true" mc:edit="fb" width="15" border="0" style="display: block;" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/h-fb.png" alt="fb"></a>   
                                                  </td>
                                                  <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                  <td>
                                                    <a style="display: block; border-style: none !important; border: 0 !important;" href="#" target="_blank" class="editable_img"><img editable="true" mc:edit="tw" width="15" border="0" style="display: block;" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/h-tw.png" alt="tw"></a>    
                                                  </td>
                                                  <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                  <td>
                                                    <a style="display: block; border-style: none !important; border: 0 !important;" href="#" target="_blank" class="editable_img"><img editable="true" mc:edit="p" width="15" border="0" style="display: block;" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/h-p.png" alt="p"></a>   
                                                  </td>
                                                  <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                  <td>
                                                    <a style="display: block; border-style: none !important; border: 0 !important;" href="#" target="_blank" class="editable_img"><img editable="true" mc:edit="g+" width="15" border="0" style="display: block;" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/h-g+.png" alt="g+"></a>   
                                                  </td>
                                                </tr>   
                                              </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                  </td>
                              </tr>
                              <tr><td height="30" style="font-size: 30px; line-height: 30px;">&nbsp;</td></tr>                              
                            </tbody>
                          </table>
                        </td>
                      </tr>
                      <!-- end section -->

                      <!-- Main Hero -->
                      <tr>
                        <td align="center" class="padding_20_show">
                          <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container500" data-bgcolor="Hero Center">
                              <tbody>
                                  <tr>
                                      <td height="20" class="hide" style="font-size: 20px; line-height: 20px;">&nbsp;
									  
									 <center> <a href="#" target="_blank" style="display: block; border-style: none !important; border: 0 !important;" class="editable_img"><img editable="true" mc:edit="logo" width="100" border="0" style="display: block; width: 100px;" src="http://letxweb.com/assets/logo.png" alt="logo"></a></center>
									  </td>
                                  </tr>
                                  
                                  <tr><td height="90" style="font-size: 90px;line-height: 90px;">&nbsp;</td></tr>
                                   
                                   <tr>
                                      <td height="15" class="hide" style="font-size: 15px;line-height: 15px;">&nbsp;</td>
                                  </tr>

                                  <tr>
                                      <td align="center" mc:edit="big-title1" style="letter-spacing: 2px;font-size: 30px;color: #FFFFFF;font-weight: 700;line-height: 48px;font-family:  Lato ,  Open Sans , sans-serif;text-transform: uppercase;" class="main-section-header" data-size="Header title" data-max="72" data-color="Header title">
                                          <!-- ======= section text ====== -->
                                          
                                          <div style="line-height: 140%;" class="main-section-header">
                                              <span class="text_container">
											  LetXWeb<br>
                                              <multiline>
											      
                                                 We create awesome designs
                                              </multiline>
                                              </span>
                                          </div>
                                      </td>   
                                    </tr>
                              <tr>
                                  <td height="15" style="font-size: 15px;line-height: 15px;">&nbsp;</td>
                              </tr>
                              
                              <tr>
                                   <td align="center" mc:edit="big-title1" style="/* text-transform: uppercase; */color: #FFFFFF;font-size: 18px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 28px;font-weight: 400;letter-spacing: 0px;" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="28">
                                       <!-- ======= section text ====== -->
                                       
                                       <div style="line-height: 120%;">
                                           <span class="text_container">
                                           <multiline>
                                               We are a creative team with full of ideas
                                           </multiline>
                                           </span>
                                       </div>
                                   </td>   
                              </tr>
                              
                              <tr><td height="20" style="font-size: 20px; line-height: 20px;">&nbsp;</td></tr>

                              <!-- button -->
                              <tr>
                                     <td align="center">
                                                                    
                                     </td>
                                   </tr>
                              <!-- end section -->

                              <tr>
                                  <td height="40" class="hide" style="font-size: 40px; line-height: 40px;">&nbsp;</td>
                              </tr>

                              <tr><td height="120" style="font-size: 120px;line-height: 120px;">&nbsp;</td></tr>
                              </tbody>
                          </table>
                        </td>
                      </tr>
                      <!-- end section -->

                      <!-- line -->
                      <tr>
                        <td align="center">
                          <table border="0" align="center" width="100%" cellpadding="0" cellspacing="0" data-bgcolor="Blue-Button" style="background-color: #0CB4CE;border-radius: 2px;">
                            <tbody>
                                <tr><td height="3" style="font-size: 3px; line-height: 3px;">&nbsp;</td></tr>
                            </tbody>
                          </table>                              
                        </td>
                      </tr>
                      <!-- end section -->

                    </tbody>
                </table>
              </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module3" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module3.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="background-color: #FFFFFF;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table class="container600" width="560" align="center" border="0" cellpadding="0" cellspacing="0"><tbody>
                              <tr><td align="center">
                                <table class="container590" width="360" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                  <tbody>
                                    <tr>
                                      <td>
                                        <table class="container590" width="160" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                          <tbody>
                                            <tr>
                                                 <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                                     <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col1.png" alt="1" width="70" height="70" style="display: block;">
                                                 </td>
                                             </tr> 
                                             <tr>
                                                 <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                 </td>
                                             </tr>
                                             <tr>
                                               <td align="center" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                   <!-- ======= section text ====== -->
                                                   <div class="editable_text" style="line-height: 24px">
                                                       <span class="text_container">
                                                       <multiline>
                                                       Strategi
                                                       </multiline>
                                                       </span>
                                                   </div>
                                               </td>
                                             </tr>
                                             <tr>
                                                 <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                 </td>
                                             </tr>
                                             <tr>
                                               <td align="center" mc:edit="list-title" style="color:#999999; font-size:13px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 20px; font-weight:400;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                                   <!-- ======= section text ====== -->
                                                   <div class="editable_text" style="line-height: 190%;">
                                                     <span class="text_container">
                                                       <multiline>
                                                       
                                                       </multiline>
                                                       </span>
                                                   </div>
                                               </td>
                                             </tr>
                                          </tbody>
                                        </table>

                                        <!-- SPACE -->
                                        <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                            <tbody><tr>
                                                <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                                </td>
                                            </tr>
                                        </tbody></table>
                                        <!-- END SPACE -->

                                        <table class="container590" width="160" align="right" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                          <tbody>
                                            <tr>
                                                 <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                                     <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col2.png" alt="1" width="70" height="70" style="display: block;">
                                                 </td>
                                             </tr> 
                                             <tr>
                                                 <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                 </td>
                                             </tr>
                                             <tr>
                                               <td align="center" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                   <!-- ======= section text ====== -->
                                                   <div class="editable_text" style="line-height: 24px">
                                                       <span class="text_container">
                                                       <multiline>
                                                       Design
                                                       </multiline>
                                                       </span>
                                                   </div>
                                               </td>
                                             </tr>
                                             <tr>
                                                 <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                 </td>
                                             </tr>
                                             <tr>
                                               <td align="center" mc:edit="list-title" style="color:#999999; font-size:13px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 20px; font-weight:400;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                                   <!-- ======= section text ====== -->
                                                   <div class="editable_text" style="line-height: 190%;">
                                                     <span class="text_container">
                                                       <multiline>
                                                       </multiline>
                                                       </span>
                                                   </div>
                                               </td>
                                             </tr>
                                          </tbody>
                                        </table>

                                      </td>
                                    </tr>
                                  </tbody>
                                </table>

                                <!-- SPACE -->
                                <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                    <tbody><tr>
                                        <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                        </td>
                                    </tr>
                                </tbody></table>
                                <!-- END SPACE -->

                                <table class="container590" width="160" align="right" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                  <tbody>
                                    <tr>
                                        <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                            <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col3.png" alt="1" width="70" height="70" style="display: block;">
                                        </td>
                                    </tr> 
                                    <tr>
                                        <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                        </td>
                                    </tr>
                                    <tr>
                                      <td align="center" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                          <!-- ======= section text ====== -->
                                          <div class="editable_text" style="line-height: 24px">
                                             <span class="text_container">
                                              <multiline>
                                              Code
                                              </multiline>
                                             </span>
                                          </div>
                                      </td>
                                    </tr>
                                    <tr>
                                        <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                        </td>
                                    </tr>
                                    <tr>
                                      <td align="center" mc:edit="list-title" style="color:#999999; font-size:13px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 20px; font-weight:400;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                          <!-- ======= section text ====== -->
                                          <div class="editable_text" style="line-height: 190%;">
                                            <span class="text_container">
                                              <multiline>
                                              
                                              </multiline>
                                              </span>
                                          </div>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table></td>
                              </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module4" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module4.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr>
            <td align="center">
            <table border="0" align="center" width="100%" style="background-color: #FFFFFF;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container600"><tbody>
                              <tr>
                                  <td align="center">
                                    <table border="0" align="center" width="60" cellpadding="0" cellspacing="0" data-bgcolor="Blue-Line" style="background-color: #0CB4CE;border-radius: 2px;">
                                      <tbody>
                                          <tr><td height="3" style="font-size: 3px; line-height: 3px;">&nbsp;</td></tr>
                                      </tbody>
                                    </table>                              
                                  </td>
                              </tr>
                              <tr><td height="20" style="font-size: 20px; line-height: 20px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="letter-spacing: 2px;color: #222222;font-size:24px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 30px;font-weight: 700;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>WE ARE CREATIVE TEAM</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="10" style="font-size: 10px; line-height: 10px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #444444;font-size: 14px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 26px;font-weight: 300;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 190%;">
                                           <span class="text_container">
                                           <multiline>
                                               Letxweb is an innovative company with a set of Experianced Designer and coder
                                           We have been working over 12 countries.                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              <tr><td height="20" style="font-size: 20px; line-height:20px;"></td></tr>

                              <tr>
                               <td align="center">
                                 <table bo                              
                                </td>
                              </tr>

                              </tbody>
                         </table>
                         </td>
                       </tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module5" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module5.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="background-color: #FFFFFF;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container600"><tbody>

                              <tr><td>
                                   <table border="0" width="280" align="left" cellpadding="0" cellspacing="0" style="" class="container600"><tbody>
                                       <tr>
                                            <td align="center" bgcolor="#FFFFFF">
                                                <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/2col2.JPG" width="100%" style="border: none; display: block; outline: none; width: 100%;">
                                            </td>
                                       </tr>
                                       <tr><td align="center">
                                            <table border="0" width="" align="center" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                                

                                                <tr><td height="10" style="font-size: 10px;line-height: 20px;">&nbsp;</td></tr>

                                                <tr>
                                          <td align="center" mc:edit="list-title" style="letter-spacing: 2px;font-family: Lato, Aria , Calibri, sans-serif;font-size: 18px;font-weight: 500;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                  <span class="text_container">
                                                  <multiline>Web development<br><span style="color: #0CB4CE; font-size: 14px"></span></multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="10" style="font-size: 10px;line-height: 10px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="center" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 13px; font-weight: 400;color: #999999;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                         </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                            </tbody></table></td>
                                       </tr>
                                   </tbody></table>
                                   
                                   <table border="0" width="5" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                       <tbody><tr><td width="5" height="40" style="font-size: 40px; line-height: 40px;"></td></tr>
                                   </tbody></table>
                                   
                                   <table border="0" width="280" align="right" cellpadding="0" cellspacing="0" style="" class="container600"><tbody>
                                       <tr>
                                            <td align="center" bgcolor="#FFFFFF">
                                                <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/2col1.JPG" width="100%" style="border: none; display: block; outline: none; width: 100%;">
                                            </td>
                                       </tr>
                                       <tr><td align="center">
                                            <table border="0" width="" align="center" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                                

                                                <tr><td height="10" style="font-size: 10px;line-height: 20px;">&nbsp;</td></tr>

                                                <tr>
                                          <td align="center" mc:edit="list-title" style="letter-spacing: 2px;font-family: Lato, Aria , Calibri, sans-serif;font-size: 18px;font-weight: 500;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                  <span class="text_container">
                                                  <multiline>SEO FEATURES<br><span style="color: #0CB4CE; font-size: 14px">FULLY RESPONSIVE</span></multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="10" style="font-size: 10px;line-height: 10px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="center" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 13px; font-weight: 400;color: #999999;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                            </tbody></table></td>
                                       </tr>
                                   </tbody></table>
                                </td>
                              </tr>
                              </tbody>
                         </table>
                         </td>
                       </tr>
                       <tr><td height="50" style="font-size: 50px; line-height:50px;"></td></tr>
                       <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module6" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module6.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center" style="">
            <table border="0" align="center" width="100%" style="width: 100%; max-width: 800px; background-color: rgb(247, 247, 247); background-size: cover; background-position: 50% 0%; background-repeat: no-repeat;" bgcolor="#F7F7F7" background="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/bg2.JPG" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr>
                        <td align="center" class="padding_20_show">
                          <table border="0" align="center" width="600" bgcolor="#FFFFFF" cellpadding="0" cellspacing="0" class="full" data-bgcolor="Hero Center">
                              <tbody>
                                   <tr><td align="center" class="padding_20_show">
                                        <table align="center" width="450" bgcolor="#FFFFFF" cellpadding="0" cellspacing="0" class="container500" data-bgcolor="Hero Center">
                                             <tbody>
                                                  <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
     
                                                  <tr>
                                                     <td align="center" mc:edit="big-title1" style="font-size: 18px;color: #222222; font-weight: 700; font-family:  Lato ,  Open Sans , sans-serif;" class="main-section-header" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="28">
                                                         <!-- ======= section text ====== -->
                                                         
                                                         <div style="line-height: 100%" class="main-section-header">
                                                             <span class="text_container">
                                                             <multiline>
                                                                JOIN TO CREATIVE TEAM <span style="color: #0CB4CE">1300</span> CLIENTS
                                                             </multiline>
                                                             </span>
                                                         </div>
                                                     </td>   
                                                   </tr>
                                                  <tr>
                                                      <td height="10" style="font-size:10px; line-height: 10px;">&nbsp;</td>
                                                  </tr>
                                                  
                                                  <tr>
                                                       <td align="center" mc:edit="big-title1" style="color: #444444; font-size: 14px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 28px;font-weight:400;" data-size="Header title" data-max="72" data-color="Header title">
                                                           <!-- ======= section text ====== -->
                                                           
                                                           <div style="line-height: 190%;">
                                                               <span class="text_container">
                                                               <multiline>
                                                                   We have clients round 12 countries and over 1300 satisfied clients
                                                               </multiline>
                                                               </span>
                                                           </div>
                                                       </td>   
                                                  </tr>
                    
                                                  
                                                  <tr><td height="20" style="font-size: 20px; line-height: 20px;">&nbsp;</td></tr>
                    
                                                  <!-- button -->
                                                  <tr>
                                                    <td align="center">
                                                      <table border="0" align="center" width="" cellpadding="0" cellspacing="0" data="" -bgcolor="Blue-Button" style="background-color: #0CB4CE;border-radius: 2px;">
                                                        <tbody>
                                                            
                                                            <tr>
                                                                <td align="center" style="padding-bottom: 15px;padding-top: 15px; color: #FFFFFF;font-size: 12px;font-family:  Lato ,  Calibri ,   sans-serif; font-weight: 500;padding-left: 20px;padding-right: 20px;letter-spacing: 1px;" mc:edit="     main-button" data-size="Button Text" data-min="12" data-max="28">
                                                                    <div class="editable_text" style="line-height: 100%;">
                                                                        <span class="text_container">
                                                                        <multiline>
                                                                            <a href="http://letxweb.com/webenq.php" target="_blank" style="color: #FFFFFF; text-   decoration: none;" data-color="Button Text">Your Requirement</a>
                                                                        </multiline>
                                                                        </span>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            
                                                        </tbody>
                                                      </table>                              
                                                    </td>
                                                  </tr>
                                                  <!-- end section -->
                    
                                                  <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                                             </tbody>
                                        </table>
                                   </td></tr>                                 
                              </tbody>
                          </table>
                        </td>
                    </tr>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module7" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module7.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
              <table border="0" align="center" width="100%" bgcolor="#FFFFFF" style="width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                  <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr>
                      <td align="center" class="padding_20_show">
                          <table class="container600" width="600" align="center" border="0" cellpadding="0" cellspacing="0">
                              <tbody><tr>
                              </tr><tr>
                                <td>
                                    <table class="container590" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                        <tbody><tr>
                                            <td align="center">
                                                <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/left-img.JPG" alt="img" width="280" height="280" class="img_scale" style="width: 280px;height: 210px;">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- SPACE -->

                                    <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                        <tbody><tr>
                                            <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- END SPACE -->

                                    <table class="container590" width="280" align="right" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"> 
                                        <tbody><tr>
                                          <td align="left" mc:edit="list-title" style="letter-spacing: 2px;font-family: Lato, Aria , Calibri, sans-serif;font-size: 18px;font-weight: 500;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                  <span class="text_container">
                                                  <multiline>Website Design and Development<br><span style="color: #0CB4CE; font-size: 14px"></span></multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                        
                                        <tr>
                                            <td height="10" style="font-size: 10px;line-height: 10px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family:  Lato ,  Calibri , sans-serif;font-size: 13px; font-weight: 400; color: #8f96a1; line-height: 26px;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                        <tr>
                                            <td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td>
                                          </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                              </tr>
                          </tbody></table>
                      </td>
                    </tr>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                  </tbody>
              </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module8" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module8.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
              <table border="0" align="center" width="100%" bgcolor="#FFFFFF" style="width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                  <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr>
                      <td align="center" class="padding_20_show">
                          <table class="container600" width="600" align="center" border="0" cellpadding="0" cellspacing="0">
                              <tbody><tr>
                              </tr><tr>
                                <td>
                                    <table class="container590" align="right" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                        <tbody><tr>
                                            <td align="center">
                                                <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/right-img.JPG" alt="img" width="280" height="280" class="img_scale" style="width: 280px;    height: 210px;">
                                            </td>
                                        </tr>
                                    </tbody></table>

                                    <!-- SPACE -->
                                    <table class="full" width="1" align="right" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                        <tbody><tr>
                                            <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- END SPACE -->

                                    <table class="container590" width="280" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"> 
                                        <tbody><tr>
                                          <td align="left" mc:edit="list-title" style="letter-spacing: 2px;font-family: Lato, Aria , Calibri, sans-serif;font-size: 18px;font-weight: 500;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                  <span class="text_container">
                                                  <multiline>SEO<br><span style="color: #0CB4CE; font-size: 14px"></span></multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                        
                                        <tr>
                                            <td height="10" style="font-size: 10px;line-height: 10px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family:  Lato ,  Calibri , sans-serif;font-size: 13px; font-weight: 400; color: #8f96a1; line-height: 26px;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                        <tr>
                                            <td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td>
                                                                         
                                          </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                              </tr>
                          </tbody></table>
                      </td>
                    </tr>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                  </tbody>
              </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module9" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module9.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="background-color: #F7F7F7;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container600"><tbody>
                              <tr><td>
                                   <table border="0" width="290" align="left" cellpadding="0" cellspacing="0" style="/* background-color: #F7F7F7; */" class="container600"><tbody>
                                        <tr><td align="center">
                                            <table border="0" width="20%" align="left" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                                  <tr>
                                                 <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                                     <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col1.png" alt="1" width="70" height="70" style="display: block;">
                                                 </td>
                                             </tr>
                                                <!-- end -->
                                            </tbody></table>

                                            <table border="0" width="80%" align="right" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;width: 70%;"><tbody>
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 150%;">
                                                            <span class="text_container">
                                                            <multiline>Full of ideas</multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
     
                                                  <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>
     
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="font-family:  Lato     ,  Arial ,  Calibri , sans-serif;font-size: 13px; font-    weight: 400;color: #999999;" data-color="Text" data-size=" Text" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 190%;">
                                                          <span class="text_container">
                                                            <multiline>
                                                            </multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
                                                <!-- end -->
                                            </tbody></table></td>
                                       </tr>
                                       
                                   </tbody></table>
                                   
                                   <table border="0" width="5" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                       <tbody><tr><td width="5" height="50" style="font-size: 50px;line-height: 50px;"></td></tr>
                                   </tbody></table>
                                   
                                   <table border="0" width="290" align="right" cellpadding="0" cellspacing="0" style="/* background-color: #F7F7F7; */" class="container600"><tbody>
                                        <tr><td align="center">
                                            <table border="0" width="20%" align="left" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                                  <tr>
                                                 <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                                     <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col2.png" alt="1" width="70" height="70" style="display: block;">
                                                 </td>
                                             </tr>
                                                <!-- end -->
                                            </tbody></table>

                                            <table border="0" width="80%" align="right" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;width: 70%;"><tbody>
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 150%;">
                                                            <span class="text_container">
                                                            <multiline>Responsive Design</multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
     
                                                  <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>
     
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="font-family:  Lato     ,  Arial ,  Calibri , sans-serif;font-size: 13px; font-    weight: 400;color: #999999;" data-color="Text" data-size=" Text" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 190%;">
                                                          <span class="text_container">
                                                            <multiline>
                                                            </multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
                                                <!-- end -->
                                            </tbody></table></td>
                                       </tr>
                                       
                                   </tbody></table> 
                                </td>
                              </tr>

                              <tr><td height="50" style="font-size: 50px;line-height: 50px;"></td></tr>
                              <tr><td>
                                   <table border="0" width="290" align="left" cellpadding="0" cellspacing="0" style="/* background-color: #F7F7F7; */" class="container600"><tbody>
                                        <tr><td align="center">
                                            <table border="0" width="20%" align="left" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                                  <tr>
                                                 <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                                     <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col3.png" alt="1" width="70" height="70" style="display: block;">
                                                 </td>
                                             </tr>
                                                <!-- end -->
                                            </tbody></table>

                                            <table border="0" width="80%" align="right" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;width: 70%;"><tbody>
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 150%;">
                                                            <span class="text_container">
                                                            <multiline>GREAT DESIGN</multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
     
                                                  <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>
     
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="font-family:  Lato     ,  Arial ,  Calibri , sans-serif;font-size: 13px; font-    weight: 400;color: #999999;" data-color="Text" data-size=" Text" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 190%;">
                                                          <span class="text_container">
                                                            <multiline>
                                                            </multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
                                                <!-- end -->
                                            </tbody></table></td>
                                       </tr>
                                       
                                   </tbody></table>
                                   
                                   <table border="0" width="5" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                       <tbody><tr><td width="5" height="50" style="font-size: 50px;line-height: 50px;"></td></tr>
                                   </tbody></table>
                                   
                                   <table border="0" width="290" align="right" cellpadding="0" cellspacing="0" style="/* background-color: #F7F7F7; */" class="container600"><tbody>
                                        <tr><td align="center">
                                            <table border="0" width="20%" align="left" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                                  <tr>
                                                 <td align="center" style="font-family:  Montserrat , sans-serif; font-size: 18px; font-weight: 300; color: #516072; line-height: 24px;">
                                                     <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/service-col1.png" alt="1" width="70" height="70" style="display: block;">
                                                 </td>
                                             </tr>
                                                <!-- end -->
                                            </tbody></table>

                                            <table border="0" width="80%" align="right" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;width: 70%;"><tbody>
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="text-transform: uppercase;font-family:  Montserrat , sans-serif;font-size: 15px;font-weight: 500;color: #2a2a2a;line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 150%;">
                                                            <span class="text_container">
                                                            <multiline>Free support</multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
     
                                                  <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>
     
                                                  <tr>
                                                    <td align="left" mc:edit="list-title" style="font-family:  Lato     ,  Arial ,  Calibri , sans-serif;font-size: 13px; font-    weight: 400;color: #999999;" data-color="Text" data-size=" Text" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 190%;">
                                                          <span class="text_container">
                                                            <multiline>
                                                            </multiline>
                                                            </span>
                                                        </div>
                                                    </td>
                                                  </tr>
                                                <!-- end -->
                                            </tbody></table></td>
                                       </tr>
                                       
                                   </tbody></table> 
                                </td>
                              </tr>
                              </tbody>
                         </table>
                         </td>
                       </tr>
                       <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                       <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module10" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module10.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
           
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module11" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module11.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="background-color: #FFFFFF;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table align="center" border="0" width="600" cellpadding="0" cellspacing="0" class="container600"><tbody>
                              <!-- Start Title -->
                              <tr>
                                  <td align="center">
                                    <table border="0" align="center" width="60" cellpadding="0" cellspacing="0" data-bgcolor="Blue-Button" style="background-color: #0CB4CE;border-radius: 2px;">
                                      <tbody>
                                          <tr><td height="3" style="font-size: 3px; line-height: 3px;">&nbsp;</td></tr>
                                      </tbody>
                                    </table>                              
                                  </td>
                              </tr>
                              <tr><td height="20" style="font-size: 20px; line-height: 20px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #222222; font-size:24px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 30px;font-weight: 700;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>OUR SERVICE</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="30" style="font-size: 30px;line-height: 30px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #999999;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 300;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 190%;">
                                           <span class="text_container">
                                           <multiline>
                                           </multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              <tr><td height="40" style="font-size: 40px;line-height: 40px;"></td></tr>
                              <tr>
                                   <td align="center">
                                     <table class="container600" width="398" align="left" border="0" cellpadding="0" cellspacing="0" style="width: 398;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                       <tbody>
                                         <tr>
                                           <td>
                                             <table class="container590" width="196" align="left" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tbody>
                                                       <tr><td style="padding: 20px;" align="center">
                                                            <table><tbody>
                                                                 <tr>
                                                         <td align="left" mc:edit="list-title" style="font-family:  Lato , sans-serif;font-size: 22px; font-weight: 300;color: #0CB4CE; line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                             <!-- ======= section text ====== -->
                                                             <div class="editable_text" style="line-height: 24px">
                                                                 <span class="text_container">
                                                                 <multiline>01</multiline>
                                                                 </span>
                                                             </div>
                                                         </td>
                                                       </tr> 
                                                       <tr>
                                                           <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                           </td>
                                                       </tr>
                                                       <tr>
                                                         <td align="left" mc:edit="list-title" style="font-family:  Lato ,  Calibri , sans-serif; font-size: 15px; font-weight: 300;color: #2a2a2a; line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                             <!-- ======= section text ====== -->
                                                             <div class="editable_text" style="line-height: 24px">
                                                                 <span class="text_container">
                                                                 <multiline>
                                                                Web Design. 98%
                                                                 </multiline>
                                                                 </span>
                                                             </div>
                                                         </td>
                                                       </tr>
                                                       <tr>
                                                           <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                           </td>
                                                       </tr>
                                                       <tr><td align="center">
                                                            <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="#f3f3f3" style="background-color: #E2E2E2;"><tbody>
                                                                 <tr><td>
                                                                      <table data-bgcolor="Chart Features" width="58%" align="left" border="0" cellpadding="0" cellspacing="0" bgcolor="#44ccb6" style="background-color: #0CB4CE;"><tbody>
                                                                           <tr><td align="center">
                                                                                <table class="table-container" width="80%" align="center" border="0" cellpadding="0" cellspacing="0"><tbody>
                                                                                     <tr><td height="10" data-color="Chart Features Title" data-size="Chart Features Title" align="left" style="font-family:  Montserrat , sans-serif; font-size: 10px; font-weight: 700; color: #ffffff; line-height: 10px;">&nbsp;
                                                                                          </td>
                                                                                     </tr></tbody>
                                                                                </table></td>
                                                                           </tr></tbody>
                                                                      </table></td>
                                                                 </tr>
                                                                 </tbody></table>
                                                            </td>
                                                       </tr>                                                      
                                                       <tr>
                                                         <td align="left" mc:edit="list-title" style="color:#999999; font-size:13px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 20px; font-weight:400;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                                             <!-- ======= section text ====== -->
                                                             <div class="editable_text" style="line-height: 190%;">
                                                               <span class="text_container">
                                                                 <multiline>
                                                                 </multiline>
                                                                 </span>
                                                             </div>
                                                         </td>
                                                       </tr>
                                                       </tbody></table>
                                                  </td></tr>
                                                 
                                                  </tbody>
                                             </table>

                                             <!-- SPACE -->
                                             <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                 <tbody><tr>
                                                     <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                                     </td>
                                                 </tr>
                                             </tbody></table>
                                             <!-- END SPACE -->

                                             <table class="container590" width="196" align="right" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tbody>
                                                       <tr><td style="padding: 20px;" align="center">
                                                            <table><tbody>
                                                                 <tr>
                                                         <td align="left" mc:edit="list-title" style="font-family:  Lato , sans-serif;font-size: 22px; font-weight: 300;color: #0CB4CE; line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                             <!-- ======= section text ====== -->
                                                             <div class="editable_text" style="line-height: 24px">
                                                                 <span class="text_container">
                                                                 <multiline>02</multiline>
                                                                 </span>
                                                             </div>
                                                         </td>
                                                       </tr> 
                                                       <tr>
                                                           <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                           </td>
                                                       </tr>
                                                       <tr>
                                                         <td align="left" mc:edit="list-title" style="font-family:  Lato ,  Calibri , sans-serif; font-size: 15px; font-weight: 300;color: #2a2a2a; line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                             <!-- ======= section text ====== -->
                                                             <div class="editable_text" style="line-height: 24px">
                                                                 <span class="text_container">
                                                                 <multiline>Coding 90%</multiline>
                                                                 </span>
                                                             </div>
                                                         </td>
                                                       </tr>
                                                       <tr>
                                                           <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                                           </td>
                                                       </tr>
                                                       <tr><td align="center">
                                                            <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="#f3f3f3" style="background-color: #E2E2E2;"><tbody>
                                                                 <tr><td>
                                                                      <table data-bgcolor="Chart Features" width="50%" align="left" border="0" cellpadding="0" cellspacing="0" bgcolor="#44ccb6" style="background-color: #0CB4CE;"><tbody>
                                                                           <tr><td align="center">
                                                                                <table class="table-container" width="80%" align="center" border="0" cellpadding="0" cellspacing="0"><tbody>
                                                                                     <tr><td height="10" data-color="Chart Features Title" data-size="Chart Features Title" align="left" style="font-family:  Montserrat , sans-serif; font-size: 10px; font-weight: 700; color: #ffffff; line-height: 10px;">&nbsp;
                                                                                          </td>
                                                                                     </tr></tbody>
                                                                                </table></td>
                                                                           </tr></tbody>
                                                                      </table></td>
                                                                 </tr>
                                                                 </tbody></table>
                                                            </td>
                                                       </tr>                                                      
                                                       <tr>
                                                         <td align="left" mc:edit="list-title" style="color:#999999; font-size:13px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 20px; font-weight:400;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                                             <!-- ======= section text ====== -->
                                                             <div class="editable_text" style="line-height: 190%;">
                                                               <span class="text_container">
                                                                 <multiline>
                                                                 </multiline>
                                                                 </span>
                                                             </div>
                                                         </td>
                                                       </tr>
                                                       </tbody></table>
                                                  </td></tr>
                                                 
                                                  </tbody>
                                             </table>

                                           </td>
                                         </tr>
                                       </tbody>
                                     </table>

                                     <!-- SPACE -->
                                     <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                         <tbody><tr>
                                             <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                             </td>
                                         </tr>
                                     </tbody></table>
                                     <!-- END SPACE -->

                                     <table class="container590" width="196" align="right" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tbody>
                                        <tr><td style="padding: 20px;" align="center">
                                             <table><tbody>
                                                  <tr>
                                          <td align="left" mc:edit="list-title" style="font-family:  Lato , sans-serif;font-size: 22px; font-weight: 300;color: #0CB4CE; line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 24px">
                                                  <span class="text_container">
                                                  <multiline>03</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr> 
                                        <tr>
                                            <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                            </td>
                                        </tr>
                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family:  Lato ,  Calibri , sans-serif; font-size: 15px; font-weight: 300;color: #2a2a2a; line-height: 24px;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 24px">
                                                  <span class="text_container">
                                                  <multiline>Client Support. 95%</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                        <tr>
                                            <td height="10" style="font-size: 1px; line-height: 10px;">&nbsp;
                                            </td>
                                        </tr>
                                        <tr><td align="center">
                                             <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="#f3f3f3" style="background-color: #E2E2E2;"><tbody>
                                                  <tr><td>
                                                       <table data-bgcolor="Chart Features" width="70%" align="left" border="0" cellpadding="0" cellspacing="0" bgcolor="#44ccb6" style="background-color: #0CB4CE;"><tbody>
                                                            <tr><td align="center">
                                                                 <table class="table-container" width="80%" align="center" border="0" cellpadding="0" cellspacing="0"><tbody>
                                                                      <tr><td height="10" data-color="Chart Features Title" data-size="Chart Features Title" align="left" style="font-family:  Montserrat , sans-serif; font-size: 10px; font-weight: 700; color: #ffffff; line-height: 10px;">&nbsp;
                                                                           </td>
                                                                      </tr></tbody>
                                                                 </table></td>
                                                            </tr></tbody>
                                                       </table></td>
                                                  </tr>
                                                  </tbody></table>
                                             </td>
                                        </tr>                                                      
                                        <tr>
                                          <td align="left" mc:edit="list-title" style="color:#999999; font-size:13px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 20px; font-weight:400;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>
                                        </tbody></table>
                                   </td></tr>
                                  
                                   </tbody>
                              </table></td>
                              </tr>
                              </tbody>
                         </table>
                         </td>
                       </tr>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module12" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module12.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="width: 100%; max-width: 800px; background-color: rgb(42, 120, 149); background-size: cover; background-position: 50% 0%; background-repeat: no-repeat;" bgcolor="#2A7895" background="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/bg1.JPG" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                      <tr>
                        <td align="center" class="padding_20_show">
                          <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container500" data-bgcolor="Hero Center">
                              <tbody>
                                  
                                   <tr><td height="70" style="font-size: 70px; line-height: 70px;">&nbsp;</td></tr>

                                   
                                   
                                   <tr><td height="20" style="font-size: 20px; line-height: 20px;"></td></tr>

                                   <tr>
                                      <td align="center" mc:edit="big-title1" style="letter-spacing: 2px;font-size: 30px;color: #FFFFFF;font-weight: 500;font-family:  Lato ,  Open Sans , sans-serif;" class="main-section-header" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="28">
                                          <!-- ======= section text ====== -->
                                          
                                          <div style="line-height: 100%" class="main-section-header">
                                              <span class="text_container">
                                              <multiline>
                                                 WE CREATE AWESOME DESIGNS
                                              </multiline>
                                              </span>
                                          </div>
                                      </td>   
                                   </tr>

                                   <tr>
                                       <td height="10" style="font-size:10px; line-height: 10px;">&nbsp;</td>
                                   </tr>
                                   
                                   <tr>
                                        <td align="center" mc:edit="big-title1" style="color: #FFFFFF;font-size: 18px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 28px;font-weight:300;letter-spacing: 0px;" data-size="Header title" data-max="72" data-color="Header title">
                                            <!-- ======= section text ====== -->
                                            
                                            <div style="line-height: 120%">
                                                <span class="text_container">
                                                <multiline>
                                                    We are a creative team with full of ideas
                                                </multiline>
                                                </span>
                                            </div>
                                        </td>   
                                   </tr>

                                   
                                   <tr><td height="20" style="font-size: 20px; line-height: 20px;">&nbsp;</td></tr>

                                   <!-- button -->
                                   <tr>
                                     <td align="center">
                                     </td>
                                   </tr>
                                   <!-- end section -->

                                   <tr><td height="70" style="font-size: 70px; line-height: 70px;">&nbsp;</td></tr>
                              </tbody>
                          </table>
                        </td>
                      </tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table>
	 <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module13" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module13.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module14" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module14.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center" class="">
              </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module15" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module15.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
              <table border="0" align="center" width="100%" bgcolor="#F6F7F9" style="width:100%;max-width: 800px;background-color: #FFFFFF;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                  <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr>
                      <td align="center" class="padding_20">
                        <table class="container600" width="598" align="center" border="0" cellpadding="0" cellspacing="0">
                            <tbody>
                              <tr>
                                  <td align="center">
                                    <table border="0" align="center" width="60" cellpadding="0" cellspacing="0" data-bgcolor="Blue-Line" style="background-color: #0CB4CE;border-radius: 2px;">
                                      <tbody>
                                          <tr><td height="3" style="font-size: 3px; line-height: 3px;">&nbsp;</td></tr>
                                      </tbody>
                                    </table>                              
                                  </td>
                              </tr>
                              <tr><td height="20" style="font-size: 20px; line-height: 20px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #222222; font-size:24px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 30px;font-weight: 700;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>OUR PRICING</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="30" style="font-size: 30px;line-height: 30px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #999999;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 300;" data-size="Sub Header" data-max="72" data-color="Sub Header">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 190%;">
                                           <span class="text_container">
                                           <multiline>
                                           </multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="50" style="font-size: 50px;line-height: 50px;"></td></tr>

                          <tr>
                            <td>
                              <table border="0" width="398" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container590">
                                <tbody><tr>
                                  <td>
                                    <table border="0" width="198" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;background-color: #0CB4CE;" class="container590" data-bgcolor="Table 1">
                                      <tbody>
                                      <tr><td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td></tr>
                                      <tr>
                                        <td align="center" mc:edit="table-subheader1" style="font-weight: 700;color: #FFFFFF;font-size: 14px;font-family:  Lato , Calibri, sans-serif;mso-line-height-rule: exactly;/* line-height: 60px; */" class="link_color" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="72">
                                          <!-- ======= section text ====== -->
                                          
                                          <div class="editable_text" style="/* line-height: 60px */">
                                            <span class="text_container">
                                                <multiline>STARTER</multiline>
                                            </span>
                                          </div>
                                       </td> 
                                      </tr>
                                      <tr><td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td></tr>
                                      <tr>
                                        <td align="center">
                                          <table align="center" width="100%" cellpadding="0" cellspacing="0" style="background-color: #09A2BA;" data-bgcolor="Table 2">
                                            <tbody>
                                              <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                              <tr>
                                                <td align="center" mc:edit="table-subheader1" style="font-weight: 900;color: #FFFFFF;font-size: 64px;font-family:  Lato , Calibri, sans-serif;mso-line-height-rule: exactly;line-height: 60px;" class="link_color" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="72">
                                                    <!-- ======= section text ====== -->
                                                    
                                                    <div class="editable_text" style="line-height: 100%;">
                                                      <span class="text_container">
                                                          <multiline>
                                                            <sup style="font-size: 16px;">$</sup>599<span style="font-size: 13px;"></span>
                                                          </multiline>
                                                      </span>
                                                    </div>
                                                 </td> 
                                              </tr>
                                              <tr><td height="15" style="font-size: 15px;line-height: 15px;">&nbsp;</td></tr>
                                            </tbody>
                                          </table>
                                        </td>
                                      </tr>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                      <tr>
                                        <td align="center">
                                          <table align="center" border="0" cellpadding="0" cellspacing="0" width="180" class="container580">
                                            <tbody><tr>
                                              <td align="center" mc:edit="table-text1" style="color: #FFFFFF;font-size: 12px;font-family:  Lato , Calibri, sans-serif; mso-line-height-rule: exactly; line-height: 23px;" class="text_color" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                                <!-- ======= section text ====== -->
                                                
                                                <div class="editable_text" style="line-height: 190%;">
                                                  <span class="text_container">
                                                      <multiline>
                                                        Website<br>10 GB OF STORAGE<br>Unlimited USERS<br>25 GB BANDWIDTH
                                                      </multiline>
                                                  </span>
                                                </div>
                                                  </td> 
                                            </tr>
                                          </tbody></table>
                                        </td>
                                      </tr>

                                      <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                      <tr>
                                        <td align="center">
                                          <table border="0" align="center" width="140" cellpadding="0" cellspacing="0" style="border-top: 2px solid #FFFFFF;" data-border-color="Button Border" data-bgcolor="Button">
                                            <tbody>
                                                <tr>
                                                  <td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td align="center" style="font-family:  Lato , Calibri, sans-serif;font-size: 14px;font-weight: 700;color: #FFFFFF;line-height: 26px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                        <div class="editable_text" style="line-height: 14px;">
                                                            <multiline>
                                                              <a href="" style="color: #FFFFFF; text-decoration: none;" data-color="Button Text"></a>
                                                            </multiline>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                  <td height="13" style="font-size: 13px; line-height: 13px;">&nbsp;</td>
                                                </tr>
                                            </tbody>
                                          </table>                              
                                        </td>
                                      </tr>
                                      
                                      
                                      
                                    </tbody></table>
                                          
                                    <table border="0" width="2" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container590">
                                      <tbody><tr><td width="2" height="50" style="font-size: 50px; line-height: 50px;"></td></tr>
                                    </tbody></table>
                                          
                                    <table border="0" width="198" align="right" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;background-color: #0CB4CE;" class="container590" data-bgcolor="Table 1">
                                      <tbody>
                                      <tr><td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td></tr>
                                      <tr>
                                        <td align="center" mc:edit="table-subheader1" style="font-weight: 700;color: #FFFFFF;font-size: 14px;font-family:  Lato , Calibri, sans-serif;mso-line-height-rule: exactly;/* line-height: 60px; */" class="link_color" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="72">
                                          <!-- ======= section text ====== -->
                                          
                                          <div class="editable_text" style="/* line-height: 60px */">
                                            <span class="text_container">
                                                <multiline>GOLDEN</multiline>
                                            </span>
                                          </div>
                                       </td> 
                                      </tr>
                                      <tr><td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td></tr>
                                      <tr>
                                        <td align="center">
                                          <table align="center" width="100%" cellpadding="0" cellspacing="0" style="background-color: #09A2BA;" data-bgcolor="Table 2">
                                            <tbody>
                                              <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                              <tr>
                                                <td align="center" mc:edit="table-subheader1" style="font-weight: 900;color: #FFFFFF;font-size: 64px;font-family:  Lato , Calibri, sans-serif;mso-line-height-rule: exactly;line-height: 60px;" class="link_color" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="72">
                                                    <!-- ======= section text ====== -->
                                                    
                                                    <div class="editable_text" style="line-height: 100%;">
                                                      <span class="text_container">
                                                          <multiline>
                                                            <sup style="font-size: 16px;">$</sup>799<span style="font-size: 13px;"></span>
                                                          </multiline>
                                                      </span>
                                                    </div>
                                                 </td> 
                                              </tr>
                                              <tr><td height="15" style="font-size: 15px;line-height: 15px;">&nbsp;</td></tr>
                                            </tbody>
                                          </table>
                                        </td>
                                      </tr>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                      <tr>
                                        <td align="center">
                                          <table align="center" border="0" cellpadding="0" cellspacing="0" width="180" class="container580">
                                            <tbody><tr>
                                              <td align="center" mc:edit="table-text1" style="color: #FFFFFF;font-size: 12px;font-family:  Lato , Calibri, sans-serif; mso-line-height-rule: exactly; line-height: 23px;" class="text_color" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                                <!-- ======= section text ====== -->
                                                
                                                <div class="editable_text" style="line-height: 190%;">
                                                  <span class="text_container">
                                                      <multiline>
                                                         Website<br>100 GB OF STORAGE<br>Unlimited USERS<br>100 GB BANDWIDTH
                                                      </multiline>
                                                  </span>
                                                </div>
                                                  </td> 
                                            </tr>
                                          </tbody></table>
                                        </td>
                                      </tr>

                                      <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                      <tr>
                                        <td align="center">
                                          <table border="0" align="center" width="140" cellpadding="0" cellspacing="0" style="border-top: 2px solid #FFFFFF;" data-border-color="Button Border" data-bgcolor="Button">
                                            <tbody>
                                                <tr>
                                                  <td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td align="center" style="font-family:  Lato , Calibri, sans-serif;font-size: 14px;font-weight: 700;color: #FFFFFF;line-height: 26px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                        <div class="editable_text" style="line-height: 14px;">
                                                            <multiline>
                                                              <a href="" style="color: #FFFFFF; text-decoration: none;" data-color="Button Text"></a>
                                                            </multiline>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                  <td height="13" style="font-size: 13px; line-height: 13px;">&nbsp;</td>
                                                </tr>
                                            </tbody>
                                          </table>                              
                                        </td>
                                      </tr>
                                      
                                      
                                      
                                    </tbody></table>
                                    
                                  </td>
                                </tr>
                              </tbody></table>  
                              
                              <table border="0" width="2" align="left" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container590">
                                <tbody><tr><td width="2" height="50" style="font-size: 50px; line-height: 50px;"></td></tr>
                              </tbody></table>
                                    
                              <table border="0" width="198" align="right" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;background-color: #0CB4CE;" class="container590" data-bgcolor="Table 1">
                                <tbody>
                                <tr><td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td></tr>
                                <tr>
                                  <td align="center" mc:edit="table-subheader1" style="font-weight: 700;color: #FFFFFF;font-size: 14px;font-family:  Lato , Calibri, sans-serif;mso-line-height-rule: exactly;/* line-height: 60px; */" class="link_color" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="72">
                                    <!-- ======= section text ====== -->
                                    
                                    <div class="editable_text" style="/* line-height: 60px */">
                                      <span class="text_container">
                                          <multiline>PREMIUM</multiline>
                                      </span>
                                    </div>
                                 </td> 
                                </tr>
                                <tr><td height="20" style="font-size: 20px;line-height: 20px;">&nbsp;</td></tr>
                                <tr>
                                  <td align="center">
                                    <table align="center" width="100%" cellpadding="0" cellspacing="0" style="background-color: #09A2BA;" data-bgcolor="Table 2">
                                      <tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                        <tr>
                                          <td align="center" mc:edit="table-subheader1" style="font-weight: 900;color: #FFFFFF;font-size: 64px;font-family:  Lato , Calibri, sans-serif;mso-line-height-rule: exactly;line-height: 60px;" class="link_color" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="72">
                                              <!-- ======= section text ====== -->
                                              
                                              <div class="editable_text" style="line-height: 100%;">
                                                <span class="text_container">
                                                    <multiline>
                                                      <sup style="font-size: 16px;">$</sup>1199<span style="font-size: 13px;"></span>
                                                    </multiline>
                                                </span>
                                              </div>
                                           </td> 
                                        </tr>
                                        <tr><td height="15" style="font-size: 15px;line-height: 15px;">&nbsp;</td></tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                                  <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                <tr>
                                  <td align="center">
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="180" class="container580">
                                      <tbody><tr>
                                        <td align="center" mc:edit="table-text1" style="color: #FFFFFF;font-size: 12px;font-family:  Lato , Calibri, sans-serif; mso-line-height-rule: exactly; line-height: 23px;" class="text_color" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                          <!-- ======= section text ====== -->
                                          
                                          <div class="editable_text" style="line-height: 190%;">
                                            <span class="text_container">
                                                <multiline>
                                                    Website and SEO <br>Unlimited GB OF STORAGE<br>Unlimited USERS<br>Unlimited GB BANDWIDTH
                                                </multiline>
                                            </span>
                                          </div>
                                            </td> 
                                      </tr>
                                    </tbody></table>
                                  </td>
                                </tr>

                                <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                <tr>
                                  <td align="center">
                                    <table border="0" align="center" width="140" cellpadding="0" cellspacing="0" style="border-top: 2px solid #FFFFFF;" data-border-color="Button Border" data-bgcolor="Button">
                                      <tbody>
                                          <tr>
                                            <td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td>
                                          </tr>
                                          <tr>
                                              <td align="center" style="font-family:  Lato , Calibri, sans-serif;font-size: 14px;font-weight: 700;color: #FFFFFF;line-height: 26px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                  <div class="editable_text" style="line-height: 14px;">
                                                      <multiline>
                                                       <a href="" style="color: #FFFFFF; text-decoration: none;" data-color="Button Text"></a>
                                                      </multiline>
                                                  </div>
                                              </td>
                                          </tr>
                                          <tr>
                                            <td height="13" style="font-size: 13px; line-height: 13px;">&nbsp;</td>
                                          </tr>
                                      </tbody>
                                    </table>                              
                                  </td>
                                </tr>
                              </tbody></table>
                            </td>
                          </tr>
                      </tbody></table>
                  </td>
                </tr>
                <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
              </tbody></table>
            </td>
          </tr></tbody>
     </table>
                                   
                                   
                         </td>
                       </tr>
                       <tr><td height="50" style="font-size: 50px; line-height:50px;"></td></tr>
                       <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module18" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module18.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
               <table border="0" align="center" width="100%" style="width: 100%; max-width: 800px; background-color: rgb(42, 120, 149); background-size: cover; background-position: 50% 0%; background-repeat: no-repeat;" cellpadding="0" cellspacing="0" bgcolor="#0CB4CE" background="http://seocustomer.com/wp-content/uploads/2016/07/seo-592747_960_720.png" data-bg="Background1" data-bgcolor="Background1">
                    <tbody>
                      <!-- Main Hero -->
                      <tr>
                        <td align="center" class="padding_20_show">
                          <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container500" data-bgcolor="Hero Center">
                              <tbody>
                                  
                                  <tr><td height="90" style="font-size: 90px;line-height: 90px;">&nbsp;</td></tr>

                                  <tr>
                                      <td align="left" mc:edit="big-title1" style="font-size: 40px; color: #FFFFFF; font-weight: 700; line-height: 48px; font-family:  Lato ,  Open Sans , sans-serif;" class="main-section-header" data-size="Header title" data-max="72" data-color="Header title">
                                          <!-- ======= section text ====== -->
                                          
                                          <div style="line-height: 100%;" class="main-section-header">
                                              <span class="text_container">
                                              <multiline>
                                                
                                              </multiline>
                                              </span>
                                          </div>
                                      </td>   
                                    </tr>
                              <tr>
                                  <td height="10" style="font-size:10px; line-height: 10px;">&nbsp;</td>
                              </tr>
                              
                              <tr>
                                   <td align="left" mc:edit="big-title1" style="color: #FFFFFF;font-size: 18px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 28px;font-weight: 400;letter-spacing: 0px;" data-color="Colored Text" data-size="Colored Text" data-min="12" data-max="28">
                                       <!-- ======= section text ====== -->
                                       
                                       <div style="line-height: 120%;">
                                           <span class="text_container">
                                           <multiline>
                                            
                                           </multiline>
                                           </span>
                                       </div>
                                   </td>   
                              </tr>

                              
                              <tr><td height="20" style="font-size: 20px; line-height: 20px;">&nbsp;</td></tr>

                              <!-- button -->
                              <tr>
                                <td align="left">
                                   <table border="0" align="left" width="300" cellpadding="0" cellspacing="0" class="container340">
                                        <tbody>
                                             <tr>
                                                  <td align="center">
                                                       <table border="0" align="left" width="" cellpadding="0" cellspacing="0" class="container340" bgcolor="" style="background-color: #0CB4CE;border-radius: 2px;" data-bgcolor="Button1">
                                                            <tbody>
                                                                <tr>
                                                                    <td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    
                                                                    
                                                                </tr>
                                                                                                                    
                                                                <tr>
                                                                    <td height="13" style="font-size: 13px; line-height: 13px;">&nbsp;</td>
                                                                </tr>
                                                         
                                                            </tbody>
                                                       </table> 
                                                       <table border="0" align="left" width="5" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="container600">
                                                            <tbody><tr><td height="20" width="5" style="font-size: 20px; line-height: 20px;">&nbsp;</td></tr>
                                                            </tbody>
                                                       </table>
                                                      <table border="0" align="right" width="" cellpadding="0" cellspacing="0" class="container340" bgcolor="" style="background-color: #0CB4CE;border-radius: 2px;" data-bgcolor="Button1">
                                                            <tbody>
                                                                <tr>
                                                                    <td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                   
                                                                    
                                                                </tr>
                                                                                                                    
                                                                <tr>
                                                                    <td height="13" style="font-size: 13px; line-height: 13px;">&nbsp;</td>
                                                                </tr>
                                                    
                                                            </tbody>
                                                       </table>
                                                  </td>
                                             </tr>
                                        </tbody>
                                   </table>
                                                                
                                </td>
                              </tr>
                              <!-- end section -->

                              <tr><td height="90" style="font-size: 90px;line-height: 90px;">&nbsp;</td></tr>
                              </tbody>
                          </table>
                        </td>
                      </tr>
                      <!-- end section -->

                    </tbody>
                </table>
              </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module19" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module19.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="background-color: #FFFFFF;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container600"><tbody>
                              <tr><td align="center" mc:edit="big-title1" style="color: #0CB4CE;font-size: 14px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 30px;font-weight: 900; letter-spacing: 2px;" data-size="Colored title" data-max="72" data-color="Colored title">
                                        <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 120%;">
                                           <span class="text_container">
                                           <multiline>FAQS</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              <tr><td height="10" style="font-size: 10px; line-height: 10px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #222222; font-size:24px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 30px;font-weight: 700;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>Have a few questions? We ve got answers!</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="30" style="font-size: 30px; line-height:30px;"></td></tr>

                              <tr><td align="center">
                                   <table border="0" width="280" class="full" align="left" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 160%;">
                                                  <span class="text_container">
                                                  <multiline>How a website Can help me?</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 13px; font-weight: 400;color: #999999;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                  A website, also written as web site,is a collection of related web pages, including 

multimedia content, typically identified with a common domain name, and published on at 

least one web server.It is an identity in the Internet world.
												  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <!-- button -->
                                        <tr>
                                             <td align="left" style="color: #FFFFFF;font-size: 12px;font-family:  Lato ,  Calibri , sans-serif; font-weight: 500;letter-spacing: 1px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                <div class="editable_text" style="line-height: 100%;">
                                                    <span class="text_container">
                                                    <multiline>
                                                        <a href="#" target="_blank" style="color: #0CB4CE; text-decoration: none;" data-color="Button Text"></a>
                                                    </multiline>
                                                    </span>
                                                </div>
                                             </td>
                                        </tr>
                                      <!-- end -->
                                  </tbody></table>

                                   <!-- SPACE -->
                                   <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                        <tbody><tr>
                                            <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- END SPACE -->

                                  <table border="0" width="280" class="full" align="right" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 160%;">
                                                  <span class="text_container">
                                                  <multiline>What is a SEO?</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 13px; font-weight: 400;color: #999999;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                            Search engine optimization (SEO) is the process of affecting the visibility of a website or a web page in a web search engine s unpaid results—often referred to as "natural", "organic", or "earned" results. In general, the earlier (or higher ranked on the search results page), and more frequently a site appears in the search results list, the more visitors it will receive from the search engine s users, and these visitors can be converted into customers.
											</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <!-- button -->
                                        <tr>
                                             <td align="left" style="color: #FFFFFF;font-size: 12px;font-family:  Lato ,  Calibri , sans-serif; font-weight: 500;letter-spacing: 1px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                <div class="editable_text" style="line-height: 100%;">
                                                    <span class="text_container">
                                                    <multiline>
                                                        <a href="#" target="_blank" style="color: #0CB4CE; text-decoration: none;" data-color="Button Text"></a>
                                                    </multiline>
                                                    </span>
                                                </div>
                                             </td>
                                        </tr>
                                      <!-- end -->
                                  </tbody></table></td>
                              </tr>

                              <tr><td height="30" style="font-size: 30px; line-height:30px;"></td></tr>

                              <tr><td align="center">
                                   <table border="0" width="280" class="full" align="left" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 160%;">
                                                  <span class="text_container">
                                                  <multiline>What is Digital Marketing?</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 13px; font-weight: 400;color: #999999;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                
Digital marketing is an umbrella term for the marketing of products or services using digital technologies, mainly on the Internet, but also including mobile phones, display advertising, and any other digital medium.
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <!-- button -->
                                        <tr>
                                             <td align="left" style="color: #FFFFFF;font-size: 12px;font-family:  Lato ,  Calibri , sans-serif; font-weight: 500;letter-spacing: 1px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                <div class="editable_text" style="line-height: 100%;">
                                                    <span class="text_container">
                                                    <multiline>
                                                        <a href="#" target="_blank" style="color: #0CB4CE; text-decoration: none;" data-color="Button Text"></a>
                                                    </multiline>
                                                    </span>
                                                </div>
                                             </td>
                                        </tr>
                                      <!-- end -->
                                   </tbody></table>

                                   <!-- SPACE -->
                                   <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                        <tbody><tr>
                                            <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- END SPACE -->

                                   <table border="0" width="280" class="full" align="right" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 160%;">
                                                  <span class="text_container">
                                                  <multiline>What is Ecommerce?</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 13px; font-weight: 400;color: #999999;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                             Electronic commerce, commonly written as e-commerce or eCommerce, is the trading or facilitation of trading in products or services using computer networks, such as the Internet or online social networks. Electronic commerce draws on technologies such as mobile commerce, electronic funds transfer, supply chain management, Internet marketing, online transaction processing, electronic data interchange (EDI), inventory management systems, and automated data collection systems. Modern electronic commerce typically uses the World Wide Web for at least one part of the transaction s life cycle although it may also use other technologies such as e-mail.
											 </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <!-- button -->
                                        <tr>
                                             <td align="left" style="color: #FFFFFF;font-size: 12px;font-family:  Lato ,  Calibri , sans-serif; font-weight: 500;letter-spacing: 1px;" mc:edit="main-button" data-size="Button Text" data-min="12" data-max="28">
                                                <div class="editable_text" style="line-height: 100%;">
                                                    <span class="text_container">
                                                    <multiline>
                                                        <a href="#" target="_blank" style="color: #0CB4CE; text-decoration: none;" data-color="Button Text"></a>
                                                    </multiline>
                                                    </span>
                                                </div>
                                             </td>
                                        </tr>
                                      <!-- end -->
                                   </tbody></table></td>
                              </tr>

                              </tbody>
                         </table>
                         </td>
                       </tr>
                       <tr><td height="50" style="font-size: 50px; line-height:50px;"></td></tr>
                       <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#EEEEEE" data-module="module20" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module20.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
        <tr>
          <td align="center">
            <table border="0" align="center" width="100%" style="width:100%; max-width:800px;" cellpadding="0" cellspacing="0">
              <tbody>
                <tr>
                  <td align="center">
                    <table border="0" width="50%" align="left" cellpadding="0" cellspacing="0" style="width: 50%; background-color: rgb(74, 89, 93); background-size: cover; background-position: 50% 0%; background-repeat: no-repeat;" class="half-container800" background="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/left-bg-img.JPG" bgcolor="#4A595D" data-bg="Left Bg Img"><tbody>
                         <tr><td align="center" style="height: 280px;" class="padding_20">
                            <table border="0" width="280" align="center" cellpadding="0" cellspacing="0" class="container600">
                              <tbody>
                                <tr>
                                    <td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;
                                    </td>
                                </tr>
                                
                                <tr>
                                  <td align="center">
                                    <table border="0" align="center" width="60" cellpadding="0" cellspacing="0" data-bgcolor="Blue-Line" style="background-color: #0CB4CE;border-radius: 2px;">
                                      <tbody>
                                          <tr><td height="3" style="font-size: 3px; line-height: 3px;">&nbsp;</td></tr>
                                      </tbody>
                                    </table>                              
                                  </td>
                              </tr>
                              <tr><td height="10" style="font-size: 10px;line-height: 10px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #FFFFFF;font-size: 18px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 30px;font-weight: 700;" data-size="Title" data-max="72" data-color="Title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>AWESOME DESIGN</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="20" style="font-size: 20px;line-height: 20px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #FFFFFF;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 300;" data-size="Text" data-max="72" data-color="Text">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 160%;">
                                           <span class="text_container">
                                           <multiline>
                                           </multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="50" style="font-size: 50px;line-height: 50px;"></td></tr>
                              
                            </tbody></table>
                          </td>
                         </tr>
                      </tbody>
                    </table>
                    
                    <table border="0" width="50%" align="right" cellpadding="0" cellspacing="0" style="width: 50%; background-color: rgb(67, 84, 88); background-size: cover; background-position: 50% 0%; background-repeat: no-repeat;" background="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/right-bg-img.JPG" bgcolor="#435458" class="half-container800" data-bg="Right Bg Img">
                      <tbody>
                         <tr><td align="center" style="height: 280px;" class="padding_20">
                            <table border="0" width="280" align="center" cellpadding="0" cellspacing="0" class="container600">
                              <tbody>
                                <tr>
                                    <td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;
                                    </td>
                                </tr>
                                
                                <tr>
                                  <td align="center">
                                    <table border="0" align="center" width="60" cellpadding="0" cellspacing="0" data-bgcolor="Blue-Line" style="background-color: #0CB4CE;border-radius: 2px;">
                                      <tbody>
                                          <tr><td height="3" style="font-size: 3px; line-height: 3px;">&nbsp;</td></tr>
                                      </tbody>
                                    </table>                              
                                  </td>
                              </tr>
                              <tr><td height="10" style="font-size: 10px;line-height: 10px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #FFFFFF;font-size: 18px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 30px;font-weight: 700;" data-size="Title" data-max="72" data-color="Title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>RESPONSIVE DESIGN</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="20" style="font-size: 20px;line-height: 20px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #FFFFFF;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 300;" data-size="Text" data-max="72" data-color="Text">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 160%;">
                                           <span class="text_container">
                                           <multiline>
                                           </multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              
                              <tr><td height="50" style="font-size: 50px;line-height: 50px;"></td></tr>
                              
                            </tbody></table>
                          </td>
                         </tr>
                      </tbody>
                    </table>   
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" data-module="module21" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module21.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
            <table border="0" align="center" width="100%" style="background-color: #FFFFFF;width:100%;max-width: 800px;" cellpadding="0" cellspacing="0" data-bgcolor="White-Bg">
                <tbody>
                    <tr><td height="50" style="font-size: 50px; line-height: 50px;">&nbsp;</td></tr>
                    <tr><td align="center" class="padding_20_show">
                         <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container600"><tbody>
                              <tr><td align="center" mc:edit="big-title1" style="color: #0CB4CE;font-size: 14px; font-family:  Lato ,  Open Sans , sans-serif; line-height: 30px;font-weight: 900; letter-spacing: 2px;" data-size="Colored title" data-max="72" data-color="Colored title">
                                        <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 120%;">
                                           <span class="text_container">
                                           <multiline>CONTACT US</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                              <tr><td height="10" style="font-size: 10px; line-height: 10px;"></td></tr>

                              <tr><td align="center" mc:edit="big-title1" style="color: #222222;font-size:24px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 30px;font-weight: 500;" data-size="Header title" data-max="72" data-color="Header title">
                              <!-- ======= section text ====== -->
                              
                                       <div style="line-height: 140%;">
                                           <span class="text_container">
                                           <multiline>Have a few questions? We ve got answers!</multiline>
                                           </span>
                                       </div>
                                   </td>
                              </tr>
                         
                              <tr><td height="30" style="font-size: 30px; line-height:30px;"></td></tr>

                              <tr><td align="center">
                                   <table border="0" width="280" align="left" class="full" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                        <tr>
                                          <td>
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                <tbody><tr>
                                                    <td align="center" mc:edit="mcimg14">
                                                        <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/footer-icn1.png" alt="img" width="25" height="25" style="display: block;">
                                                    </td>
                                                    <td align="center" mc:edit="mcimg14">
                                                        &nbsp;&nbsp;&nbsp;
                                                    </td>
                                                    <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 160%;">
                                                            <span class="text_container">
                                                            <multiline>WORK TIME</multiline>
                                                            </span>
                                                        
                                                    </div></td>
                                                </tr>
                                            </tbody></table>
                                            
                                          </td>
                                        </tr>
                                        
                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="color: #999999;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 500;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                  Mon : Fri - 8:30am : 7:30pm<br>
                                                  Sat : Sun - Closed
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                      <!-- end -->
                                  </tbody></table>

                                  <!-- space -->
                                  <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                            <tbody><tr>
                                                <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                                </td>
                                            </tr>
                                   </tbody></table>
                                   <!-- end section -->

                                   <table border="0" width="280" align="right" class="full" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                        <tr>
                                          <td>
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                <tbody><tr>
                                                    <td align="center" mc:edit="mcimg14">
                                                        <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/footer-icn2.png" alt="img" width="25" height="25" style="display: block;">
                                                    </td>
                                                    <td align="center" mc:edit="mcimg14">
                                                        &nbsp;&nbsp;&nbsp;
                                                    </td>
                                                    <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 160%;">
                                                            <span class="text_container">
                                                            <multiline>POSTAL ADDRESS:</multiline>
                                                            </span>
                                                        
                                                    </div></td>
                                                </tr>
                                            </tbody></table>
                                          </td>
                                        </tr>
                                        
                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="color: #999999;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 500;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>
                                                 Letxweb, 20 Adelle Drive, Dover NH 03820, USA
                                                  </multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                      <!-- end -->
                                  </tbody></table>
                                  </td>
                              </tr>

                              <tr><td height="30" style="font-size: 30px; line-height:30px;"></td></tr>

                              <tr><td align="center">
                                   <table border="0" width="280" align="left" class="full" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                        <tr>
                                          <td>
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                <tbody><tr>
                                                    <td align="center" mc:edit="mcimg14">
                                                        <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/footer-icn3.png" alt="img" width="25" height="25" style="display: block;">
                                                    </td>
                                                    <td align="center" mc:edit="mcimg14">
                                                        &nbsp;&nbsp;&nbsp;
                                                    </td>
                                                    <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 160%;">
                                                            <span class="text_container">
                                                            <multiline>HEADQUARTERS</multiline>
                                                            </span>
                                                        
                                                    </div></td>
                                                </tr>
                                            </tbody></table>
                                          </td>
                                        </tr>
                                        
                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="color: #999999;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 500;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>Letxweb, 20 Adelle Drive, Dover NH 03820, USA</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                      <!-- end -->
                                  </tbody></table>

                                  <!-- space -->
                                  <table class="full" width="1" align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                            <tbody><tr>
                                                <td width="1" height="30" style="font-size: 30px; line-height: 30px;">
                                                </td>
                                            </tr>
                                   </tbody></table>
                                   <!-- end section -->

                                   <table border="0" width="280" align="right" class="full" cellpadding="0" cellspacing="0" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"><tbody>
                                        <tr><td height="10" style="font-size: 10px; line-height: 10px;">&nbsp;</td></tr>
                                        <tr>
                                          <td>
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                <tbody><tr>
                                                    <td align="center" mc:edit="mcimg14">
                                                        <img editable="true" src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/images/footer-icn4.png" alt="img" width="25" height="25" style="display: block;">
                                                    </td>
                                                    <td align="center" mc:edit="mcimg14">
                                                        &nbsp;&nbsp;&nbsp;
                                                    </td>
                                                    <td align="left" mc:edit="list-title" style="font-family: Lato, Aria , Calibri, sans-serif;font-size: 15px; font-weight: 700;color: #2a2a2a;" data-color="Headline" data-size="Headline" data-min="12" data-max="28">
                                                        <!-- ======= section text ====== -->
                                                        <div class="editable_text" style="line-height: 160%;">
                                                            <span class="text_container">
                                                            <multiline>PHONE</multiline>
                                                            </span>
                                                        
                                                    </div></td>
                                                </tr>
                                            </tbody></table>
                                          </td>
                                        </tr>
                                        
                                        <tr><td height="15" style="font-size: 15px; line-height: 15px;">&nbsp;</td></tr>

                                        <tr>
                                          <td align="left" mc:edit="list-title" style="color: #999999;font-size: 14px;font-family:  Lato ,  Open Sans , sans-serif;line-height: 26px;font-weight: 500;" data-color="Text" data-size="Text" data-min="12" data-max="28">
                                              <!-- ======= section text ====== -->
                                              <div class="editable_text" style="line-height: 190%;">
                                                <span class="text_container">
                                                  <multiline>Phone Number: + 61291889320<br>Email ID:Info@Letxweb.Com</multiline>
                                                  </span>
                                              </div>
                                          </td>
                                        </tr>

                                      <!-- end -->
                                  </tbody></table>
                                  </td>
                              </tr>

                              </tbody>
                         </table>
                         </td>
                       </tr>
                       <tr><td height="50" style="font-size: 50px; line-height:50px;"></td></tr>
                       <tr><td height="1" style="font-size: 1px; line-height: 1px; background-color: #EEEEEE">&nbsp;</td></tr>
                </tbody>
            </table>
            </td>
          </tr></tbody>
     </table><table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#EEEEEE" data-module="module22" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2016/03/20/7vBjWbpCO3ftdN9QwlhmiYAZ/demo/thumbnails/module22.png" style="background-color: #EEEEEE;" data-bgcolor="Body bgcolor"><tbody>
          <tr><td align="center">
               <table border="0" align="center" width="100%" bgcolor="#516072" style="width:100%;max-width: 800px;background-color: #FFFFFF;" cellpadding="0" cellspacing="0" class="" data-bgcolor="Footer-Bg">
                  <tbody>
                    <tr>
                      <td align="center" class="padding_20">
                        <table border="0" align="center" width="600" cellpadding="0" cellspacing="0" class="container590">
                          <tbody>
                            <tr><td height="30" style="font-size: 30px; line-height: 30px;">&nbsp;</td></tr>

                            <tr>
                              <td align="center" mc:edit="unsubscribe-link" style="color: #999999;font-size: 14px;font-family: Lato, Aria , Calibri, sans-serif;line-height: 24px;font-weight: 500;" data-color="Footer Text" data-size="Footer Text" data-min="12" data-max="28">
                                <div class="editable_text" style="line-height: 24px;">
                                  <span class="text_container">
                                    <multiline>© 2016. All Rights Reserved Letxweb<br> 
                                      
                                    </multiline>
                                  </span>
                                </div>  
                              </td>
                            </tr>

                            <tr><td height="30" style="font-size: 30px; line-height: 30px;">&nbsp;</td></tr>
                        </tbody></table>
                      </td>
                    </tr>
                  </tbody>
                </table>
            </td>
          </tr></tbody>
     </table>	
	 </body>
	 </html>';
	$name=$this->session->userdata('uname');
	$sub="LetXweb News Letter";
	echo send_mail1($sub,$email,$msg,$name,$card);
	}
?>