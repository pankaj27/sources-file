<?php
  
  include('smtpmail2/smtpmail/sendpimail.php');
	// $email1=explode(",",$email);
	//$cmailcount=count($email1);
	//$bkid=$bkid;
	$email=$cstml;
	
	
	$msg='Dear sir, We are pleased to inform you that your  booking is successfully done and follows are your performa Invoice details';
	$name=$this->session->userdata('uname');
	$sub="GK RICKSHAW PVT LTD. PI INVOICE";
	echo send_pimail($sub,$email,$msg,$name);
	
?>