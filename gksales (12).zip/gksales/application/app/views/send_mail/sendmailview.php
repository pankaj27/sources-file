<?php
  include("connection.php");
  include('smtpmail2/smtpmail/mail.php');
	 $email1=explode(",",$email);
	$cmailcount=count($email1);
	for($i=0;$i<$cmailcount;$i++)
	{
		$email=$email1[$i];
		$qry=mysqli_query($con,"select * from clientmaster where id='".trim($email)."'");
		$row=mysqli_fetch_array($qry);
		$email=$row['email'];
		$uid=$this->session->userdata('uid');
		$getemail=mysqli_query($con,"select * from salesman where id='".trim($uid)."'");
		$re=mysqli_fetch_array($getemail);
		$name=$re['name'];
		$image=$re['image'];
		$desig=$re['desig'];
		$phno=$re['phno'];
		$email2=$re['email'];
		$imagepath=base_url()."uploads/Salesman/".$image;
	
	$card=$card;
	
	$msg='<!DOCTYPE html>
<html>
<head>
<title>GK Rickshaw</title>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Democracy Newsletter templates, Email Templates, Newsletters, Marketing  templates, 
	Advertising templates, free Newsletter" />
<!-- //Custom Theme files -->
<style type="text/css">
	body{
		background-color:#a7d9fb;
		width: 100%;
		margin:0;
		padding: 0;
		 -webkit-font-smoothing: antialiased;
	}
	html{
		width: 100%;
	}
	table{
		font-size: 14px;
		border:0;
	}
	 /* ----------- responsive ----------- */
		 @media only screen and (max-width:810px){
				table.table-head {
					width: 725px !important;
				}
		 }
		 @media only screen and (max-width:768px){
				table.table-head {
					width: 680px !important;
				}
				.header-top{
					width: 650px !important;
				}
				.header-mid{
				width: 290px !important;
				}
		 }
		 
		  @media only screen and (max-width:700px){
				table.table-head {
					width: 600px !important;
				}
				.header-top{
					width: 550px !important;
				}
				.header-mid{
				width: 220px !important;
				}
		 }
		 @media only screen and (max-width:670px){
				table.table-head {
					width: 550px !important;
				}
				.header-top{
					width: 500px !important;
				}
				.header-mid{
				width: 240px !important;
				}
				.logo{
					width: 100% !important;
				}
				.nav{
				width: 100% !important;
				}
				.nav-menu{
					text-align:center !important;
					    padding-top: 8px !important;
				}
				.high{
					height:120px !important;
				}
				.high1{
					height:70px !important;
				}
				.banner{
				width: 500px !important;
				}
				.wel{
					font-size:2.3em !important;
				}
				.text-small{
					font-size:1.1em !important;
				}
				.text-high{
					font-size:2.5em !important;
				}
				.logo-text{
					color:#519FD4 !important;
				}
				.nav-menu a{
					color:#000 !important;
				}
				td.nav-social {
				text-align: center !important;
				width: 22% !important;
				margin: 0 auto !important;
				display: block !important;
			}
		 }
		 @media only screen and (max-width:570px){
				table.table-head {
					width: 400px !important;
				}
				.header-top{
					width: 350px !important;
				}
				.header-mid{
				width: 100% !important;
				}
				.banner {
					width: 350px !important;
				}
				.content-bottom{
					width:350px !important;
				}
				.text-high {
					font-size: 2em !important;
					text-align: center !important;
				}
				.header-mid1{
					padding-top:15px !important;
				}
				.high-top{
					height:20px !important;
				}
				.high-top1{
					height:30px !important;
				}
				.high-1{
				height:15px !important;
				}
				.high {
					height: 90px !important;
				}
				.high1 {
					height: 55px !important;
				}
				.header-mid1 {
					padding-top: 24px !important;
				}
				.header-mid2{
				padding-top: 15px !important;
				}
				.high-bottom{
					height: 60px !important;
				}
				.high-bottom1{
					height: 200px !important;
				}
				.high {
				height: 70px !important;
			}
				
		}
		@media only screen and (max-width:420px){
				table.table-head {
					width:350px !important;
				}
				.header-top{
					width: 280px !important;
				}
				.day{
					font-size:2em !important;
				}
				.banner {
					width: 280px !important;
				}
				.content-bottom{
					width:280px !important;
				}
				.text-high {
					font-size: 1.6em !important;
				}
				.header-mid1{
					padding-top:10px !important;
				}
				.high-top{
					height:15px !important;
				}
				.high-top1{
					height:20px !important;
				}
				.high-1{
				height:10px !important;
				}
				.high {
					height: 30px !important;
				}
				.high1 {
					height: 40px !important;
				}
				.header-mid1 {
					padding-top: 20px !important;
				}
				.header-mid2{
				padding-top: 10px !important;
				}
				.high-bottom{
					height: 40px !important;
				}
				.high-bottom1{
					height: 130px !important;
				}
				
			.nav-menu {
				font-size:0.85em !important;
			}
			td.nav-social {
				width: 36% !important;
			}
			.high-2{
				height:25px !important;
			}
			.para{
				font-size:0.9em !important;
				line-height:1.8em !important;
			}
			.read{
				    font-size: 0.9em !important;
			}
			.wel {
				font-size: 2em !important;
			}
			.high-4{
				height:10px !important;
			}
			.logo-text {
				font-size: 2.4em !important;
			}
		}
		@media only screen and (max-width:375px){
				table.table-head {
					width: 270px !important;
				}
				.header-top{
					width: 230px !important;
				}
				.day{
					font-size:2em !important;
				}
				.banner {
					width: 230px !important;
				}
				.content-bottom{
					width:230px !important;
				}
				
				
		}
</style>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<table border="0" width="100%" cellpadding="0" cellspacing="0">
		<tr><td height="30" ></td></tr>
		<tr >
			<td width="100%" align="center" valign="top" >
				<!--main-content-->
				<table class="table-head" width="800" border="0" cellpadding="0" cellspacing="0" align="center" >
					<!--header-->
					<tr >
						<td background="http://www.gkrickshaw.com/images/ab.jpg" style="background-size:cover;background-position:center;">
							<!--header-->
						<table width="720" border="0" cellpadding="0" cellspacing="0" align="center"   height="85" class="header-top">
							<tr>
								<td height="30" class="high-1"></td>
							</tr>
							<tr>
								<td>
									<table border="0" align="left" cellpadding="0" cellspacing="0" class="logo">
									
										<tr>
											<td align="center">
												<a href="#" class="logo-text" style="text-decoration: none; color:#fff; font-size: 3em; font-family: Myriad Pro;" ></a>
											</td>
										</tr>
									</table>
									<table border="0" align="right" cellpadding="0" cellspacing="0" class="nav">
										
										<tr>
											<td  style="text-align:right; font-size: 1.1em; font-family: Verdana;" class="nav-menu">
												<a style="text-decoration: none; color:#ec3003" href="#"></a>
												<span>&nbsp; &nbsp;</span>
												<a style="text-decoration: none; color:#ec3003" href="#"></a>
												<span>&nbsp; &nbsp;</span>
												<a style="text-decoration: none; color:#ec3003" href="#"></a>
												
												<span>&nbsp; &nbsp;</span>
												<a style="text-decoration: none; color:#ec3003" href="#"></a>
												
											</td>
											</tr>
											<tr>
												<td height="10"></td>
											</tr>
											<tr>
											<td align="right" class="nav-social">
												<table>
													<tr>
														<td width="22">
															<a href="#"><img src="http://www.gkrickshaw.com/images/dr.png" width="24" height="24"></a>
														</td>
														<td width="1">	
														</td>
														<td width="22">
															<a href="#"><img src="http://www.gkrickshaw.com/images/fa.png" width="24" height="24"></a>
														</td>
														<td width="1">	
														</td>
														<td width="22">
															<a href="#"><img src="http://www.gkrickshaw.com/images/ga.png" width="24" height="24"></a>
														</td>
													</tr>
												</table>
												
											</td>
										</tr>
									</table>
								</td>
							</tr>
					
						</table>
					<!--//header-->
							<table border="0"  width="650" cellpadding="0" cellspacing="0" align="center" class="banner">
								<tr ><td height="250" class="high">
								 <center>  <img src="http://www.gkrickshaw.com/images/pc2.png" width="150" height="150"></center>
							</td></tr>
								<tr>
									<td >
								<tr>
									<td style="color: #000; font-size: 2.5em;text-align:center; font-family:  Trajan Pro;   letter-spacing: 2px;" class="day">
										GK Rickshaw
									</td>
								</tr>
								<tr><td height="20"></td></tr>
								<tr>
									<td style="color: #777;font-size: 0.9em;font-family: Verdana;text-align:center; font-weight: normal;line-height: 2.2em;" class="para">
								G.K.Rickshow was formed in 2014 to develop high quality product with cutting edge technology in order to provide performance, services, long lasting and environment friendly products. Being an ISO 9001:2008 certified company, we ensure that our products and services are safe, reliable and of good quality. We are one of the leading manufacturers of electric passenger rickshaw as well as cargo rickshaw
								, operating from an industrial location of Hooghly, West Bengal, India
								  
								</td>
								</tr>
								<tr>
									<td style="color: #777;font-size: 0.9em;font-family: Verdana;text-align:center; font-weight: normal;line-height: 2.2em;" class="para">
							 	</td>
								</tr>
								<tr><td height="25"></td></tr>
							</td>
								</tr>	
								<tr><td height="100" class="high1"></td></tr>
							</table>
						
						</td>
					</tr>
					<!--//about-->
					<!--welcome-->
					<tr bgcolor="#fafafa"><td height="50" class="high-2">	
						</td></tr>
					<tr bgcolor="#fafafa">
						<td >
							<table border="0" align="center" width="720" cellpadding="0" cellspacing="0" align="center" class="header-top">
								<tr>
									<td >
										<!---->
										<table border="0" align="left" width="320" cellpadding="0" cellspacing="0" align="center" class="header-mid">
									<tr>
									<td >
										<img src="http://www.gkrickshaw.com/images/we.png" alt="" width="100%" height="150" >
									</td>
									</tr>
									<tr><td height="10"></td></tr>
								<tr>
									<td>
									<img src="http://www.gkrickshaw.com/images/we1.png" alt="" width="100%" height="150" >
								</td></tr>
							</table>
							<!---->
							<table border="0" align="right" width="330" cellpadding="0" cellspacing="0" align="center" class="header-mid">
								<tr>
									<td height="40" class="high-top"></td>
								</tr>
								<tr>
									<td style="color: #ec3003; font-size: 3em; font-family: Trajan Pro;  text-align: center; letter-spacing: 2px;" class="wel">
										WE<span style="color:#36990a;"> Care</span>
									</td>
								</tr>
								<tr><td height="20" class="high-4"></td></tr>
								<tr>
									<td style="color: #777;font-size: 0.95em;font-family: Verdana; text-align: center;font-weight: normal;line-height: 2.2em;" class="para">
								We started our journey with the motive of make a safer and greener world.
                                Out self determination and your support will let us to grow well.We have started a
                                greem journey in India. 								
								
								</td>
								</tr>
							</table>
							</td>
								</tr>	
							</table>
							
							
						</td>
					</tr>
					<tr bgcolor="#fafafa"><td height="50" class="high-top">
							
						</td></tr>
					<!--//welcome-->
					<!--about-->
					<tr bgcolor="#ffffff"><td height="50" class="high-top">
							
						</td></tr>
					<tr bgcolor="#ffffff">
						<td >
								<table border="0" align="center" width="720" cellpadding="0" cellspacing="0" class="header-top">
									<tr>
									<td>
								
							<table border="0" align="left" width="330" cellpadding="0" cellspacing="0" class="header-mid" >
								<tr>
									<td style="color:#ec3003; font-size: 1.4em; font-family: Trajan Pro;   letter-spacing: 2px;" class="text-small">
										Our <span style="color:#36990a;">Models</span>
									</td>
								</tr>
								<tr><td height="20" class="high-4"></td></tr>
								<tr>
									<td style="color: #777;font-size: 0.9em;font-family: Verdana; font-weight: normal;line-height: 2.2em;" class="para">
								We have a range of ecofriendly and cost effective models.We are Icat certified and have 7 state approvals.
								A huge number of dealers and salesman across the country are making best efforts to provide you the right service.
								
								</td>
								</tr>
								<tr><td height="25"></td></tr>
															</table>
						
										<table border="0" align="right" width="330" cellpadding="0" cellspacing="0" align="center" class="header-mid header-mid1">
									<tr>
									<td >
										<img src="http://www.gkrickshaw.com/images/pi.jpg" alt="" width="100%" height="270" >
									</td>
									</tr>
									
							</table>
							</td>
							</tr>
							</table>
							
							
							</td>
								</tr>	

						<tr bgcolor="#ffffff"><td height="50" class="high-top">
							
						</td></tr>
						<tr bgcolor="#ffffff">
						
						<td >
							
								<table border="0" align="center" width="720" cellpadding="0" cellspacing="0" class="header-top">
									<tr>
									<td>
									<table border="0" align="left" width="330" cellpadding="0" cellspacing="0" align="center" class="header-mid">
									<tr>
									<td >
										<img src="http://www.gkrickshaw.com/images/pi1.jpg" alt="" width="100%" height="270" >
									</td>
									</tr>
												
							</table>
							<table border="0" align="right" width="330" cellpadding="0" cellspacing="0" class="header-mid header-mid2">
								<tr>
									<td style="color:#ec3003; font-size: 1.4em; font-family: Trajan Pro;   letter-spacing: 2px;" class="text-small">
										ICAT<span style="color:#36990a;"> /State approvals</span>
									</td>
								</tr>
								<tr><td height="20"></td></tr>
								<tr>
									<td style="color: #777;font-size: 0.95em;font-family: Verdana; font-weight: normal;line-height: 2.2em;" class="para">
								We provide the widest range of E Rickshaw with ICAT certification. We have 7 state approvals covering states 
								like West Bengal,Bihar,Jharkhand,Odisha, Delhi(Union Teritory),Haryana, Uttar Pradesh.  
								</td>
								</tr>
								<tr><td height="25"></td></tr>
								</table>
							</td>
							</tr>
							</table>
							</td>
								</tr>	
							<tr bgcolor="#ffffff">
								<td height="50" class="high-top1">
								</td>
								</tr>
					<!--//about-->
					<!--services-->
					<!--content-middle-->
					<tr bgcolor="#fafafa">
						<td >
							<table border="0" width="720" align="center"  cellpadding="0" cellspacing="0" class="header-top">
								<tr>
								<td height="50" class="high-top1">
								</td>
								</tr>
								<tr>
								<td>
								<table border="0" align="left" width="330" cellpadding="0" cellspacing="0" class="header-mid">
								
								<tr>
									<td style="text-align:right; color:#ec3003; font-size: 3em; font-family: Trajan Pro;   letter-spacing: 2px;" class="text-high">
										We are not big <span style="color:#36990a;"> but your support will make us the </span>Best
									</td>
								</tr>
							</table>
								<table border="0" align="right" width="330" cellpadding="0" cellspacing="0" class="header-mid">
								
								<tr>
									<td style="color: #777;font-size: 0.9em;font-family: Verdana; font-weight: normal;line-height: 2.2em;" class="para">
							 	Our Motto and determination helps us to grow.We need your help and support to make the work a pollution  free world
								Thanks for the support and help.
								</td>
								</tr>
							</table>
								</td>
								</tr>
							<tr>
								<td height="50" class="high-top">
								</td>
								</tr>
							</table>
							<!--content-middle-->
					<!--content-bottom-->
					<tr bgcolor="#fff"><td height="80" class="high-bottom">
						<center>	<h2 style="color:#36990a"><b>Feel Free To Call</b></h2></center>
						</td></tr>
					<tr >
						<td background="http://www.gkrickshaw.com/images/pc.jpg" style="background-size:cover;background-position:center;">
							<table border="0" width="550" align="center"  cellpadding="0" cellspacing="0" class="content-bottom" >
								<tr>
									<td align="center">
										<img src="'.$imagepath.'" alt=""  height="80" style="border-radius:50%;" >
									</td>
									</tr>
									<tr><td height="10"></td></tr>
								<tr>
									<td style="text-align:center; color:#ec3003; font-size: 1.4em; font-family: Trajan Pro;   letter-spacing: 2px;">
										<span style="color:#36990a;">'.$name.'</span>
										<br>
										'.$desig.'
										<br>
										Email:'.$email2.'<br>
										Phno:'.$phno.'
									</td>
								</tr>
								<tr><td height="10"></td></tr>
								<tr>
									<td style="text-align:center;color: #777;font-size: 0.95em;font-family: Verdana; font-weight: normal;line-height: 2.2em;" class="para">
We are really grateful to all who are participating with us in this green ride.								
								</td>
								</tr>
							<tr>
								<td height="300" class="high-bottom1">
								</td>
								</tr>
							</table>
							
						</td>
					</tr>
					<!--//services-->
								<!--footer strat here-->
								<tr bgcolor="#ffffff">
								<td>
								 <table width="720" align="center" border="0" cellpadding="0" cellspacing="0" class="header-top">
								  	
								  		   
								  		   	 <tr> 
								  		  	  	<td   height="50" class="high-2"> </td>
								  		  	  </tr>
								  		  	  <tr>
								  		  	  	<td style="font-size:2em; color:#ec3003; font-family:Trajan Pro; text-align:center;">
								  		  	  		GK<span style="color:#36990a;">Rickshaw</span>
								  		  	  	</td>
								  		  	  </tr>
								  		  	  <tr>
								  		  	  	<td  height="10"> </td>
								  		  	  </tr>
								  		  	  <tr>
								  		  	  	<td style="font-size:0.95em; color:#777; font-family:Verdana; line-height:2.5em; text-align: center;" class="para">
								  		  	  	    <a href="#" style=";font-size: 1em; font-weight: 800; color:#ec3003;">
								  		  	     </td>
								  		  	  </tr>
								  		  	  <tr> 
								  		  	  	<td class="ftr-email" height="15"> </td>
								  		  	  </tr>
								  		  	  <tr>
								  		  	  	<td style="text-align:center; font-size: 1em; color: #777; font-family: Verdana;">Email: <a href="#" style="text-decoration:none; color:#36990a; font-weight: 800;">sales@gkrickshow.com</a></td>
								  		  	  </tr>
											  <td style="text-align:center; font-size: 1em; color: #777; font-family: Verdana;">Call Us: <a href="#" style="text-decoration:none; color:#36990a; font-weight: 800;">033-64517771</a></td>
											  
								  		  	  <tr> 
								  		  	  	<td class="footer-height" height="30"> </td>
								  		  	  </tr>
											  <tr>
								  					<td style="text-align:center; color:#777;font-family:Verdana; font-size:1em; line-height:1.8em;" class="para">
								  						© 2016 GK Rickshaw Pvt. Ltd. All rights reserved
								  					</td>
								  				</tr>
												<tr> 
								  		<td   height="50" class="high-2"> </td>
								  	</tr>
								  		  </table>
								  		</td>
								  	</tr>
									 
								  </table>
								  </td>
								  </tr>
				<!--//main-content-->
			
		<tr><td height="30"></td></tr>
	</table>
</body>
</html>';
	$name=$this->session->userdata('uname');
	$sub="GK RICKSHAW PVT LTD. COMPANY BROCHURE";
	echo send_mail1($sub,$email,$msg,$name,$card);
	}
?>