<?php include("connection.php"); ?>
<?php $this->load->view('headercss.php'); ?>

<?php $this->load->view('topnav.php'); ?>
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/jquerymodal/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/starcss/css/style.css">
  
  
<style>
		table,tr,th,td{
			border:1px solid #0aa89e;
			text-align: center;
		}
	   thead{
			background-color:#0aa89e;
			color: white;
			text-align:center;
			width:44px;
		}
		tr{
			text-align: center;
		}
		
	</style>
	<style>
	h3 {
font-family: Verdana;
color: #2358A0;
}
h2 {
font-family: Verdana;
color: #2D9C1C;
}
	</style>


		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<?php $this->load->view('navmenu.php'); ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Enquiry</a>
							</li>
							<li class="active">View</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						
			<div class="row">
						<div class="tab-pane active" id="first1">
								<table id="example" class="table  table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
            <tr>
            	<th>Sl No.</th>
                <th>Name</th>
                <th>Contact Info</th>
                <th>Address</th>
	        <th>Location Info</th>
                <th>REMARK 1</th>
                <th>Next Followup</th>
	        <th>Rating</th>
	        <th>ACTION</th>
            </tr>
        </thead>
        
        <tbody>
		
			<?php  if(isset($enq) && !empty($enq)){  $i=1; ?>
			<?php foreach($enq as $row){
				
				$dat1=$row->dat;
				$dat2=$row->date2;
				$dat3=$row->date3;
				$remark3=$row->remark3;
				
				
			 ?>
            <tr>
               <th><?php echo $i ?> </th>
                <th>Name :<?php echo $row->name; ?><br><i>(Company:<?php echo $row->compname ; ?>)</i>
                	<input type="hidden" id="cust_<?php echo $i; ?>" value="<?php echo $row->id; ?>" />
                </th>
                <th><i>(<?php echo $row->phone; ?>)<br>(<?php echo $eml=$row->email; ?>)</i></th>
                <th><?php echo $row->address; ?></th>
				<th>State :<?php echo $row->state; ?><br><i>(Dist :<?php echo $row->dist; ?>)<br>(Location :<?php echo $row->location; ?>)</i></th>
                <th><div contenteditable id="reamrk_<?php echo $i; ?>"><?php echo $row->remark1; ?></div></th>
                <th>
                	
                	<input type="text" class="datepick" value="<?php if(isset($row->dat))echo $row->dat; ?>" id="datepick_<?php echo $i; ?>"/>
                </th>
				<th>
					<div class="rate_row" id="rating_<?php echo $i; ?>"></div>
                	<br>
                	<?php if(isset($row->rating)){ ?>
                	<?php echo $row->rating; ?><i class="fa fa-star" aria-hidden="true"></i>
                	<?php } ?>
			</th>
				<td>
					<button type="button" id="savefolo_<?php echo $i; ?>" class="btn btn-link" onclick="save_followup(this.id);" ><i class="fa fa-save" aria-hidden="true"></i></button>&nbsp;&nbsp;
					
					<a href="<?php echo base_url();?>enquery_controller/edit/<?php echo $row->id;  ?>" class="tooltip-success">
							 <!--<button type="button" class="btn btn-sm btn-success">--><i class="ace-icon fa fa-pencil">
							</i> </a>&nbsp;&nbsp;								
					<a href="<?php echo base_url(); ?>enquery_controller/deleteenq/<?php echo $row->id; ?>"onclick="return confirm('Are you sure to delete?')" class="tooltip-success">
					<!--<button type="button"  class="btn btn-sm btn-danger">--><i class="ace-icon fa fa-times bigger-125">
					<!--<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-default">--></i></a>&nbsp;&nbsp;
					
					
					<!--<a href="<?php echo base_url();?>enquery_controller/follow/<?php echo $row->id;  ?>" class="tooltip-success"><i class="ace-icon fa fa-check bigger-125" data-toggle="modal" data-target="#myModal">--
					<button type="button" onclick="return confirm('Are you sure to delete?')" class="btn btn-default"></i></a>-->
					<button type="button" class="btn btn-link" href="#modal-form_<?php echo $i; ?>" data-toggle="modal"><i class="fa fa-envelope" aria-hidden="true"></i></button>
					&nbsp;&nbsp;
					 <div class="message"></div>
					<div id="modal-form_<?php echo $i; ?>" class="modal" tabindex="-1">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="blue bigger">Please Choose Category</h4>
											</div>

											<div class="modal-body">
												<div class="row">
													<div class="col-xs-12 col-sm-12">
														<form class="form-horizontal" role="form" action="<?php echo base_url(); ?>Enquery_controller/sendmailfromenquery" method="post" >
														<!--<div class="form-group">
															
					
															<div class="col-md-9" style="text-align: left;">
																&nbsp;&nbsp;<input type="checkbox"  id="form-field-1" name="card[]" value="1"  /> E-CARD FOR <?php  echo strtoupper($this->session->userdata('uname')); ?>
															</div>
															<div class="col-md-3">
																
															</div>
														</div>-->
														<div class="form-group">
															<div class="col-md-9" style="text-align: left;">	
																&nbsp;&nbsp;<input type="checkbox" id="form-field-1" name="card[]" value="3"  /> MODEL DETAILS<input type="text" style="display:none;" id="copy_me_<?php echo $i; ?>_1" class="copy-me" value="<?php echo base_url(); ?>emailtemplate/dealership/avalon_ebrochure.pdf">
			                                                       &nbsp;&nbsp;<button type="button" id="copy_btn_<?php echo $i  ?>_1" class="btn btn-link" onclick="copyToClipboard(this.id)" style="float:right;" ><i class="fa fa-clipboard" aria-hidden="true"></i></button>
			   
															</div>
															<div class="col-md-3">
																
															</div>
														</div>
														<div class="form-group">
															<div class="col-md-9" style="text-align: left;">
																&nbsp;&nbsp;<input type="checkbox" id="form-field-1" name="card[]" value="4"  /> DISTRIBUTORSHIP FORM
																<input type="text" style="display:none;" id="copy_me_<?php echo $i; ?>_2" class="copy-me" value="<?php echo base_url(); ?>emailtemplate/dealership/application_dealership_form.pdf">
			                                                       &nbsp;&nbsp;<button type="button" id="copy_btn_<?php echo $i  ?>_2" class="btn btn-link" onclick="copyToClipboard(this.id)" style="float:right;" ><i class="fa fa-clipboard" aria-hidden="true"></i></button>
			   
															</div>
															<div class="col-md-3">
																
															</div>
														</div>
														<div class="form-group">
															<div class="col-md-9" style="text-align: left;">
																&nbsp;&nbsp;<input type="checkbox" id="form-field-1" name="card[]" value="5"  /> DISTRIBUTORSHIP RULES & REGULATION
																<input type="text" style="display:none;" id="copy_me_<?php echo $i; ?>_3" class="copy-me" value="<?php echo base_url(); ?>emailtemplate/dealership/Rules & Regulations for the Agents.pdf">
			                                                       &nbsp;&nbsp;<button type="button" id="copy_btn_<?php echo $i  ?>_3" class="btn btn-link" onclick="copyToClipboard(this.id)" style="float:right;" ><i class="fa fa-clipboard" aria-hidden="true"></i></button>
			   
															</div>
															<div class="col-md-3">
																
															</div>
														</div>
														<div class="form-group">
															<div class="col-md-9" style="text-align: left;">
																&nbsp;&nbsp;<input type="checkbox" id="form-field-1" name="card[]" value="6"  /> SPAREPARTS  PRICE LIST
																<input type="text" style="display:none;" id="copy_me_<?php echo $i; ?>_4" class="copy-me" value="<?php echo base_url(); ?>emailtemplate/dealership/catagoryPICLISTPAQ.pdf">
			                                                       &nbsp;&nbsp;<button type="button" id="copy_btn_<?php echo $i  ?>_4" class="btn btn-link" onclick="copyToClipboard(this.id)" style="float:right;" ><i class="fa fa-clipboard" aria-hidden="true"></i></button>
			   
															</div>
															<div class="col-md-3">
																
															</div>
														</div>
														<div class="form-group">
															<label class="col-sm-3 control-label no-padding-right" for="form-field-1" >EMAIL</label>
					
															<div class="col-sm-9">
																<input type="text" id="form-field-1" placeholder="Enter Email "  name="email" class="col-xs-10 col-sm-5" required="required" value="<?php if(isset($eml)&& !empty($eml)){ echo $eml; } ?>" />
															</div>
														</div>
														
														
													</div>

													
												</div>
											</div>

											<div class="modal-footer">
												<button class="btn btn-sm" data-dismiss="modal" btype="button">
													<i class="ace-icon fa fa-times"></i>
													Cancel
												</button>

												<button class="btn btn-sm btn-primary" type="submit">
													<i class="ace-icon fa fa-check"></i>
													Save
												</button>
											</div>
											</form>
										</div>
									</div>
								</div><!-- PAGE CONTENT ENDS -->									
				</td>
            </tr>
			
			
            <?php $i++; } } ?>
        </tbody>
    </table>
	
	 
		
				</div>
				</div>
					</div>
										

        <?php $this->load->view('footerjs.php'); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquerymodal/js/jquery.modal.js"></script>

		<script>
  $(function(){
    $("#example").dataTable();
  })
  </script> 
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

 <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
 <script src="<?php echo base_url(); ?>assets/starcss/js/starwarsjs.js"></script> 
 <script>
   $( document ).ready(function() {
   	   $(".datepick").datepicker();
            $('.rate_row').starwarsjs({
                stars : 5,
                count : 1
                
            });
			
			

        });
  </script>
     
		<!-- inline scripts related to this page -->
		
		<script>
		 //$(".message").delay(5000).fadeOut();
		function save_followup(id)
		{
			var idsplit=id.split("_");
			var rating=$("#rating_"+idsplit[1]+" input[type='hidden']").val();
			var remark=$("#reamrk_"+idsplit[1]).text();
			var dat=$("#datepick_"+idsplit[1]).val();
			var id=$("#cust_"+idsplit[1]).val();
			//alert(id);
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Enquery_controller/savefolloeups",
  			data :{'rating':rating,'remark':remark,'dat':dat,'id':id},
  			success : function(data){
  				 				 
  				alert("Saving Succesfull");
  				//$(".prts").html(data);
  				//$(".message").text("Savingg Succesfully");
  			  
              }  
           });
			//alert(rating);
		}
function getcolorquantity(id)
{
	var idsplit=id.split("_");
	var divmodalid=idsplit[1];
	var tot=0;var gettot;
	var colorcdno=$("#colorcode").val();
	for( var n=1;n<colorcdno;n++)
	{
		
		gettot=$("#colorqty_"+divmodalid+"_"+n).val();
		if(gettot=="")
		{
			gettot=0;
			
		}
		tot=tot+parseInt(gettot);
		//alert(tot);
	}
	var existtot=$("#productqty_"+divmodalid).val();
	if(existtot==""){existtot=0;}
	var resttot=parseInt(existtot)-parseInt(tot);
	if(resttot==0){resttot="";}
	if(resttot<0)
	{
		alert('please type right number of quantity');
		
	}else{
		
		$("#productqtycolor_"+divmodalid).val(resttot);
	}
	
	
}
function getallspareparts()
{
	//alert('hello');
	var modelname=$("#modelname").val();
	//alert(modelname);
	var idsplit=modelname.split("_");
	var modcode=idsplit[0];
	var modnam=idsplit[1];
	//alert(modnam);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getallspare_parts_sort_by_modelname",
  			data :{'modcode':modcode,'modnam':modnam},
  			success : function(data){
  				 				 
  				//alert(data);
  				$(".prts").html(data);
  			  
              }  
           });
}
function getmodelqty(id)
{
	var idsplit=id.split("_");
	var idx=idsplit[1];
	var noqty=$("#productqty_"+idsplit[1]).val();
	var partssp=parseInt($("#partssp_"+idsplit[1]).val());
	for(var c=1;c<partssp;c++)
	{
		var ptaqty=$("#ptsap_"+idx+"_"+c).val();
		var hidpty=$("#ptsaphidden_"+idx+"_"+c).val();
		 if(noqty=="")
		 {
		 	$("#ptsap_"+idx+"_"+c).val(hidpty);
		 }else
		 {
		 	var noqty1=parseInt(noqty)*parseInt(ptaqty);
		    $("#ptsap_"+idx+"_"+c).val(noqty1);
		 }
		
		//alert(ptaqty);
	}
	//alert(idx);
	//alert(noqty);
	
}
function getpartsdetails(id,divid)
{
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var ds=divid;
	var notr=$("#notr").val();
	//alert(notr);
	//var notr1=notr-1;
	var colorcode23=parseInt($("#colorcode").val());
	var req="";
	var valid=0;
	for(var c=1;c<notr;c++)
	{
		var prtsqty=$("#ptsap_"+ds+"_"+c).val();
		//alert(prtsqty);
		
		if(($("#req_"+ds+"_"+c).prop('checked') == true) && ($("#specification_"+ds+"_"+c).val()!="9999")){
			req +=$("#req_"+ds+"_"+c).val()+"@"+prtsqty+"||";
    
         }else
         { 
         	if($("#req_"+ds+"_"+c).prop('checked') == true){
         		valid++;
         	}else
         	{
         		
         	}
         	
         }
		
	}
	//alert(valid);
	
	var color="";
	for(var d=1;d<colorcode23;d++)
	{
		gettot=$("#colorqty_"+ds+"_"+d).val();
		if(gettot=="")
		{
			
		}else
		{
			color +=$("#colorqty_"+ds+"_"+d).val()+"->"+d+"#";
		}
	}
	// alert(req);
	var modelid=$("#modid_"+idsplit[1]).val();
	var modelname=$("#modname_"+idsplit[1]).val();
	var prqty=$("#productqty_"+idsplit[1]).val();
	//$('.inputr').append("<input type='text'");
  			    
     //$('.inputr').append("<input type='text' name='modelname_"+tr2+"' value='"+modelname+"'/>");
    // $('.inputr').append("<input type='text' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prqty+"' />");
    // $('.inputr').append("<input type='text'/>");
	//alert(modelid);
	//alert(modelname);;
	//alert(color);
	
	var rowCount = $('#example tr').length;
	var tr=rowCount-1;
	var tr2=tr+1;
	$("#tbalerow").val(tr2);
	//var rew=$("#product_spec").val(req);
	//alert(req);
	if(valid<1){
	$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td><input type="hidden" name="productspec" value="'+req+'" id="productspec_'+tr2+'"  /><input type="hidden" name="matid_'+tr2+'" value=""/></td><td><input type="hidden" name="" value=""/></td><td>'+modelid+'<input type="hidden" value="'+modelid+'" id="modelid_'+tr2+'"/></td><td>'+modelname+'<input type="hidden" value="'+modelname+'" id="modelname_'+tr2+'"/></td><td><input style="width:50px;" required type="text" name="matqty_'+tr2+'" value="'+prqty+'" /> </td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
	$('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='modelid1_"+tr2+"' value='"+modelid+"'/>");
  			    
  $('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
   $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' value='"+prqty+"' />");
   $('.inputr').append("<input type='hidden' name='specification_"+tr2+"' value='"+req+"' />");
   $('.inputr').append("<input type='hidden' name='colorspe_"+tr2+"' value='"+color+"' />");
   
  }else
  {
  	alert('Please Select All Specification ');
  }
   
   	$("#submit").show();
   
   
	// $('.inputr').append("<input type='text'/>");
	//$('.inputr').append("<input type='text'");
}
function anchor_test(id)
{
	//var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var id1=id;
	var matid1="matid";
	var specid=$("#speci_"+id1).val();
	var prtsqt=parseInt($("#noprts_"+id1).val());
	var model=$("#modelname").val();
	if(model==""){
		 //alert("Please Select Model Name");
		 modal({
				type: 'warning',
				title: 'Message!',
				text: '<h4><b>Please Select Model Name</b></h4>',
			});
			
			
	}else{
		//alert(specid);
	var rowCount = $('#example tr').length;
	var modelsplit=model.split("_");
	var modelid=modelsplit[0];
	var modelname=modelsplit[1];
	var tr=rowCount-1;
	var tr2=tr+1;
	$("#tbalerow").val(tr2);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getdetails_purchase",
  			data :{'id':id1,'specid':specid},
  			success : function(data){
  				//alert('hello');
  				var json=JSON.parse(data);
  				
  				var matid=json.matid;
  				//alert(matid);
  				var unit=parseInt(json.unit);
  				var matname=json.matname;
  				var specif=json.specif;
  				var prtd=prtsqt*unit;
  				//$("#matid").val(matid);
  				$('#example tr:last').after('<tr class="getrow_'+tr2+'"><td>'+ tr2 +'</td><td>'+ matid+'<input type="hidden" name="matid_'+tr2+'" value="'+matid+'"/></td><td>'+ matname +'<br><i>('+specif+')</i><input type="hidden" name="matname_'+tr2+'" value="'+matname+'"/></td><td>'+modelid+'<input type="hidden" value="'+modelid+'" id="modelid_'+tr2+'"/></td><td>'+modelname+'<input type="hidden" value="'+modelname+'" id="modelname_'+tr2+'"/></td><td><input style="width:50px;text-align:center;" required type="text" value="'+prtd+'"  id="matqty12_'+tr2+'" name="matqty_'+tr2+'"  onkeyup="getqtyval(this.id)" /><br><i>('+unit+'X'+prtsqt+')</i> </td><td><button type="button" id="delete_'+tr2+'" class="btn ink-reaction btn-floating-action btn-sm btn-primary" onclick="deletetrrow(this.id)"><i class="fa fa-minus"></i></button></td></tr>');
  				 
  			    $('.inputr').append("<input type='hidden' id='matidval_"+tr2+"' name='matid_"+tr2+"' value='"+matid+"'/>");
  			    
  			    $('.inputr').append("<input type='hidden' name='modelname_"+tr2+"' value='"+modelname+"'/>");
  			     $('.inputr').append("<input type='hidden' name='prqty1_"+tr2+"' id='prqty1_"+tr2+"' value='"+prtd+"'  />");
  			     $('.inputr').append("<input type='hidden' name='prtspecif_"+tr2+"' id='prtspecif_"+tr2+"' value='"+specid+"'  />");
  			     
              }  
           });
          
     //alert(matid);
     
   	   $("#submit").show();
   
	
	}
	//alert('hello');
	//alert(id);
	//$('#example tr:last').after('<tr><td>'+ tr2 +'</td><td>'+ matid1+'</td><td>'+ matname1 +'</td><td><input type="text" name="matqty" /> </td><td><button>Delete</button></td></tr>');
}
 function deletetrrow(id)
{
	var idsplit=id.split("_");
	//var vendors=$("#vendor").val();
	var rowCount = $('#example tr').length;
	var result=confirm("Want to delete?");
	//alert(result);
	if(result==true)
	{
		//alert(this);
		//$(this).closest('tr').remove();
		$(".getrow_"+idsplit[1]).css("background-color","#a94442");

		$(".getrow_"+idsplit[1]).fadeOut(400, function(){
			$(".getrow_"+idsplit[1]).remove();
		});
	}
	rowCount=rowCount-1;
	if( rowCount<2)
	{
		$("#submit").hide();
	}
	
	
	
	// alert('hello');
}
function getcstdtls()
{
	//alert('hello');
	var custmail=$("#custid").val();
	alert(custmail);
	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>Paymentcontroller/getcustmer",
  			data :{'custmail':custmail},
  			success : function(data){
  				 				 
  				//alert(data);
  				
  				var json=JSON.parse(data);
  				
  				var cmpnme=json.comp;
  				var name=json.name;
  				var img=json.image;
  				$("#comp").val(cmpnme);
  				$("#custname").val(name);
  				$("#img").html('<img id="blah" src="<?php echo base_url(); ?>uploads/clientpics/'+img+'" alt="your image" width="150" height="150" name="image1"/>');
  				
  				//$(".prts").html(data);
  			  
              }  
       });
}
function addspecification(id,spd)
{
	var idsplit=id.split("_");
	var divis=spd;
	var specification=$("#specification_"+divis+"_"+idsplit[2]).val();
	//alert(specification);
	if(specification=="0")
	{
		specification=9999;
	}
	var req=$("#req_"+divis+"_"+idsplit[2]).val();
	var chr=req.indexOf("9999");
	if(chr>-1)
	{
		req=req.slice(0,-5);
	}else
	{
		req=req.slice(0,-2);
	}
	//alert(req);
	req += '_'+specification;

//str += ' ' + 'and some more blah';
$("#req_"+divis+"_"+idsplit[2]).val(req);
	//alert(req);
}

		</script>
		
<script>

       
		function getratings()
		{
				var get_rate=$(".get_rate").val();
				alert(get_rate);
		
		}
function copyToClipboard(id) {
	var idsplit=id.split("_");
	alert(idsplit);
	var idno=idsplit[3];
	
  var success   = true,
      range     = document.createRange(),
      selection;

  // For IE.
  if (window.clipboardData) {
    window.clipboardData.setData("Text", $("#copy_me_"+idsplit[2]+"_"+idsplit[3]).val());        
  } else {
    // Create a temporary element off screen.
    var tmpElem = $('<div>');
    tmpElem.css({
      position: "absolute",
      left:     "-1000px",
      top:      "-1000px",
    });
    // Add the input value to the temp element.
    tmpElem.text($("#copy_me_"+idsplit[2]+"_"+idsplit[3]).val());
    $("body").append(tmpElem);
    // Select temp element.
    range.selectNodeContents(tmpElem.get(0));
    selection = window.getSelection ();
    selection.removeAllRanges ();
    selection.addRange (range);
    // Lets copy.
    try { 
      success = document.execCommand ("copy", false, null);
    }
    catch (e) {
      copyToClipboardFF($("#copy_me_"+idsplit[2]+"_"+idsplit[3]).val());
    }
    if (success) {
      alert ("The text is on the clipboard, try to paste it!");
      //alert($("#copy_me_"+idsplit[2]).val());
      // remove temp element.
      tmpElem.remove();
    }
  }
}

    </script>
	</body>
</html>
