<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Enquiry_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getstate()
	{
		$query=$this->db->query("select * from state");
		return $query->result();
	}
	public function saveenq($data_array)
	{
		$this->db->insert("enquiry",$data_array);
	}
	public function fetchenq($user)
	{
		$query=$this->db->query("select * from enquiry where user='".trim($user)."' order by id desc");
		return $query->result();
	}
	public function fetchenq1($id)
	{
		$query=$this->db->query("select * from enquiry where id=".trim($id)."");
		return $query->result();
	}
	public function updateenq($data_array,$id) 
	{
		$this->db->where('id', $id);
		$this->db->update('enquiry', $data_array);
	}
	public function deleteenq($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('enquiry');
	}
	public function updatefollow($data_array,$id)
	{
		$this->db->where('id', $id);
		$this->db->update('enquiry',$data_array);
	}
	public function getsaverating($data_array,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("enquiry",$data_array);
	}
}
