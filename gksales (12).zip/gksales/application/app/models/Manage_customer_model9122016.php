<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_customer_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getcountry()
	{
		$query=$this->db->query("select * from countrylist order by name asc");
		return $query->result();
	}
	public function getstatename($country)
	{
		$query=$this->db->query("select * from state order by statename asc");
		return $query->result();
	}
	public function getlastid()
	{
		$query=$this->db->query("select max(id) as id from clientmaster");
		$res=$query->result();
		foreach($res as $row)
		{
			$id=$row->id;
		}
		return $id;
	}
	public function saveclentdetails($data_array)
	{
		$this->db->insert('clientmaster',$data_array);
	}
	public function getallcustomer($uid)
	{
		$query=$this->db->query("select * from clientmaster where sid='".trim($uid)."'");
		return $query->result();
	}
	
	
	
}
