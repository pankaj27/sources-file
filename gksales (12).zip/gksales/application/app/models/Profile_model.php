<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function fetchterget()
	{
		$query=$this->db->query("select * from set_terget");
		return $query->result();
	}
	public function delete_trgt($id1)
	{
		$this->db->where('id', $id1);
		$this->db->delete('set_terget');
	}
	public function getsalesmandetails($uid)
	{
		$query=$this->db->query("select * from salesman where id='".trim($uid)."'");
		return $query->result();
	}
	public function getcheckexist($dte,$uid,$yrcode)
	{
		$query=$this->db->query("select * from tour_plan where userid='".trim($uid)."' and dte='".trim($dte)."' and yrcode='".trim($yrcode)."'");
		return $query->result();
	}
	public function updatetourplan($data_array,$dte)
	{
		$this->db->where("dte",$dte);
		$this->db->update("tour_plan",$data_array);
	}
	public function savetoupplan($data_array)
	{
		$this->db->insert("tour_plan",$data_array);
	}
	public function getplandetails($d2,$uid)
	{
		$query=$this->db->query("select * from tour_plan where dte='".trim($d2)."' and userid='".$uid."' ");
		return $query->result();
	}
	public function getallplantour($dt)
	{
		$query=$this->db->query("SELECT * FROM `daybydayplan` where dte < '".trim($dt)."' order by dte asc");
		return $query->result();
	}
	public function checkdaybydayexist($dte,$uid,$fromloc,$toloc,$yrcode)
	{
		$query=$this->db->query("select * from daybydayplan where userid='".trim($uid)."' and dte='".trim($dte)."' and formloc='".trim($fromloc)."' and toloca='".trim($toloc)."' and yrcode='".trim($yrcode)."'");
		return $query->result();
	}
	public function updatedaybydayplan($data_array,$dte)
	{
		$this->db->where("dte",$dte);
		$this->db->update("daybydayplan",$data_array);
	}
	public function savedaybydayplan($data_array)
	{
		$this->db->insert("daybydayplan",$data_array);
	}
	
}