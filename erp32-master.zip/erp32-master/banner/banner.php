<?php


// -------------------------------------------
//           left banner content
// -------------------------------------------

$banner = '<br />
		 <a href="#">
			<img border="0" src="../banner/ad.gif" />
		 </a>';


// -------------------------------------------
//           homepage content
// -------------------------------------------

$homepage = '<img border="0" src="../banner/home.jpg" />';

