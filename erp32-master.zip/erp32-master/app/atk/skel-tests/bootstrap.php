<?php
$GLOBALS['config_atkroot'] = "../back-end/"; // change this to your ATK application root!
$GLOBALS['config_testroot'] = "./";

require_once $GLOBALS['config_atkroot'].'atk.inc';
require_once $GLOBALS['config_atkroot'].'atk/test/bootstrap.inc';