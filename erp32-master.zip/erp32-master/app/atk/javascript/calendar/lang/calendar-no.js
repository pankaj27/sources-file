// ** I18N
Calendar._DN = new Array
("S�ndag",
 "Mandag",
 "Tirsdag",
 "Onsdag",
 "Torsdag",
 "Fredag",
 "L�rdag",
 "S�ndag");
Calendar._MN = new Array
("Januar",
 "Februar",
 "Mars",
 "April",
 "Mai",
 "Juni",
 "Juli",
 "August",
 "September",
 "Oktober",
 "November",
 "Desember");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Endre f�rste dag i uken";
Calendar._TT["PREV_YEAR"] = "Forrige �r (hold for meny)";
Calendar._TT["PREV_MONTH"] = "Forrige m�ned (hold for meny)";
Calendar._TT["GO_TODAY"] = "G� til idag";
Calendar._TT["NEXT_MONTH"] = "Neste m�ned (hold for meny)";
Calendar._TT["NEXT_YEAR"] = "Neste �r (hold for meny)";
Calendar._TT["SEL_DATE"] = "Velg dato";
Calendar._TT["DRAG_TO_MOVE"] = "Dra for � flytte";
Calendar._TT["PART_TODAY"] = " (idag)";
Calendar._TT["MON_FIRST"] = "Vis mandag f�rst";
Calendar._TT["SUN_FIRST"] = "Vis s�ndag f�rst";
Calendar._TT["CLOSE"] = "Lukk";
Calendar._TT["TODAY"] = "Idag";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "D, M d";

Calendar._TT["WK"] = "Uke";
